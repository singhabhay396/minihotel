<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Owner_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/***********************************************************************
	 ** Function name : selectAdminData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select admin data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectAdminData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('adm.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectDepartmentData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Department Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectDepartmentData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('admdep.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectSubadminData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Subadmin Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectSubadminData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('adm.*, admt.admin_metadata_value as admin_type');
		$this->db->from($tblName);
		$this->db->join("admin_metadata as admt", "adm.encrypt_id=admt.admin_id", "LEFT");
		$this->db->join("admin_metadata as admta", "adm.encrypt_id=admta.admin_id", "LEFT");
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : getAdminDepartment
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for get Admin Department
	 ** Date : 08 April 2022
	 ************************************************************************/
	function getAdminDepartment($departmentId = '')
	{
		$html			=	'<option value="">Select Department Name</option>';
		$this->db->select('encrypt_id,department_name');
		$this->db->from('admin_department');
		$this->db->order_by("department_name ASC");
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			$data	=	$query->result_array();
			foreach ($data as $info) :
				if ($info['encrypt_id'] == $departmentId) :  $select = 'selected="selected"';
				else : $select = '';
				endif;
				$html		.=	'<option value="' . $info['encrypt_id'] . '" ' . $select . '>' . $info['department_name'] . '</option>';
			endforeach;
		endif;

		return $html;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectHomePageHeadingData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Home Page Heading Data
	 ** Date : 25 April 2022
	 ************************************************************************/
	function selectHomePageHeadingData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('hph.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectSelletData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Seller Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectSelletData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '',$grField='')
	{
		$this->db->select('ven.*, vende.vendor_address, vende.vendor_nationality, vende.vendor_pan, vende.vendor_address_proof, vende.vendor_kyc_status');
		$this->db->from($tblName);

		$this->db->join("vendor_details as vende", "ven.vendor_id=vende.vendor_id", "LEFT");
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
       
	    if ($grField) :		$this->db->group_by($grField);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$this->db->where('ven.parent_id', sessionData('MHM_OWNER_ID'));
		$query = $this->db->get();
		//print_r($this->db->last_query());die;
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	function GetVendorList(){
		$this->db->select('*');
		$this->db->from('vendor');
		$this->db->where('parent_id', sessionData('MHM_OWNER_ID'));
		$query = $this->db->get();
		//print_r($this->db->last_query());die;
		return $query->result_array();
	}

	/***********************************************************************
	 ** Function name : selectHomeSliderData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Home Slider Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectHomeSliderData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('hslid.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectTestimonialData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Testimonial Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectTestimonialData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('teti.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectCmsPagesData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Cms Pages Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectCmsPagesData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('cms.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectSmallCmsData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Small Cms Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectSmallCmsData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('cms.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectMailTemplateData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Mail Template Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectMailTemplateData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('emlt.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectFeaturesData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Features Data
	 ** Date : 25 April 2022
	 ************************************************************************/
	function selectFeaturesData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('hph.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}

	/***********************************************************************
	 ** Function name : selectAdminMessageData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Features Data
	 ** Date : 07 May 2022
	 ************************************************************************/
	function selectAdminMessageData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('adm.*,v.vendor_business_name,a.admin_display_name');
		$this->db->from($tblName);
		$this->db->join('vendor as v', 'adm.hotel_manager_id = v.vendor_id', 'left');
		$this->db->join('admin as a', 'a.encrypt_id = adm.admin_id', 'left');
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}

	/***********************************************************************
	 ** Function name : getAllVendors
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for get All Vendors
	 ** Date : 09  MAY 2022
	 ************************************************************************/
	public function getAllVendors($assignVendorId = '')
	{
		$html = '';
		$this->db->select('vn.vendor_id,vn.vendor_name,vn.vendor_business_name');
		$this->db->from('vendor as vn');
		$this->db->where("vn.status = 'A'");
		$this->db->order_by("vn.vendor_name ASC");
		$query = $this->db->get();
		if ($query->num_rows() > 0) :
			$data = $query->result_array();
			foreach ($data as $info) :
				if ($info['vendor_id'] == $assignVendorId) : $select = 'selected="selected"';
				else : $select = '';
				endif;
				$html .= '<option value="' . $info['vendor_id'] . '" ' . $select . '>' . $info['vendor_business_name'] . '</option>';
			endforeach;
		endif;
		return $html;
	} // END OF FUNCTION


	 /***********************************************************************
     ** Function name : getAllOnboardHotels
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room Info
     ** Date : 21 May 2022
     ************************************************************************/
    public function getAllOnboardHotels()
    {
        $this->db->select('id');
        $this->db->from('vendor');
        $this->db->where('vendor_type = "Verified"');
        $this->db->where('status = "A"');
        $query = $this->db->get();
        return $query->num_rows();
    } // END OF FUNCTION

	    /***********************************************************************
     ** Function name : getVendorMessage
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room Info
     ** Date : 21 May 2022
     ************************************************************************/
    public function getVendorMessage($date='')
    {
        $this->db->select('id');
        $this->db->from('admin_individual_chat');
        $this->db->like('creation_date', $date);
        $this->db->where('admin_id', sessionData('MHM_ADMIN_ID'));
        $this->db->where('msg_flag_admin', 1);
        $query = $this->db->get();
        return $query->num_rows();

    } // END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectQuotesData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Quotes Data
	 ** Date : 09 JUNE 2022
	 ************************************************************************/
	function selectQuotesData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('q.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}
//
	/***********************************************************************
	 ** Function name : selectPricePackageData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Quotes Data
	 ** Date : 20 JUNE 2022
	 ************************************************************************/
	function selectPricePackageData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('p.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}
    /***********************************************************************
	 ** Function name : selectReservvationData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Reservvation Data
	 ** Date : 20 Nov 2022
	 ************************************************************************/
	function selectReservvationData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('cr.*,v.vendor_business_name');
		$this->db->from($tblName);
      	$this->db->join("vendor as v", "cr.hotel_manager_id=v.vendor_id", "LEFT");
        //$this->db->join("vendor_details as vd", "cr.hotel_manager_id=vd.vendor_id", "LEFT");
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}
  
  
   /***********************************************************************
	 ** Function name : selectReservvationData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Reservvation Data
	 ** Date : 20 Nov 2022
	 ************************************************************************/
 	public function getDataByParticularField($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select('cr.*,v.vendor_business_name,v.first_manager_contact_number,vd.vendor_address');
		$this->db->from($tableName);
      	$this->db->join("vendor as v", "cr.hotel_manager_id=v.vendor_id", "LEFT");
        $this->db->join("vendor_details as vd", "cr.hotel_manager_id=vd.vendor_id", "LEFT");
      	$this->db->where($fieldName, $fieldValue);
		$query = $this->db->get();
        //echo $this->db->last_query(); die;
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}
  
    /***********************************************************************
	 ** Function name : selectmessagehistory
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Reservvation Data
	 ** Date : 20 Nov 2022
	 ************************************************************************/
	function selectmessagehistory($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '',$editId='')
	{
		$this->db->select('cr.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
        $this->db->where('cr.hotel_manager_id',$editId);
		$query = $this->db->get();
        //echo $this->db->last_query(); die;
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}
  
  public function selectCustomerSummaryBookData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = ''){
  	$this->db->select('csb.*,rn.room_no,rn.room_no_use,rn.room_id');
    $this->db->from($tblName);
    $this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'left');
    if ($whereCon['where']) : $this->db->where($whereCon['where']);
    endif;
    if ($whereCon['like']) : $this->db->where($whereCon['like']);
    endif;
    if ($shortField) : $this->db->order_by($shortField);
    endif;
    if ($numPage) : $this->db->limit($numPage, $cnt);
    endif;
    $this->db->where("rn.room_no_use = 'Y'");
    $query = $this->db->get();
    // echo $this->db->last_query();
    // die;
    if ($action == 'data') :
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    elseif ($action == 'count') :
        return $query->num_rows();
    endif;
  }
  public function getTotalExtendStayRoomRent($customerId){
  	$this->db->select('SUM(cbb.bill_amount) as totalfoodbill');
		$this->db->from('custom_bill_book as cbb');
		$this->db->where('cbb.page_source', 'extend_stay');
		$this->db->where('cbb.customer_id', $customerId);
		$this->db->group_by('cbb.customer_id');
		$query	=	$this->db->get();
		//echo $this->db->last_query();die;
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
  }
  public function getAllGuestDataForExcelDownloadOwner($Search){
		$toDate = date('Y-m-d', strtotime($Search['toDate']));
		$fromDate = date('Y-m-d', strtotime($Search['fromDate']));
		$this->db->select('csb.summary_book_id,cbb.customer_id,csb.hotel_manager_id,csb.customer_name,csb.check_in_datetime,
        csb.check_out_datetime,csb.assign_room_number,csb.entry_number,csb.gst_number,csb.company_name,cbb.bill_generated_date,
        cbb.bill_number,csb.amount as roomrent,rn.room_no,SUM(cbb.bill_amount) as totalRoomRent,csb.room_rent_type as gstType,
		om.ots_name,cbb.page_source,csb.number_of_person,COUNT(cbb.customer_id) as totalDays');
		$this->db->from('custom_bill_book as cbb');
		$this->db->join('customer_summary_book as csb', 'csb.summary_book_id = cbb.customer_id', 'left');
		$this->db->join('ots_master as om', 'csb.ots_id = om.ots_id', 'left');
		$this->db->join('room_number as rn', 'csb.assign_room_number = rn.room_id', 'left');
		if ($fromDate != '1970-01-01' && $toDate != '1970-01-01') {
			$this->db->where("DATE(csb.check_out_datetime) BETWEEN '$fromDate' AND '$toDate'");
		}
		$this->db->where('csb.check_out_datetime !=', 'NULL');
		if ($Search['businessType'] == "B2B") { 
			$this->db->where('csb.gst_number !=', '');
		} elseif ($Search['businessType'] == "B2C") {
			$this->db->where('csb.gst_number' == '');
		}
		if($Search['reffer_mode']!='All'){
			$this->db->where('csb.reffer_mode', $Search['reffer_mode']);
			if($Search['reffer_mode']=='online'){
				if($Search['ots_id']!='All'){
					$this->db->where('csb.ots_id', $Search['ots_id']);
				}
			}else{
				if($Search['direct_mode']!='All'){
					$this->db->where('csb.ots_id', $Search['direct_mode']);
				}
			}
		}
		if($Search['choose_plan']!='All'){
			$this->db->where('csb.choose_plan', $Search['choose_plan']);
		}
		if($Search['bill_generated']!='All'){ 
			$this->db->where("csb.user_status",$Search['bill_generated']); 
		}
		$this->db->where('cbb.page_source', 'extend_stay');
		//$this->db->where_in('csb.hotel_manager_id', $Search['VendorArr']);
		$this->db->where('csb.hotel_manager_id', $Search['VendorArr']);
		$this->db->order_by("csb.check_out_datetime DESC");
		$this->db->group_by('cbb.customer_id');
		$query	=	$this->db->get();
		//echo $this->db->last_query();die;
		if ($query->num_rows() > 0) :
			return $query->result_array();
		else :
			return false;
		endif;
	}
  public function getAllGuestDataForExcelDownloadOwnerNew($Search){
		$toDate = date('Y-m-d', strtotime($Search['toDate']));
		$fromDate = date('Y-m-d', strtotime($Search['fromDate']));

		$this->db->select('csb.summary_book_id,csb.hotel_manager_id,csb.customer_name,csb.check_in_datetime,csb.check_out_datetime,csb.assign_room_number,csb.entry_number,csb.gst_number,csb.company_name,csb.amount as roomrent,csb.room_rent_type as gstType,csb.number_of_person');
		$this->db->from('customer_summary_book as csb');
		if ($fromDate != '1970-01-01' && $toDate != '1970-01-01') {
			$this->db->where("csb.check_out_datetime BETWEEN '$fromDate' AND '$toDate'");
		}
		$this->db->where('csb.check_out_datetime !=', 'NULL');
		if ($Search['businessType'] == "B2B") { 
			$this->db->where('csb.gst_number !=', '');
		} elseif ($Search['businessType'] == "B2C") {
			$this->db->where('csb.gst_number' == '');
		}
		if($Search['reffer_mode']!='All'){
			$this->db->where('csb.reffer_mode', $Search['reffer_mode']);
			if($Search['reffer_mode']=='online'){
				if($Search['ots_id']!='All'){
					$this->db->where('csb.ots_id', $Search['ots_id']);
				}
			}else{
				if($Search['direct_mode']!='All'){
					$this->db->where('csb.ots_id', $Search['direct_mode']);
				}
			}
		}
		if($Search['choose_plan']!='All'){
			$this->db->where('csb.choose_plan', $Search['choose_plan']);
		}
		if($Search['bill_generated']!='All'){ 
			$this->db->where("csb.user_status",$Search['bill_generated']); 
		}
		$this->db->where('csb.hotel_manager_id', $Search['VendorArr']);
		$this->db->order_by("csb.check_out_datetime DESC");
		$query	=	$this->db->get();
		//echo $this->db->last_query();die;
		if ($query->num_rows() > 0) :
			return $query->result_array();
		else :
			return false; 
		endif;
	}
	public function getAllGuestDataForExcelDownloadOwnerOld($Search){
		$toDate = date('Y-m-d', strtotime($Search['toDate']));
		$fromDate = date('Y-m-d', strtotime($Search['fromDate']));
		//$this->db->select('csb.summary_book_id,cbb.customer_id,csb.hotel_manager_id,csb.customer_name,csb.check_in_datetime,csb.check_out_datetime,csb.assign_room_number,csb.entry_number,csb.gst_number,csb.company_name,cbb.bill_generated_date,cbb.bill_number,csb.amount as roomrent,rn.room_no,SUM(cbb.bill_amount) as totalRoomRent,csb.room_rent_type as gstType,om.ots_name,cbb.page_source,csb.number_of_person,COUNT(cbb.customer_id) as totalDays');
		
		$this->db->select('csb.summary_book_id,cbb.customer_id,csb.hotel_manager_id,csb.customer_name,csb.check_in_datetime,csb.check_out_datetime,csb.assign_room_number,csb.entry_number,csb.gst_number,csb.company_name,cbb.bill_generated_date,cbb.bill_number,csb.amount as roomrent,SUM(cbb.bill_amount) as totalRoomRent,csb.room_rent_type as gstType,cbb.page_source,csb.number_of_person,COUNT(cbb.customer_id) as totalDays');
		$this->db->from('custom_bill_book as cbb');
		
		$this->db->join('customer_summary_book as csb', 'csb.summary_book_id = cbb.customer_id', 'left');
		//$this->db->join('ots_master as om', 'csb.ots_id = om.ots_id', 'left');
		//$this->db->join('room_number as rn', 'csb.assign_room_number = rn.room_id', 'left');
		if ($fromDate != '1970-01-01' && $toDate != '1970-01-01') {
			$this->db->where("csb.check_out_datetime BETWEEN '$fromDate' AND '$toDate'");
		}
		$this->db->where('csb.check_out_datetime !=', 'NULL');
		if ($Search['businessType'] == "B2B") { 
			$this->db->where('csb.gst_number !=', '');
		} elseif ($Search['businessType'] == "B2C") {
			$this->db->where('csb.gst_number' == '');
		}
		if($Search['reffer_mode']!='All'){
			$this->db->where('csb.reffer_mode', $Search['reffer_mode']);
			if($Search['reffer_mode']=='online'){
				if($Search['ots_id']!='All'){
					$this->db->where('csb.ots_id', $Search['ots_id']);
				}
			}else{
				if($Search['direct_mode']!='All'){
					$this->db->where('csb.ots_id', $Search['direct_mode']);
				}
			}
		}
		if($Search['choose_plan']!='All'){
			$this->db->where('csb.choose_plan', $Search['choose_plan']);
		}
		if($Search['bill_generated']!='All'){ 
			$this->db->where("csb.user_status",$Search['bill_generated']); 
		}
		$this->db->where('cbb.page_source', 'extend_stay');
		//$this->db->where_in('csb.hotel_manager_id', $Search['VendorArr']);
		$this->db->where('csb.hotel_manager_id', $Search['VendorArr']);
		$this->db->order_by("csb.check_out_datetime DESC");
		$this->db->group_by('cbb.customer_id');
		$query	=	$this->db->get();
		//echo $this->db->last_query();die;
		if ($query->num_rows() > 0) :
			return $query->result_array();
		else :
			return false;
		endif;
	}
	public function DownloadCheckOutDataOwner($vendorId,$fromDate = '',$toDate = ''){
		$whereCon['where'] = "csb.check_out_datetime != 'NULL' AND csb.status ='Y'";
    $this->db->select('csb.*,rn.room_no');
    $this->db->from('customer_summary_book as csb');
    $this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'LEFT');
    if ($whereCon['where']) : $this->db->where($whereCon['where']);endif;
    $this->db->where_in('csb.hotel_manager_id', $vendorId);
    if($fromDate!='' AND $toDate!=''){
      $FromDate = date('Y-m-d',strtotime($fromDate));
      $ToDate = date('Y-m-d',strtotime($toDate));
      $this->db->where("csb.check_out_datetime BETWEEN '$FromDate' AND '$ToDate'");
    }
    $this->db->order_by('csb.check_out_datetime DESC');
    $query = $this->db->get();
    //print_r($this->db->last_query());    
    if ($query->num_rows() > 0) :
      return $query->result_array();
    else :
      return false;
    endif;
  }
  public function GetAllHotelList($useType = null){
  	$owner_id = sessionData('MHM_OWNER_ID');
  	$this->db->select('vendor_id','vendor_business_name');
		$this->db->from('vendor');
		$this->db->where('parent_id', $owner_id);
		$query2 = $this->db->get();
		$HotelList = $query2->result_array();
		if($useType == 'list'){
			return $HotelList;
		}
		else{
			$HotelArr = [$owner_id];
			foreach ($HotelList as $key => $value) {
				$HotelArr[] = $value['vendor_id'];
			}
			//echo '<pre>';print_r($HotelArr);die;
			$HotelArr = array_unique($HotelArr);
			return $HotelArr;
		}
  }

  function GetOwnerVendorList($vendor_id = ''){
  	$vendorId = !empty($vendor_id) ? $vendor_id : sessionData('MHM_OWNER_ID');
		$this->db->select('*');
		$this->db->from('vendor');
		$this->db->where('vendor_id', $vendorId);
  	$query = $this->db->get();
  	$OwnerDetails = $query->result_array();
  	$VendorArr = $OwnerDetails;
		$this->db->select('*');
		$this->db->from('vendor');
		$this->db->where('parent_id', $vendorId);
		$query = $this->db->get();
		$VendorList = $query->result_array();
		foreach ($VendorList as $key => $value) {
			$VendorArr[] = $value;
		}
		//echo '<pre>';print_r($VendorArr);die;
		return $VendorArr;
	}
	public function getTotalSaleByOtsIdReport($otsId = '', $fromDate = '', $toDate = '',$VendorArr,$range = ''){

		if($range == 'today'){
            $dates = date('Y-m-d');
            $dates2 = date('Y-m-d');
            $fromDate       = $dates;
            $toDate     = $dates2;
        }
        elseif($range == 'yesterday'){
            $dates = date('Y-m-d',strtotime("-1 days"));
            $dates2 = date('Y-m-d');
            $fromDate       = $dates;
            $toDate     = $dates;
        }
        elseif($range == 'week'){
            $start = (date('D') != 'Mon') ? date('Y-m-d', strtotime('last Monday')) : date('Y-m-d');
            $finish = (date('D') != 'Sun') ? date('Y-m-d', strtotime('next Sunday')) : date('Y-m-d');
            $fromDate       = $finish;
            $toDate     = $start;
        }
        elseif($range == 'last_month'){
            $start = date("Y-m-d", strtotime("first day of previous month"));
            $finish = date("Y-m-d", strtotime("last day of previous month"));
            $fromDate       = $finish;
            $toDate     = $start;
        }
        elseif($range == 'till_now'){
            $start = date("Y-m-01");
            $finish = date("Y-m-d");
            $fromDate       = $finish;
            $toDate     = $start;
        }
    $hotel_manager_id = $VendorArr;
		$this->db->select('SUM(details.advance_paid) as totalAmount');
    $this->db->from('customer_summary_details as details');
    $this->db->join('customer_summary_book as book', 'book.summary_book_id = details.customer_id');
    $this->db->where("book.ots_id", $otsId);
    if (!empty($fromDate)) :
      $this->db->where("DATE_FORMAT(book.creation_date,'%Y-%m-%d') <=", $fromDate);
      $this->db->where("DATE_FORMAT(book.creation_date,'%Y-%m-%d') >=", $toDate);
    endif;
    $this->db->where("book.hotel_manager_id",$hotel_manager_id); 
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
    	//print_r($this->db->last_query());
      return $query->row_array();
    else :
      return false;
    endif;
  }
  public function getTotalSaleByOtsIdReportBusiness($otsId = '', $fromDate = '', $toDate = '',$VendorArr,$range = ''){
  		if($range == 'today'){
            $dates = date('Y-m-d');
            $dates2 = date('Y-m-d');
            $fromDate       = $dates;
            $toDate     = $dates2;
        }
        elseif($range == 'yesterday'){
            $dates = date('Y-m-d',strtotime("-1 days"));
            $dates2 = date('Y-m-d');
            $fromDate       = $dates;
            $toDate     = $dates;
        }
        elseif($range == 'week'){
            $start = (date('D') != 'Mon') ? date('Y-m-d', strtotime('last Monday')) : date('Y-m-d');
            $finish = (date('D') != 'Sun') ? date('Y-m-d', strtotime('next Sunday')) : date('Y-m-d');
            $fromDate       = $finish;
            $toDate     = $start;
        }
        elseif($range == 'last_month'){
            $start = date("Y-m-d", strtotime("first day of previous month"));
            $finish = date("Y-m-d", strtotime("last day of previous month"));
            $fromDate       = $finish;
            $toDate     = $start;
        }
        elseif($range == 'till_now'){
            $start = date("Y-m-01");
            $finish = date("Y-m-d");
            $fromDate       = $finish;
            $toDate     = $start;
        }
    $hotel_manager_id = $VendorArr;
		$this->db->select('*');
    $this->db->from('customer_summary_details as details');
    $this->db->join('customer_summary_book as book', 'book.summary_book_id = details.customer_id');
    $this->db->where("book.ots_id", $otsId);
    if (!empty($fromDate)) :
      $this->db->where("DATE_FORMAT(book.creation_date,'%Y-%m-%d') <=", $fromDate);
      $this->db->where("DATE_FORMAT(book.creation_date,'%Y-%m-%d') >=", $toDate);
    endif;
    $this->db->where("book.hotel_manager_id",$hotel_manager_id); 
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
    	//print_r($this->db->last_query());
      return $query->result_array();
    else :
      return false;
    endif;
  }
	public function getTotalSaleByOtsIdReportOLD($otsId = '', $fromDate = '', $toDate = '',$VendorArr){
		if($VendorArr!=''){ 
      $hotel_manager_id = explode(',', $VendorArr);
    }else{
      $hotel_manager_id = $this->GetAllHotelList();
    }
		$this->db->select('SUM(amount) as totalAmount');
    $this->db->from('customer_summary_book');
    $this->db->where("ots_id", $otsId);
    if (!empty($fromDate)) :
      $this->db->where('creation_date <=', $fromDate);
      $this->db->where('creation_date >=', $toDate);
    endif;
    $this->db->where_in("hotel_manager_id",$hotel_manager_id); 
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
    	//print_r($this->db->last_query());
      return $query->row_array();
    else :
      return false;
    endif;
  }
  function getTotalExpensesByOwnerId($serviceId,$VendorArr,$fromDate = '', $toDate = '',$range=''){

    $hotel_manager_id = $VendorArr;
    if($range == 'today'){
        $dates = date('Y-m-d');
        $dates2 = date('Y-m-d');
        $fromDate       = $dates;
        $toDate     = $dates2;
    }
    elseif($range == 'yesterday'){
        $dates = date('Y-m-d',strtotime("-1 days"));
        $dates2 = date('Y-m-d');
        $fromDate       = $dates;
        $toDate     = $dates;
    }
    elseif($range == 'week'){
        $start = (date('D') != 'Mon') ? date('Y-m-d', strtotime('last Monday')) : date('Y-m-d');
        $finish = (date('D') != 'Sun') ? date('Y-m-d', strtotime('next Sunday')) : date('Y-m-d');
        $fromDate       = $finish;
        $toDate     = $start;
    }
    elseif($range == 'last_month'){
        $start = date("Y-m-d", strtotime("first day of previous month"));
        $finish = date("Y-m-d", strtotime("last day of previous month"));
        $fromDate       = $finish;
        $toDate     = $start;
    }
    elseif($range == 'till_now'){
        $start = date("Y-m-01");
        $finish = date("Y-m-d");
        $fromDate       = $finish;
        $toDate     = $start;
    }
  	$this->db->select('SUM(amount_out) as totalExpense');
    $this->db->from('customer_summary_details');
    if (!empty($fromDate)) :
      $this->db->where("DATE_FORMAT(creation_date,'%Y-%m-%d') <=", $fromDate);
      $this->db->where("DATE_FORMAT(creation_date,'%Y-%m-%d') >=", $toDate);
    endif;
    $this->db->where('service_id', $serviceId);
    $this->db->where('daybook_mode = "Out"');
    $this->db->where("hotel_manager_id",$hotel_manager_id); 
    $query = $this->db->get();
    //echo $this->db->last_query();die;
    if ($query->num_rows() > 0) :
      return $query->row_array();
    else :
      return false;
    endif;
  } 

  function GetManagerList(){
  	$owner_id = sessionData('MHM_OWNER_ID');
		$this->db->select('id,manager_name');
		$this->db->from('manager');
		$this->db->where('vendor_id', $owner_id);
		$query	=	$this->db->get();
		return $query->result_array();
	}
	function GetLogType(){
		$this->db->select('id,log_type');
		$this->db->from('log_type');
		$this->db->order_by('sort asc');
		$query	=	$this->db->get();
		return $query->result_array();
	}

	public function getDayWiseTotalSales($paymentMode, $date,$id = null){
		
		if ($date != "") {
    		$date = $date;
	    } else {
	      $date = date('Y-m-d');
	    }
	    if(!empty($id)){
	  		$hotel_manager_id[] = $id;
	  	}
	  	else{
	  		$hotel_manager_id = $this->GetAllHotelList();
	  	}
	    $this->db->select('SUM(payment_paid) as totalAmount');
	    $this->db->from('customer_summary_details');
	    $this->db->where_in("hotel_manager_id",$hotel_manager_id); 
	    $this->db->where("amount_mode", $paymentMode);
	    $this->db->like("creation_date", $date);
	    $query = $this->db->get();
	    //echo $this->db->last_query(); die;
	    if ($query->num_rows() > 0) :
	      return $query->row_array();
	    else :
	      return false;
	    endif;
  }
  public function getDayWiseSingalTotalSales($paymentMode, $date,$hotel_manager_id){
		$this->db->select('SUM(payment_paid) as totalAmount');
    $this->db->from('customer_summary_details');
    $this->db->where("hotel_manager_id",$hotel_manager_id); 
    $this->db->where("amount_mode", $paymentMode);
    $this->db->like("creation_date", $date);
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($query->num_rows() > 0) :
      return $query->row_array();
    else :
      return false;
    endif;
  }
  public function selectDayBookOutManagerData($id = null,$type = null){
	if(!empty($id)){
  		$hotel_manager_id[] = $id;
  	}
  	else{
  		$hotel_manager_id = $this->GetAllHotelList();
  	}
	$whereCon['where'] = "hdbo.order_date like '%" . date('Y-m-d') . "%'";
  	$this->db->select('hdbo.*,hs.service_name');
    $this->db->from('customer_summary_details as hdbo');
    $this->db->join('hotel_services as hs', 'hdbo.service_id=hs.service_id', 'LEFT');
    if ($whereCon['where']) : $this->db->where($whereCon['where']);endif;
    $this->db->where_in("hdbo.hotel_manager_id",$hotel_manager_id); 
    $this->db->where("hdbo.daybook_mode", 'Out');
    $this->db->order_by('hdbo.detail_book_id ASC');
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($query->num_rows() > 0) :
      return $query->result_array();
    else :
      return false;
    endif;
  }
  public function GetTotalCheckIn($id = null, $type= null, $ots_id = null){
  	$date = date('Y-m-d');
  	if(!empty($id)){
  		$hotel_manager_id[] = $id;
  	}
  	else{
  		$hotel_manager_id = $this->GetAllHotelList();
  	}
  	$this->db->select('csb.*');
    $this->db->from('customer_summary_book as csb');
    //$this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'left');
    if(!empty($ots_id)){
    	$this->db->where("csb.ots_id",$ots_id);
    }
    $this->db->where_in("csb.hotel_manager_id",$hotel_manager_id);
    $whereCon['like'] = "(csb.check_in_datetime LIKE '%" . $date . "%')";
    $this->db->where($whereCon['like']);
    $query = $this->db->get();
    //echo "<pre>"; print_r($query->result_array()); exit;
    if($type == 'view'){
    	return $query->result_array();	
    }
    else{
    	return $query->num_rows();
    }
    
  }
  public function GetTotalCheckOut($id = null,$type = null, $ots_id = null){
  	$date = date('Y-m-d');
  	if(!empty($id)){
  		$hotel_manager_id[] = $id;
  	}
  	else{
  		$hotel_manager_id = $this->GetAllHotelList();
  	}
  	$this->db->select('csb.*');
    $this->db->from('customer_summary_book as csb');
    //$this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'left');
     if(!empty($ots_id)){
    	$this->db->where("csb.ots_id",$ots_id);
    }
    $this->db->where_in("csb.hotel_manager_id",$hotel_manager_id);
    $whereCon['like'] = "(csb.check_out_datetime LIKE '%" . $date . "%')";
    $this->db->where($whereCon['like']);
    $query = $this->db->get();
    if($type == 'view'){
    	return $query->result_array();	
    }
    else{
    	return $query->num_rows();
    }

    
  }
  public function GetHotelTotalCheckIn($hotel_manager_id){
  	$date = date('Y-m-d');
  	$this->db->select('csb.*');
    $this->db->from('vendors_checkin_count as csb');
    //$this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'left');
    $this->db->where("csb.hotel_manager_id",$hotel_manager_id);
    //$whereCon['like'] = "(csb.check_in_datetime LIKE '%" . $date . "%')";
    //$this->db->where($whereCon['like']);
    $query = $this->db->get();
    return $query->result_array();
  }
  public function GetHotelTotalCheckOut($hotel_manager_id){
  	$date = date('Y-m-d');
  	$this->db->select('csb.*');
    $this->db->from('vendor_checkout_count as csb');
    //$this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'left');
    $this->db->where("csb.hotel_manager_id",$hotel_manager_id);
    //$whereCon['like'] = "(csb.check_out_datetime LIKE '%" . $date . "%')";
    //$this->db->where($whereCon['like']);
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
   return $query->result_array();
  }
  public function selectHotelDayBookOutManagerData($hotel_manager_id){
		$whereCon['where'] = "hdbo.order_date like '%" . date('Y-m-d') . "%'";
  	$this->db->select('hdbo.*,hs.service_name');
    $this->db->from('customer_summary_details as hdbo');
    $this->db->join('hotel_services as hs', 'hdbo.service_id=hs.service_id', 'LEFT');
    if ($whereCon['where']) : $this->db->where($whereCon['where']);endif;
    $this->db->where("hdbo.hotel_manager_id",$hotel_manager_id); 
    $this->db->where("hdbo.daybook_mode", 'Out');
    $this->db->order_by('hdbo.detail_book_id ASC');
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
      return $query->result_array();
    else :
      return false;
    endif;
  }
  public function GetBookingMode($vendor_id,$ots_id){
  		$date = date('Y-m-d');
  		if(!empty($vendor_id) && $vendor_id != 'all'){
  			$hotel_manager_id[] = $vendor_id;
	  	}
	  	else{
	  		$hotel_manager_id = $this->GetAllHotelList();
	  	} 	
  		$this->db->select('COUNT(csb.ots_id) as totalDays');
		$this->db->from('customer_summary_book as csb');
		//$this->db->where_in("csb.hotel_manager_id",$hotel_manager_id);
		$this->db->where("csb.ots_id", $ots_id);
    	$whereCon['like'] = "(csb.check_in_datetime LIKE '%" . $date . "%')";
    	$this->db->where($whereCon['like']);
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
	      return $query->result_array();
	    else :
	      return false;
	    endif;
  }
  public function getAllOtsByHotelIds($id)
    {
    	if(!empty($id)){
  		$hotel_manager_id[] = $id;
	  	}
	  	else{
	  		$hotel_manager_id = $this->GetAllHotelList();
	  	}
        $this->db->select('ots_id,ots_name,status,hotel_manager_id');
        $this->db->from('ots_master');
        $this->db->where_in("hotel_manager_id",$hotel_manager_id);
        //$this->db->where_in("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("status = 'Y'");
        $this->db->order_by("ots_id ASC");
        $query = $this->db->get();
        $data = $query->result_array();
        return $data;
    }

    public function GetTotalCheckInOffLine($id = null, $type= null, $ots_id = null){
  	$date = date('Y-m-d');
  	if(!empty($id)){
  		$hotel_manager_id[] = $id;
  	}
  	else{
  		$hotel_manager_id = $this->GetAllHotelList();
  	}
  	$this->db->select('csb.*');
    $this->db->from('customer_summary_book as csb');
    if(!empty($ots_id)){
    	$this->db->where("csb.reffer_mode",$ots_id);
    	$this->db->where_in("csb.direct_mode",['commission','non_commission']);
    }
    $this->db->where_in("csb.hotel_manager_id",$hotel_manager_id);
    $whereCon['like'] = "(csb.check_in_datetime LIKE '%" . $date . "%')";
    $this->db->where($whereCon['like']);
    $query = $this->db->get();

    if($type == 'view'){
    	return $query->result_array();	
    }
    else{
    	return $query->num_rows();
    }
    
  }
  public function GetTotalCheckOutOffLine($id = null,$type = null, $ots_id = null){
  	$date = date('Y-m-d');
  	if(!empty($id)){
  		$hotel_manager_id[] = $id;
  	}
  	else{
  		$hotel_manager_id = $this->GetAllHotelList();
  	}
  	$this->db->select('csb.*');
    $this->db->from('customer_summary_book as csb');
    if(!empty($ots_id)){
    	$this->db->where("csb.reffer_mode",$ots_id);
    	$this->db->where_in("csb.direct_mode",['commission','non_commission']);
    }
    $this->db->where_in("csb.hotel_manager_id",$hotel_manager_id);
    $whereCon['like'] = "(csb.check_out_datetime LIKE '%" . $date . "%')";
    $this->db->where($whereCon['like']);
    $query = $this->db->get();
    if($type == 'view'){
    	return $query->result_array();	
    }
    else{
    	return $query->num_rows();
    }

  }

  public function GetTotalSales($id = null,$type = null){
  	$date = date('Y-m-d');
  	if(!empty($id)){
  		$hotel_manager_id[] = $id;
  	}
  	else{
  		$hotel_manager_id = $this->GetAllHotelList();
  	}
  	$this->db->select('csd.id,csd.hotel_manager_id,csd.customer_id,csd.amount_mode,csd.payment_paid');
    $this->db->from('customer_summary_details as csd');
    if(!empty($type)){
    	$this->db->where("csd.amount_mode",$type);
    }
    $this->db->where("csd.payment_paid > 0");
    $this->db->where_in("csd.hotel_manager_id",$hotel_manager_id);
    $whereCon['like'] = "(csd.order_date LIKE '%" . $date . "%')";
    $this->db->where($whereCon['like']);
    $this->db->order_by("order_date DESC");
    $query = $this->db->get();
    if($query->num_rows()){
    	return $query->result_array();	
    }
    else{
    	return false;
    }

  }

  public function GetTotalCheckInCount($id = null){
  	$date = date('Y-m-d');
  	if(!empty($id)){
  		$hotel_manager_id[] = $id;
  	}
  	else{
  		$hotel_manager_id = $this->GetAllHotelList();
  	}
  	$this->db->select('SUM(csb.checkin_count) as total');
    $this->db->from('vendors_checkin_count as csb');
    $this->db->where_in("csb.hotel_manager_id",$hotel_manager_id);
    $query = $this->db->get();
    
    if($query->num_rows()){
    	$result = $query->row_array();
    	return !empty($result['total']) ? $result['total']: 0;	
    }
    else{
    	return false;
    }  
  }

  public function GetTotalCheckOutCount($id = null){
  	if(!empty($id)){
  		$hotel_manager_id[] = $id;
  	}
  	else{
  		$hotel_manager_id = $this->GetAllHotelList();
  	}
  	$this->db->select('SUM(csb.checkin_count) as total');
    $this->db->from('vendor_checkout_count as csb');
    $this->db->where_in("csb.hotel_manager_id",$hotel_manager_id);
    $query = $this->db->get();
    if($query->num_rows()){
    	$result = $query->row_array();
    	return !empty($result['total']) ? $result['total']: 0;	
    }
    else{
    	return false;
    }
    
  }

  public function getDayWiseTotalSalesCount($paymentMode, $date,$id = null){
		
	    if(!empty($id)){
	  		$hotel_manager_id[] = $id;
	  	}
	  	else{
	  		$hotel_manager_id = $this->GetAllHotelList();
	  	}
	  	$this->db->select('SUM(totalAmount) as total');
	    $this->db->from($paymentMode);
	    $this->db->where_in("hotel_manager_id",$hotel_manager_id);
	    $query = $this->db->get();
	    if($query->num_rows()){
	    	$result = $query->row_array();
	    	return !empty($result['total']) ? $result['total']: 0;	
	    }
	    else{
	    	return false;
	    }
  	}
  	public function getTotalSalesAjax($id = null){
	  	if(!empty($id)){
	  		$hotel_manager_id[] = $id;
	  	}
	  	else{
	  		$hotel_manager_id = $this->GetAllHotelList();
	  	}
	  	$this->db->select('SUM(csb.totalAmount) as total');
	    $this->db->from('vendor_today_total_sales as csb');
	    $this->db->where_in("csb.hotel_manager_id",$hotel_manager_id);
	    $query = $this->db->get();
	    if($query->num_rows()){
	    	$result = $query->row_array();
	    	return !empty($result['total']) ? $result['total']: 0;	
	    }
	    else{
	    	return false;
	    }
    
  	}
  	public function getTotalExpanseAjax($id = null){
	  	if(!empty($id)){
	  		$hotel_manager_id[] = $id;
	  	}
	  	else{
	  		$hotel_manager_id = $this->GetAllHotelList();
	  	}
	  	$this->db->select('SUM(csb.totalAmount) as total');
	    $this->db->from('vendor_today_expense_sales as csb');
	    $this->db->where_in("csb.hotel_manager_id",$hotel_manager_id);
	    $query = $this->db->get();
	    if($query->num_rows()){
	    	$result = $query->row_array();
	    	return !empty($result['total']) ? $result['total']: 0;	
	    }
	    else{
	    	return false;
	    }
    
  	}
  	public function getCheckinByOtsIdReportBusiness($otsId = '', $fromDate = '', $toDate = '',$VendorArr,$range = ''){
  		if($range == 'today'){
            $dates = date('Y-m-d');
            $dates2 = date('Y-m-d');
            $fromDate       = $dates;
            $toDate     = $dates2;
        }
        elseif($range == 'yesterday'){
            $dates = date('Y-m-d',strtotime("-1 days"));
            $dates2 = date('Y-m-d');
            $fromDate       = $dates;
            $toDate     = $dates;
        }
        elseif($range == 'week'){
            $start = (date('D') != 'Mon') ? date('Y-m-d', strtotime('last Monday')) : date('Y-m-d');
            $finish = (date('D') != 'Sun') ? date('Y-m-d', strtotime('next Sunday')) : date('Y-m-d');
            $fromDate       = $finish;
            $toDate     = $start;
        }
        elseif($range == 'last_month'){
            $start = date("Y-m-d", strtotime("first day of previous month"));
            $finish = date("Y-m-d", strtotime("last day of previous month"));
            $fromDate       = $finish;
            $toDate     = $start;
        }
        elseif($range == 'till_now'){
            $start = date("Y-m-01");
            $finish = date("Y-m-d");
            $fromDate       = $finish;
            $toDate     = $start;
        }
    $hotel_manager_id = $VendorArr;
		$this->db->select('COUNT(book.id) as totalChecking');
    $this->db->from('customer_summary_book as book');
    //$this->db->join('customer_summary_book as book', 'book.summary_book_id = details.customer_id');
    $this->db->where("book.ots_id", $otsId);
    if (!empty($fromDate)) :
      $this->db->where("DATE_FORMAT(book.check_in_datetime,'%Y-%m-%d') <=", $fromDate);
      $this->db->where("DATE_FORMAT(book.check_in_datetime,'%Y-%m-%d') >=", $toDate);
    endif;
    $this->db->where("book.hotel_manager_id",$hotel_manager_id); 
    $query = $this->db->get();
    if($query->num_rows()){
    	$result = $query->row_array();
    	return !empty($result['totalChecking']) ? $result['totalChecking']: 0;	
    }
    else{
    	return false;
    }
  }

  function GetOwnerRestaurantList($VendorID){
  	if($VendorID!='All'){ 
      $hotel_manager_id = explode(',', $VendorID);
    }else{
      $hotel_manager_id = $this->GetAllHotelList();
    }
		$this->db->select('*');
		$this->db->from('restaurant');
		$this->db->where_in("hotel_manager_id",$hotel_manager_id); 
		$query = $this->db->get();
		$VendorList = $query->result_array();
		$VendorArr = [];
		foreach ($VendorList as $key => $value) {
			$VendorArr[] = $value;
		}
		//echo '<pre>';print_r($VendorArr);die;
		return $VendorArr;
	}

	public function selectHotelMenuData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
  {
    $this->db->select('ms.*');
    $this->db->from($tblName);
    if ($whereCon['where']) : $this->db->where($whereCon['where']);
    endif;
    if ($whereCon['like']) : $this->db->where($whereCon['like']);
    endif;
    if ($shortField) : $this->db->order_by($shortField);
    endif;
    if ($numPage) : $this->db->limit($numPage, $cnt);
    endif;
    $this->db->where('hotel_manager_id', $this->session->userdata('MHM_REST_HOTEL_ID'));
    $query = $this->db->get();
    if ($action == 'data') :
      if ($query->num_rows() > 0) :
        return $query->result_array();
      else :
      	return false;
      endif;
    elseif ($action == 'count') :
      return $query->num_rows();
    endif;
  }
  public function getAllGuestDataForCollectionReport($Search){ 
		$toDate = date('Y-m-d', strtotime($Search['toDate']));
		$fromDate = date('Y-m-d', strtotime($Search['fromDate']));
		$this->db->select('csd.amount_mode,csd.payment_paid,csd.order_date,csd.page_source,csd.daybook_mode,csd.advance_paid,csd.order_date,csb.summary_book_id,csb.hotel_manager_id,csb.customer_name,csb.check_in_datetime,
        csb.check_out_datetime,csb.assign_room_number,csb.entry_number,csb.gst_number,csb.company_name,csb.amount as roomrent,rn.room_no,csb.room_rent_type as gstType,
		om.ots_name,csb.number_of_person');
		$this->db->from('customer_summary_details as csd');
		$this->db->join('customer_summary_book as csb', 'csb.summary_book_id = csd.customer_id', 'left');
		$this->db->join('ots_master as om', 'csb.ots_id = om.ots_id', 'left');
		$this->db->join('room_number as rn', 'csb.assign_room_number = rn.room_id', 'left');
		if ($fromDate != '1970-01-01' && $toDate != '1970-01-01') {
			$this->db->where("DATE(csd.order_date) BETWEEN '$fromDate' AND '$toDate'");
		}
		$this->db->where('csd.daybook_mode', 'In');
		//$this->db->where('csd.advance_paid !=', '');
		$this->db->where('csd.page_source', 'add_an_advance');
		if ($Search['businessType'] == "B2B") { 
			$this->db->where('csb.gst_number !=', '');
		} elseif ($Search['businessType'] == "B2C") {
			$this->db->where('csb.gst_number' == '');
		}
		if($Search['amount_mode']!='All'){
			$this->db->where('csd.amount_mode', $Search['amount_mode']);
		}
		if($Search['reffer_mode']!='All'){
			$this->db->where('csb.reffer_mode', $Search['reffer_mode']);
			if($Search['reffer_mode']=='online'){
				if($Search['ots_id']!='All'){
					$this->db->where('csb.ots_id', $Search['ots_id']);
				}
			}else{
				if($Search['direct_mode']!='All'){
					$this->db->where('csb.ots_id', $Search['direct_mode']);
				}
			}
		}
		// if($Search['choose_plan']!='All'){
		// 	$this->db->where('csb.choose_plan', $Search['choose_plan']);
		// }
		// if($Search['bill_generated']!='All'){ 
		// 	$this->db->where("csb.user_status",$Search['bill_generated']); 
		// }
		//$this->db->where('cbb.page_source', 'extend_stay');
		//$this->db->where_in('csb.hotel_manager_id', $Search['VendorArr']);
		$this->db->where('csd.hotel_manager_id', $Search['VendorArr']);
		$this->db->order_by("csb.check_out_datetime DESC");
		//$this->db->group_by('csd.customer_id');
		$query	=	$this->db->get();
		//echo $this->db->last_query();die;
		if ($query->num_rows() > 0) :
			return $query->result_array();
		else :
			return false;
		endif;
	}
    public function sumOfTotalSaleByOtsIdReportBusiness($otsId = '', $fromDate = '', $toDate = '',$VendorArr,$range = ''){
  		if($range == 'today'){
            $dates = date('Y-m-d');
            $dates2 = date('Y-m-d');
            $fromDate       = $dates;
            $toDate     = $dates2;
        }
        elseif($range == 'yesterday'){
            $dates = date('Y-m-d',strtotime("-1 days"));
            $dates2 = date('Y-m-d');
            $fromDate       = $dates;
            $toDate     = $dates;
        }
        elseif($range == 'week'){
            $start = (date('D') != 'Mon') ? date('Y-m-d', strtotime('last Monday')) : date('Y-m-d');
            $finish = (date('D') != 'Sun') ? date('Y-m-d', strtotime('next Sunday')) : date('Y-m-d');
            $fromDate       = $finish;
            $toDate     = $start;
        }
        elseif($range == 'last_month'){
            $start = date("Y-m-d", strtotime("first day of previous month"));
            $finish = date("Y-m-d", strtotime("last day of previous month"));
            $fromDate       = $finish;
            $toDate     = $start;
        }
        elseif($range == 'till_now'){
            $start = date("Y-m-01");
            $finish = date("Y-m-d");
            $fromDate       = $finish;
            $toDate     = $start;
        }
    $hotel_manager_id = $VendorArr;
    	 //echo "sssss".$otsId; exit;
		$this->db->select('SUM(details.payment_paid) paid_amount,amount_mode');
    $this->db->from('customer_summary_details as details');
    $this->db->join('customer_summary_book as book', 'book.summary_book_id = details.customer_id');
    $this->db->where("book.ots_id", $otsId);
    if (!empty($fromDate)) :
      $this->db->where("DATE_FORMAT(book.creation_date,'%Y-%m-%d') <=", $fromDate);
      $this->db->where("DATE_FORMAT(book.creation_date,'%Y-%m-%d') >=", $toDate);
    endif;
    $this->db->where("book.hotel_manager_id",$hotel_manager_id); 
    $this->db->group_by('details.amount_mode');
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
    	//echo "<pre>"; print_r($query->result_array()); exit;
      return $query->result_array();
    else :
      return false;
    endif;
  }
  public function GetAllSubOwnerList($useType = null){
  	$owner_id = sessionData('MHM_OWNER_ID');

  	$this->db->select('v.vendor_id','v.vendor_business_name','sub_owner.vendor_id');
		$this->db->from('sub_owner');
		$this->db->join('vendor as v', 'v.vendor_id = sub_owner.vendor_id');
		$this->db->where('sub_owner.owner_id', $owner_id);
		$query2 = $this->db->get();
		$HotelList = $query2->result_array();
		if($useType == 'list'){
			return $HotelList;
		}
		else{
			$HotelArr = [$owner_id];
			foreach ($HotelList as $key => $value) {
				$HotelArr[] = $value['vendor_id'];
			}

			$HotelArr = array_unique($HotelArr);
			return $HotelArr;
		}
  }

  function GetSubOwnerVendorList(){

  	$owner_id = sessionData('MHM_OWNER_ID');
  	$parent_owner = sessionData('MHM_PARENT_OWNER');
  // 	$this->db->select('*');
		// $this->db->from('vendor as v');
		// $this->db->join('sub_owner', 'v.vendor_id = sub_owner.vendor_id', "LEFT");
		// $this->db->where('v.vendor_id',$parent_owner);
		// $query3 = $this->db->get();
		// $HotelList2 = $query3->result_array();

  	$this->db->select('*');
		$this->db->from('sub_owner');
		$this->db->join('vendor as v', 'v.vendor_id = sub_owner.vendor_id');
		$this->db->where('sub_owner.owner_id', $owner_id);
		$query2 = $this->db->get();
		$HotelList = $query2->result_array();
		//$finalList = array_merge($HotelList2,$HotelList);
		foreach ($HotelList as $key => $value) {
			$VendorArr[] = $value;
		}
		//echo '<pre>';print_r($HotelList2);die;
		return $VendorArr;
	}
	/***********************************************************************
	 ** Function name : selectSelletData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Seller Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectSelletOwnerData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '',$grField='')
	{
		$this->db->select('ven.*, vende.vendor_address, vende.vendor_nationality, vende.vendor_pan, vende.vendor_address_proof, vende.vendor_kyc_status');
		$this->db->from($tblName);
		$this->db->join("vendor as ven", "ven.vendor_id=so.vendor_id", "INNER");
		$this->db->join("vendor_details as vende", "ven.vendor_id=vende.vendor_id", "LEFT");
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
       
	    if ($grField) :		$this->db->group_by($grField);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$this->db->where('so.owner_id', sessionData('MHM_OWNER_ID'));
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION
}
