<?php
if (!defined("BASEPATH")) {
    exit("No direct script access allowed");
}
class Message_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    public function getownerData($parent_id)
    {
        $conn = [
            "parent_id" => $parent_id,
        ];
        $this->db->where($conn);
        return $this->db->get("mhmholets_vendor")->result_array();
    }
    function getmessagedata1(
        $action = "",
        $tblName = "",
        $whereCon = "",
        $shortField = "",
        $numPage = "",
        $cnt = ""
    ) {
        //$this->db->select("emlt.*");
        $this->db->from($tblName);
        if ($whereCon["where"]):
            $this->db->where($whereCon["where"]);
        endif;
        if ($whereCon["like"]):
            $this->db->where($whereCon["like"]);
        endif;
        if ($shortField):
            $this->db->order_by($shortField);
        endif;
        if ($numPage):
            $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == "data"):
            if ($query->num_rows() > 0):
                return $query->result_array();
            else:
                return false;
            endif;
        elseif ($action == "count"):
            return $query->num_rows();
        endif;
    } 
    public function getmessagedata()
    {
        $this->db->order_by("id", "desc");
        return $this->db->get("mhmholets_add_message")->result_array();
    }public function getcheckboxdata($id)
    {
        $this->db->select("vendor_id, vendor_business_name");
        $this->db->order_by("id", "desc");
        $this->db->where("parent_id",$id);
        $result = $this->db->get("mhmholets_vendor")->result_array();
        if(!empty($result)){
            $this->db->select("vendor_id, vendor_business_name");
            $this->db->order_by("id", "desc");
            $this->db->where("vendor_id",$id);
            $result2 = $this->db->get("mhmholets_vendor")->result_array();
            $result = array_merge($result2,$result);
        }

        return $result;
    }
    public function getvendorname($id)
    {
        $conn = [
            "vendor_id" => $id,
        ];
        $this->db->select("parent_id,vendor_business_name");
        $this->db->where($conn);
        $data = $this->db->get("mhmholets_vendor")->row_array();
        $vendor_data = $this->getcheckboxdata($data['parent_id']);
        return $vendor_data;
    }
    public function editmsgdata($id)
    {
        $conn = [
            "id" => $id,
        ];
        $this->db->where($conn);
        return $this->db->get("mhmholets_add_message")->row_array();
    }

    

    public function updatemessage($id, $data)
    {
        $this->db->where("id", $id);
        return $this->db->update("mhmholets_add_message", $data);
    }
    function addmessage($data)
    {
        $this->db->insert("add_message", $data);
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
    public function getSummaryBookById($customerId) {

        $conn = [
            "summary_book_id" => $customerId,
        ];
        $this->db->where($conn);
        return $this->db->get("mhmholets_customer_summary_book")->row_array();
    }
}
