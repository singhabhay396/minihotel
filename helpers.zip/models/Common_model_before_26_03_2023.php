<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Common_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	/***********************************************************************
	 ** Function name : addData
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for add data
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function addData($tableName = '', $param = array())
	{
		$this->db->insert($tableName, $param);
		return $this->db->insert_id();
	}	// END OF FUNCTION
	/* * *********************************************************************
	 * * Function name : editData
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for edit data
	 * * Date : 14 APRIL 2022
	 * * **********************************************************************/
	function editData($tableName = '', $param = '', $fieldName = '', $fieldVallue = '')
	{
		$this->db->where($fieldName, $fieldVallue);
		$this->db->update($tableName, $param);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : editDataByMultipleCondition
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for edit data by multiple condition
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function editDataByMultipleCondition($tableName = '', $param = array(), $whereCondition = array())
	{
		$this->db->where($whereCondition);
		$this->db->update($tableName, $param);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : deleteData
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for delete data
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function deleteData($tableName = '', $fieldName = '', $fieldVallue = '')
	{
		$this->db->delete($tableName, array($fieldName => $fieldVallue));
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : deleteParticularData
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for delete particular data
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function deleteParticularData($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->delete($tableName, array($fieldName => $fieldValue));
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : deleteParticularVenodrData
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for delete particular data
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function deleteParticularVenodrData($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->delete($tableName, array($fieldName => $fieldValue));
		$this->db->delete('vendor_details', array($fieldName => $fieldValue));
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : deleteByMultipleCondition
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for delete by multiple condition
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function deleteByMultipleCondition($tableName = '', $whereCondition = array())
	{
		$this->db->delete($tableName, $whereCondition);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getDataByParticularField
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get data by encryptId
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getDataByParticularField($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select('*');
		$this->db->from($tableName);
		$this->db->where($fieldName, $fieldValue);
		$query = $this->db->get();
		//echo $this->db->last_query(); die;
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getDataByQuery
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get data by query
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getDataByQuery($action = '', $query = '', $from = '')
	{
		$query = $this->db->query($query);
		if ($from == 'procedure') :
			mysqli_next_result($this->db->conn_id);
		endif;
		if ($action == 'count') :
			return $query->num_rows();
		elseif ($action == 'single') :
			if ($query->num_rows() > 0) :
				return $query->row_array();
			else :
				return false;
			endif;
		elseif ($action == 'multiple') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getFieldInArray
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get data by condition
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getFieldInArray($field = '', $query = '')
	{
		$returnarray			=	array();
		$query = $this->db->query($query);
		if ($query->num_rows() > 0) :
			$data	=	$query->result_array();
			foreach ($data as $info) :
				array_push($returnarray, trim($info[$field]));
			endforeach;
		endif;
		return $returnarray;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getTwoFieldsInArray
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get Two Fields In Array
	 ** Date : 22  MAY 2022
	 ************************************************************************/
	public function getTwoFieldsInArray($firstField = '', $secondField = '', $query = '')
	{
		$returnarray			=	array();
		$query = $this->db->query($query);
		if ($query->num_rows() > 0) :
			$data	=	$query->result_array();
			foreach ($data as $info) :
				array_push($returnarray, array($firstField => trim($info[$firstField]), $secondField => trim($info[$secondField])));
			endforeach;
		endif;
		return $returnarray;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getParticularDataByFields
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get particular data by fields
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getParticularDataByFields($selectField = '', $tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select($selectField);
		$this->db->from($tableName);
		$this->db->where($fieldName, ucfirst(strtolower($fieldValue)));
		$this->db->or_where($fieldName, strtolower($fieldValue));
		$query = $this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getLastOrderByFields
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get Last Order By Fields
	 ** Date : 14 MAY 2022
	 ************************************************************************/
	public function getLastOrderByFields($selectField = '', $tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select($selectField);
		$this->db->from($tableName);
		if ($fieldName && $fieldValue) :
			$this->db->where($fieldName, $fieldValue);
		endif;
		$this->db->order_by($selectField . ' DESC');
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() > 0) :
			$data 	=	$query->row_array();
			return $data[$selectField];
		else :
			return 0;
		endif;
	}	// END OF FUNCTION
	/* * *********************************************************************
	 * * Function name : setAttributeInUse
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for set Attribute In Use
	 * * Date : 20 MAY 2022
	 * * **********************************************************************/
	function setAttributeInUse($tableName = '', $param = '', $fieldName = '', $fieldValue = '')
	{
		$paramarray[$param]	=	'Y';
		$this->db->where($fieldName, $fieldValue);
		$this->db->update($tableName, $paramarray);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : increaseDecreaseCountByQuery
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for increase Decrease Count By Query
	 ** Date : 06 SEPTEMBER 2018
	 ************************************************************************/
	function increaseDecreaseCountByQuery($query = '')
	{
		$this->db->query($query);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getArrayDataByParticularField
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get data by encryptId
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getArrayDataByParticularField($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select('*');
		$this->db->from($tableName);
		$this->db->where($fieldName, $fieldValue);
		$query = $this->db->get();
		if ($query->num_rows() > 0) :
			return $query->result_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	** Function name : getAllGuestDataForExcel
	** Developed By : Ashish Umrao
	** Purpose  : This function used for get All Guest Data For Excel
	** Date : 25 SEPTEMBER 2022
	************************************************************************/
	public function getAllGuestDataForExcelDownload($vendorId, $fromDate = '', $toDate = '', $businessType = '')
	{
		$toDate = date('Y-m-d', strtotime($toDate));
		$fromDate = date('Y-m-d', strtotime($fromDate));
		$this->db->select('csb.summary_book_id,csb.hotel_manager_id,csb.customer_name,csb.check_in_datetime,
        csb.check_out_datetime,csb.assign_room_number,csb.entry_number,csb.gst_number,cbb.bill_generated_date,
        cbb.bill_number,cbb.cgst,cbb.sgst,cbb.paybal_amount,csb.amount as roomrent,rn.room_no,
        cbb.total_amount as foodotherservice,csb.room_rent_type as gstType');
		$this->db->from('custom_bill_book as cbb');
		//$this->db->join('customer_summary_details as csd', 'csb.summary_book_id = csd.customer_id', 'left');
		$this->db->join('customer_summary_book as csb', 'csb.summary_book_id = cbb.customer_id', 'left');
		$this->db->join('room_number as rn', 'csb.assign_room_number = rn.room_id', 'left');
		if ($fromDate != '1970-01-01' && $toDate != '1970-01-01') {
			$this->db->where("csb.check_out_datetime BETWEEN '$fromDate' AND '$toDate'");
		}
		$this->db->where('csb.check_out_datetime !=', 'NULL');
		if ($businessType == "B2B") {
			$this->db->where('csb.gst_number !=', '');
		} elseif ($businessType == "B2C") {
			$this->db->where('csb.gst_number' == '');
		}
		$this->db->where('csb.hotel_manager_id', $vendorId);
		$this->db->order_by("csb.check_out_datetime DESC");
		$this->db->group_by('cbb.customer_id');
		$query	=	$this->db->get();
		//echo $this->db->last_query();die;
		if ($query->num_rows() > 0) :
			return $query->result_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION

}
