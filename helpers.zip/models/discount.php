<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>
<div class="main">
<div class="bready">
<ol class="breadcrumb">
<li><a href="{VENDOR_SITE_URL}dashboard" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
</ol>
</div>
<div class="main-content">
<div class="container-fluid">
<div class="panel panel-headline inr-form">
<div class="panel-heading row">
<h3 class="panel-title tab">Discount</h3>
<a href="<?php echo correctLink('summaryBookVendorData', '{VENDOR_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-default add_btn">Back</a>
</div>
<hr class="differ">
<div class="panel">
<div class="panel-body row">
<form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="" enctype="multipart/form-data" autocomplete="off">
<input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?= $EDITTASKDATA['encrypt_id'] ?>" />
<input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITTASKDATA['detail_book_id'] ?>" />
<input type="hidden" name="CustomerID" id="CustomerID" value="<?= $custId ?>" />
<input type="hidden" name="manager_name" id="manager_name" value="<?=sessionData('MHM_VENDOR_MANAGER_NAME')?>" />
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
<fieldset>
<legend>Item Details</legend>
<?php $allfilterids   = array();
if ($TotalFilterDefault) : $TotalFilterDefaultCount = $TotalFilterDefault;
elseif ($SUMMARYDETAIL <> "") : $TotalFilterDefaultCount = count($SUMMARYDETAIL);
else : $TotalFilterDefaultCount = 1;
endif; ?>
<input type="hidden" name="TotalFilterDefault" id="TotalFilterDefault" value="<?php echo $TotalFilterDefaultCount; ?>" />
<div id="FilterDefault">
<span>
<input type="hidden" name="filter_details_id_1" id="filter_details_id_1" class="form-control" value="" />
<div class="col-md-12 col-sm-12 col-xs-12 form-space">
<div class="col-md-6 col-sm-12 col-xs-12">
<div class="form-group <?php if (form_error('service_id')) : ?>error<?php endif; ?>">
<label class="fancy-checkbox form-headings">Discount Type
<span class="required">*</span></label>
<input type="radio" id="html" name="fav_language" value="HTML">
<label for="html">HTML</label> 
<input type="radio" id="css" name="fav_language" value="CSS">
<label for="css">CSS</label> 

 
  </div>
</div>
<div class="col-md-6 col-sm-12 col-xs-12">
<div class="form-group <?php if (form_error('quantity')) : ?>error<?php endif; ?>">
<label class="fancy-checkbox form-headings">Discount Value

<span class="required">*</span></label>
<input type="text" name="quantity_1" id="quantity_1" value="<?php if (set_value('quantity')) : echo set_value('quantity');
else : echo stripslashes($EDITTASKDATA['quantity']);
endif; ?>" class="form-control numberonly required" placeholder="Discount Value

">
<?php if (form_error('quantity')) : ?>
<span for="quantity" generated="true" class="help-inline"><?php echo form_error('quantity'); ?></span>
<?php endif; ?>
</div>
</div>
</div>
</span>
</div>
<br />
<div class="form-group"> <a href="javascript:void(0);" class="addMoreFilterDetails pull-right">+ Add Another Item</a>
<input type="hidden" name="AllFilterIds" id="AllFilterIds" value="<?php echo implode('_____', $allfilterids); ?>" />
</div>
</fieldset>
<input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
<button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
<a href="<?php echo correctLink('summaryBookVendorData', '{VENDOR_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
<span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
:- <strong><span style="color:#FF0000;">*</span> Indicates
Required Fields</strong> </span>
</span>
</form>
</div>
</div>
</div>
</div>
</div>
</div>

<form action="{VENDOR_SITE_URL}hotelmenus/save" class="modal fade" id="addServiceModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
<h4 class="modal-title" id="myModalLabel" style="text-align: center;">Add New Service</h4>
</div>
<div class="modal-body">
<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
<input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
<div class="row">
<div class="col-md-6 col-sm-6 col-xs-6">
<div class="form-group <?php if (form_error('menu_name')) : ?>error<?php endif; ?>">
<label class="fancy-checkbox form-headings">Menu Name<span class="required">*</span></label>
<input type="text" name="menu_name" id="menu_name" value="<?= set_value('menu_name') ? set_value('menu_name') : "" ?>" class="form-control required" placeholder="Menu Name">
<?php if (form_error('menu_name')) : ?>
<p for="menu_name" generated="true" class="error"><?php echo form_error('menu_name'); ?></p>
<?php endif;
if ($menuError) :  ?>
<span for="menu_name" generated="true" class="help-inline"><?php echo $menuError; ?></span>
<?php endif; ?>
</div>
</div>
<div class="col-md-6 col-sm-6 col-xs-6">
<div class="form-group <?php if (form_error('menu_price')) : ?>error<?php endif; ?>">
<label class="fancy-checkbox form-headings">Price<span class="required">*</span></label>
<input type="text" name="menu_price" id="menu_price" value="<?= set_value('menu_price') ? set_value('menu_price') : "" ?>" class="form-control required" placeholder="Price">
<?php if (form_error('menu_price')) : ?>
<p for="menu_price" generated="true" class="error"><?php echo form_error('menu_price'); ?></p>
<?php endif; ?>
</div>
</div>
</div>
</div>
<div class="modal-footer">
<button type="button" class="btn btn-default" data-dismiss="modal" style="padding: 6px 12px;">Close</button>
<button type="submit" class="btn btn-primary" style="padding: 6px 12px;">Save changes</button>
</div>
</div>
</div>
</form>

<script>
$(function() {
var scntDiv = $('#currentPageForm #FilterDefault');
var i = $('#currentPageForm #FilterDefault > span').size();
$(document).on('click', '#currentPageForm .addMoreFilterDetails', function() {
i++;
$('<hr style="border-top: 1px solid !important;border: dotted;"><span><input type="hidden" name="filter_details_id_' + i + '" id="filter_details_id_' + i + '" class="form-control" value="" /><div class="col-md-12 col-sm-12 col-xs-12 form-space"> <div class="col-md-6 col-sm-12 col-xs-12"> <div class="form-group <?php if (form_error('service_id')) : ?>error<?php endif; ?>"> <label class="fancy-checkbox form-headings">Select Item (' + i + ')<span class="required">*</span></label> <select name="service_id_' + i + '" id="service_id_' + i + '" class="form-control select2 <?php if ($EDITTASKDATA['service_id'] == '') : echo "required";

endif; ?>"> <?php echo $this->vendor_model->getAllServicesByHotelId($assignroomId); ?> </select> <?php if (form_error('service_id')) : ?> <span for="service_id" generated="true" class="help-inline"><?php echo form_error('service_id'); ?></span> <?php endif; ?> </div> </div> <div class="col-md-4 col-sm-12 col-xs-12"> <div class="form-group <?php if (form_error('quantity')) : ?>error<?php endif; ?>"> <label class="fancy-checkbox form-headings">Quantity (' + i + ')<span class="required">*</span></label> <input type="text" name="quantity_' + i + '" id="quantity_' + i + '" value="<?php if (set_value('quantity')) : echo set_value('quantity');
                                                                                                                                                                                                                                                                                                                                                                                                        else : echo stripslashes($EDITTASKDATA['quantity']);
                                                                                                                                                                                                                                                                                                                                                                                                        endif; ?>" class="form-control numberonly required" placeholder="Quantity"> <?php if (form_error('quantity')) : ?> <span for="quantity" generated="true" class="help-inline"><?php echo form_error('quantity'); ?></span> <?php endif; ?> </div> </div> </div><br/><div class="form-group"><a href="javascript:void(0);" class="removeMoreFilterDetails pull-right"></br>-Remove Item</a></div></span>').appendTo(scntDiv);
$('#currentPageForm #TotalFilterDefault').val(i);
return false;
});
$(document).on('click', '#currentPageForm .removeMoreFilterDetails', function() {
if (i > 1) {
$(this).parents('span').remove();
i--;
}
return false;
});
});
</script>
<script>
$('.select2').select2();

$('#addServiceModal').on('submit', function(e) {
e.preventDefault();
console.log("submitted");

$.ajax({
type: 'POST',
url: $(this).attr("action"),
data: $(this).serialize(),
success: function(response) {
var obj = response;
if (obj.formError == 'No') {
var text = obj.menu.menu_name + "(" + obj.menu.price + ")";
var value = obj.menu.menu_id + "__" + obj.menu.price + "__" + obj.menu.menu_name;
var newOption = new Option(text, value, true, true);
$('#service_id_1').append(newOption).trigger('change');
$('#addServiceModal').modal("hide");
}
}
});
});
</script>