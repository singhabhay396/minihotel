<?php 

if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
class Vendor_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }



public function insert_discount(){
	   $this->db->insert("mhmholets_customer_summary_book", $data);
        if ($this->db->affected_rows() > 0) {
            return true;
        } else {
            return false;
        }

}    
 ?>