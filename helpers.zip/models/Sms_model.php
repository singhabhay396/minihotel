<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Sms_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	/***********************************************************************
	 ** Function name : getVendorDataById
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for get vendor Data By Id
	 ** Date : 20 JUNE 2022
	 ************************************************************************/
	function getVendorDataById($vendorId = '')
	{
		$this->db->select('id,vendor_id,device_id,device_type,vendor_phone,vendor_business_name');
		$this->db->from('vendor');
		$this->db->where("vendor_id", $vendorId);
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : getVendorDataByPhone
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for get Vendor Data By Phone
	 ** Date : 20 JUNE 2022
	 ************************************************************************/
	function getVendorDataByPhone($vendorPhone = '')
	{
		$this->db->select('id,vendor_id,device_id,device_type,vendor_phone,vendor_business_name');
		$this->db->from('vendor');
		$this->db->where("vendor_phone", $vendorPhone);
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/* * *********************************************************************
	 * * Function name : sendSms
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for send Sms
	 * * Date : 25   MAY 2022
	 * * **********************************************************************/
	public function sendSms($mobileNumber = '', $message = '',$templateID = '')
	{ 
		if ($mobileNumber != '' && $message != '') :
			$authKey 			= 	"197812ALXqsgqb65a8140fa";
			$userName   = "MHMBO";
			$userPassword  = "854702";
			$sender 			= 	"MINIHM"; //maximum 6 capital caractor
			$mobileNumber		=	trim($mobileNumber);
			$message 			= 	urlencode($message);
			//echo $message; die;
			$url  				=  'http://anysms.in/api.php?username='.$userName.'&password='.$userPassword.'&sender='.$sender.'&sendto=' . $mobileNumber . '&message=' . $message.'&PEID=1501562610000042829&templateid='.$templateID.'';
			$curl = curl_init();
			curl_setopt_array($curl, array(
				CURLOPT_URL => $url,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING => "",
				CURLOPT_MAXREDIRS => 10,
				CURLOPT_TIMEOUT => 30,
				CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST => "GET",
				CURLOPT_SSL_VERIFYHOST => 0,
				CURLOPT_SSL_VERIFYPEER => 0,
			));
			$response 			= 	curl_exec($curl);
			//print_r($response); die;
			$err 				= 	curl_error($curl);
			//print_r($err); die;
			curl_close($curl);
			if ($err) :
				return false;
			else :
				return true;
			endif;
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	#########################################################################################################################
	################################################		ADMIN SECTION 		#############################################
	#########################################################################################################################
	#########################################################################################################################
	################################################		SELLER SECTION 		#############################################
	#########################################################################################################################
	/***********************************************************************
	 ** Function name : sendOtpSmsToVendor
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This is use for send Otp Sms To Vendor
	 ** Date : 20 JUNE 2022
	 ************************************************************************/
	function sendOtpSmsToVendor($mobileNumber = '', $otp = '')
	{
		if ($mobileNumber && $otp) :
			$templateID  = '1507165570811814448';
			$message		=	"Your One Time Password is {#$otp#} to register your phone number with Mini Hotel Man. Don't Share Your OTP with Anyone. Regards, TEAM MINIHM";
			$returnMessage	=	$this->sendSms($mobileNumber, $message,$templateID);
			return $returnMessage;
		endif;
	}
	#########################################################################################################################
	################################################		USER SECTION 		#############################################
	#########################################################################################################################
	/***********************************************************************
	 ** Function name : sendReservationMessage
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This is use for send Otp Sms To User
	 ** Date : 17 November 2022
	 ************************************************************************/
	function sendReservationMessage($MSGDATA)
	{ 
      //echo "<pre>"; print_r($MSGDATA);die;
	$guestName  = $MSGDATA['guest_name'];
	$templateID  = '1507166540013528637';
	$guestMobileNumber  = $MSGDATA['guest_mobile_number'];
	$bookingId  = $MSGDATA['booking_id'];
	$reminderDatetime  = date('d-m-Y H:i:s',strtotime($MSGDATA['reminder_datetime']));
	$reminderEndDatetime  = date('d-m-Y H:i:s',strtotime($MSGDATA['reminder_end_datetime']));
	$stayDuration  = $MSGDATA['stay_duration'];
	$noOfPerson  = $MSGDATA['no_of_person'];
	$roomType  = $MSGDATA['room_type'];
	$mealPlan  = $MSGDATA['meal_plan'];
	$paymentSummery  = $MSGDATA['payment_summery'];
	$hotelName  = $MSGDATA['vendor_business_name'];
	$hotelAddress  = $MSGDATA['vendor_address'];
    $reception  = $MSGDATA['first_manager_contact_number'];
		if (!empty($guestName)) :
			$message		=	"Dear $guestName,Thank you for choosing us. Your booking is confirmed at $hotelName and the details are as follows - Booking ID - $bookingId, Check in date & time- $reminderDatetime, Check out date & time- $reminderEndDatetime, Duration of stay - $stayDuration, Number of persons - $noOfPerson, Room Type- $roomType, Meal plan - $mealPlan, Payment Summary - $paymentSummery For any queries, changes or cancellations feel free to contact us at - $reception. We are delighted to serve you with a hassle-free stay & provide you a pleasurable experience at our hotel. Regards $hotelName, $hotelAddress, Team Mini Hotel Man MINIHM";
			$returnMessage	=	$this->sendSms($guestMobileNumber, $message,$templateID);
			return $returnMessage;
		endif;
	}
}