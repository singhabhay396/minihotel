<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Emailtemplate_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	/***********************************************************************
	 ** Function name : getVendorDataById
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for get Vendor Data By Id
	 ** Date : 26 MAY 2022
	 ************************************************************************/
	function getVendorDataById($vendorId = '')
	{
		$this->db->select('v.id,v.vendor_id,v.device_id,v.device_type,v.vendor_title,v.vendor_name,v.vendor_business_name,v.vendor_phone,v.vendor_email,v.first_manager_contact_number,vd.vendor_address');
		$this->db->from('vendor as v');
		$this->db->join('vendor_details as vd', 'vd.vendor_id = v.vendor_id', 'left');
		$this->db->where("v.vendor_id", $vendorId);
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : getAdminData
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for get Admin Data
	 ** Date : 24 MAY 2022
	 ************************************************************************/
	function getAdminData()
	{
		$this->db->select('admin_name,admin_display_name,admin_email_id,admin_mobile_number');
		$this->db->from('admin');
		$this->db->where("admin_id = '1'");
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : getEmailTemplateByMailType
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This is for get Email Template By Mail Type
	 ** Date : 24 MAY 2022
	 ************************************************************************/
	function getEmailTemplateByMailType($type = '')
	{
		$this->db->select('from_email,to_email,bcc_email,subject,mail_header,mail_body,mail_footer,html');
		$this->db->from('email_template');
		$this->db->where('mailTypeData', $type);
		$query = $this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}
	///////////////////////////////////////////////////////////////////////////////
	/////////////////////////////		ADMIN SECTION 		///////////////////////
	///////////////////////////////////////////////////////////////////////////////
	/***********************************************************************
	 ** Function name : sendPasswordRecoverMail
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for send Password Recover Mail
	 ** Date : 24 MAY 2022
	 ************************************************************************/
	function sendPasswordRecoverMail($result = array(), $param = array())
	{
		if (!empty($result['admin_email_id']) && !empty($param['admin_password_otp'])) :
			$MTData			=	$this->getEmailTemplateByMailType('AdminForgotPasswordMailToAdmin');
			$fromMail  		= 	MAIL_FROM_MAIL;
			$siteFullName	=	MAIL_SITE_FULL_NAME;
			$toMail  		= 	$result['admin_email_id'];
			$subject 		= 	$MTData['subject'];
			$sitefullurl	= 	base_url();
			#.............................. message section ............................#
			$MHData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_header']));
			$MBData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_body']));
			$MBData 		= 	str_replace('{USERNAME}', $result['admin_name'], $MBData);
			$MBData 		= 	str_replace('{USEROTP}', $param['admin_password_otp'], $MBData);
			$MBData 		= 	str_replace('{OTPPAGELINK}', $sitefullurl . 'password-recover', $MBData);
			$MFData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_footer']));
			$MHtml	 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['html']));
			$MHtml	 		= 	str_replace('{MAILERHEAD}', $MHData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERBODY}', $MBData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERFOOTER}', $MFData, $MHtml);
			$this->email->from($fromMail, $siteFullName);
			$this->email->to($toMail);
			if ($MTData['bcc_email']) :
				$this->email->bcc($MTData['bcc_email']);
			endif;
			$this->email->subject($subject);
			$this->email->set_mailtype('html');
			$this->email->message($MHtml);
			$this->email->send();
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : UserRegistrationMailToAdmin
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for User Registration Mail To Admin
	 ** Date : 24 MAY 2022
	 ************************************************************************/
	function UserRegistrationMailToAdmin($vendorId = '')
	{
		if (!empty($vendorId)) :
			$MTData			=	$this->getEmailTemplateByMailType('UserResignationMailToAdmin');
			$AdminData		=	$this->getAdminData();
			$UserData		=	$this->getVendorDataById($vendorId);
			$fromMail  		= 	MAIL_FROM_MAIL;
			$siteFullName	=	MAIL_SITE_FULL_NAME;
			$toMail  		= 	$AdminData['admin_email_id'];
			$subject 		= 	$MTData['subject'];
			$sitefullurl	= 	base_url();
			#.............................. message section ............................#
			$MHData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_header']));
			$MBData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_body']));
			$MBData 		= 	str_replace('{ADMINNAME}', $AdminData['admin_name'], $MBData);
			$MBData 		= 	str_replace('{VENDORBUSINESS}', $UserData['vendor_business_name'], $MBData);
			$MBData 		= 	str_replace('{VENDORPHONE}', $UserData['vendor_phone'], $MBData);
			$MBData 		= 	str_replace('{VENDOREMAIL}', $UserData['vendor_email'], $MBData);
			$MFData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_footer']));
			$MHtml	 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['html']));
			$MHtml	 		= 	str_replace('{MAILERHEAD}', $MHData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERBODY}', $MBData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERFOOTER}', $MFData, $MHtml);
      		//echo $MHtml;die;
			$this->smtp_mailer($siteFullName, $toMail, $toName, '', $subject, $MHtml, '');
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : UserRegistrationMailToUser
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for User Registration Mail To User
	 ** Date : 24 MAY 2022
	 ************************************************************************/
	function UserRegistrationMailToUser($vendorId = '', $userPassword = '', $userPasscode = '')
	{
		if (!empty($vendorId) && !empty($userPassword) && !empty($userPasscode)) :
      		//echo $vendorId.'--'.$userPassword.'--'.$userPasscode; die;
			$MTData			=	$this->getEmailTemplateByMailType('UserResignationMailToUser');
			$UserData		=	$this->getVendorDataById($vendorId);
			$fromMail  		= 	MAIL_FROM_MAIL;
			$siteFullName	=	MAIL_SITE_FULL_NAME;
			$toMail  		= 	$UserData['vendor_email'];
			$toName  		= 	$UserData['vendor_business_name'];
			$subject 		= 	$MTData['subject'];
			$sitefullurl	= 	base_url();
			#.............................. message section ............................#
			$MHData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_header']));
			$MBData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_body']));
			$MBData 		= 	str_replace('{VENDORNAME}', $UserData['vendor_business_name'], $MBData);
			$MBData 		= 	str_replace('{VENDORPHONE}', $UserData['vendor_phone'], $MBData);
			$MBData 		= 	str_replace('{VENDOREMAIL}', $UserData['vendor_email'], $MBData);
			$MBData 		= 	str_replace('{VENDORPASSWORD}', $userPassword, $MBData);
			$MBData 		= 	str_replace('{VENDORPASSCODE}', $userPasscode, $MBData);
			$MFData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_footer']));
			$MHtml	 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['html']));
			$MHtml	 		= 	str_replace('{MAILERHEAD}', $MHData, $MHtml);
			$MHtml			= 	str_replace('{MAILERBODY}', $MBData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERFOOTER}', $MFData, $MHtml);
			//echo "<pre>"; print_r($MHtml); die;
			// $bigbody=$MHtml;
     		$this->smtp_mailer($siteFullName, $toMail, $toName, '', $subject, $MHtml, '');
		endif;
	}
  	public function smtp_mailer($sitefullname = '', $tomail = '', $toname = '', $bcc_email = '', $subject = '', $body = '', $attachment = '')
	{ //echo $tomail.'---'.$bcc_email.'---'.$body;die;
		include_once APPPATH . 'third_party/mail/class.phpmailer.php';
		error_reporting(E_ALL ^ E_NOTICE);
		$mail                = 	new PHPMailer();
		$mail->IsSMTP(); // telling the class to use SMTP
		$mail->SMTPDebug = 2;
		$mail->Mailer = "smtp";
		$mail->Host          = 	"smtp.gmail.com";
		$mail->SMTPAuth      = 	true;                  // enable SMTP authentication
		$mail->SMTPSecure 	 = 	"tls";
		$mail->SMTPKeepAlive = 	true;                  // SMTP connection will not close after each email sent
		$mail->Port          = 	'587';
		$mail->Username      = 	"admin@minihotelman.com"; // SMTP account username
		$mail->Password      = 	"Dhangurutegbahadurji";        // SMTP account password
		$mail->SetFrom('admin@minihotelman.com', $sitefullname);
		//$mail->AddReplyTo('ashishumrao2@gmail.com', $sitefullname);
		$mail->Subject		= 	$subject;
		$mail->MsgHTML("$body");
        $mail->IsHTML(true);
		$mail->AddAddress($tomail, $toname);
		//if ($bcc_email) :
		//$this->email->bcc($bcc_email);
		//endif;
		if (!$mail->Send()) {
			echo 'Message was not sent.';
			echo 'Mailer error: ' . $mail->ErrorInfo;
		} else {
			echo 'Message has been sent.';
		}
	}
	/***********************************************************************
	 ** Function name : ContactUsMailToAdmin
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for Contact Us Mail To Admin
	 ** Date : 24 MAY 2022
	 ************************************************************************/
	function ContactUsMailToAdmin($userData = array())
	{
		if (!empty($userData['contact_f_name']) && !empty($userData['contact_email'])) :
			$MTData			=	$this->getEmailTemplateByMailType('ContactusMailToAdmin');
			$AdminData		=	$this->getAdminData();
			$fromMail  		= 	MAIL_FROM_MAIL;
			$siteFullName	=	MAIL_SITE_FULL_NAME;
			$toMail  		= 	$AdminData['admin_email_id'];
			$subject 		= 	$MTData['subject'];
			$sitefullurl	= 	base_url();
			#.............................. message section ............................#
			$MHData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_header']));
			$MBData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_body']));
			$MBData 		= 	str_replace('{ADMINNAME}', $AdminData['admin_name'], $MBData);
			$MBData 		= 	str_replace('{USERNAME}', $userData['contact_f_name'] . ' ' . $userData['contact_l_name'], $MBData);
			$MBData 		= 	str_replace('{USEREMAIL}', $userData['contact_email'], $MBData);
			$MBData 		= 	str_replace('{USERSUBJECT}', $userData['contact_reason'], $MBData);
			$MBData 		= 	str_replace('{USERMESSAGE}', $userData['contact_message'], $MBData);
			$MFData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_footer']));
			$MHtml	 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['html']));
			$MHtml	 		= 	str_replace('{MAILERHEAD}', $MHData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERBODY}', $MBData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERFOOTER}', $MFData, $MHtml);
			$this->email->from($fromMail, $siteFullName);
			$this->email->to($toMail);
			if ($MTData['bcc_email']) :
				$this->email->bcc($MTData['bcc_email']);
			endif;
			$this->email->subject($subject);
			$this->email->set_mailtype('html');
			$this->email->message($MHtml);
			$this->email->send();
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : sendVendorPasswordRecoverMailToAdmin
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for send Password Recover Mail
	 ** Date : 12 JULY 2022
	 ************************************************************************/
	function sendVendorPasswordRecoverMailToAdmin($result = array(), $newPassword)
	{
		if (!empty($result['vendor_email']) && !empty($newPassword)) :
			$MTData			=	$this->getEmailTemplateByMailType('ChangeVendorPassword');
			$fromMail  		= 	MAIL_FROM_MAIL;
			$siteFullName	=	MAIL_SITE_FULL_NAME;
			$toMail  		= 	$result['vendor_email'];
			$subject 		= 	$MTData['subject'];
			$sitefullurl	= 	base_url();
			#.............................. message section ............................#
			$MHData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_header']));
			$MBData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_body']));
			$MBData 		= 	str_replace('{VENDORNAME}', $result['vendor_business_name'], $MBData);
			$MBData 		= 	str_replace('{VENDORPHONE}', $result['vendor_phone'], $MBData);
			$MBData 		= 	str_replace('{VENDOREMAIL}', $result['vendor_email'], $MBData);
			$MBData 		= 	str_replace('{VENDORPASSWORD}', $newPassword, $MBData);
			$MFData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_footer']));
			$MHtml	 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['html']));
			$MHtml	 		= 	str_replace('{MAILERHEAD}', $MHData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERBODY}', $MBData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERFOOTER}', $MFData, $MHtml);
			$this->email->from($fromMail, $siteFullName);
			$this->email->to($toMail);
			if ($MTData['bcc_email']) :
				$this->email->bcc($MTData['bcc_email']);
			endif;
			$this->email->subject($subject);
			$this->email->set_mailtype('html');
			$this->email->message($MHtml);
			$this->email->send();
		endif;
	}	// END OF FUNCTION
  /***********************************************************************
	 ** Function name : sendReservationMessage
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for User Registration Mail To User
	 ** Date : 13 Desc 2022
	 ************************************************************************/
	function sendReservationMessage($result = array())
	{
		if (!empty($result['hotel_manager_id']) && !empty($result['guest_mobile_number'])) :
			$MTData			=	$this->getEmailTemplateByMailType('ReminderMessageApproval');     
			$UserData		=	$this->getVendorDataById($result['hotel_manager_id']);
			$fromMail  		= 	MAIL_FROM_MAIL;
			$siteFullName	=	MAIL_SITE_FULL_NAME;
			$toMail  		= 	$result['guest_email'];
			$toName  		= 	$UserData['vendor_business_name'];
			$subject 		= 	$MTData['subject'];
			$sitefullurl	= 	base_url();
			#.............................. message section ............................#
			$MHData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_header']));
			$MBData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_body']));
            $MBData 		= 	str_replace('{GUESTNAME}', $result['guest_name'], $MBData);
            $MBData 		= 	str_replace('{BUSINESSNAME}', $UserData['vendor_business_name'], $MBData);
			$MBData 		= 	str_replace('{BOOKINGID}', $result['booking_id'], $MBData);
			$MBData 		= 	str_replace('{CHECKINDATETIME}', $result['reminder_datetime'], $MBData);
			$MBData 		= 	str_replace('{CHECKOUTDATETIME}', $result['reminder_end_datetime'], $MBData);
			$MBData 		= 	str_replace('{DURATIONOFSTAY}', $result['stay_duration'], $MBData);
			$MBData 		= 	str_replace('{NUMBEROFPERSON}', $result['no_of_person'], $MBData);
			$MBData 		= 	str_replace('{ROOMRENT}', $result['room_rent'], $MBData);
			$MBData 		= 	str_replace('{ROOMTYPE}', $result['room_type'], $MBData);
			$MBData 		= 	str_replace('{MEALPLAN}', $result['meal_plan'], $MBData);
			$MBData 		= 	str_replace('{PAYMENTSUMMARY}', $result['payment_summery'], $MBData);
			//Add hotel name address,phone number			
//			$MBData 		= 	str_replace('{HOTELNAME}', $UserData['payment_summery'], $MBData);			
			$MBData 		= 	str_replace('{HOTELADDRESS}', $UserData['vendor_address'], $MBData);			
			$MBData 		= 	str_replace('{HOTELPHONENUMBER}', $UserData['first_manager_contact_number'], $MBData);
			//end			
			$MFData 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['mail_footer']));
			$MHtml	 		= 	str_replace('../../../../', $sitefullurl, stripslashes($MTData['html']));
			$MHtml	 		= 	str_replace('{MAILERHEAD}', $MHData, $MHtml);
			$MHtml			= 	str_replace('{MAILERBODY}', $MBData, $MHtml);
			$MHtml	 		= 	str_replace('{MAILERFOOTER}', $MFData, $MHtml);
			//echo $MHtml;die;
     		$this->smtp_mailer($siteFullName, $toMail, $toName, '', $subject, $MHtml, '');
		endif;
	}
}