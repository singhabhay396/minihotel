<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Ownerauth_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/* * *********************************************************************
	 * * Function name : Authenticate
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for Vendor Login Page
	 * * Date : 11 APRIL  2022
	 * * **********************************************************************/
	public function Authenticate($userEmail = '')
	{
		$this->db->select('ven.*, vende.vendor_address, vende.vendor_nationality,
						   vende.vendor_pan, vende.vendor_address_proof, vende.vendor_pincode,
						   vende.vendor_kyc_status,vende.bill_number');
		$this->db->from('vendor as ven');
		$this->db->join("vendor_details as vende", "ven.vendor_id=vende.vendor_id", "LEFT");
		$this->db->where('ven.vendor_email', $userEmail);
		$this->db->where('ven.parent_id', 0);
		//$this->db->or_where('ven.vendor_phone', $userEmail);
		$this->db->where("ven.vendor_type = 'Verified'");
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : getVendorDataByEmail
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for get Vendor Data By Email
	 * * Date : 11 APRIL  2022
	 * * **********************************************************************/
	public function getVendorDataByEmail($userEmail = '')
	{
		$this->db->select('sel.*, vende.vendor_address, vende.vendor_nationality,
						   vende.vendor_pan, vende.vendor_address_proof, vende.vendor_pincode,
						   vende.vendor_kyc_status');
		$this->db->from('vendor as sel');
		$this->db->join("vendor_details as vende", "sel.vendor_id=vende.vendor_id", "LEFT");
		$this->db->where('vendor_email', $userEmail);
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : encriptPassword
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for encript_password
	 * * Date : 11 APRIL  2022
	 * * **********************************************************************/
	public function encriptPassword($password)
	{
		return $this->encrypt->encode($password, $this->config->item('encryption_key'));
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : decryptsPassword
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for encript_password
	 * * Date : 11 APRIL  2022
	 * * **********************************************************************/
	public function decryptsPassword($password)
	{
		return $this->encrypt->decode($password, $this->config->item('encryption_key'));
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : checkVendorLoginCookie
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for check Vendor Login Cookie
	 * * Date : 11 APRIL  2022
	 * * **********************************************************************/
	public function checkVendorLoginCookie()
	{
		if ($_COOKIE['MHM_VENDOR_LOGIN_EMAIL']) :

			$result		=	$this->Authenticate($_COOKIE['MHM_VENDOR_LOGIN_PHONE']);
			if ($result) :
				if ($result['status'] == 'A' && $result['vendor_kyc_status'] == 'Y') :
					$vendorCurrentPath			=	base_url() . 'vendor/' . $result['vendor_slug'] . '/';

					$this->session->set_userdata(array(
						'MHM_VENDOR_LOGGED_IN' => true,
						'MHM_VENDOR_ID' => $result['vendor_id'],
						'MHM_VENDOR_SLUG' => $result['vendor_slug'],
						'MHM_VENDOR_TITLE' => $result['vendor_title'],
						'MHM_VENDOR_NAME' => $result['vendor_name'],
						'MHM_VENDOR_BUSINESS_NAME' => $result['vendor_business_name'],
						'MHM_VENDOR_PHONE' => $result['vendor_phone'],
						'MHM_VENDOR_EMAIL' => $result['vendor_email'],
						'MHM_VENDOR_IMAGE' => $result['vendor_image'],
						'MHM_VENDOR_CURRENT_PATH' => $vendorCurrentPath,
						'MHM_VENDOR_ADDRESS' => $result['vendor_address'],
						'MHM_VENDOR_NATIONALITY' => $result['vendor_nationality'],
						'MHM_VENDOR_PAN' => $result['vendor_pan'],
						'MHM_VENDOR_ADDRESS_PROOF' => $result['vendor_address_proof'],
						'MHM_VENDOR_PINCODE' => $result['vendor_pincode'],
						'MHM_VENDOR_KYC_STATUS' => $result['vendor_kyc_status'],
						'MHM_VENDOR_LAST_LOGIN' => $result['vendor_last_login'] . ' (' . $result['vendor_last_login_ip'] . ')'
					));

					setcookie('MHM_VENDOR_LOGIN_PHONE', $result['vendor_phone'], time() + 60 * 60 * 24 * 100, '/');

					if ($_COOKIE['MHM_VENDOR_REFERENCE_PAGES']) :
						redirect(base_url() . $_COOKIE['MHM_VENDOR_REFERENCE_PAGES']);
					else :
						redirect($vendorCurrentPath . 'dashboard');
					endif;
				endif;
			endif;
		endif;
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : authCheck
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for auth Check
	 * * Date : 11 APRIL  2022
	 * * **********************************************************************/
	public function authCheck()
	{
		if ($this->session->userdata('MHM_OWNER_ID') == "") :
			setcookie('MHM_VENDOR_REFERENCE_PAGES', uri_string(), time() + 60 * 60 * 24 * 5, '/');
			redirect(base_url() . 'owner');
		else :
			$result = $this->Authenticate(sessionData('MHM_OWNER_EMAIL'));
			if($result['status'] != 'A'){
				setcookie('MHM_OWNER_LOGIN_EMAIL', '', time() - 60 * 60 * 24 * 100, '/');
        setcookie('MHM_OWNER_REFERENCE_PAGES', '', time() - 60 * 60 * 24 * 100, '/');
        $this->session->unset_userdata(array(
            'MHM_OWNER_LOGGED_IN',
            'MHM_OWNER_ID',
            'MHM_OWNER_OWNER_PASSCODE',
            'MHM_OWNER_SLUG',
            'MHM_OWNER_TITLE',
            'MHM_OWNER_NAME',
            'MHM_OWNER_BUSINESS_NAME',
            'MHM_OWNER_PHONE',
            'MHM_OWNER_EMAIL',
            'MHM_OWNER_IMAGE',
            'MHM_OWNER_CURRENT_PATH',
            'MHM_OWNER_ADDRESS',
            'MHM_OWNER_NATIONALITY',
            'MHM_OWNER_PAN',
            'MHM_OWNER_ADDRESS_PROOF',
            'MHM_OWNER_PINCODE',
            'MHM_OWNER_KYC_STATUS',
            'MHM_OWNER_LAST_LOGIN',
        ));
        redirect(base_url() . 'owner/login');
			}else{
				return true;
			}
		endif;
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : checkOTP
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for Admin otp
	 * * Date : 11 APRIL  2022
	 * * **********************************************************************/
	public function checkOTP($userOtp = '')
	{
		$this->db->select('*');
		$this->db->from('vendor');
		$this->db->where('vendor_otp', $userOtp);
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
}