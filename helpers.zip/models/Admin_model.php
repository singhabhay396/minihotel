<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Admin_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/***********************************************************************
	 ** Function name : selectAdminData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select admin data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectAdminData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('adm.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectDepartmentData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Department Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectDepartmentData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('admdep.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectSubadminData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Subadmin Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectSubadminData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('adm.*, admt.admin_metadata_value as admin_type');
		$this->db->from($tblName);
		$this->db->join("admin_metadata as admt", "adm.encrypt_id=admt.admin_id", "LEFT");
		$this->db->join("admin_metadata as admta", "adm.encrypt_id=admta.admin_id", "LEFT");
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : getAdminDepartment
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for get Admin Department
	 ** Date : 08 April 2022
	 ************************************************************************/
	function getAdminDepartment($departmentId = '')
	{
		$html			=	'<option value="">Select Department Name</option>';
		$this->db->select('encrypt_id,department_name');
		$this->db->from('admin_department');
		$this->db->order_by("department_name ASC");
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			$data	=	$query->result_array();
			foreach ($data as $info) :
				if ($info['encrypt_id'] == $departmentId) :  $select = 'selected="selected"';
				else : $select = '';
				endif;
				$html		.=	'<option value="' . $info['encrypt_id'] . '" ' . $select . '>' . $info['department_name'] . '</option>';
			endforeach;
		endif;

		return $html;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectHomePageHeadingData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Home Page Heading Data
	 ** Date : 25 April 2022
	 ************************************************************************/
	function selectHomePageHeadingData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('hph.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectSelletData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Seller Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectSelletData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '',$grField='',$is_owner = 1)
	{
		$this->db->select('ven.*, vende.vendor_address, vende.vendor_nationality, vende.vendor_pan, vende.vendor_address_proof, vende.vendor_kyc_status');
		$this->db->from($tblName);
		$this->db->join("vendor_details as vende", "ven.vendor_id=vende.vendor_id", "LEFT");
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
       
	    if ($grField) :		$this->db->group_by($grField);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
        $this->db->where('is_owner', $is_owner);
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectHomeSliderData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Home Slider Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectHomeSliderData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('hslid.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectTestimonialData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Testimonial Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectTestimonialData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('teti.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectCmsPagesData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Cms Pages Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectCmsPagesData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('cms.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectSmallCmsData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Small Cms Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectSmallCmsData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('cms.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectMailTemplateData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Mail Template Data
	 ** Date : 08 April 2022
	 ************************************************************************/
	function selectMailTemplateData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('emlt.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectFeaturesData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Features Data
	 ** Date : 25 April 2022
	 ************************************************************************/
	function selectFeaturesData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('hph.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}

	/***********************************************************************
	 ** Function name : selectAdminMessageData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Features Data
	 ** Date : 07 May 2022
	 ************************************************************************/
	function selectAdminMessageData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('adm.*,v.vendor_business_name,a.admin_display_name');
		$this->db->from($tblName);
		$this->db->join('vendor as v', 'adm.hotel_manager_id = v.vendor_id', 'left');
		$this->db->join('admin as a', 'a.encrypt_id = adm.admin_id', 'left');
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}

	/***********************************************************************
	 ** Function name : getAllVendors
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for get All Vendors
	 ** Date : 09  MAY 2022
	 ************************************************************************/
	public function getAllVendors($assignVendorId = '')
	{
		$html = '';
		$this->db->select('vn.vendor_id,vn.vendor_name,vn.vendor_business_name');
		$this->db->from('vendor as vn');
		$this->db->where("vn.status = 'A'");
		$this->db->order_by("vn.vendor_name ASC");
		$query = $this->db->get();
		if ($query->num_rows() > 0) :
			$data = $query->result_array();
			foreach ($data as $info) :
				if ($info['vendor_id'] == $assignVendorId) : $select = 'selected="selected"';
				else : $select = '';
				endif;
				$html .= '<option value="' . $info['vendor_id'] . '" ' . $select . '>' . $info['vendor_business_name'] . '</option>';
			endforeach;
		endif;
		return $html;
	} // END OF FUNCTION


	 /***********************************************************************
     ** Function name : getAllOnboardHotels
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room Info
     ** Date : 21 May 2022
     ************************************************************************/
    public function getAllOnboardHotels()
    {
        $this->db->select('id');
        $this->db->from('vendor');
        $this->db->where('vendor_type = "Verified"');
        $this->db->where('status = "A"');
        $query = $this->db->get();
        return $query->num_rows();
    } // END OF FUNCTION

	    /***********************************************************************
     ** Function name : getVendorMessage
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room Info
     ** Date : 21 May 2022
     ************************************************************************/
    public function getVendorMessage($date='')
    {
        $this->db->select('id');
        $this->db->from('admin_individual_chat');
        $this->db->like('creation_date', $date);
        $this->db->where('admin_id', sessionData('MHM_ADMIN_ID'));
        $this->db->where('msg_flag_admin', 1);
        $query = $this->db->get();
        return $query->num_rows();

    } // END OF FUNCTION

	/***********************************************************************
	 ** Function name : selectQuotesData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Quotes Data
	 ** Date : 09 JUNE 2022
	 ************************************************************************/
	function selectQuotesData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('q.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}
//
	/***********************************************************************
	 ** Function name : selectPricePackageData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Quotes Data
	 ** Date : 20 JUNE 2022
	 ************************************************************************/
	function selectPricePackageData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('p.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}
    /***********************************************************************
	 ** Function name : selectReservvationData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Reservvation Data
	 ** Date : 20 Nov 2022
	 ************************************************************************/
	function selectReservvationData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
	{
		$this->db->select('cr.*,v.vendor_business_name');
		$this->db->from($tblName);
      	$this->db->join("vendor as v", "cr.hotel_manager_id=v.vendor_id", "LEFT");
        //$this->db->join("vendor_details as vd", "cr.hotel_manager_id=vd.vendor_id", "LEFT");
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
		$query = $this->db->get();
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}
  
  
   /***********************************************************************
	 ** Function name : selectReservvationData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Reservvation Data
	 ** Date : 20 Nov 2022
	 ************************************************************************/
 	public function getDataByParticularField($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select('cr.*,v.vendor_business_name,v.first_manager_contact_number,vd.vendor_address');
		$this->db->from($tableName);
      	$this->db->join("vendor as v", "cr.hotel_manager_id=v.vendor_id", "LEFT");
        $this->db->join("vendor_details as vd", "cr.hotel_manager_id=vd.vendor_id", "LEFT");
      	$this->db->where($fieldName, $fieldValue);
		$query = $this->db->get();
        //echo $this->db->last_query(); die;
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}
  
    /***********************************************************************
	 ** Function name : selectmessagehistory
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for select Reservvation Data
	 ** Date : 20 Nov 2022
	 ************************************************************************/
	function selectmessagehistory($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '',$editId='')
	{
		$this->db->select('cr.*');
		$this->db->from($tblName);
		if ($whereCon['where']) :	$this->db->where($whereCon['where']);
		endif;
		if ($whereCon['like']) :  $this->db->where($whereCon['like']);
		endif;
		if ($shortField) :		$this->db->order_by($shortField);
		endif;
		if ($numPage) :			$this->db->limit($numPage, $cnt);
		endif;
        $this->db->where('cr.hotel_manager_id',$editId);
		$query = $this->db->get();
        //echo $this->db->last_query(); die;
		if ($action == 'data') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		elseif ($action == 'count') :
			return $query->num_rows();
		endif;
	}
  

}
