<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Front_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }

    /***********************************************************************
     ** Function name : getCMSData
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for get CMS Data
     ** Date : 22 APRIL 2022
     ************************************************************************/
    function getCMSData($pageUrl = '')
    {
        $this->db->select('cms_id,title,content,seo_title,seo_keyword,seo_description');
        $this->db->from('cms');
        $this->db->where("page_url", $pageUrl);		$this->db->where("status='Y'");
        $query    =    $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    }    // END OF FUNCTION

    /***********************************************************************
     ** Function name : getCMSHeadingData
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for get CMS Heading Data
     ** Date : 25 APRIL 2022
     ************************************************************************/
    function getCMSHeadingData($type = '')
    {
        $this->db->select('heading_id,title,sub_title,content,video_url,image');
        $this->db->from('home_page_heading');
        $this->db->where("type", $type);		$this->db->where("status='Y'");
        $query    =    $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    }
    // END OF FUNCTION

    /***********************************************************************
     ** Function name : getSliderData
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for get Slider Data
     ** Date : 25 APRIL 2022
     ************************************************************************/
    function getSliderData($type = '')
    {
        $this->db->select('slider_id,title,sub_title,content,slider_image');
        $this->db->from('home_slider');		$this->db->where("status='Y'");
        $query    =    $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    }
    // END OF FUNCTION

    /***********************************************************************
     ** Function name : getTestimonialData
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for get Testimonial Data
     ** Date : 25 APRIL 2022
     ************************************************************************/
    function getTestimonialData($type = '')
    {
        $this->db->select('testimonial_id,name,content,image');
        $this->db->from('testimonial');		$this->db->where("status='Y'");
        $query    =    $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    }
    // END OF FUNCTION

    /***********************************************************************
     ** Function name : getCMSFeatureData
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for get CMS Heading Data
     ** Date : 25 APRIL 2022
     ************************************************************************/
    function getCMSFeatureData($type = '')
    {
        $this->db->select('heading_id,title,image');
        $this->db->from('home_page_heading');
        $this->db->where("type", $type);		$this->db->where("status='Y'");
        $query    =    $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    }
    // END OF FUNCTION

    /***********************************************************************
     ** Function name : getGeneralData
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for get CMS Data
     ** Date : 25 APRIL 2022
     ************************************************************************/
    function getGeneralData()
    {
        $this->db->select('small_cms_id,contact_email,contact_phone,contact_address,link1,link2,link3,link4');
        $this->db->from('small_cms');		$this->db->where("status='Y'");
        $query    =    $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    }    // END OF FUNCTION

     /***********************************************************************
     ** Function name : subscription
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for get subscription Data
     ** Date : 20 JUNE 2022
     ************************************************************************/
    function subscription()
    {
        $this->db->select('*');
        $this->db->from('package_plans');
        $query    =    $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    }    // END OF FUNCTION

}
