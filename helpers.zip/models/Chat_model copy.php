<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Chat_model extends CI_Model
{
    private $_request, $_response, $_query, $_post, $_server, $_cookies;
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
        $this->_request  = &$_REQUEST;
        $this->_query    = &$_GET;
        $this->_post     = &$_POST;
        $this->_server   = &$_SERVER;
        $this->_cookies  = &$_COOKIE;
    }
    const ACTION_POSTFIX = 'Action';
    const ACTION_DEFAULT = 'indexAction';

    /***********************************************************************
     ** Function name : dispatchActions
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function dispatchActions()
    {
        $action = $this->getQuery('action');
        if ($action && $action .= self::ACTION_POSTFIX) {
            if (method_exists($this, $action)) {
                $this->setResponse(
                    call_user_func(array($this, $action), array())
                );
            } else {
                $this->setHeader("HTTP/1.0 404 Not Found");
            }
        } else {
            $this->setResponse(
                call_user_func(array($this, self::ACTION_DEFAULT), array())
            );
        }
        return $this->_response;
    }
    /***********************************************************************
     ** Function name : render
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function render()
    {
        if ($this->_response) {
            if (is_scalar($this->_response)) {
                echo $this->_response;
            } else {
                throw new \Exception('Response content must be type scalar');
            }
            exit;
        }
    }
    /***********************************************************************
     ** Function name : getQuery
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function getQuery($param = null, $default = null)
    {
        if ($param) {
            return isset($this->_query[$param]) ?
                $this->_query[$param] : $default;
        }
        return $this->_query;
    }
    /***********************************************************************
     ** Function name : setResponse
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function setResponse($content)
    {
        $this->_response = $content;
    }
    /***********************************************************************
     ** Function name : setHeader
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function setHeader($params)
    {
        if (!headers_sent()) {
            if (is_scalar($params)) {
                header($params);
            } else {
                foreach ($params as $key => $value) {
                    header(sprintf('%s: %s', $key, $value));
                }
            }
        }
        return $this;
    }
    /***********************************************************************
     ** Function name : getMessages
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function getMessages($limit = CHAT_HISTORY, $reverse = true)
    {
        $response = $this->db->query("(SELECT * FROM mhmholets_admin_messages
            ORDER BY `date` DESC LIMIT $limit) ORDER BY `date` ASC");
        return $response->result();
    }
    /***********************************************************************
     ** Function name : addMessage
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function addMessage($username, $message, $ip, $userimage)
    {
        $username = addslashes($username);
        $message = addslashes($message);
        $userimage = addslashes($userimage);

        return (bool) $this->db->query("INSERT INTO mhmholets_admin_messages
            VALUES (NULL, '{$username}', '{$message}','{$userimage}', '{$ip}', NOW())");
    }
    /***********************************************************************
     ** Function name : addMessageAdmin
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function addMessageAdmin($adminname, $message, $ip, $userimage)
    {
        $username = addslashes($adminname);
        $message = addslashes($message);
        $userimage = addslashes($userimage);
        return (bool) $this->db->query("INSERT INTO mhmholets_admin_messages
            VALUES (NULL, '{$username}', '{$message}','{$userimage}', '{$ip}', NOW())");
    }
    /***********************************************************************
     ** Function name : removeMessages
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function removeMessages()
    {
        return (bool) $this->db->query("TRUNCATE TABLE mhmholets_admin_messages");
    }
    /***********************************************************************
     ** Function name : removeOldMessages
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function removeOldMessages($limit = CHAT_HISTORY)
    {
        return (bool)$query = $this->db->query("SELECT `id` FROM mhmholets_admin_messages ORDER BY DATE DESC LIMIT $limit");
        if ($query->num_rows() > 0) :
            $data    =    $query->result_array();
            foreach ($data as  $value) :
                $this->db->where_not_in('id', $value['id']);
                $this->db->delete('mhmholets_admin_messages');
            endforeach;
        endif;
    }
    /***********************************************************************
     ** Function name : getOnline
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function getOnline($count = true, $timeRange = CHAT_ONLINE_RANGE)
    {
        if ($count) {
            $response = $this->db->query("SELECT count(*) as total FROM mhmholets_online_user");
            return $response->result_array();
        }
        $response = $this->db->query("SELECT ip FROM mhmholets_online_user");
        $result = $response->result_array();
        return $result;
    }

    /***********************************************************************
     ** Function name : updateOnline
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function updateOnline($hash, $ip)
    {
        return (bool) $this->db->query("REPLACE INTO mhmholets_online_user
            VALUES ('{$hash}', '{$ip}', NOW())") or die(mysqli_connect_error());
    }
    /***********************************************************************
     ** Function name : clearOffline
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function clearOffline($timeRange = CHAT_ONLINE_RANGE)
    {
        return (bool) $this->db->query("DELETE FROM mhmholets_online_user
            WHERE last_update <= (NOW() - INTERVAL {$timeRange} MINUTE)");
    }
    /***********************************************************************
     ** Function name : getCookie
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function getCookie($param = null, $default = null)
    {
        if ($param) {
            return isset($this->cookies[$param]) ?
                $this->cookies[$param] : $default;
        }
        return $this->_cookies;
    }
    /***********************************************************************
     ** Function name : getModel
     ** Developed By : Ashish UMrao

     ** Date : 11  MAY 2022
     ************************************************************************/
    public function getModel()
    {
        if ($this->_defaultModel && class_exists($this->_defaultModel)) {
            return new $this->_defaultModel;
        }
    }
    /***********************************************************************
     ** Function name : sanitize
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function sanitize($string, $quotes = ENT_QUOTES, $charset = 'utf-8')
    {
        return htmlentities($string, $quotes, $charset);
    }
    /***********************************************************************
     ** Function name : addData
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function indexAction()
    {
        return null;
    }
    /***********************************************************************
     ** Function name : setModel
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function setModel($namespace)
    {
        $this->_defaultModel = $namespace;
        return $this;
    }
    /***********************************************************************
     ** Function name : setSession
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function setSession($key, $value)
    {
        $_SESSION[$key] = $value;
        return $this;
    }
    /***********************************************************************
     ** Function name : setCookie
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function setCookie($key, $value, $seconds = 3600)
    {
        $this->_cookies[$key] = $value;
        if (!headers_sent()) {
            setcookie($key, $value, time() + $seconds);
            return $this;
        }
    }
    /***********************************************************************
     ** Function name : getRequest
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function getRequest($param = null, $default = null)
    {
        if ($param) {
            return isset($this->_request[$param]) ?
                $this->_request[$param] : $default;
        }
        return $this->_request;
    }
    /***********************************************************************
     ** Function name : getPost
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function getPost($param = null, $default = null)
    {
        if ($param) {
            return isset($this->_post[$param]) ?
                $this->_post[$param] : $default;
        }
        return $this->_post;
    }
    /***********************************************************************
     ** Function name : getServer
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function getServer($param = null, $default = null)
    {
        if ($param) {
            return isset($this->_server[$param]) ?
                $this->_server[$param] : $default;
        }
        return $this->_server;
    }
    /***********************************************************************
     ** Function name : getSession
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function getSession($param = null, $default = null)
    {
        if ($param) {
            return isset($this->_session[$param]) ?
                $this->_session[$param] : $default;
        }
        return $this->_session;
    }
    /***********************************************************************
     ** Function name : listAction
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function listAction()
    {
        $this->setHeader(array('Content-Type' => 'application/json'));
        $messages = $this->getMessages();
        if ($messages <> "") {
            foreach ($messages as &$message) {
                $message->me = $this->getServer('REMOTE_ADDR') === $message->ip;
            }
        }
        return json_encode($messages);
    }
    /***********************************************************************
     ** Function name : saveAction
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function saveAction()
    {
        $username = $this->getPost('username');
        $userimage = $this->getPost('userimage');
        $message = $this->getPost('message');
        $ip             = currentIp();
        //$this->setCookie('username', $username, 9999 * 9999);

        $result = array('success' => false);
        if ($username && $message && $userimage) {
            $cleanUsername = $username;
            $result = array(
                'success' => $this->addMessage($cleanUsername, $message, $ip, $userimage)
            );
        }

        if ($this->isAdmin($username)) {
            $this->parseAdminCommand($username,$message,$userimage);
        }
        $this->setHeader(array('Content-Type' => 'application/json'));
        return json_encode($result);
    }
    /***********************************************************************
     ** Function name : isAdmin
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    private function isAdmin()
    {
        $Adminname = "adm123_ Weblieu";
        $pattern = '/^'.ADMIN_USERNAME_PREFIX.'/i';
        return preg_match($pattern, $Adminname);
    }
    /***********************************************************************
     ** Function name : parseAdminCommand
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    private function parseAdminCommand($username,$message,$userimage)
    {
        if ($message == '/clear') {
            $this->removeMessages();
            return true;
        }
        if ($message == '/online') {
            $online = $this->getOnline(true);
            $ipArr = array();
            foreach ($online as $item) {
                $ipArr[] = $item['ip'];
            }
            $message = 'Online: ' . implode(", ", $ipArr);
            $this->addMessageAdmin($username, $message,currentIp(),$userimage);
            return true;
        }
    }
    /***********************************************************************
     ** Function name : getMyUniqueHash
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    private function getMyUniqueHash()
    {
        $unique  = $this->getServer('REMOTE_ADDR');
        $unique .= $this->getServer('HTTP_USER_AGENT');
        $unique .= $this->getServer('HTTP_ACCEPT_LANGUAGE');
        return md5($unique);
    }
    /***********************************************************************
     ** Function name : pingAction
     ** Developed By : Ashish UMrao
     ** Date : 11  MAY 2022
     ************************************************************************/
    public function pingAction()
    {
        $ip = currentIp();
        $hash = $this->getMyUniqueHash();
        $this->updateOnline($hash, $ip);
        $this->clearOffline();
        $this->removeOldMessages();
        $onlines = $this->getOnline();
        $this->setHeader(array('Content-Type' => 'application/json'));
        return json_encode($onlines);
    }
}