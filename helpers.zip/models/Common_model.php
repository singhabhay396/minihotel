<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Common_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}
	/***********************************************************************
	 ** Function name : addData
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for add data
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function addData($tableName = '', $param = array())
	{
		$this->db->insert($tableName, $param);
		return $this->db->insert_id();
	}	// END OF FUNCTION
	/* * *********************************************************************
	 * * Function name : editData
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for edit data
	 * * Date : 14 APRIL 2022
	 * * **********************************************************************/
	function editData($tableName = '', $param = '', $fieldName = '', $fieldVallue = '')
	{
		$this->db->where($fieldName, $fieldVallue);
		$this->db->update($tableName, $param);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : editDataByMultipleCondition
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for edit data by multiple condition
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function editDataByMultipleCondition($tableName = '', $param = array(), $whereCondition = array())
	{
		$this->db->where($whereCondition);
		$this->db->update($tableName, $param);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : deleteData
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for delete data
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function deleteData($tableName = '', $fieldName = '', $fieldVallue = '')
	{
		$this->db->delete($tableName, array($fieldName => $fieldVallue));
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : deleteParticularData
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for delete particular data
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function deleteParticularData($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->delete($tableName, array($fieldName => $fieldValue));
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : deleteParticularVenodrData
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for delete particular data
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function deleteParticularVenodrData($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->delete($tableName, array($fieldName => $fieldValue));
		$this->db->delete('vendor_details', array($fieldName => $fieldValue));
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : deleteByMultipleCondition
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for delete by multiple condition
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	function deleteByMultipleCondition($tableName = '', $whereCondition = array())
	{
		$this->db->delete($tableName, $whereCondition);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getDataByParticularField
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get data by encryptId
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getDataByParticularField($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select('*');
		$this->db->from($tableName);
		$this->db->where($fieldName, $fieldValue);
		$query = $this->db->get();
		//echo $this->db->last_query(); die;
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getDataByQuery
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get data by query
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getDataByQuery($action = '', $query = '', $from = '')
	{
		$query = $this->db->query($query);
		if ($from == 'procedure') :
			mysqli_next_result($this->db->conn_id);
		endif;
		if ($action == 'count') :
			return $query->num_rows();
		elseif ($action == 'single') :
			if ($query->num_rows() > 0) :
				return $query->row_array();
			else :
				return false;
			endif;
		elseif ($action == 'multiple') :
			if ($query->num_rows() > 0) :
				return $query->result_array();
			else :
				return false;
			endif;
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getFieldInArray
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get data by condition
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getFieldInArray($field = '', $query = '')
	{
		$returnarray			=	array();
		$query = $this->db->query($query);
		if ($query->num_rows() > 0) :
			$data	=	$query->result_array();
			foreach ($data as $info) :
				array_push($returnarray, trim($info[$field]));
			endforeach;
		endif;
		return $returnarray;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getTwoFieldsInArray
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get Two Fields In Array
	 ** Date : 22  MAY 2022
	 ************************************************************************/
	public function getTwoFieldsInArray($firstField = '', $secondField = '', $query = '')
	{
		$returnarray			=	array();
		$query = $this->db->query($query);
		if ($query->num_rows() > 0) :
			$data	=	$query->result_array();
			foreach ($data as $info) :
				array_push($returnarray, array($firstField => trim($info[$firstField]), $secondField => trim($info[$secondField])));
			endforeach;
		endif;
		return $returnarray;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getParticularDataByFields
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get particular data by fields
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getParticularDataByFields($selectField = '', $tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select($selectField);
		$this->db->from($tableName);
		$this->db->where($fieldName, ucfirst(strtolower($fieldValue)));
		$this->db->or_where($fieldName, strtolower($fieldValue));
		$query = $this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getLastOrderByFields
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get Last Order By Fields
	 ** Date : 14 MAY 2022
	 ************************************************************************/
	public function getLastOrderByFields($selectField = '', $tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select($selectField);
		$this->db->from($tableName);
		if ($fieldName && $fieldValue) :
			$this->db->where($fieldName, $fieldValue);
		endif;
		$this->db->order_by($selectField . ' DESC');
		$this->db->limit(1);
		$query = $this->db->get();
		if ($query->num_rows() > 0) :
			$data 	=	$query->row_array();
			return $data[$selectField];
		else :
			return 0;
		endif;
	}	// END OF FUNCTION
	/* * *********************************************************************
	 * * Function name : setAttributeInUse
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for set Attribute In Use
	 * * Date : 20 MAY 2022
	 * * **********************************************************************/
	function setAttributeInUse($tableName = '', $param = '', $fieldName = '', $fieldValue = '')
	{
		$paramarray[$param]	=	'Y';
		$this->db->where($fieldName, $fieldValue);
		$this->db->update($tableName, $paramarray);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name : increaseDecreaseCountByQuery
	 ** Developed By : Ashish UMrao
	 ** Purpose  : This function used for increase Decrease Count By Query
	 ** Date : 06 SEPTEMBER 2018
	 ************************************************************************/
	function increaseDecreaseCountByQuery($query = '')
	{
		$this->db->query($query);
		return true;
	}	// END OF FUNCTION
	/***********************************************************************
	 ** Function name: getArrayDataByParticularField
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get data by encryptId
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getArrayDataByParticularField($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select('*');
		$this->db->from($tableName);
		$this->db->where($fieldName, $fieldValue);
		$query = $this->db->get();
		if ($query->num_rows() > 0) :
			return $query->result_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	/***********************************************************************
	** Function name : getAllGuestDataForExcel
	** Developed By : Ashish Umrao
	** Purpose  : This function used for get All Guest Data For Excel
	** Date : 25 SEPTEMBER 2022
	************************************************************************/
	public function getAllGuestDataForExcelDownload($vendorId, $fromDate = '', $toDate = '', $businessType = '')
	{
		$toDate = date('Y-m-d', strtotime($toDate));
		$fromDate = date('Y-m-d', strtotime($fromDate));
		$this->db->select('csb.summary_book_id,cbb.customer_id,csb.hotel_manager_id,csb.customer_name,csb.check_in_datetime,
        csb.check_out_datetime,csb.assign_room_number,csb.entry_number,csb.gst_number,csb.company_name,cbb.bill_generated_date,
        cbb.bill_number,csb.amount as roomrent,rn.room_no,SUM(cbb.bill_amount) as totalRoomRent,csb.room_rent_type as gstType,
		om.ots_name,cbb.page_source,csb.number_of_person,COUNT(cbb.customer_id) as totalDays');
		$this->db->from('custom_bill_book as cbb');
		$this->db->join('customer_summary_book as csb', 'csb.summary_book_id = cbb.customer_id', 'left');
		$this->db->join('ots_master as om', 'csb.ots_id = om.ots_id', 'left');
		$this->db->join('room_number as rn', 'csb.assign_room_number = rn.room_id', 'left');
		if ($fromDate != '1970-01-01' && $toDate != '1970-01-01') {
			$this->db->where("csb.check_out_datetime BETWEEN '$fromDate' AND '$toDate'");
		}
		$this->db->where('csb.check_out_datetime !=', 'NULL');
		if ($businessType == "B2B") {
			$this->db->where('csb.gst_number !=', '');
		} elseif ($businessType == "BTC") {
			$this->db->where('csb.gst_number' == '');
		}
		$this->db->where('cbb.page_source', 'extend_stay');
		$this->db->where('csb.hotel_manager_id', $vendorId);
		$this->db->order_by("csb.check_out_datetime DESC");
		$this->db->group_by('cbb.customer_id');
		$query	=	$this->db->get();
		//echo $this->db->last_query();die;
		if ($query->num_rows() > 0) :
			return $query->result_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION

  	/***********************************************************************
	 ** Function name : getFoodBillTotalAmount
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for get All Guest Data For Excel
	 ** Date : 25 SEPTEMBER 2022
	 ************************************************************************/
	public function getFoodBillTotalAmount($customerId='')
	{ 
		$this->db->select('SUM(cbb.bill_amount) as totalfoodbill,cbb.page_source');
		$this->db->from('custom_bill_book as cbb');
		$this->db->where('cbb.page_source', 'add_a_service');
		$this->db->where('cbb.customer_id', $customerId);
		$this->db->group_by('cbb.customer_id');
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
	function UpdateBillBookServiceCheck($GetBookID = array()){
		$this->db->where('hotel_manager_id',sessionData('MHM_VENDOR_ID'));
		$this->db->where_in('customer_id',$GetBookID);
		$this->db->update('custom_bill_book', ['service_check'=>0]);
		return true;
	}
  function UpdateBillBookServiceChecked($Save,$service_id){
    //echo $service_id.'***';
    //echo '<pre>';print_r($Save);echo '</pre>';
    //$UpdateWhere['id'] = $service_id;
    //$this->db->where('hotel_manager_id',sessionData('MHM_VENDOR_ID'));
    $this->db->where('id',$service_id);
		$this->db->update('custom_bill_book', $Save);
    //echo $this->db->last_query();
		return true;
	}
	public function selectwhatsapplisting($action,$tblName,$whereCon,$shortField, $numPage, $cnt, $vendor_id,$msg_type,$status){
      $this->db->select('*');
      $this->db->from($tblName);
      if ($whereCon['where']) : $this->db->where($whereCon['where']);
      endif;
      if ($whereCon['like']) : $this->db->where($whereCon['like']);
      endif;
      if ($shortField) : $this->db->order_by($shortField,'desc');
      endif;
      if ($numPage) : $this->db->limit($numPage, $cnt);
      endif;
      if($vendor_id!='All'){
        $this->db->where('vendor_id', $vendor_id);
      }
      if($status != 'All'){
      	 $this->db->where('status', $status);
      }
      if($msg_type!='All'){
        $this->db->where('msg_type', $msg_type);
      }
      $query = $this->db->get();
      //print_r($this->db->last_query());die;
      if ($action == 'data') :
          if ($query->num_rows() > 0) :
              return $query->result_array();
          else :
              return false;
          endif;
      elseif ($action == 'count') :
          return $query->num_rows();
      endif;
    }
  function CheckVendorWhatsApp(){
  	$whereCon['where'] = "vendor_id = '" . sessionData('MHM_VENDOR_ID') . "' ";
  	$this->db->select('whatsapp_checkin,whatsapp_checkout,whatsapp_bulk');
    $this->db->from('vendor');
    $this->db->where($whereCon['where']);
    $query = $this->db->get();
    $row = $query->row_array();
    return $row;
  }
  function CheckOwnerWhatsApp(){
  	$whereCon['where'] = "vendor_id = '" . sessionData('MHM_OWNER_ID') . "' ";
  	$this->db->select('whatsapp_checkin,whatsapp_checkout,whatsapp_bulk');
    $this->db->from('vendor');
    $this->db->where($whereCon['where']);
    $query = $this->db->get();
    $row = $query->row_array();
    return $row;
  }
  function CoutnTotalWhatsapp(){
  	$LoginVenderId = sessionData('MHM_VENDOR_ID');
    $VendorDetails = $this->getDataByParticularField('vendor', 'vendor_id', $LoginVenderId);
  	$this->db->select('id');
    $this->db->from('customer_whatsapp');
    $this->db->where('vendor_id', $VendorDetails['id']);
    $this->db->where('status', 1);
    $query = $this->db->get();
    //print_r($this->db->last_query());
    return $query->num_rows();
  }  
	function CheckOutMsg($custId){
    $CheckWhatsApp = $this->CheckVendorWhatsApp();
    if($CheckWhatsApp['whatsapp_checkin'] == 1){
    	$LoginVenderId = sessionData('MHM_VENDOR_ID');
	    $VendorDetails = $this->getDataByParticularField('vendor', 'vendor_id', $LoginVenderId);
	    $customer = $this->getDataByParticularField('customer_summary_book', 'encrypt_id', $custId);
	    $checkOut = date("d M Y",strtotime($customer['check_in_datetime']));
	    $mobile = '91'.$customer['customer_mobile_number'];
	    $Name = $customer['customer_name'] ?? '';
	    $VendorPhone = $VendorDetails['first_manager_contact_number'] ?? '';
	    $BusinessName = $VendorDetails['vendor_business_name'] ?? '';
	    $FeedbackLink = $VendorDetails['feedback_link'] ?? '';
	    $contact_owner = $VendorDetails['contact_owner'] ?? '';

	    $msg = 'Hi '.$Name.'<br/>Thank you for staying with us. 😀<br/>For your next visit you can book directly and get best offers!<br/>Call at '.$VendorPhone.' to book.<br/>In the meantime, can you please help us by giving an awesome feedback?<br/>Link - '.$FeedbackLink.'<br/><br/>Regards<br/>'.$BusinessName;
	    	
	    $SaveTemplate['msg'] = htmlentities($msg);
	    $SaveTemplate['vendor_id'] = $VendorDetails['id'];
	    $SaveTemplate['customer_id'] = $customer['id'];
	    $SaveTemplate['customer_mobile'] = $mobile;
	    $SaveTemplate['customer_name'] = $Name;
	    $SaveTemplate['vendor_phone'] = $VendorPhone;
	    $SaveTemplate['business_name'] = $BusinessName;
	    $SaveTemplate['msg_type'] = 'CheckOut';
	    $SaveTemplate['add_date'] = date('Y-m-d H:i:s');
	    //$this->addData('customer_whatsapp', $SaveTemplate);
	    $curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => 'https://backend.aisensy.com/campaign/t1/api/v2',
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => '',
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => 'POST',
			  CURLOPT_POSTFIELDS =>'{
				    "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2MDZhMTlkOTAwNWJkMGI2ZjRkMWY0ZSIsIm5hbWUiOiJNaW5pIEhvdGVsIE1hbiBCdXNpbmVzcyBTb2x1dGlvbnMgIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2MDZhMTlkOTAwNWJkMGI2ZjRkMWY0NyIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzExNzEwNjIxfQ.dq1TvNetzpPoSMqWGv4OBLBbkpbr-60BnkxBYq1cH1o",
				    "campaignName": "check-out",
				    "destination": "'.$mobile.'",
				    "userName": "Mini Hotel Man Business Solutions ",
				    "templateParams": ["'.$Name.'","'.$checkOut.'","'.$VendorPhone.'","'.$FeedbackLink.'","'.$BusinessName.'"],
			      	"source": "new-landing-page form",
			      	  "media": {},
  					"buttons": [],
  					"carouselCards": []
				}',
			  CURLOPT_HTTPHEADER => array(
			    'Content-Type: application/json'
			  ),
			));
	  
			$response = curl_exec($curl);
			curl_close($curl);
			$Result = json_decode($response,true);
			$Status = $Result['messaging_product'] ?? 'Error';
			$whatsapp_id = $Result['messages'][0]['id'] ?? '';
			$SaveTemplate['whatsapp_id'] 	= isset($Result['submitted_message_id']) ? $Result['submitted_message_id'] :'';
			$SaveTemplate['status'] 			= !empty($Result['success']) ? 1:0;
			$this->addData('customer_whatsapp', $SaveTemplate);
			//echo '<pre>';print_r($Result);echo '<pre>';
		}
	}
	function CheckInMsg($custId){
		$CheckWhatsApp = $this->CheckVendorWhatsApp();
    if($CheckWhatsApp['whatsapp_checkin'] == 1){

	    $LoginVenderId = sessionData('MHM_VENDOR_ID');
	    $VendorDetails = $this->getDataByParticularField('vendor', 'vendor_id', $LoginVenderId);
	    $customer = $this->getDataByParticularField('customer_summary_book', 'encrypt_id', $custId);
	    
	    $mobile = '91'.$customer['customer_mobile_number'];
	    //$mobile = '919871659388';
	    $Name = $customer['customer_name'] ?? '';
	    $amount = $customer['amount'] ?? '';
	    $VendorPhone = $VendorDetails['first_manager_contact_number'] ?? '';
	    $BusinessName = $VendorDetails['vendor_business_name'] ?? '';
	    $contact_owner = $VendorDetails['contact_owner'] ?? '.';
	    $feedback_link = $VendorDetails['feedback_link'] ?? '.';

	    
	    $msg = 'Hello '.$Name.'<br/>Welcome to '.$BusinessName.' 🙏<br/>Thank you for choosing us!<br/>We hope you have a wonderful stay at our property. 😍<br/>Your room rent per day is - ₹ '.$amount.'<br/>If you need anything,<br/>please contact reception at - '.$VendorPhone.'<br/>If you have any complaints/feedbacks, please contact owner at - '.$contact_owner.'<br/>Regards<br/>'.$BusinessName.'<br/>😀';

	    $SaveTemplate['msg'] = htmlentities($msg);
	    $SaveTemplate['vendor_id'] = $VendorDetails['id'];
	    $SaveTemplate['customer_id'] = $customer['id'];
	    $SaveTemplate['customer_mobile'] = $mobile;
	    $SaveTemplate['customer_name'] = $Name;
	    $SaveTemplate['vendor_phone'] = $VendorPhone;
	    $SaveTemplate['business_name'] = $BusinessName;
	    $SaveTemplate['msg_type'] = 'CheckIn';
	    $SaveTemplate['add_date'] = date('Y-m-d H:i:s');
	    //$this->addData('customer_whatsapp', $SaveTemplate);
	    $curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => 'https://backend.aisensy.com/campaign/t1/api/v2',
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => '',
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => 'POST',
			  CURLOPT_POSTFIELDS =>'{
				    "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2MDZhMTlkOTAwNWJkMGI2ZjRkMWY0ZSIsIm5hbWUiOiJNaW5pIEhvdGVsIE1hbiBCdXNpbmVzcyBTb2x1dGlvbnMgIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2MDZhMTlkOTAwNWJkMGI2ZjRkMWY0NyIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzExNzEwNjIxfQ.dq1TvNetzpPoSMqWGv4OBLBbkpbr-60BnkxBYq1cH1o",
				    "campaignName": "Mini Hotel",
				    "destination": "'.$mobile.'",
				    "userName": "Mini Hotel Man Business Solutions ",
				    "templateParams": ["'.$Name.'","'.$BusinessName.'","'.$amount.'","'.$VendorPhone.'","'.$contact_owner.'","'.$BusinessName.'"],
			      	"source": "new-landing-page form",
			      	  "media": {},
  					"buttons": [],
  					"carouselCards": []
				}',
			  CURLOPT_HTTPHEADER => array(
			    'Content-Type: application/json'
			  ),
			));
			$response = curl_exec($curl);
			curl_close($curl);
			$Result = json_decode($response,true);
			$Status = $Result['messaging_product'] ?? 'Error';
			$whatsapp_id = $Result['messages'][0]['id'] ?? '';
			$SaveTemplate['whatsapp_id'] 	= isset($Result['submitted_message_id']) ? $Result['submitted_message_id'] :'';
			$SaveTemplate['status'] 			= !empty($Result['success']) ? 1:0;
			$this->addData('customer_whatsapp', $SaveTemplate);
		}
	}
	function CheckInMsgOld($custId){
		$CheckWhatsApp = $this->CheckVendorWhatsApp();
    if($CheckWhatsApp['whatsapp_checkin']==1){

	    $LoginVenderId = sessionData('MHM_VENDOR_ID');
	    $VendorDetails = $this->getDataByParticularField('vendor', 'vendor_id', $LoginVenderId);
	    $customer = $this->getDataByParticularField('customer_summary_book', 'encrypt_id', $custId);
	    
	    $mobile = '91'.$customer['customer_mobile_number'];
	    //$mobile = '919871659388';
	    $Name = $customer['customer_name'] ?? '';
	    $VendorPhone = $VendorDetails['first_manager_contact_number'] ?? '';
	    $BusinessName = $VendorDetails['vendor_business_name'] ?? '';

	    $msg = 'Hi '.$Name.'<br/>Thank you for choosing us. 😀<br/>We hope you have a wonderful stay at our property. If you have any queries,<br/>contact reception at - '.$VendorPhone.'<br/><br/>Regards<br/>'.$BusinessName.'<br/>Sent by mentioned hotel. MHM Software holds no liability.';
	    $SaveTemplate['msg'] = htmlentities($msg);
	    $SaveTemplate['vendor_id'] = $VendorDetails['id'];
	    $SaveTemplate['customer_id'] = $customer['id'];
	    $SaveTemplate['customer_mobile'] = $mobile;
	    $SaveTemplate['customer_name'] = $Name;
	    $SaveTemplate['vendor_phone'] = $VendorPhone;
	    $SaveTemplate['business_name'] = $BusinessName;
	    $SaveTemplate['msg_type'] = 'CheckIn';
	    $SaveTemplate['add_date'] = date('Y-m-d H:i:s');
	    //$this->addData('customer_whatsapp', $SaveTemplate);

	    $curl = curl_init();
			curl_setopt_array($curl, array(
			  CURLOPT_URL => 'https://waba.com.bot/cloud/v1/messages',
			  CURLOPT_RETURNTRANSFER => true,
			  CURLOPT_ENCODING => '',
			  CURLOPT_MAXREDIRS => 10,
			  CURLOPT_TIMEOUT => 0,
			  CURLOPT_FOLLOWLOCATION => true,
			  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  CURLOPT_CUSTOMREQUEST => 'POST',
			  CURLOPT_POSTFIELDS =>'{
			    "to": "'.$mobile.'",
			    "recipient_type": "individual",
			    "type": "template",
			    "template": {"language": {"policy": "deterministic","code": "en"},
			      "name": "customer_check_in_msg",
			      "components": [{"type": "body","parameters": [{"type": "text","text": "'.$Name.'"},{"type": "text","text": "'.$VendorPhone.'"},{"type": "text","text": "'.$BusinessName.'"}]}]
			    }
			}',
			  CURLOPT_HTTPHEADER => array(
			    'API-KEY: 64fc26d750c97e2a108574b5',
			    'Content-Type: application/json'
			  ),
			));
			$response = curl_exec($curl);
			curl_close($curl);
			$Result = json_decode($response,true);
			$Status = $Result['messaging_product'] ?? 'Error';
			$whatsapp_id = $Result['messages'][0]['id'] ?? '';
			$SaveTemplate['whatsapp_id'] 	= $whatsapp_id;
			$SaveTemplate['status'] 			= 0;
			$this->addData('customer_whatsapp', $SaveTemplate);
			//echo '<pre>';print_r($Result);echo '<pre>';
		}
	}

    function BulkMsg($BulkData){

		$CheckWhatsApp = $this->CheckVendorWhatsApp();
		
		if($CheckWhatsApp['whatsapp_bulk'] == 1){
		    $LoginVenderId = $BulkData['vendor_id'];
		    $VendorDetails = $this->getDataByParticularField('vendor', 'vendor_id', $LoginVenderId);
		    $VendorInfo = $this->getDataByParticularField('vendor_details', 'vendor_id', $VendorDetails['vendor_id']);
		    $template = $BulkData['template_id'];
		    if($template == 1){
		    	$templateName = 'weekend-discount';	
		    }
		    elseif($template == 2){
		    	$templateName = 'percentage-discount';
		    }
		    elseif($template == 3){
		    	$templateName = 'price-discount';
		    }
		    elseif($template == 4){
		    	$templateName = 'festive-discount';
		    }
		    elseif($template == 5){
		    	$templateName = 'bulk-five';
		    }
	    	$mobile = '91'.$BulkData['mobile'];
	    	//$mobile = '917800992805';
	    	$Name = $BulkData['name'] ?? '';
	    	$VendorPhone = $VendorDetails['first_manager_contact_number'];
	        $BusinessName = $VendorDetails['vendor_business_name'];
	    	$variable_name = $BulkData['variable_name'];
	    	$vendor_address = $VendorInfo['vendor_address'];
	        $msg = 'Hi '.$Name.'<br/>We are giving a special discount for our selected customers only this weekend. 😍<br/>Book your room now and get a flat '.$variable_name.' % discount on your booking.<br/>Call now to book - '.$VendorPhone.'<br/><br/>Regards<br/>'.$BusinessName;

		    $SaveTemplate['msg'] = htmlentities($msg);
		    $SaveTemplate['vendor_id'] = $VendorDetails['id'];
		    $SaveTemplate['customer_id'] = 0;
		    $SaveTemplate['customer_mobile'] = $mobile;
		    $SaveTemplate['customer_name'] = $Name;
		    $SaveTemplate['vendor_phone'] = $VendorPhone;
		    $SaveTemplate['business_name'] = $BusinessName;
		    $SaveTemplate['msg_type'] = 'BulkMsg';
		    $SaveTemplate['add_date'] = date('Y-m-d H:i:s');
	    	//$this->addData('customer_whatsapp', $SaveTemplate);
	    	if($template == 5){
	    		$curl = curl_init();
				curl_setopt_array($curl, array(
			  	CURLOPT_URL => 'https://backend.aisensy.com/campaign/t1/api/v2',
			  	CURLOPT_RETURNTRANSFER => true,
			  	CURLOPT_ENCODING => '',
			  	CURLOPT_MAXREDIRS => 10,
			  	CURLOPT_TIMEOUT => 0,
			  	CURLOPT_FOLLOWLOCATION => true,
			  	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  	CURLOPT_CUSTOMREQUEST => 'POST',
			  	CURLOPT_POSTFIELDS =>'{
				    "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2MDZhMTlkOTAwNWJkMGI2ZjRkMWY0ZSIsIm5hbWUiOiJNaW5pIEhvdGVsIE1hbiBCdXNpbmVzcyBTb2x1dGlvbnMgIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2MDZhMTlkOTAwNWJkMGI2ZjRkMWY0NyIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzExNzEwNjIxfQ.dq1TvNetzpPoSMqWGv4OBLBbkpbr-60BnkxBYq1cH1o",
				    "campaignName": "'.$templateName.'",
				    "destination": "'.$mobile.'",
				    "userName": "Mini Hotel Man Business Solutions ",
				    "templateParams": ["'.$Name.'","'.$variable_name.'","'.$VendorPhone.'","'.$BusinessName.'","'.$vendor_address.'"] ,
			      	"source": "new-landing-page form",
			      	  "media": {},
  					"buttons": [],
  					"carouselCards": []
					}',
				CURLOPT_HTTPHEADER => array(
				    'Content-Type: application/json'
				  ),
				));
				$response = curl_exec($curl);
				curl_close($curl);
				$Result = json_decode($response,true);
				$Status = $Result['messaging_product'] ?? 'Error';
				$whatsapp_id = $Result['messages'][0]['id'] ?? '';
				$SaveTemplate['whatsapp_id'] 	= isset($Result['submitted_message_id']) ? $Result['submitted_message_id'] :'';
				$SaveTemplate['status'] 			= !empty($Result['success']) ? 1:0;
	    	}
	    	else{
	    		$curl = curl_init();
				curl_setopt_array($curl, array(
			  	CURLOPT_URL => 'https://backend.aisensy.com/campaign/t1/api/v2',
			  	CURLOPT_RETURNTRANSFER => true,
			  	CURLOPT_ENCODING => '',
			  	CURLOPT_MAXREDIRS => 10,
			  	CURLOPT_TIMEOUT => 0,
			  	CURLOPT_FOLLOWLOCATION => true,
			  	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			  	CURLOPT_CUSTOMREQUEST => 'POST',
			  	CURLOPT_POSTFIELDS =>'{
				    "apiKey": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY2MDZhMTlkOTAwNWJkMGI2ZjRkMWY0ZSIsIm5hbWUiOiJNaW5pIEhvdGVsIE1hbiBCdXNpbmVzcyBTb2x1dGlvbnMgIiwiYXBwTmFtZSI6IkFpU2Vuc3kiLCJjbGllbnRJZCI6IjY2MDZhMTlkOTAwNWJkMGI2ZjRkMWY0NyIsImFjdGl2ZVBsYW4iOiJCQVNJQ19NT05USExZIiwiaWF0IjoxNzExNzEwNjIxfQ.dq1TvNetzpPoSMqWGv4OBLBbkpbr-60BnkxBYq1cH1o",
				    "campaignName": "'.$templateName.'",
				    "destination": "'.$mobile.'",
				    "userName": "Mini Hotel Man Business Solutions ",
				    "templateParams": ["'.$Name.'","'.$variable_name.'","'.$VendorPhone.'","'.$BusinessName.'"],
			      	"source": "new-landing-page form",
			      	  "media": {},
  					"buttons": [],
  					"carouselCards": []
					}',
				CURLOPT_HTTPHEADER => array(
				    'Content-Type: application/json'
				  ),
				));
				$response = curl_exec($curl);
				curl_close($curl);
				$Result = json_decode($response,true);
				$Status = $Result['messaging_product'] ?? 'Error';
				$whatsapp_id = $Result['messages'][0]['id'] ?? '';
				$SaveTemplate['whatsapp_id'] 	= isset($Result['submitted_message_id']) ? $Result['submitted_message_id'] :'';
				$SaveTemplate['status'] 			= !empty($Result['success']) ? 1:0;
	    	}
	    	
			$this->addData('customer_whatsapp', $SaveTemplate);
			//echo '<pre>';print_r($Result);echo '<pre>';
		}
	}
	function Bulk1($BulkData){
    $LoginVenderId = $BulkData['vendor_id'];
    $VendorDetails = $this->getDataByParticularField('vendor', 'vendor_id', $LoginVenderId);
    
    $mobile = '91'.$BulkData['mobile'];
    //$mobile = '919871659388';
    $Name = $BulkData['Name'] ?? '';
    $VendorPhone = $VendorDetails['first_manager_contact_number'];
    $BusinessName = $VendorDetails['vendor_business_name'];
    $variable_name = $BulkData['variable_name'];

    $msg = 'Hi '.$Name.'<br/>We are giving a special discount for our selected customers only this weekend. 😍<br/>Book your room now and get a flat '.$variable_name.' % discount on your booking.<br/>Call now to book - '.$VendorPhone.'<br/><br/>Regards<br/>'.$BusinessName;

    $SaveTemplate['msg'] = htmlentities($msg);
    $SaveTemplate['vendor_id'] = $VendorDetails['id'];
    $SaveTemplate['customer_id'] = 0;
    $SaveTemplate['customer_mobile'] = $mobile;
    $SaveTemplate['customer_name'] = $Name;
    $SaveTemplate['vendor_phone'] = $VendorPhone;
    $SaveTemplate['business_name'] = $BusinessName;
    $SaveTemplate['msg_type'] = 'BulkMsg';
    $SaveTemplate['add_date'] = date('Y-m-d H:i:s');
    //$this->addData('customer_whatsapp', $SaveTemplate);
    $curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://waba.com.bot/cloud/v1/messages',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>'{
			    "to": "'.$mobile.'",
			    "recipient_type": "individual",
			    "type": "template",
			    "template": {
			        "language": {
			            "policy": "deterministic",
			            "code": "en"
			        },
			        "name": "bulk_one",
			        "components": [
			            {
			                "type": "body",
			                "parameters": [
			                    {
			                        "type": "text",
			                        "text": "'.$Name.'"
			                    },
			                    {
			                        "type": "text",
			                        "text": "'.$variable_name.'"
			                    },
			                    {
			                        "type": "text",
			                        "text": "'.$VendorPhone.'"
			                    },
			                    {
			                        "type": "text",
			                        "text": "'.$BusinessName.'"
			                    }
			                ]
			            }
			        ]
			    }
			}',
		  CURLOPT_HTTPHEADER => array(
		    'API-KEY: 64fc26d750c97e2a108574b5',
		    'Content-Type: application/json'
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		$Result = json_decode($response,true);
		$Status = $Result['messaging_product'] ?? 'Error';
		$whatsapp_id = $Result['messages'][0]['id'] ?? '';
		$SaveTemplate['whatsapp_id'] 	= $whatsapp_id;
		$SaveTemplate['status'] 			= 0;
		$this->addData('customer_whatsapp', $SaveTemplate);
		//echo '<pre>';print_r($Result);echo '<pre>';
	}
	function Bulk2($BulkData){
    $LoginVenderId = $BulkData['vendor_id'];
    $VendorDetails = $this->getDataByParticularField('vendor', 'vendor_id', $LoginVenderId);
    
    $mobile = '91'.$BulkData['mobile'];
    //$mobile = '919871659388';
    $Name = $BulkData['Name'] ?? '';
    $VendorPhone = $VendorDetails['first_manager_contact_number'];
    $BusinessName = $VendorDetails['vendor_business_name'];
    $variable_name = $BulkData['variable_name'];

    $msg = 'Hi '.$Name.'<br/>We are giving a special discount for our special customers like you! Book your room now and get a flat '.$variable_name.' % discount! 😍 Hurry up! Only first 15 customers can avail this offer. Call now to book - '.$VendorPhone.'<br/><br/>Regards<br/>'.$BusinessName;

    $SaveTemplate['msg'] = htmlentities($msg);
    $SaveTemplate['vendor_id'] = $VendorDetails['id'];
    $SaveTemplate['customer_id'] = 0;
    $SaveTemplate['customer_mobile'] = $mobile;
    $SaveTemplate['customer_name'] = $Name;
    $SaveTemplate['vendor_phone'] = $VendorPhone;
    $SaveTemplate['business_name'] = $BusinessName;
    $SaveTemplate['msg_type'] = 'BulkMsg';
    $SaveTemplate['add_date'] = date('Y-m-d H:i:s');
    //$this->addData('customer_whatsapp', $SaveTemplate);
    //echo '<pre>';print_r($SaveTemplate);
    $curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://waba.com.bot/cloud/v1/messages',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>'{
		    "to": "'.$mobile.'",
		    "recipient_type": "individual",
		    "type": "template",
		    "template": {
		        "language": {
		            "policy": "deterministic",
		            "code": "en"
		        },
		        "name": "bulk_2",
		        "components": [
		            {
		                "type": "body",
		                "parameters": [
		                    {
		                        "type": "text",
		                        "text": "'.$Name.'"
		                    },
		                    {
		                        "type": "text",
		                        "text": "'.$variable_name.'"
		                    },
		                    {
		                        "type": "text",
		                        "text": "'.$VendorPhone.'"
		                    },
		                    {
		                        "type": "text",
		                        "text": "'.$BusinessName.'"
		                    }
		                ]
		            }
		        ]
		    }
		}',
		  CURLOPT_HTTPHEADER => array(
		    'API-KEY: 64fc26d750c97e2a108574b5',
		    'Content-Type: application/json'
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		$Result = json_decode($response,true);
		$Status = $Result['messaging_product'] ?? 'Error';
		$whatsapp_id = $Result['messages'][0]['id'] ?? '';
		$SaveTemplate['whatsapp_id'] 	= $whatsapp_id;
		$SaveTemplate['status'] 			= 0;
		$this->addData('customer_whatsapp', $SaveTemplate);
		//echo '<pre>';print_r($Result);echo '<pre>';
	}
	function Bulk3($BulkData){
    $LoginVenderId = $BulkData['vendor_id'];
    $VendorDetails = $this->getDataByParticularField('vendor', 'vendor_id', $LoginVenderId);
    
    $mobile = '91'.$BulkData['mobile'];
    //$mobile = '919871659388';
    $Name = $BulkData['Name'] ?? '';
    $VendorPhone = $VendorDetails['first_manager_contact_number'];
    $BusinessName = $VendorDetails['vendor_business_name'];
    $variable_name = $BulkData['variable_name'];

    $msg = 'Hi '.$Name.'<br/>Long time now see? 🤗 Book your room now starting at just ₹ '.$variable_name.' HURRY UP!! OFFER VALID FOR TODAY ONLY.<br/>📞Call now to book - '.$VendorPhone.'<br/><br/>Regards<br/>'.$BusinessName;

    $SaveTemplate['msg'] = htmlentities($msg);
    $SaveTemplate['vendor_id'] = $VendorDetails['id'];
    $SaveTemplate['customer_id'] = 0;
    $SaveTemplate['customer_mobile'] = $mobile;
    $SaveTemplate['customer_name'] = $Name;
    $SaveTemplate['vendor_phone'] = $VendorPhone;
    $SaveTemplate['business_name'] = $BusinessName;
    $SaveTemplate['msg_type'] = 'BulkMsg';
    $SaveTemplate['add_date'] = date('Y-m-d H:i:s');
    //$this->addData('customer_whatsapp', $SaveTemplate);

    $curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://waba.com.bot/cloud/v1/messages',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>'{
			    "to": "'.$mobile.'",
			    "recipient_type": "individual",
			    "type": "template",
			    "template": {
			        "language": {
			            "policy": "deterministic",
			            "code": "en"
			        },
			        "name": "bulk_3",
			        "components": [
			            {
			                "type": "body",
			                "parameters": [
			                    {
			                        "type": "text",
			                        "text": "'.$Name.'"
			                    },
			                    {
			                        "type": "text",
			                        "text": "'.$variable_name.'"
			                    },
			                    {
			                        "type": "text",
			                        "text": "'.$VendorPhone.'"
			                    },
			                    {
			                        "type": "text",
			                        "text": "'.$BusinessName.'"
			                    }
			                ]
			            }
			        ]
			    }
			}',
		  CURLOPT_HTTPHEADER => array(
		    'API-KEY: 64fc26d750c97e2a108574b5',
		    'Content-Type: application/json'
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		$Result = json_decode($response,true);
		$Status = $Result['messaging_product'] ?? 'Error';
		$whatsapp_id = $Result['messages'][0]['id'] ?? '';
		$SaveTemplate['whatsapp_id'] 	= $whatsapp_id;
		$SaveTemplate['status'] 			= 0;
		$this->addData('customer_whatsapp', $SaveTemplate);
		//echo '<pre>';print_r($Result);echo '<pre>';
	}
	function Bulk4($BulkData){
    $LoginVenderId = $BulkData['vendor_id'];
    $VendorDetails = $this->getDataByParticularField('vendor', 'vendor_id', $LoginVenderId);
    
    $mobile = '91'.$BulkData['mobile'];
    //$mobile = '919871659388';
    $Name = $BulkData['Name'] ?? '';
    $VendorPhone = $VendorDetails['first_manager_contact_number'];
    $BusinessName = $VendorDetails['vendor_business_name'];
    $variable_name = $BulkData['variable_name'];

    $msg = 'Hi '.$Name.'<br/>Enjoy this festive season with your loved ones at our hotel! 🏩 🥳😍 Book your room now starting at just ₹ '.$variable_name.' Offer valid for first 10 customers only. *So hurry up and call now to book *-'.$VendorPhone.'<br/><br/>Regards<br/>'.$BusinessName;

    $SaveTemplate['msg'] = htmlentities($msg);
    $SaveTemplate['vendor_id'] = $VendorDetails['id'];
    $SaveTemplate['customer_id'] = 0;
    $SaveTemplate['customer_mobile'] = $mobile;
    $SaveTemplate['customer_name'] = $Name;
    $SaveTemplate['vendor_phone'] = $VendorPhone;
    $SaveTemplate['business_name'] = $BusinessName;
    $SaveTemplate['msg_type'] = 'BulkMsg';
    $SaveTemplate['add_date'] = date('Y-m-d H:i:s');

    $curl = curl_init();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'https://waba.com.bot/cloud/v1/messages',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => '',
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 0,
		  CURLOPT_FOLLOWLOCATION => true,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => 'POST',
		  CURLOPT_POSTFIELDS =>'{
		    "to": "'.$mobile.'",
		    "recipient_type": "individual",
		    "type": "template",
		    "template": {
		        "language": {
		            "policy": "deterministic",
		            "code": "en"
		        },
		        "name": "bulk_2",
		        "components": [
		            {
		                "type": "body",
		                "parameters": [
		                    {
		                        "type": "text",
		                        "text": "'.$Name.'"
		                    },
		                    {
		                        "type": "text",
		                        "text": "'.$variable_name.'"
		                    },
		                    {
		                        "type": "text",
		                        "text": "'.$VendorPhone.'"
		                    },
		                    {
		                        "type": "text",
		                        "text": "'.$BusinessName.'"
		                    }
		                ]
		            }
		        ]
		    }
		}',
		  CURLOPT_HTTPHEADER => array(
		    'API-KEY: 64fc26d750c97e2a108574b5',
		    'Content-Type: application/json'
		  ),
		));
		$response = curl_exec($curl);
		curl_close($curl);
		$Result = json_decode($response,true);
		$Status = $Result['messaging_product'] ?? 'Error';
		$whatsapp_id = $Result['messages'][0]['id'] ?? '';
		$SaveTemplate['whatsapp_id'] 	= $whatsapp_id;
		$SaveTemplate['status'] 			= 0;
		$this->addData('customer_whatsapp', $SaveTemplate);
		//echo '<pre>';print_r($Result);echo '<pre>';die();
	}

	public function SaveOwnerLog($log_type){
		$SaveLog['vendor_id'] = $this->session->userdata('MHM_OWNER_ID');
		$SaveLog['manager_id'] = 0;
		$SaveLog['log_type'] = $log_type;
		$SaveLog['response'] = json_encode($_REQUEST);
		$SaveLog['add_date'] = date('Y-m-d H:i:s');
		//echo '<pre>';print_r($SaveLog);die;
		$this->db->insert('log', $SaveLog);
		return $this->db->insert_id();
	}

	public function SaveVendorLog($SaveLogData,$log_type,$previousData = []){
		$SaveLog['vendor_id'] = $this->session->userdata('MHM_VENDOR_ID');
		$SaveLog['manager_id'] = $this->session->userdata('MHM_VENDOR_MANAGER_ID');
		$SaveLog['log_type'] = $log_type;
		$SaveLog['response'] = json_encode($SaveLogData);
		if($previousData != ''){
			$SaveLog['previous_data'] = json_encode($previousData);
		}
		$SaveLog['add_date'] = date('Y-m-d H:i:s');
		$this->db->insert('log', $SaveLog);
		return $this->db->insert_id();
	}

	public function CountCalendarDate($type,$room_id){
		$BlockQuery = "SELECT id FROM ".getTablePrefix()."calendar_date WHERE type='".$type."' AND room_id=".$room_id." AND cal_date='".date('Y-m-d')."' ";
		$BlockCount = $this->getDataByQuery('count', $BlockQuery); 
		return $BlockCount;
	}
	public function GetCalendarLabel($room_id){
		$sql = "SELECT label.remarks FROM ".getTablePrefix()."calendar_date as cdate join ".getTablePrefix()."calendar_label_room as label on cdate.calendar_id=label.id WHERE cdate.type='LabelRoom' AND cdate.cal_date='".date('Y-m-d')."' AND cdate.room_id='".$room_id."' ";
		$result = $this->getDataByQuery('single', $sql); 
		return $result;
	}
	public function GetTotalArrivalsRoom(){
		$vendor_id = $this->session->userdata('MHM_VENDOR_ID');
		$sql = "SELECT id FROM ".getTablePrefix()."calendar_reservations WHERE check_in_date='".date('Y-m-d')."' AND hotel_manager_id='".$vendor_id."' ";
		$CountData = $this->getDataByQuery('count', $sql); 
		return $CountData;
	}
	public function CheckReservationsRoom($room_id){
		$vendor_id = $this->session->userdata('MHM_VENDOR_ID');
		$sql = "SELECT id FROM ".getTablePrefix()."calendar_reservations WHERE check_in_date='".date('Y-m-d')."' AND assign_room_number='".$room_id."' AND hotel_manager_id='".$vendor_id."' ";
		$CountData = $this->getDataByQuery('count', $sql); 
		return $CountData;
	}
	public function GetTotalCustomerDebit($summary_book_id,$companyId,$type = '',$callType = ''){
    $this->db->select('SUM(details.payment_paid) as advanceAmount');
    $this->db->from('customer_summary_details as details');
    $this->db->join('customer_summary_book as book', 'book.summary_book_id=details.customer_id');
    $this->db->where("details.page_source", 'add_an_advance');
    if($type == 'BTC'){
    	$this->db->where("details.amount_mode", 'BTC');
    }
    else if($type == 'prepaid'){
    	$this->db->where("details.amount_mode", 'prepaid');
    }
    $this->db->where("details.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    $this->db->where("details.customer_id", $summary_book_id);
    if($callType == 'ota'){
    	$this->db->where('book.ots_id', $companyId);
    }
    else{
    	$this->db->where('book.gst_number', $companyId);
    }
    
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    $row = $query->row_array();
    return $row['advanceAmount'] ?? 0;
  }
  public function GetTotalCompanyDebit($companyId){
    $this->db->select('SUM(details.payment_paid) as advanceAmount');
    $this->db->from('customer_summary_details as details');
    $this->db->join('customer_summary_book as book', 'book.summary_book_id=details.customer_id');
    $this->db->where("details.page_source", 'add_an_advance');
    $this->db->where("details.amount_mode", 'BTC');
    $this->db->where("details.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    $this->db->where('book.gst_number', $companyId);
    $query = $this->db->get();
    $row = $query->row_array();
    return $row['advanceAmount'] ?? 0;
  }
  public function GetTotalCompanyCredit($companyId){
    $this->db->select('SUM(amount) as Amount');
    $this->db->from('company_credit');
    $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    $this->db->where("company_id", $companyId);
    $query = $this->db->get();
    $row = $query->row_array();
    return $row['Amount'] ?? 0;
  }
  public function UpdateOpeningBalance($companyId,$date){
  	$ODate = date('Y-m',strtotime($date . " -1 months"));
  	$TotalDebit = $this->GetTotalMonthsDebit($companyId,$date);
  	$TotalCredit = $this->GetTotalMonthsCredit($companyId,$date);

  	$sql = "SELECT id FROM " . getTablePrefix() . "company_opening WHERE (o_date LIKE '%" . $ODate . "%') AND hotel_manager_id = '" . $this->session->userdata('MHM_VENDOR_ID') . "' AND company_id='".$companyId."' ";
  	$Count = $this->getDataByQuery('count', $sql);
  	
		$param['hotel_manager_id'] = addslashes($this->session->userdata('MHM_VENDOR_ID'));
		$param['hotel_manager_name'] = sessionData('MHM_VENDOR_MANAGER_NAME');
		$param['company_id'] = $companyId;
		$param['o_date'] = $ODate.'-01';
		$param['amount'] = ($TotalDebit-$TotalCredit);
		$param['add_date'] = date('Y-m-d H:i:s');
  	if($Count>0){
  		$result = $this->getDataByQuery('single', $sql);
  		$Uwhere['id'] = $result['id'];
      $this->common_model->editDataByMultipleCondition('company_opening', $param, $Uwhere);
  	}else{
  		$this->common_model->addData('company_opening', $param);
  	}
  }
  public function GetTotalMonthsDebit($companyId,$date){
  	$ODate = date('Y-m',strtotime($date . " -1 months"));
  	$this->db->select('SUM(details.payment_paid) as advanceAmount');
    $this->db->from('customer_summary_details as details');
    $this->db->join('customer_summary_book as book', 'book.summary_book_id=details.customer_id');
    $this->db->where("details.page_source", 'add_an_advance');
    $this->db->where("details.amount_mode", 'BTC');
    $this->db->where("details.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    $this->db->where('book.gst_number', $companyId);
    $this->db->where("book.check_out_datetime LIKE '%$ODate%'");
    $query = $this->db->get();
    $row = $query->row_array();
    return $row['advanceAmount'] ?? 0;
  }
  public function GetTotalMonthsCredit($companyId,$date){
  	$ODate = date('Y-m',strtotime($date . " -1 months"));
  	$this->db->select('SUM(amount) as Amount');
    $this->db->from('company_credit');
    $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    $this->db->where("company_id", $companyId);
    $this->db->where("c_date LIKE '%$ODate%'");
    $query = $this->db->get();
    $row = $query->row_array();
    return $row['Amount'] ?? 0;
  }
  public function GetOpeningBalance($date,$companyId){
  	$ODate = date('Y-m',strtotime($date . " -1 months"));
  	$sql = "SELECT * FROM " . getTablePrefix() . "company_opening WHERE (o_date LIKE '%" . $ODate . "%') AND hotel_manager_id = '" . $this->session->userdata('MHM_VENDOR_ID') . "' AND company_id='".$companyId."' ";
  	$result = $this->getDataByQuery('single', $sql); 
  	return $result;
  }
  public function RandomColorPart() {
    return str_pad( dechex( mt_rand( 0, 255 ) ), 2, '0', STR_PAD_LEFT);
	}
  public function RandomColor() {
    return $this->RandomColorPart() . $this->RandomColorPart() . $this->RandomColorPart();
	}
	public function AddGroupColorCode($param){
		$ColorArr = ['FFFF00','FFA500','FFFDD0','ff0000','E0B0FF','12AD2B','000000','808080','FF00FF','964B00'];
		$ColorArr2 = [];
		$add_date = date('Y-m-d',strtotime($param['check_in_datetime']));
		$Save['hotel_manager_id'] = $param['hotel_manager_id'];
		$Save['entry_number'] = $param['entry_number'];
		$Save['add_date'] = $add_date;

		$ColorQuery = "SELECT `color_code` FROM ".getTablePrefix()."customer_summary_book_color WHERE `hotel_manager_id` = '".$Save['hotel_manager_id']."' AND `add_date` = '".$add_date."' ";
    $GetColor = $this->common_model->getDataByQuery('multiple', $ColorQuery);
    foreach ($GetColor as $color) {
    	$ColorArr2[] = $color['color_code'];
    }
		$result = array_diff($ColorArr,$ColorArr2);
		if($result){
			$color_code = current($result);
		}else{
			$color_code = $this->RandomColor();
		}
		$Save['color_code'] = $color_code;
		$ColorQuery = "SELECT `color_code` FROM ".getTablePrefix()."customer_summary_book_color WHERE `hotel_manager_id` = '".$Save['hotel_manager_id']."' AND `entry_number` = '".$Save['entry_number']."' ";
    $ColorCount = $this->common_model->getDataByQuery('count', $ColorQuery);
    if($ColorCount==0){
    	$this->addData('customer_summary_book_color', $Save);	
    }
	}
	public function GetRoomNumber($room_id){
		$Query = "SELECT room_no FROM ".getTablePrefix()."room_number WHERE room_id='".$room_id."' AND hotel_manager_id=".sessionData('MHM_VENDOR_ID')." ";
		$result = $this->getDataByQuery('single', $Query); 
		return $result;
	}
	public function GetRoomCategory($id){
		$Query = "SELECT category_name FROM ".getTablePrefix()."room_category WHERE id='".$id."'";
		$result = $this->getDataByQuery('single', $Query);
		$CatName = '';
		if($result){
			$CatName = $result['category_name']; 
		}
		return $CatName;
	}
	public function Getownerflashmessage(){
		$hotel_manager_id = sessionData('MHM_OWNER_ID');
		$this->db->select('mhmholets_add_message.*');
		$this->db->from('mhmholets_add_message');
		$this->db->where('mhmholets_add_message.bussines_name', $hotel_manager_id);
		$this->db->where('mhmholets_add_message.status','A');
		$query = $this->db->get(); 
		 return $query->row_array();
	}
	public function Getmanagerflashmessage(){
		$hotel_owner_id = sessionData('MHM_VENDOR_MANAGER_ID');
		$this->db->where('id', $hotel_owner_id);
		$manager_data= $this->db->get('mhmholets_manager')->row();
		$hotel_id=$manager_data->vendor_id;

		$this->db->select('mhmholets_add_message.*');
		$this->db->from('mhmholets_add_message');
		$this->db->like('mhmholets_add_message.child_hotels', $hotel_id);  
		$this->db->where('mhmholets_add_message.status','A');
		$query = $this->db->get(); 
		//echo $this->db->last_query(); die;
		return $query->row_array();
  }

  public function GetTotalKOTAmount($kot_number,$hotel_manager_id){
  	$this->db->select('SUM(advance_paid) as Amount');
    $this->db->from('customer_summary_details');
    $this->db->where("hotel_manager_id", $hotel_manager_id);
    $this->db->where("kot_number", $kot_number);
    $query = $this->db->get();
    $row = $query->row_array();
    //echo $this->db->last_query(); die;
    return $row['Amount'] ?? 0;
  }

  public function GetTableTotalAmt($table_id,$hotel_manager_id){
  	$SqlAmt = "SELECT cart.qty,menu.price FROM ".getTablePrefix()."hotel_menu_cart as cart join ".getTablePrefix()."hotel_menu as menu on menu.id=cart.menu_id WHERE cart.table_id='".$table_id."' AND cart.hotel_manager_id='".$hotel_manager_id."' order by cart.id DESC";
  	$MenuArr = $this->common_model->getDataByQuery('multiple', $SqlAmt);
  	$TotalAmt = 0;
  	if($MenuArr){
  		foreach ($MenuArr as $row) {
  			$TotalAmt+=$row['price']*$row['qty'];
  		}
  	}
  	return $TotalAmt;
  }
  public function GetSaleCustomerItemData($kot_number,$hotel_manager_id){
  	$SqlAmt = "SELECT bill_item,advance_paid,quantity FROM ".getTablePrefix()."customer_summary_details WHERE kot_number='".$kot_number."' AND hotel_manager_id='".$hotel_manager_id."' order by id DESC";
  	$ResultArr = $this->common_model->getDataByQuery('multiple', $SqlAmt);
  	return $ResultArr;
  }
  public function GetSaleTableItemData($kot_no,$hotel_manager_id){
  	$SqlAmt = "SELECT menu_name,qty FROM ".getTablePrefix()."restaurant_kot WHERE kot_no='".$kot_no."' AND hotel_manager_id='".$hotel_manager_id."' order by id DESC";
  	$ResultArr = $this->common_model->getDataByQuery('multiple', $SqlAmt);
  	return $ResultArr;
  }
  function getOtsName($id){
		$this->db->select('ots_name');
		$this->db->from('ots_master');
		$this->db->where('ots_id', $id);
		$query = $this->db->get();
		return $query->result_array();
	}

    public function getdiscountdata($id)
	{
	$this->db->select('discount_type,discount_value');
    $this->db->from('customer_summary_book');
    $this->db->where('encrypt_id',$id);
    $query = $this->db->get();
    $row = $query->row_array();
    return $row;
	}


	public function updatediscountdata($data,$id)
	{
    $this->db->where('encrypt_id',$id);
    $this->db->update('customer_summary_book', $data);
    return true;
	}


public function deletediscountdata($id)
{
	// echo $id; die("-------------------");
				$this->db->where('encrypt_id', $id);
        $this->db->set('discount_type', NULL);
        $this->db->set('discount_value', NULL);
        $this->db->update('customer_summary_book');
        return true;
}



public function updatebilldiscount($discount_type, $discount_value,$Customerid)
{
				$this->db->where('summary_book_id', $Customerid);
        $this->db->set('discount_type', $discount_type);
        $this->db->set('discount_value', $discount_value);
        $this->db->update('customer_summary_book');
        return true;
}

/***********************************************************************
	 ** Function name: getDataByParticularField
	 ** Developed By: Ashish UMrao
	 ** Purpose: This function used for get data by encryptId
	 ** Date : 14 APRIL 2022
	 ************************************************************************/
	public function getDataBySubGuest($tableName = '', $fieldName = '', $fieldValue = '')
	{
		$this->db->select('*');
		$this->db->from($tableName);
		$this->db->where($fieldName, $fieldValue);
		$query = $this->db->get();
		//echo $this->db->last_query(); die;
		if ($query->num_rows() > 0) :
			return $query->result_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION

    public function GetTotalMonthsDebitOts($ots_id,$date){
  	$ODate = date('Y-m',strtotime($date . " -1 months"));
  	$this->db->select('SUM(details.payment_paid) as advanceAmount');
    $this->db->from('customer_summary_details as details');
    $this->db->join('customer_summary_book as book', 'book.summary_book_id=details.customer_id');
    $this->db->where("details.page_source", 'add_an_advance');
    $this->db->where("details.amount_mode", 'prepaid');
    $this->db->where("details.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    $this->db->where('book.ots_id', $ots_id);
    $this->db->where("book.check_out_datetime LIKE '%$ODate%'");
    $query = $this->db->get();
    $row = $query->row_array();
    return $row['advanceAmount'] ?? 0;
  }
  public function GetTotalMonthsCreditOts($ots_id,$date){
  	$ODate = date('Y-m',strtotime($date . " -1 months"));
  	$this->db->select('SUM(amount) as Amount');
    $this->db->from('ots_credit');
    $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    $this->db->where("ots_id", $ots_id);
    $this->db->where("c_date LIKE '%$ODate%'");
    $query = $this->db->get();
    $row = $query->row_array();
    return $row['Amount'] ?? 0;
  }

	public function GetTotalOtsDebit($ots_id){
    $this->db->select('SUM(details.payment_paid) as advanceAmount');
    $this->db->from('customer_summary_details as details');
    $this->db->join('customer_summary_book as book', 'book.summary_book_id=details.customer_id');
    $this->db->where("details.page_source", 'add_an_advance');
    $this->db->where("details.amount_mode", 'prepaid');
    $this->db->where("details.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    $this->db->where('book.ots_id', $ots_id);
    $query = $this->db->get();
    $row = $query->row_array();
    return $row['advanceAmount'] ?? 0;
  }
  public function GetTotalOtsCredit($ots_id){
    $this->db->select('SUM(amount) as Amount');
    $this->db->from('ots_credit');
    $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    $this->db->where("ots_id", $ots_id);
    $query = $this->db->get();
    $row = $query->row_array();
    return $row['Amount'] ?? 0;
  }

  public function UpdateOpeningBalanceOts($ots_id,$date){
  	$ODate = date('Y-m',strtotime($date . " -1 months"));
  	$TotalDebit = $this->GetTotalMonthsDebitOts($ots_id,$date);
  	$TotalCredit = $this->GetTotalMonthsCreditOts($ots_id,$date);

  	$sql = "SELECT id FROM " . getTablePrefix() . "ots_opening WHERE (o_date LIKE '%" . $ODate . "%') AND hotel_manager_id = '" . $this->session->userdata('MHM_VENDOR_ID') . "' AND ots_id='".$ots_id."' ";
  	$Count = $this->getDataByQuery('count', $sql);
  	
		$param['hotel_manager_id'] = addslashes($this->session->userdata('MHM_VENDOR_ID'));
		$param['hotel_manager_name'] = sessionData('MHM_VENDOR_MANAGER_NAME');
		$param['ots_id'] = $ots_id;
		$param['o_date'] = $ODate.'-01';
		$param['amount'] = ($TotalDebit-$TotalCredit);
		$param['add_date'] = date('Y-m-d H:i:s');
  	if($Count>0){
  		$result = $this->getDataByQuery('single', $sql);
  		$Uwhere['id'] = $result['id'];
      $this->common_model->editDataByMultipleCondition('ots_opening', $param, $Uwhere);
  	}else{
  		$this->common_model->addData('ots_opening', $param);
  	}
  }

   public function GetOpeningBalanceOts($date,$ots_id){
  	$ODate = date('Y-m',strtotime($date . " -1 months"));
  	$sql = "SELECT * FROM " . getTablePrefix() . "ots_opening WHERE (o_date LIKE '%" . $ODate . "%') AND hotel_manager_id = '" . $this->session->userdata('MHM_VENDOR_ID') . "' AND ots_id='".$ots_id."' ";
  	$result = $this->getDataByQuery('single', $sql); 
  	return $result;
  }

  public function GetTotalCustomerDebitOts($companyId,$type = '',$callType = ''){
  	$ODate           = date('Y-m');
    $this->db->select('SUM(details.payment_paid) as advanceAmount');
    $this->db->from('customer_summary_details as details');
    $this->db->join('customer_summary_book as book', 'book.summary_book_id=details.customer_id');
    $this->db->where("details.page_source", 'add_an_advance');
    if($type == 'BTC'){
    	$this->db->where("details.amount_mode", 'BTC');
    }
    else if($type == 'prepaid'){
    	$this->db->where("details.amount_mode", 'prepaid');
    }
    $this->db->where("check_out_datetime LIKE '%$ODate%'");
    $this->db->where("details.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
    //$this->db->where("details.customer_id", $summary_book_id);
    if($callType == 'ota'){
    	$this->db->where('book.ots_id', $companyId);
    }
    else{
    	$this->db->where('book.gst_number', $companyId);
    }
    
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    $row = $query->row_array();
    return $row['advanceAmount'] ?? 0;
  }

}