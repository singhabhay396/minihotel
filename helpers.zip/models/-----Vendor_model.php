<?php
if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
class Vendor_model extends CI_Model
{
    public function __construct()
    {
        parent::__construct();
        $this->load->database();
    }
    /***********************************************************************
     ** Function name : selectVendorData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Vendor data
     ** Date : 16 APRIL 2022
     ************************************************************************/
    public function selectVendorData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '', $shortFieldGROUP = '')
    {
        $this->db->select('ven.*, vendetails.vendor_address, vendetails.vendor_nationality,
						   vendetails.vendor_pan, vendetails.vendor_address_proof, vendetails.vendor_pincode,
						   vendetails.vendor_kyc_status,vendetails.bill_number');
        $this->db->from($tblName);
        $this->db->join("vendor_details as vendetails", "ven.vendor_id=vendetails.vendor_id", "LEFT");
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortFieldGROUP) : $this->db->group_by($shortFieldGROUP);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    }
    /***********************************************************************
     ** Function name : selectHotelRoomData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Car Brand Data
     ** Date : 08 April 2022
     ************************************************************************/
    public function selectHotelRoomData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('rn.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where('hotel_manager_id', $this->session->userdata('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectCustomerSummaryBookData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Car Brand Data
     ** Date : 11 April 2022
     ************************************************************************/
    public function selectCustomerSummaryBookData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('csb.*,rn.room_no,rn.room_no_use,rn.room_id');
        $this->db->from($tblName);
        $this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'left');
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where("rn.room_no_use = 'Y'");
        $query = $this->db->get();
        // echo $this->db->last_query();
        // die;
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllRoomsByHotelId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Rooms By Hotel Id
     ** Date : 11 APRIL 2022
     ************************************************************************/
    public function getAllRoomsByHotelId($assignroomId = '')
    {
        $html = '<option value="">Select Room</option>';
        $this->db->select('room_id,room_no');
        $this->db->from('room_number');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("room_no_use = 'N'");
        $this->db->where("status = 'Y'");
        $this->db->order_by("room_no ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            $data = $query->result_array();
            foreach ($data as $info) :
                if ($info['room_id'] == $assignroomId) : $select = 'selected="selected"';
                else : $select = '';
                endif;
                $html .= '<option value="' . $info['room_id'] . '" ' . $select . '>' . $info['room_no'] . ' </option>';
            endforeach;
        endif;
        return $html;
    }
    // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllOtsByHotelId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Ots By Hotel Id
     ** Date : 08 FEB 2023
     ************************************************************************/
    public function getAllOtsByHotelId($assignroomId = '')
    {
        $html = '<option value="">Select Booking Platform</option>';
        $this->db->select('ots_id,ots_name,status');
        $this->db->from('ots_master');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("status = 'Y'");
        $this->db->order_by("ots_id ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            $data = $query->result_array();
            foreach ($data as $info) :
                if ($info['ots_id'] == $assignroomId) : $select = 'selected="selected"';
                else : $select = '';
                endif;
                $html .= '<option value="' . $info['ots_id'] . '" ' . $select . '>' . $info['ots_name'] . '</option>';
            endforeach;
        endif;
        return $html;
    }
    // END OF FUNCTION
    /***********************************************************************
     ** Function name : detele_content
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for detele content
     ** Date : 13 APRIL 2022
     ************************************************************************/
    public function delete_content($content_url = '')
    {
        $this->db->delete('customer_id_proof', array('doc_url' => $content_url));
        return true;
    }
    /***********************************************************************
     ** Function name : selectCustomerSummaryDetailsData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select summary Details Data
     ** Date : 11 April 2022
     ************************************************************************/
    public function selectCustomerSummaryDetailsData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('csd.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllCustomerByHotelId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Customers By Hotel Id
     ** Date : 11 APRIL 2022
     ************************************************************************/
    public function getAllCustomerByHotelId($customerId = '')
    {
        $html = '<option value="">Select Customer</option>';
        $this->db->select('summary_book_id,customer_name,rn.room_no');
        $this->db->from('customer_summary_book as csb');
        $this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'LEFT');
        $this->db->where("csb.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        //$this->db->where("csb.check_out_datetime = 'NULL'");
        $this->db->where("csb.status = 'Y'");
        $this->db->order_by("csb.customer_name ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            $data = $query->result_array();
            foreach ($data as $info) :
                if ($info['summary_book_id'] == $customerId) : $select = 'selected="selected"';
                else : $select = '';
                endif;
                $html .= '<option value="' . $info['summary_book_id'] . '" ' . $select . '>' . $info['customer_name'] . ' (' . $info['room_no'] . ')</option>';
            endforeach;
        endif;
        return $html;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectCustomerSummaryDayBookData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select day book summary Data
     ** Date : 11 April 2022
     ************************************************************************/
    public function selectCustomerSummaryDayBookData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('csd.*,csb.summary_book_id,csb.customer_name,csb.assign_room_number,csb.entry_number,rn.room_no');
        $this->db->from($tblName);
        $this->db->join('customer_summary_book as csb', 'csd.customer_id=csb.summary_book_id', 'LEFT');
        $this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'LEFT');
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        //echo $this->db->last_query(); die;
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectHotelServiceData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Hotel Service Data
     ** Date : 13 April 2022
     ************************************************************************/
    public function selectHotelServiceData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('hs.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where('hotel_manager_id', $this->session->userdata('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllServicessByHotelId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for ge tAll Services By Hotel Id
     ** Date : 11 APRIL 2022
     ************************************************************************/
    public function getAllServicessByHotelId($assignserviceId = '')
    {
        $html = '<option value="">Name of Expense</option>';
        $this->db->select('service_id,service_name');
        $this->db->from('hotel_services as hs');
        $this->db->where("hs.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("hs.status = 'Y'");
        $this->db->order_by("hs.service_name ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            $data = $query->result_array();
            foreach ($data as $info) :
                if ($info['service_id'] == $assignserviceId) : $select = 'selected="selected"';
                else : $select = '';
                endif;
                $html .= '<option value="' . $info['service_id'] . '" ' . $select . '>' . $info['service_name'] . '</option>';
            endforeach;
        endif;
        return $html;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectDayBookOutManagerData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Day Book Out Manager Data
     ** Date : 13 April 2022
     ************************************************************************/
    public function selectDayBookOutManagerData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('hdbo.*,hs.service_name');
        $this->db->from($tblName);
        $this->db->join('hotel_services as hs', 'hdbo.service_id=hs.service_id', 'LEFT');
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        //echo $this->db->last_query(); die;
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectTotalDayBookManagerData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Total Day Book Manager Data
     ** Date : 13 April 2022
     ************************************************************************/
    public function selectTotalDayBookManagerData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $curntDate = date('Y-m-d');
        $this->db->select('DATE(csd.order_date) as date,SUM(csd.payment_paid) as InAmount,SUM(csd.amount_out) as OutAmount');
        $this->db->from($tblName);
        if ($whereCon['where']): $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']): $this->db->where($whereCon['like']);
        endif;
        if ($shortField): $this->db->order_by($shortField);
        endif;
        if ($numPage): $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where('csd.order_date <', $curntDate);
        $this->db->where("csd.amount_mode ='offline'");
        $this->db->group_by('date');
        $this->db->order_by('date', 'DESC');
        $query = $this->db->get();
        //echo $this->db->last_query(); die;
        if ($action == 'data'):
            if ($query->num_rows() > 0):
                return $query->result_array();
            else:
                return false;
            endif;
        elseif ($action == 'count'):
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectOccupancyManagerData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Occupancy Manager Data
     ** Date : 15 April 2022
     ************************************************************************/
    public function selectOccupancyManagerData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('csb.*,rn.room_no');
        $this->db->from($tblName);
        $this->db->join('customer_summary_details as csd', 'csd.customer_id=csb.summary_book_id', 'LEFT');
        $this->db->join('room_number as rn', 'csb.assign_room_number=rn.room_id', 'LEFT');
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        //echo $this->db->last_query();die;
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectImportantData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Important Data
     ** Date : 15 April 2022
     ************************************************************************/
    public function selectImportantData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('id.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : deleteImportantDocument
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for detele content
     ** Date : 13 APRIL 2022
     ************************************************************************/
    public function deleteImportantDocument($content_url = '')
    {
        $this->db->delete('important_document', array('encrypt_id' => $content_url));
        return true;
    }
    /***********************************************************************
     ** Function name : getDayWiseTotalSales
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for get Day Wise Total Sales
     ** Date : 26 APRIL 2022
     ************************************************************************/
    public function getDayWiseTotalSales($paymentMode, $date)
    {
        if ($date != "") {
            $date = $date;
        } else {
            $date = date('Y-m-d');
        }
        $this->db->select('SUM(payment_paid) as totalAmount');
        $this->db->from('customer_summary_details');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("amount_mode", $paymentMode);
        $this->db->like("creation_date", $date);
        $query = $this->db->get();
        //echo $this->db->last_query(); die;
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    }
    // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectAllCalendarReminderData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select All Calendar Reminder Data
     ** Date : 26 April 2022
     ************************************************************************/
    public function selectAllCalendarReminderData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('cr.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectCheckOutSummaryBookData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Car Brand Data
     ** Date : 29 April 2022
     ************************************************************************/
    public function selectCheckOutSummaryBookData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('csb.*,rn.room_no');
        $this->db->from($tblName);
        $this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'LEFT');
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectstaffmanagementManagerData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select staff management Manager Data
     ** Date : 30 April 2022
     ************************************************************************/
    public function selectstaffmanagementManagerData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('hdbo.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectstaffattendanceManagerData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select staff attendance Manager Data
     ** Date : 30 April 2022
     ************************************************************************/
    public function selectstaffattendanceManagerData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('statt.staff_id,statt.staff_name');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        //echo $this->db->last_query(); die;
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalSaleByManagerId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Manager Id
     ** Date : 2 Mey 2022
     ************************************************************************/
    public function getTotalSaleByManagerId($tblName = '', $whereCon = '')
    {
        $this->db->select('SUM(csd.payment_paid) as totalSale,csd.page_source');
        $this->db->from($tblName);
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        $this->db->where("csd.page_source='add_an_advance'");
        $query = $this->db->get();
        //echo $this->db->last_query(); die;
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalSaleByOnlineDirectModeWise
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Manager Id
     ** Date : 2 Mey 2022
     ************************************************************************/
    public function getTotalSaleByOnlineDirectModeWise($tblName1 = '', $whereCon1 = '', $modeType = '')
    {
        $this->db->select('SUM(csb.commission_amount) as totalDirectCommision');
        $this->db->from($tblName1);
        if ($whereCon1['like']) : $this->db->where($whereCon1['like']);
        endif;
        $this->db->where("csb.reffer_mode", $modeType);
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalSaleByDirectCommissionMode
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Direct Commission Mode
     ** Date : 2 Mey 2022
     ************************************************************************/
    public function getTotalSaleByDirectCommissionMode($tblName1 = '', $whereCon1 = '', $modeType = '', $directType = '')
    {
        $this->db->select('SUM(csb.prepaid_amount) as prepaidCommision,SUM(csb.commission_amount) as totalCommision');
        $this->db->from($tblName1);
        if ($whereCon1['like']) : $this->db->where($whereCon1['like']);
        endif;
        $this->db->where("csb.reffer_mode", $modeType);
        if ($modeType == 'offline') :
            $this->db->where("csb.direct_mode", $directType);
        else :
            $this->db->where("csb.online_mode", $directType);
        endif;
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalPaymentsReceivedByPaymentMode
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Manager Id
     ** Date : 2 Mey 2022
     ************************************************************************/
    public function getTotalPaymentsReceivedByPaymentMode($tblName = '', $whereCon = '', $paymentType = '')
    {
        $this->db->select('SUM(csd.payment_paid) as totalAmount');
        $this->db->from($tblName);
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        $this->db->where("csd.amount_mode", $paymentType);
        $this->db->where("csd.daybook_mode='In'");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalPaymentsExpences
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Manager Id
     ** Date : 2 Mey 2022
     ************************************************************************/
    public function getTotalPaymentsExpences($tblName = '', $whereCon = '')
    {
        $this->db->select('SUM(csd.amount_out) as totalexpenceAmount,csd.page_source');
        $this->db->from($tblName);
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        //$this->db->where("csd.page_source='add_a_service'");
        $this->db->where("csd.daybook_mode = 'Out'");
        $query = $this->db->get();
        //echo $this->db->last_query();die;
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalAverageRoomRent
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Manager Id
     ** Date : 2 Mey 2022
     ************************************************************************/
    public function getTotalAverageRoomRent($tblName = '', $whereCon = '')
    {
        $this->db->select('AVG(csd.advance_paid) as avgroomrent,SUM(csd.advance_paid) as totalRoomRent');
        $this->db->from($tblName);
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        $this->db->where("csd.page_source='extend_stay'");
        //$this->db->where('room_rent_status', 'Y');
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectBillBookSummaryData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Bill Book Summary Data
     ** Date : 02 MEY 2022
     ************************************************************************/
    public function selectBillBookSummaryData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('csb.*,rn.room_no');
        $this->db->from($tblName);
        //$this->db->join('customer_summary_details as csd', 'csb.summary_book_id=csd.customer_id', 'LEFT');
        $this->db->join('room_number as rn', 'csb.assign_room_number = rn.room_id', 'LEFT');
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->like('csb.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $this->db->where('csb.check_out_datetime !=', "NULL");
        //$this->db->like('csd.page_source','extend_stay');
        //$this->db->or_where('csd.page_source =', "add_a_service");
        //$this->db->group_by('csd.customer_id');
        $query = $this->db->get();
        //echo $this->db->last_query(); die;
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : generatebillbookInvoice
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Manager Id
     ** Date : 3 Mey 2022
     ************************************************************************/
    public function generatebillbookInvoice($customerId = '')
    {
        $this->db->select('csb.summary_book_id,csb.customer_name,csb.customer_mobile_number,csb.check_in_datetime,csb.check_out_datetime,
                            csb.assign_room_number,csb.entry_number,csb.number_of_person,rn.room_no');
        $this->db->from('customer_summary_book as csb');
        $this->db->join('room_number as rn', 'csb.assign_room_number=rn.room_id', 'LEFT');
        $this->db->where('csb.encrypt_id', $customerId);
        $this->db->where('csb.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name :
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Manager Id
     ** Date : 3 Mey 2022
     ************************************************************************/
    public function get_all_summary_data($customerId = '', $type = '')
    { 
        $this->db->select('csd.customer_id,csd.id,cbb.bill_generated_date,cbb.bill_item,cbb.bill_number,cbb.paybal_amount,csd.advance_paid,csd.order_date,cbb.bill_amount,csd.page_source,cbb.total_amount');
        $this->db->from('custom_bill_book as cbb');
        $this->db->join('customer_summary_details as csd', 'cbb.customer_id=csd.customer_id', 'LEFT');
        $this->db->where('cbb.customer_id', $customerId);
        if (empty($type)) { 
            $this->db->where('cbb.page_source', 'extend_stay');
        }
        $this->db->where('cbb.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : get_all_food_servie_data
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get_all_food_servie_data
     ** Date : 15 March 2023
     ************************************************************************/
    public function get_all_food_servie_data($customerId = '')
    {
        $this->db->select('csd.customer_id,csd.id,cbb.bill_generated_date,cbb.bill_item,cbb.bill_number,cbb.paybal_amount,csd.advance_paid,csd.order_date,cbb.bill_amount,csd.page_source');
        $this->db->from('custom_bill_book as cbb');
        $this->db->join('customer_summary_details as csd', 'cbb.customer_id=csd.detail_book_id', 'LEFT');
        $this->db->where('cbb.customer_id', $customerId);
        $this->db->where('cbb.page_source', 'add_a_service');
        $this->db->where('cbb.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        // echo $this->db->last_query();
        // die;
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    }
    /***********************************************************************
     ** Function name : selectVendorMessageData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Vendor Message Data
     ** Date : 09 May 2022
     ************************************************************************/
    public function selectVendorMessageData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('adm.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where("hotel_manager_id", $this->session->userdata('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    }
    /***********************************************************************
     ** Function name : getAllMiscAcountData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Misc Acount Data
     ** Date : 27 Mey 2022
     ************************************************************************/
    public function getAllMiscAcountData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    }
    /***********************************************************************
     ** Function name : getCustomerInfo
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for getCustomerInfo
     ** Date : 16 March 2023
     ************************************************************************/
    public function getCustomerInfo($customerId = '')
    {
        $this->db->select('csb.summary_book_id,csb.customer_name,csb.customer_mobile_number,csb.check_in_datetime,csb.check_out_datetime,
                            csb.assign_room_number,csb.entry_number,csb.number_of_person,rn.room_no,csb.gst_number,csb.company_name,csb.company_address,csb.room_rent_type');
        $this->db->from('customer_summary_book as csb');
        $this->db->join('room_number as rn', 'csb.assign_room_number=rn.room_id', 'LEFT');
        $this->db->where('csb.summary_book_id', $customerId);
        $this->db->where('csb.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    }
    /***********************************************************************
     ** Function name : generateCustomebillbookInvoice
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for generate Custome bill book Invoice
     ** Date : 9 Mey 2022
     ************************************************************************/
    public function generateCustomebillbookInvoice($customerId = '', $type = '')
    {
        $this->db->select('cbb.customer_id,cbb.bill_number,SUM(cbb.bill_amount) as total_amount,cbb.cgst,cbb.sgst,cbb.paybal_amount,cbb.page_source');
        $this->db->from('custom_bill_book as cbb');
        $this->db->where('cbb.customer_id', $customerId);
        if (!empty($type)) {
            $this->db->where('cbb.page_source', $type);
        }
        $this->db->where('cbb.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        // echo $this->db->last_query();
        // die;
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getRoomInfo
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room Info
     ** Date : 12 May 2022
     ************************************************************************/
    public function getRoomInfo($type = '')
    {
        $this->db->select('rm.id');
        $this->db->from('room_number as rm');
        $this->db->where('rm.room_no_use', $type);
        $this->db->where('rm.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        return $query->num_rows();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalOwnersWallet
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Owners Wallet
     ** Date : 12 May 2022
     ************************************************************************/
    public function getTotalOwnersWallet($tblName = '', $whereCon = '')
    {
        $this->db->select('SUM(csd.amount_out) as ownerWallet');
        $this->db->from($tblName);
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        $this->db->where('csd.owners_wallet="Y"');
        $this->db->where("csd.daybook_mode = 'Out'");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getOccupencyRoom
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Occupency Percentage By Manager Id
     ** Date : 12 Mey 2022
     ************************************************************************/
    public function getOccupencyRoom($tblName1 = '', $whereCon1 = '')
    {
        $this->db->select('csb.assign_room_number as occupencyPercentage');
        $this->db->from($tblName1);
        if ($whereCon1['like']) : $this->db->where($whereCon1['like']);
        endif;
        $this->db->group_by('csb.assign_room_number');
        $query = $this->db->get();
        return $query->num_rows();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalRoom
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Room By Manager Id
     ** Date : 12 Mey 2022
     ************************************************************************/
    public function getTotalRoom()
    {
        $this->db->select('room_no');
        $this->db->from('room_number');
        $this->db->where('status', 'Y');
        $this->db->where('hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        return $query->num_rows();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectAdminMessageData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Features Data
     ** Date : 07 May 2022
     ************************************************************************/
    public function selectAdminMessageData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('adm.*,v.vendor_business_name,a.admin_display_name');
        $this->db->from($tblName);
        $this->db->join('vendor as v', 'adm.hotel_manager_id = v.vendor_id', 'left');
        $this->db->join('admin as a', 'a.encrypt_id = adm.admin_id', 'left');
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where('adm.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    }
    /***********************************************************************
     ** Function name : getTotalExpensesByOwnerId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Expenses By Owner Id
     ** Date : 21 Mey 2022
     ************************************************************************/
    public function getTotalExpensesByOwnerId($serviceId)
    {
        $this->db->select('SUM(amount_out) as totalExpense');
        $this->db->from('customer_summary_details');
        $this->db->where('service_id', $serviceId);
        $this->db->where('daybook_mode = "Out"');
        $this->db->where('hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllExpensesByOwnerId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Expenses By Owner Id
     ** Date : 21 Mey 2022
     ************************************************************************/
    public function getAllExpensesByOwnerId($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '', $serviceId = '')
    {
        $this->db->select('order_date,amount_out');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where('service_id', $serviceId);
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAdminMessage
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room Info
     ** Date : 21 May 2022
     ************************************************************************/
    public function getAdminMessage($date = '')
    {
        $this->db->select('id');
        $this->db->from('admin_individual_chat');
        $this->db->like('creation_date', $date);
        $this->db->where('hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $this->db->where('msg_flag', 1);
        $query = $this->db->get();
        return $query->num_rows();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getReminderData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room Info
     ** Date : 21 May 2022
     ************************************************************************/
    public function getReminderData($date = '')
    {
        $this->db->select('id');
        $this->db->from('calendar_reservation');
        $this->db->like('reminder_datetime', $date);
        $this->db->where('hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $this->db->where('msg_flag', 1);
        $query = $this->db->get();
        return $query->num_rows();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectCFormdataData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select  C Form Data
     ** Date : 23 MAY 2022
     ************************************************************************/
    public function selectCFormData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('cf.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAttedanceStatusBydate
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Attedance Status By date
     ** Date : 25 Mey 2022
     ************************************************************************/
    public function getAttedanceStatusBydate($staffId, $date)
    {
        $this->db->select('attendance,time_start,time_end');
        $this->db->from('staff_attedance');
        $this->db->like('date', date('Y-m-d', strtotime($date)));
        $this->db->where('staff_id', $staffId);
        $this->db->where('hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : delete_attendance_data_by_date
     ** Developed By : Ashish umrao
     ** Purpose  : This function used for delete item data
     ** Date : 09  MAY 2022
     ************************************************************************/
    public function delete_attendance_data_by_date($attendDate)
    {
        $this->db->like('date', date('Y-m-d', strtotime($attendDate)));
        $this->db->where('hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $this->db->delete('staff_attedance');
        return true;
    }
    /***********************************************************************
     ** Function name : selectstaffSalaryManagerData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select staff attendance Manager Data
     ** Date : 30 April 2022
     ************************************************************************/
    public function selectstaffSalaryManagerData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('statt.staff_id,statt.staff_name');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectstaffSalaryData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select staff Salary Data
     ** Date : 26 MAY 2022
     ************************************************************************/
    public function selectstaffSalaryData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '', $userId = '')
    {
        $this->db->select('ss.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where('staff_id', $userId);
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getCurrentSalaryByStaffId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Current Salary By Staff Id
     ** Date : 26 May 2022
     ************************************************************************/
    public function getCurrentSalaryByStaffId($staffId = '')
    {
        $this->db->select('salary');
        $this->db->from('staff_accounts');
        $this->db->like('staff_id', $staffId);
        $this->db->where('hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        return $query->row_array();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAdvanceSalaryByStaffId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Current Salary By Staff Id
     ** Date : 26 May 2022
     ************************************************************************/
    public function getAdvanceSalaryByStaffId($staffId = '', $date = '')
    {
        $this->db->select('SUM(advance_salary) as AdvanceSalary');
        $this->db->from('staff_salary');
        $this->db->like('staff_id', $staffId);
        $this->db->like('pay_date', date('m-Y', strtotime($date)));
        $this->db->where('hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        return $query->row_array();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllTotalRecordsByDate
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Total Records By Date
     ** Date : 27 May 2022
     ************************************************************************/
    public function getAllTotalRecordsByDate($date = '')
    {
        $this->db->select('SUM(ma.double_bedsheet) as totalDoubleBessheet, SUM(ma.single_bedsheet) as singleBedSheet,SUM(ma.pillow_covers) as pillowCovers,SUM(ma.towels) as totalTowels, SUM(ma.other1) as otherFirst, SUM(ma.other2) as secondOther');
        $this->db->from('miss_account as ma');
        $this->db->like('ma.date', date('m-Y', strtotime($date)));
        $this->db->where('ma.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        return $query->row_array();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getLastEntryDate
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Total Records By Date
     ** Date : 07 JUNE 2022
     ************************************************************************/
    public function getLastEntryDate()
    {
        $this->db->select('order_date');
        $this->db->from('customer_summary_details as csd');
        $this->db->where('csd.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $this->db->order_by('order_date', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTodaysQuotes
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for  get Todays Quotes
     ** Date : 09 JUNE 2022
     ************************************************************************/
    public function getTodaysQuotes()
    {
        $this->db->select('vq.quotes');
        $this->db->from('vendor_quotes as vq');
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectAttendanceDataById
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Attendance Data By Id
     ** Date : 08 JULY 2022
     ************************************************************************/
    public function selectAttendanceDataById($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '', $staff_id = '')
    {
        $this->db->select('sa.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where('sa.staff_id', $staff_id);
        $this->db->where('sa.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        //echo $this->db->last_query();die;
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : delete_item_data
     ** Developed By : Ashish umrao
     ** Purpose  : This function used for delete item data
     ** Date : 09  MAY 2022
     ************************************************************************/
    public function delete_item_data($cust_id = '')
    {
        $this->db->delete('custom_bill_book', array('customer_id' => $cust_id));
        return true;
    }
    /***********************************************************************
     ** Function name : getAllServicesByHotelId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Services By Hotel Id
     ** Date : 01 Nov 2022
     ************************************************************************/
    public function getAllServicesByHotelId($assignserviceId = '')
    {
        $html = '<option value="">Select Service</option>';
        $this->db->select('menu_id,menu_name,price');
        $this->db->from('hotel_menu');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("status = 'Y'");
        $this->db->order_by("menu_name ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            $data = $query->result_array();
            foreach ($data as $info) :
                if ($info['menu_id'] == $assignserviceId) : $select = 'selected="selected"';
                else : $select = '';
                endif;
                $html .= '<option value="' . $info['menu_id'] . '__' . $info['price'] . '__' . $info['menu_name'] . '" ' . $select . '>' . $info['menu_name'] . '(' . $info['price'] . ') </option>';
            endforeach;
        endif;
        return $html;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectHotelMenuData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Hotel Menu Data
     ** Date : 18 October 2022
     ************************************************************************/
    public function selectHotelMenuData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('ms.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where('hotel_manager_id', $this->session->userdata('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getRoomRent
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Total Records By Date
     ** Date : 06 November 2022
     ************************************************************************/
    public function getRoomRent($customerId)
    {
        $this->db->select('csb.amount');
        $this->db->from('customer_summary_book as csb');
        $this->db->where('csb.summary_book_id', $customerId);
        $this->db->where('csb.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $this->db->order_by('id', 'desc');
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllServicesByHotelId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Services By Hotel Id
     ** Date : 01 Nov 2022
     ************************************************************************/
    public function getAllServicesByHotelIdAndName($assignserviceId = '')
    {
        $this->db->select('menu_id,menu_name,price');
        $this->db->from('hotel_menu');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("menu_id", $assignserviceId);
        $this->db->where("status = 'Y'");
        $this->db->order_by("menu_name ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllAvaiableRoomsByHotelId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Rooms By Hotel Id
     ** Date : 11 APRIL 2022
     ************************************************************************/
    public function getAllAvaiableRoomsByHotelId()
    {
        $this->db->select('room_id,room_no');
        $this->db->from('room_number');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("room_no_use = 'N'");
        $this->db->where("status = 'Y'");
        $this->db->order_by("room_no ASC");
        $query = $this->db->get();
        //echo $this->db->last_query();die;
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : checkMenuExistOrNot
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Rooms By Hotel Id
     ** Date : 08 DEC 2022
     ************************************************************************/
    public function checkMenuExistOrNot($menuName = '')
    {
        $this->db->select('menu_id,menu_name,hotel_manager_id');
        $this->db->from('hotel_menu');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("menu_name", $menuName);
        $this->db->where("status = 'Y'");
        $query = $this->db->get();
        //echo $this->db->last_query();die;
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    }
    /***********************************************************************
     ** Function name : getTotalTotalFoodAndOtherServices
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Total Food And Other Services
     ** Date : 2 Mey 2022
     ************************************************************************/
    public function getTotalTotalFoodAndOtherServices($tblName = '', $whereCon = '')
    {
        $this->db->select('SUM(csd.advance_paid) as totalRoomRent');
        $this->db->from($tblName);
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        $this->db->where("csd.page_source='add_a_service'");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getRoomfrombase
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room from base
     ** Date : 17 DESC 2022
     ************************************************************************/
    public function getRoomfrombase($tblName1 = '', $whereCon1 = '', $type = '')
    {
        $this->db->select('COUNT(csb.assign_room_number) as roomCount');
        $this->db->from($tblName1);
        if ($whereCon1['like']) : $this->db->where($whereCon1['like']);
        endif;
        $this->db->where('csb.reffer_mode', $type);
        //$this->db->group_by('csb.assign_room_number');
        $query = $this->db->get();
        //echo $this->db->last_query(); die;
        return $query->row_array();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getRoomCommissioned
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room from base
     ** Date : 18 DESC 2022
     ************************************************************************/
    public function getRoomCommissioned($tblName1 = '', $whereCon1 = '', $type = '', $subType = '')
    {
        $this->db->select('COUNT(csb.assign_room_number) as roomCountdata');
        $this->db->from($tblName1);
        if ($whereCon1['like']) : $this->db->where($whereCon1['like']);
        endif;
        $this->db->where('csb.reffer_mode', $type);
        $this->db->where('csb.direct_mode', $subType);
        //$this->db->group_by('csb.assign_room_number');
        $query = $this->db->get();
        return $query->row_array();
    } // END OF FUNCTION
    public function getTotalSumData($summary_book_id)
    {
        $this->db->select('SUM(payment_paid) as totalAmount,SUM(advance_paid) as advanceAmount');
        $this->db->from('customer_summary_details');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("customer_id", $summary_book_id);
        $query = $this->db->get();
        //echo $this->db->last_query(); die;
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    }
    // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectCustomerIdBookData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Customer Id Book Data
     ** Date : 29 Jan 2023
     ************************************************************************/
    public function selectCustomerIdBookData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('csb.*,rn.room_no');
        $this->db->from($tblName);
        $this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'LEFT');
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getVacantRoomInfo
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Room Info
     ** Date : 12 May 2022
     ************************************************************************/
    public function getVacantRoomInfo()
    {
        $this->db->select('rm.id');
        $this->db->from('room_number as rm');
        $this->db->like('rm.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $this->db->group_start(); //this will start grouping
        $this->db->where('rm.room_no_use =', 'N');
        $this->db->or_where('rm.room_no_use =', "D");
        $this->db->group_end();
		$query = $this->db->get();
        return $query->num_rows();
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectOtsMasterData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for select Ots Master Data
     ** Date : 08 Feb 2023
     ************************************************************************/
    public function selectOtsMasterData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('om.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
     	 $this->db->where('om.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : selectCompanyMasterData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for sselect Company Master Data
     ** Date : 08 Feb 2023
     ************************************************************************/
    public function selectCompanyMasterData($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '')
    {
        $this->db->select('cinfo.*');
        $this->db->from($tblName);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $this->db->where("cinfo.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllGuestListByCompanyId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Guest List By Company Id
     ** Date : 10 FEB 2023
     ************************************************************************/
    public function getAllGuestListByCompanyId($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '', $companyId = '')
    {
        $this->db->select('csb.*,rn.room_no,rn.room_no_use,rn.room_id');
        $this->db->from($tblName);
        $this->db->join('room_number as rn', 'csb.assign_room_number=rn.room_id', 'left');
        $this->db->where('csb.gst_number', $companyId);
        //$this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    }
    /***********************************************************************
     ** Function name : getTotalSaleByOtsId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Ots Id
     ** Date : 10 FEB 2023
     ************************************************************************/
    public function getTotalSaleByOtsId($otsId = '', $fillterDate = '', $type = '')
    {
        $this->db->select('SUM(amount) as totalAmount');
        $this->db->from('customer_summary_book');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        if ($type === 'COMPANY') {
            $this->db->like("gst_number", $otsId);
        } elseif ($type === 'OTA') {
            $this->db->like("ots_id", $otsId);
        }
        if ($fillterDate <> "") {
            $this->db->like("check_out_datetime", $fillterDate);
        } else {
            $this->db->like("check_out_datetime", date('Y-m'));
        }
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    }
    // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllGuestListByOtsId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Guest List By Ots Id
     ** Date : 10 FEB 2023
     ************************************************************************/
     public function getAllGuestListByOtsId($action = '', $tblName = '', $whereCon = '', $shortField = '', $numPage = '', $cnt = '', $otsId = '')
    {
        $this->db->select('csb.*,rn.room_no,rn.room_no_use,rn.room_id');
        $this->db->from($tblName);
        $this->db->join('room_number as rn', 'csb.assign_room_number=rn.room_id', 'left');
        $this->db->where('csb.ots_id', $otsId);
        if ($whereCon['where']) : $this->db->where($whereCon['where']);
        endif;
        if ($whereCon['like']) : $this->db->where($whereCon['like']);
        endif;
        if ($shortField) : $this->db->order_by($shortField);
        endif;
        if ($numPage) : $this->db->limit($numPage, $cnt);
        endif;
        $query = $this->db->get();
        if ($action == 'data') :
            if ($query->num_rows() > 0) :
                return $query->result_array();
            else :
                return false;
            endif;
        elseif ($action == 'count') :
            return $query->num_rows();
        endif;
    }
    /***********************************************************************
     ** Function name : getAllCompanyByHotelId
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Company By Hotel Id
     ** Date : 11 FEB 2023
     ************************************************************************/
    public function getAllCompanyByHotelId($assignCompanyId = '')
    {
        $html = '<option value="">Select GSTIN</option><option value="#">No Gst</option>';
        $this->db->select('company_id,company_gst,status');
        $this->db->from('company_info');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->where("status = 'Y'");
        $this->db->order_by("company_id ASC");
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            $data = $query->result_array();
            foreach ($data as $info) :
                if ($info['company_gst'] == $assignCompanyId) : $select = 'selected="selected"';
                else : $select = '';
                endif;
                $html .= '<option value="' . $info['company_gst'] . '" ' . $select . '>' . $info['company_gst'] . '</option>';
            endforeach;
        endif;
        return $html;
    }
    // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalOtaSale
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale
     ** Date : 11 fEB 2023
     ************************************************************************/
    public function getTotalOtaSale()
    {
        $this->db->select('om.*');
        $this->db->from('ots_master as om');
        $this->db->where("om.hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalSaleByOtsIdReport
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Ots Id
     ** Date : 11 FEB 2023
     ************************************************************************/
    public function getTotalSaleByOtsIdReport($otsId = '', $fromDate = '', $toDate = '')
    {
        $this->db->select('SUM(amount) as totalAmount');
        $this->db->from('customer_summary_book');
        $this->db->where("hotel_manager_id", sessionData('MHM_VENDOR_ID'));
        $this->db->like("ots_id", $otsId);
        if (!empty($fromDate)) :
            $this->db->where('creation_date >=', $fromDate);
            $this->db->where('creation_date <=', $toDate);
        endif;
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->row_array();
        else :
            return false;
        endif;
    }
    // END OF FUNCTION
    /***********************************************************************
     ** Function name : getTotalRooms
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Rooms
     ** Date : 12 May 2022
     ************************************************************************/
    public function getTotalRooms()
    {
        $this->db->select('rm.id,rm.room_no,rm.room_no_use');
        $this->db->from('room_number as rm');
        $this->db->where('rm.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : getAllGroupBillDataByEntryNumber
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get All Group Bill Data ByEntryNumber
     ** Date : 10 JUNE 2022
     ************************************************************************/
    public function getAllGroupBillDataByEntryNumber($entryNumber){
        $this->db->select('csb.*,rn.room_no');
        $this->db->from('customer_summary_book as csb');
        $this->db->join('room_number as rn', 'rn.room_id = csb.assign_room_number', 'left');
        //$this->db->join('customer_summary_details as csd', 'csd.customer_id = csb.summary_book_id', 'left');
        $this->db->where('csb.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $this->db->where('csb.entry_number', $entryNumber);
        $query = $this->db->get();
        //echo $this->db->last_query();die;
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    }
     /***********************************************************************
     ** Function name : getAllGroupSummaryData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for get Total Sale By Manager Id
     ** Date : 11 JUNE 2023
     ************************************************************************/
    public function getAllGroupSummaryData($customerId = '', $type = '')
    { 
        $this->db->select('csd.customer_id,csd.id,cbb.bill_generated_date,cbb.bill_item,cbb.bill_number,cbb.paybal_amount,csd.advance_paid,csd.order_date,cbb.bill_amount,csd.page_source,cbb.total_amount');
        $this->db->from('custom_bill_book as cbb');
        $this->db->join('customer_summary_details as csd', 'cbb.customer_id=csd.customer_id', 'LEFT');
        $this->db->where('cbb.customer_id', $customerId);
        if (empty($type)) { 
            $this->db->where('cbb.page_source', 'extend_stay');
        }
        $this->db->where('cbb.hotel_manager_id', sessionData('MHM_VENDOR_ID'));
        $query = $this->db->get();
        if ($query->num_rows() > 0) :
            return $query->result_array();
        else :
            return false;
        endif;
    } // END OF FUNCTION
}
