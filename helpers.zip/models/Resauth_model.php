<?php
if (!defined('BASEPATH')) exit('No direct script access allowed');
class Resauth_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	/* * *********************************************************************
	 * * Function name : Authenticate
	 * * Developed By : Yashpal Singh
	 * * Purpose  : This function used for Restaurant Login Page
	 * * Date : 08 Feb  2024
	 * * **********************************************************************/
	public function Authenticate($userEmail = ''){
		$this->db->select('*');
		$this->db->from('restaurant');
		$this->db->where('rest_email', $userEmail);
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : getVendorDataByEmail
	 * * Developed By : Yashpal Singh
	 * * Purpose  : This function used for get Restaurant Data By Email
	 * * Date : 08 Feb  2024
	 * * **********************************************************************/
	public function getVendorDataByEmail($userEmail = '')
	{
		$this->db->select('sel.*, vende.vendor_address, vende.vendor_nationality,
						   vende.vendor_pan, vende.vendor_address_proof, vende.vendor_pincode,
						   vende.vendor_kyc_status');
		$this->db->from('vendor as sel');
		$this->db->join("vendor_details as vende", "sel.vendor_id=vende.vendor_id", "LEFT");
		$this->db->where('vendor_email', $userEmail);
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : encriptPassword
	 * * Developed By : Yashpal Singh
	 * * Purpose  : This function used for encript_password
	 * * Date : 08 Feb  2024
	 * * **********************************************************************/
	public function encriptPassword($password)
	{
		return $this->encrypt->encode($password, $this->config->item('encryption_key'));
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : decryptsPassword
	 * * Developed By : Yashpal Singh
	 * * Purpose  : This function used for encript_password
	 * * Date : 08 Feb  2024
	 * * **********************************************************************/
	public function decryptsPassword($password)
	{
		return $this->encrypt->decode($password, $this->config->item('encryption_key'));
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : checkVendorLoginCookie
	 * * Developed By : Yashpal Singh
	 * * Purpose  : This function used for check Vendor Login Cookie
	 * * Date : 08 Feb  2024
	 * * **********************************************************************/
	public function checkVendorLoginCookie()
	{
		if ($_COOKIE['MHM_VENDOR_LOGIN_EMAIL']) :

			$result		=	$this->Authenticate($_COOKIE['MHM_REST_EMAIL']);
			if ($result) :
				if ($result['status'] == 'A' ) :
					$vendorCurrentPath = base_url() . 'restaurant/';
					$this->session->set_userdata(array(
						'MHM_REST_LOGGED_IN' => true,
						'MHM_REST_ID' => $result['id'],
						'MHM_REST_HOTEL_ID' => $result['hotel_manager_id'],
            'MHM_REST_NAME' => $result['rest_name'],
            'MHM_REST_BUSINESS_NAME' => $result['rest_name'],
            'MHM_REST_PHONE' => $result['rest_phone'],
            'MHM_REST_EMAIL' => $result['rest_email'],
            'MHM_REST_IMAGE' => $result['rest_image'],
            'MHM_REST_CURRENT_PATH' => $vendorCurrentPath,
					));
					setcookie('MHM_REST_PHONE', $result['rest_phone'], time() + 60 * 60 * 24 * 100, '/');
					if ($_COOKIE['MHM_VENDOR_REFERENCE_PAGES']) :
						redirect(base_url() . $_COOKIE['MHM_VENDOR_REFERENCE_PAGES']);
					else :
						redirect($vendorCurrentPath . 'dashboard');
					endif;
				endif;
			endif;
		endif;
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : authCheck
	 * * Developed By : Yashpal Singh
	 * * Purpose  : This function used for auth Check
	 * * Date : 08 Feb  2024
	 * * **********************************************************************/
	public function authCheck()
	{
		if ($this->session->userdata('MHM_REST_ID') == "") :
			setcookie('MHM_VENDOR_REFERENCE_PAGES', uri_string(), time() + 60 * 60 * 24 * 5, '/');
			redirect(base_url() . 'restaurant');
		else :
			return true;
		endif;
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : checkOTP
	 * * Developed By : Yashpal Singh
	 * * Purpose  : This function used for Admin otp
	 * * Date : 08 Feb  2024
	 * * **********************************************************************/
	public function checkOTP($userOtp = '')
	{
		$this->db->select('*');
		$this->db->from('vendor');
		$this->db->where('vendor_otp', $userOtp);
		$query	=	$this->db->get();
		if ($query->num_rows() > 0) :
			return $query->row_array();
		else :
			return false;
		endif;
	}	// END OF FUNCTION
}