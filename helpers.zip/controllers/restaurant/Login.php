<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}
class Login extends CI_Controller{
  public function __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('resauth_model', 'vendor_model', 'emailtemplate_model', 'sms_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('owner');
  }
  public function apidata(){
    //$Query = "SELECT * FROM " . getTablePrefix() . "customer_summary_details WHERE creation_date = '0000-00-00 00:00:00' limit 1000 ";
    //$resultArr = $this->common_model->getDataByQuery('multiple', $Query);
    //echo '<pre>';print_r($resultArr);die();
    $i=0;
    //foreach ($resultArr as $row) {
      //$Update['order_date'] = date('Y-m-d H:i:s',strtotime($row['order_date']));
      //$Update['creation_date'] = date('Y-m-d H:i:s',strtotime($row['order_date']));
      //$this->common_model->editData('customer_summary_details', $Update, 'id', $row['id']);
      //echo '<pre>';print_r($Update);
    //}
    //echo '<pre>';print_r($result);
  }
  
  public function index(){
    if ($this->session->userdata('MHM_REST_ID')) {
      redirect('restaurant/dashboard');
    }
    $data['error'] = '';
    $this->resauth_model->checkVendorLoginCookie();
    /*-----------------------------------Login ---------------*/
    if ($this->input->post('loginFormSubmit')):
      $error = 'NO';
      $this->form_validation->set_rules('userEmail', 'email', 'trim|required');
      $vendoremail = str_replace(' ', '', $this->input->post('userEmail'));
      if ($this->input->post('userEmail') && !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)):
        if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)):
          $error = 'YES';
          $data['mobileerror'] = 'Please enter correct email id.';
        endif;
      endif;
      
      $this->form_validation->set_rules('userPassword', 'password', 'trim|required');
      if ($this->form_validation->run() && $error == 'NO'):
        $result = $this->resauth_model->Authenticate(trim($this->input->post('userEmail')));
        //echo '<pre>';print_r($result);die();
        if ($result):
          // echo $this->resauth_model->decryptsPassword($result['vendor_password']);
          // die;
          if ($this->resauth_model->decryptsPassword($result['rest_password']) != trim($this->input->post('userPassword'))):
            $data['error'] = lang('invalidpassword');
          elseif ($result['status'] != 'A'):
            $data['error'] = lang('accountblock');
          else:

            $Query = "SELECT vendor_business_name FROM " . getTablePrefix() . "vendor WHERE vendor_id = '" . $result['hotel_manager_id'] . "'";
            $HotelData = $this->common_model->getDataByQuery('single', $Query);

            $vendorCurrentPath = base_url() . 'restaurant/';
            $this->session->set_userdata(array(
                'MHM_REST_LOGGED_IN' => true,
                'MHM_REST_ID' => $result['id'],
                'MHM_REST_HOTEL_ID' => $result['hotel_manager_id'],
                'MHM_REST_NAME' => $result['rest_name'],
                'MHM_REST_BUSINESS_NAME' => $HotelData['vendor_business_name'],
                'MHM_REST_PHONE' => $result['rest_phone'],
                'MHM_REST_EMAIL' => $result['rest_email'],
                'MHM_REST_IMAGE' => $result['logo'],
                'MHM_REST_CURRENT_PATH' => $vendorCurrentPath,
            ));
            //$param['vendor_last_login'] = currentDateTime();
            //$param['vendor_last_login_ip'] = currentIp();
            //$this->common_model->editData('vendor', $param, 'vendor_id', $result['vendor_id']);
            setcookie('MHM_REST_LOGIN_EMAIL', $result['rest_email'], time() + 60 * 60 * 24 * 100, '/');
            setcookie('MHM_USERNAME', $result['rest_name'], time() + 60 * 60 * 24 * 100, '/');
            redirect($vendorCurrentPath . 'dashboard');
          endif;
        else:
          $data['error'] = lang('invalidlogindetails');
        endif;
      endif;
    endif;
    /*-----------------------------------Forgot password ---------------*/
    if ($this->input->post('recoverformSubmit')):
      //Set rules
      $this->form_validation->set_rules('forgotMobile', 'mobile', 'trim|required');
      if ($this->form_validation->run()):
        $result = $this->resauth_model->Authenticate(trim($this->input->post('forgotMobile')));
        if ($result):
          $param['vendor_otp'] = generateRandomString(4, 'n');
          $this->common_model->editData('vendor', $param, 'vendor_id', $result['vendor_id']);
          $this->sms_model->sendOtpSmsToVendor($result['vendor_phone'], $param['vendor_otp']);
          redirect(base_url() . 'vendor/password-recover');
        else:
          $data['forgoterror'] = lang('invalidmobile');
        endif;
      endif;
    endif;
    $this->layouts->set_title('Login');
    $this->layouts->restaurant_view('restaurant/login', array(), $data, 'login');
  }
  public function password_recover(){
    if ($this->session->userdata('MHM_VENDOR_ID')) {
      redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . 'dashboard');
    }
    $data['error'] = '';
    $this->resauth_model->checkVendorLoginCookie();
        /*-----------------------------------recover password ---------------*/
        if ($this->input->post('passwordRecoverFormSubmit')):
            //Set rules
            $this->form_validation->set_rules('userOtp', 'otp', 'trim|required|min_length[4]|max_length[4]');
            $this->form_validation->set_rules('userPassword', 'New password', 'trim|required|min_length[6]|max_length[25]');
            $this->form_validation->set_rules('userConfPassword', 'Confirm password', 'trim|required|min_length[6]|matches[userPassword]');
            if ($this->form_validation->run()):
                $newPassword = $this->input->post('userPassword');
                $result = $this->resauth_model->checkOTP(trim($this->input->post('userOtp')));
                if ($result):
                    $param['vendor_password'] = $this->resauth_model->encriptPassword(trim($newPassword));
                    $param['vendor_otp'] = '';
                    $param['update_date'] = currentDateTime();
                    $this->common_model->editData('vendor', $param, 'vendor_id', $result['vendor_id']);
                    $this->emailtemplate_model->sendVendorPasswordRecoverMailToAdmin($result, $newPassword);
                    $data['recoversuccess'] = lang('passrecoversuccess');
                    //redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . '/');
                else:
                    $data['recovererror'] = lang('invalidotp');
                endif;
            endif;
        endif;
        $this->layouts->set_title('Password Recover');
        $this->layouts->restaurant_view('vendor/password_recover', array(), $data, 'login');
    } // END OF FUNCTION
    public function profile()
    {
        if ($this->session->userdata('MHM_VENDOR_OWNER_PASSCODE') == '') {
            redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . 'dashboard');
        }
        $this->resauth_model->authCheck();
        $data['error'] = '';
        $data['activeMenu'] = '';
        $data['activeSubMenu'] = '';
        $whereCon['where'] = 'ven.vendor_id ="' . $this->session->userdata('MHM_VENDOR_ID') . '"';
        $shortField = 'ven.id ASC';
        $shortFieldGROUP = 'ven.id';
        $this->load->library('pagination');
        $config['base_url'] = $this->session->userdata('MHM_VENDOR_CURRENT_PATH') . $this->router->fetch_class() . '/index';
        $tblName = 'vendor as ven';
        $con = '';
        $config['total_rows'] = $this->vendor_model->selectVendorData('count', $tblName, $whereCon, $shortField, '0', '0', $shortFieldGROUP);
        $config['per_page'] = 10;
        $config['uri_segment'] = getUrlSegment();
        $this->pagination->initialize($config);
        if ($this->uri->segment(getUrlSegment())):
            $page = $this->uri->segment(getUrlSegment());
        else:
            $page = 0;
        endif;
        $data['ADMINDATA'] = $this->vendor_model->selectVendorData('data', $tblName, $whereCon, $shortField, $config['per_page'], $page, $shortFieldGROUP);
        $this->layouts->set_title('Profile');
        $this->layouts->owner_view('vendor/profile', array(), $data);
    } // END OF FUNCTION
    public function editprofile($editId = '')
    {
        $this->resauth_model->authCheck();
        $data['error'] = '';
        $data['activeMenu'] = '';
        $data['activeSubMenu'] = '';
        $data['EDITDATA'] = $this->common_model->getDataByParticularField('vendor', 'vendor_id', $editId);
        if ($data['EDITDATA'] == ''):
            redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . 'dashboard');
        endif;
        $kycQuery = "SELECT * FROM " . getTablePrefix() . "vendor_details
									 WHERE vendor_id = '" . $editId . "'";
        $data['KYCDATA'] = $this->common_model->getDataByQuery('single', $kycQuery);
        if ($this->input->post('SaveChanges')):
            $error = 'NO';
            $this->form_validation->set_rules('vendor_business_name', 'Business name', 'trim|required');
            $this->form_validation->set_rules('vendor_title', 'Title', 'trim|required');
            $this->form_validation->set_rules('vendor_name', 'Name', 'trim|required');
            $this->form_validation->set_rules('vendor_email', 'E-Mail', 'trim|required');
            $this->form_validation->set_rules('admin_mobile_number', 'Phone', 'trim|required|min_length[10]|max_length[15]');
            $adminmobile = str_replace(' ', '', $this->input->post('admin_mobile_number'));
            if ($this->input->post('admin_mobile_number') && !preg_match('/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i', $adminmobile)):
                if (!preg_match("/^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1})?([0-9]{10})$/", $adminmobile)):
                    $error = 'YES';
                    $data['mobileerror'] = 'Please Eneter Correct Number.';
                endif;
            endif;
            $this->form_validation->set_rules('owner_secoundry_contact_number', 'Phone', 'trim|min_length[10]|max_length[15]');
            /*$ownerSecndmobile        =    str_replace(' ', '', $this->input->post('owner_secoundry_contact_number'));
            if ($this->input->post('owner_secoundry_contact_number') && !preg_match('/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i', $ownerSecndmobile)) :
            if (!preg_match("/^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1})?([0-9]{10})$/", $ownerSecndmobile)) :
            $error                        =    'YES';
            $data['owner_secoundry_contact_number']         =     'Please Eneter Correct Number.';
            endif;
            endif;*/
            $this->form_validation->set_rules('manager_contact_number_first', 'Phone', 'trim|required|min_length[10]|max_length[15]');
            /*$mngrmobile        =    str_replace(' ', '', $this->input->post('manager_contact_number_first'));
            if ($this->input->post('manager_contact_number_first') && !preg_match('/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i', $mngrmobile)) :
            if (!preg_match("/^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1})?([0-9]{10})$/", $mngrmobile)) :
            $error                        =    'YES';
            $data['manager_contact_number_first']         =     'Please Eneter Correct Number.';
            endif;
            endif;*/
            $this->form_validation->set_rules('manager_contact_number_secound', 'Phone', 'trim|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('vendor_image', 'Image', 'trim');
            $this->form_validation->set_rules('vendor_address', 'Address', 'trim|required');
            $this->form_validation->set_rules('gst_number', 'Gst Number', 'trim');
            if ($this->form_validation->run() && $error == 'NO'):
                $param['vendor_title'] = addslashes($this->input->post('vendor_title'));
                $param['vendor_name'] = addslashes($this->input->post('vendor_name'));
                $param['vendor_business_name'] = addslashes($this->input->post('vendor_business_name'));
                $param['vendor_email'] = addslashes($this->input->post('vendor_email'));
                $param['vendor_phone'] = addslashes($this->input->post('admin_mobile_number'));
                $param['owner_secoundry_contact_number'] = addslashes($this->input->post('owner_secoundry_contact_number'));
                $param['first_manager_contact_number'] = addslashes($this->input->post('manager_contact_number_first'));
                $param['secound_manager_contact_number'] = addslashes($this->input->post('manager_contact_number_secound'));
                $param['vendor_image'] = addslashes($this->input->post('vendor_image'));
                $SDparam['vendor_address'] = addslashes($this->input->post('vendor_address'));
                //$SDparam['vendor_city']                            =     addslashes($this->input->post('vendor_city'));
                //$SDparam['vendor_pincode']                        =     addslashes($this->input->post('vendor_pincode'));
                $SDparam['you_are'] = addslashes($this->input->post('you_are')); //entry_number
                $SDparam['bill_number'] = addslashes($this->input->post('bill_number'));
                $SDparam['entry_number'] = addslashes($this->input->post('entry_number'));
                $SDparam['vendor_gst'] = addslashes($this->input->post('gst_number'));
                $SDparam['website_url'] = addslashes($this->input->post('website'));
                $SDparam['managed_by'] = addslashes($this->input->post('managed_by'));
                $SDparam['other_details'] = addslashes($this->input->post('other_details'));
                $vendorId = $this->input->post('CurrentDataID');
                $param['update_date'] = currentDateTime();
                $this->common_model->editData('vendor', $param, 'vendor_id', $vendorId);
                if ($vendorId):
                    $SDparam['update_date'] = currentDateTime();
                    $this->common_model->editData('vendor_details', $SDparam, 'vendor_id', $vendorId);
                endif;
                $result = $this->resauth_model->Authenticate($param['vendor_phone']);
                if ($result):
                    $vendorCurrentPath = base_url() . 'vendor/' . $result['vendor_slug'] . '/';
                    $this->session->set_userdata(array(
                        'MHM_VENDOR_LOGGED_IN' => true,
                        'MHM_VENDOR_ID' => $result['vendor_id'],
                        'MHM_VENDOR_SLUG' => $result['vendor_slug'],
                        'MHM_VENDOR_TITLE' => $result['vendor_title'],
                        'MHM_VENDOR_NAME' => $result['vendor_name'],
                        'MHM_VENDOR_BUSINESS_NAME' => $result['vendor_business_name'],
                        'MHM_VENDOR_PHONE' => $result['vendor_phone'],
                        'MHM_VENDOR_OWNER_PHONE_SECOUNDRY' => $result['owner_secoundry_contact_number'],
                        'MHM_VENDOR_MANAGER_PHONE_FIRST' => $result['manager_contact_number_first'],
                        'MHM_VENDOR_MANAGER_PHONE_SECOUND' => $result['manager_contact_number_secound'],
                        'MHM_VENDOR_EMAIL' => $result['vendor_email'],
                        'MHM_VENDOR_IMAGE' => $result['vendor_image'],
                        'MHM_VENDOR_CURRENT_PATH' => $vendorCurrentPath,
                        'MHM_VENDOR_ADDRESS' => $result['vendor_address'],
                        'MHM_VENDOR_NATIONALITY' => $result['vendor_nationality'],
                        'MHM_VENDOR_PAN' => $result['vendor_pan'],
                        'MHM_VENDOR_ADDRESS_PROOF' => $result['vendor_address_proof'],
                        'MHM_VENDOR_PINCODE' => $result['vendor_pincode'],
                        'MHM_VENDOR_KYC_STATUS' => $result['vendor_kyc_status'],
                        'MHM_VENDOR_LAST_LOGIN' => $result['vendor_last_login'] . ' (' . $result['vendor_last_login_ip'] . ')',
                    ));
                    setcookie('MHM_VENDOR_LOGIN_EMAIL', $result['vendor_email'], time() + 60 * 60 * 24 * 100, '/');
                endif;
                $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . 'profile');
            endif;
        endif;
        $this->layouts->set_title('Edit Profile');
        $this->layouts->owner_view('vendor/editprofile', array(), $data);
    } // END OF FUNCTION
    // END OF FUNCTION
    /* * *********************************************************************
     * * Function name : changepassword
     * * Developed By : Ashish Umrao
     * * Purpose  : This function used for change password
     * * Date : 11 APRIL 2022
     * * **********************************************************************/
    public function changepassword($editId = '')
    {
        $this->resauth_model->authCheck();
        $data['error'] = '';
        $data['activeMenu'] = '';
        $data['activeSubMenu'] = '';
        $data['EDITDATA'] = $this->common_model->getDataByParticularField('vendor', 'vendor_id', $editId);
        if ($data['EDITDATA'] == ''):
            redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . 'dashboard');
        endif;
        $data['OLDPASSWORD'] = $this->resauth_model->decryptsPassword($data['EDITDATA']['vendor_password']);
        if ($this->input->post('SaveChanges')):
            $error = 'NO';
            $this->form_validation->set_rules('old_password', 'Old password', 'trim');
            $this->form_validation->set_rules('current_password', 'Current password', 'trim|required|min_length[6]|matches[old_password]');
            $this->form_validation->set_rules('new_password', 'New password', 'trim|required|min_length[6]|max_length[25]');
            $this->form_validation->set_rules('conf_password', 'Confirm password', 'trim|required|min_length[6]|matches[new_password]');
            if ($this->form_validation->run() && $error == 'NO'):
                $NewPassword = $this->input->post('new_password');
                $param['vendor_password'] = $this->resauth_model->encriptPassword($NewPassword);
                $vendorId = $this->input->post('CurrentDataID');
                $param['update_date'] = currentDateTime();
                $this->common_model->editData('vendor', $param, 'vendor_id', $vendorId);
                $this->emailtemplate_model->sendVendorPasswordRecoverMailToAdmin($data['EDITDATA'], $NewPassword);
                $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . 'profile');
            endif;
        endif;
        $this->layouts->set_title('Edit Profile');
        $this->layouts->owner_view('vendor/changepassword', array(), $data);
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : firstImageUpload
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for first Image Upload
     ** Date : 11 APRIL 2022
     ************************************************************************/
    public function firstImageUpload()
    {
        if ($this->input->post('imageData')):
            $imageData = $this->input->post('imageData');
            $imageName = time() . '.png';
            $imageFolder = '';
            $imageType = 'vendorImage';
            $this->load->library("upload_crop_img");
            $returnFileName = $this->upload_crop_img->_upload_canvas_image($imageData, $imageName, $imageType, $imageFolder);
            if ($returnFileName):
                echo $returnFileName;
                die;
            else:
                echo 'UPLODEERROR';
                die;
            endif;
        else:
            echo 'UPLODEERROR';
            die;
        endif;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : firstImageDelete
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for first Image Delete
     ** Date : 11 APRIL 2022
     ************************************************************************/
    public function firstImageDelete()
    {
        $imageName = $this->input->post('imageName');
        if ($imageName):
            $this->load->library("upload_crop_img");
            $return = $this->upload_crop_img->_delete_image($imageName);
        endif;
        echo '1';
        die;
    } // END OF FUNCTION
    /***********************************************************************
     ** Function name : UplodeImage
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used uplode image
     ** Date : 11 APRIL 2022
     ************************************************************************/
    public function UplodeImage()
    {
        $file_name = $_FILES['uploadfile']['name'];
        if ($file_name):
            $tmp_name = $_FILES['uploadfile']['tmp_name'];
            $imageInformation = getimagesize($_FILES['uploadfile']['tmp_name']);
            if ($imageInformation[0] <= 800 && $imageInformation[1] <= 800):
                $this->load->library("upload_crop_img");
                $return_file_name = $this->upload_crop_img->_upload_image($file_name, $tmp_name, 'vendorProofImage');
                echo $return_file_name;
                die;
            else:
                echo 'ERROR_____Image Must Be Max Width:800px And Height:800px.';
                die;
            endif;
        else:
            echo 'UPLODEERROR';
            die;
        endif;
    }
    /***********************************************************************
     ** Function name : DeleteImage
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for delete image by ajax.
     ** Date : 11 APRIL 2022
     ************************************************************************/
    public function DeleteImage()
    {
        $imagename = $this->input->post('imagename');
        if ($imagename):
            $this->load->library("upload_crop_img");
            $return = $this->upload_crop_img->_delete_image($imagename);
        endif;
        echo '1';
        die;
    }
    /***********************************************************************
     ** Function name : logout
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for logout
     ** Date : 11 APRIL 2022
     ************************************************************************/
    public function logout()
    {
        setcookie('MHM_REST_LOGIN_EMAIL', '', time() - 60 * 60 * 24 * 100, '/');
        setcookie('MHM_REST_REFERENCE_PAGES', '', time() - 60 * 60 * 24 * 100, '/');
        $this->session->unset_userdata(array(
            'MHM_REST_LOGGED_IN',
            'MHM_REST_ID',
            'MHM_REST_HOTEL_ID',
            'MHM_REST_NAME',
            'MHM_REST_BUSINESS_NAME',
            'MHM_REST_PHONE',
            'MHM_REST_EMAIL',
            'MHM_REST_IMAGE',
            'MHM_REST_CURRENT_PATH',            
        ));
        redirect(base_url() . 'restaurant/login');
    } // END OF FUNCTION
}
