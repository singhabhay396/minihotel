<?php defined('BASEPATH') or exit('No direct script access allowed');

class Menu extends CI_Controller
{
	public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    ini_set('display_errors', 1);
    $this->load->model(array('resauth_model', 'vendor_model', 'owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor');
    $this->resauth_model->authCheck();
  }
	public function index(){	
		$data['error'] 						= 	'';
		$data['activeMenu'] 				= 	'Menu';
		$data['activeSubMenu'] 				= 	'Menu';
		$hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
		

		$CatQuery = "SELECT * FROM ".getTablePrefix()."hotel_menu_category WHERE hotel_manager_id='".$hotel_manager_id."'";
		$data['CategoryArr'] = 	$this->common_model->getDataByQuery('multiple', $CatQuery);

		$baseUrl 							= 	base_url('restaurant/menu/index');
		$qStringdata						=	explode('?', currentFullUrl());
		$suffix								= 	$qStringdata[1] ? '?' . $qStringdata[1] : '';

		//////////////////		ADD EDIT SECTION   START 	////////////////
		$data['formError']					=	'No';
		$data['editid']						=	'';
		$data['editlink']					= 	$qStringdata[1] ? $baseUrl . '?' . $qStringdata[1] . '&editid=' : $baseUrl . '?editid=';
		if (strpos($data['editlink'], 'showLength')) :
			$showlinkdata					=	explode('&editid=', $data['editlink']);
			if ($page > 0) :
				$newlinkdata				=	explode('?', $showlinkdata[0]);
				$data['cancellink']			= 	$newlinkdata[0] . '/' . $page . '?' . $newlinkdata[1];
			else :
				$data['cancellink']			= 	$showlinkdata[0];
			endif;
		else :
			$showlinkdata					=	explode('?editid=', $data['editlink']);
			if ($page > 0) :
				$data['cancellink']			= 	$showlinkdata[0] . '/' . $page;
			else :
				$data['cancellink']			= 	$showlinkdata[0];
			endif;
		endif;

		if ($this->input->get('editid')) :
			$data['editid']					=	$this->input->get('editid');
			$data['EDITDATA']				=	$this->common_model->getDataByParticularField('hotel_menu', 'menu_id', $data['editid']);
		endif;

		if ($this->input->post('SaveChanges')) :
			$error											=	'NO';
			$data['formError']					=	'Yes';
			$this->form_validation->set_rules('menu_name', 'Menu', 'required|trim');
			$this->form_validation->set_rules('menu_price', 'Pice', 'required|trim');
			if ($this->form_validation->run() && $error == 'NO') :
				$data['formError']				=	'No';    			
				$param['hotel_manager_id']		= 	addslashes($this->session->userdata('MHM_REST_HOTEL_ID'));
        $param['menu_name']				= 	addslashes($this->input->post('menu_name'));
				$param['price']				= 	addslashes($this->input->post('menu_price'));
				$param['category_id']				= 	addslashes($this->input->post('category_id'));
				if ($this->input->post('CurrentDataID') == '') :
					$param['creation_date']		=	currentDateTime();
					$param['created_by']		=	$this->session->userdata('MHM_REST_HOTEL_ID');
					$param['status']			=	'Y';
					$alastInsertId				=	$this->common_model->addData('hotel_menu', $param);
					$Uparam['encrypt_id']		=	ashishEncript($alastInsertId);
					$Uparam['menu_id']		=	generateUniqueId($alastInsertId);
					$Uwhere['id']				=	$alastInsertId;
					$this->common_model->editDataByMultipleCondition('hotel_menu', $Uparam, $Uwhere);
					$this->session->set_flashdata('alert_success', lang('addsuccess'));
				else :
					$menuId					=	$this->input->post('CurrentDataID');
					$param['update_date']		=	currentDateTime();
					$param['updated_by']		=	$this->session->userdata('MHM_REST_HOTEL_ID');
					$this->common_model->editData('hotel_menu', $param, 'menu_id', $menuId);
					$this->session->set_flashdata('alert_success', lang('updatesuccess'));
				endif;
				redirect('restaurant/menu/index');
			endif;
		endif;
		//////////////////		ADD EDIT SECTION   END 	////////////////

		$this->layouts->set_title('Food Menu');
		$this->layouts->restaurant_view('restaurant/menu/index', array(), $data);
	}	// END OF FUNCTION
	public function Pagination(){
		$Search['category_id']     = $_GET['category_id'] ?? 'All';
    $Search['menu_name']     = $_GET['menu_name'] ?? '';
    $Search['price']       = $_GET['price'] ?? '';
    $Search['status']       = $_GET['status'] ?? 'All';
    $Search['page']           = $_GET['page'] ?? 1;
    $Search['numofrecords']   = $_GET['numofrecords'] ?? 100;
    //$Search['cur_page']       = $Search['page'];
    $Limitpage                = $Search['page']-1;
    $Search['start']          = $Limitpage * $Search['numofrecords'];
    
    $Search['action'] = 'count';
    $TotalData = $this->PaginationData($Search);
    $data['PAGINATION'] = Pagination($Search['numofrecords'],$TotalData, $Search['page']);
    $Search['action'] = 'data';
    $data['ALLDATA'] = $this->PaginationData($Search);
    //echo '<pre>';print_r($data);die;
    $this->load->view('restaurant/menu/Pagination', $data);
	}
	function PaginationData($Search){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $this->db->select('ms.*,category.category_name');
    $this->db->from('hotel_menu as ms');
    $this->db->join('hotel_menu_category as category', 'category.id=ms.category_id', 'LEFT');

    if($Search['menu_name']!=''){ $this->db->where("ms.menu_name LIKE '%" . $Search['menu_name'] . "%'"); }
    if($Search['category_id']!='All'){ $this->db->where("ms.category_id",$Search['category_id']); }
    if($Search['price']!=''){ $this->db->where("ms.price",$Search['price']); }
    if($Search['status']!='All'){ $this->db->where("ms.status",$Search['status']); }

    $this->db->where("ms.hotel_manager_id",$hotel_manager_id); 
    $this->db->order_by('ms.menu_name asc');
    if ($Search['action']=='data'){ $this->db->limit($Search['numofrecords'], $Search['start']); }
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($Search['action'] == 'data'){
      if ($query->num_rows() > 0){
        return $query->result_array();
      }else{
        return false;
      }
    }elseif ($Search['action'] == 'count'){
      return $query->num_rows();
    }
  }

	function changeStatus($changeStatusId = '', $statusType = ''){
		$param['status']		=	$statusType;
		$this->common_model->editData('hotel_menu', $param, 'menu_id', $changeStatusId);
		$this->session->set_flashdata('alert_success', lang('statussuccess'));
		redirect('restaurant/menu/index');
	}
	function deleteData($deleteId = ''){
		$this->common_model->deleteParticularData('hotel_menu', 'menu_id', $deleteId);
		$this->session->set_flashdata('alert_success', lang('deletesuccess'));
		redirect('restaurant/menu/index');
	}

  public function save(){
		if ($this->input->post('SaveChanges')) :
			$error								=	'NO';
			$data['formError']					=	'Yes';
			$this->form_validation->set_rules('menu_name', 'Menu', 'required|trim');
			$this->form_validation->set_rules('menu_price', 'Pice', 'required|trim');
			if ($this->form_validation->run() && $error == 'NO') :
				$data['formError']				=	'No';
				$param['hotel_manager_id']		= 	addslashes($this->session->userdata('MHM_REST_HOTEL_ID'));
				$param['menu_name']				= 	addslashes($this->input->post('menu_name'));
				$param['price']				= 	addslashes($this->input->post('menu_price'));
				$param['category_id']				= 	addslashes($this->input->post('category_id'));
				if ($this->input->post('CurrentDataID') == '') :
					$param['creation_date']		=	currentDateTime();
					$param['created_by']		=	$this->session->userdata('MHM_REST_HOTEL_ID');
					$param['status']			=	'Y';
					$currentDataID				=	$this->common_model->addData('hotel_menu', $param);
					$Uparam['encrypt_id']		=	ashishEncript($currentDataID);
					$Uparam['menu_id']		=	generateUniqueId($currentDataID);
					$Uwhere['id']				=	$currentDataID;
					$this->common_model->editDataByMultipleCondition('hotel_menu', $Uparam, $Uwhere);
				else :
					$currentDataID					=	$this->input->post('CurrentDataID');
					$param['update_date']		=	currentDateTime();
					$param['updated_by']		=	$this->session->userdata('MHM_REST_HOTEL_ID');
					$this->common_model->editData('hotel_menu', $param, 'menu_id', $currentDataID);
				endif;

				$query = "SELECT menu_id,menu_name,price FROM " . getTablePrefix() . "hotel_menu WHERE id = '" . $currentDataID . "' AND hotel_manager_id = '" . $this->session->userdata('MHM_VENDOR_ID') . "'";
				$data['menu'] = $this->common_model->getDataByQuery('single', $query);
			endif;
		endif;

		//add the header here
		header('Content-Type: application/json');
		echo json_encode($data);
	} // END OF FUNCTION
	public function menucategory(){
		$data['error'] 						= 	'';
		$data['activeMenu'] 				= 	'hotelmenus';
		$data['activeSubMenu'] 				= 	'hotelmenus';
		$data['LoginVenderId'] = sessionData('MHM_REST_HOTEL_ID');

		$CatQuery = "SELECT * FROM " . getTablePrefix() . "hotel_menu_category WHERE hotel_manager_id = '" . $data['LoginVenderId'] . "'";
		$data['ALLDATA'] = 	$this->common_model->getDataByQuery('multiple', $CatQuery);

		//////////////////		ADD EDIT SECTION   START 	////////////////
		$data['formError']					=	'No';
		$data['editid']						=	'';
		if ($this->input->get('editid')) :
			$data['editid']					=	$this->input->get('editid');
			$data['EDITDATA']				=	$this->common_model->getDataByParticularField('hotel_menu_category', 'id', $data['editid']);
		endif;

		if ($this->input->post('SaveChanges')) :
			$error								=	'NO';
			$data['formError']					=	'Yes';
			$this->form_validation->set_rules('category_name', 'category_name', 'required');

			if ($this->form_validation->run() && $error == 'NO') :
				$data['formError']				=	'No';
				$param['hotel_manager_id']		= 	addslashes($this->session->userdata('MHM_REST_HOTEL_ID'));
				$param['category_name']				= 	addslashes($this->input->post('category_name'));
				$param['manager_id']					=		addslashes($this->session->userdata('MHM_REST_HOTEL_ID'));

				if ($this->input->post('CurrentDataID') == '') :
					$param['add_Date']		=	date('Y-m-d H:i:s');
					$alastInsertId				=	$this->common_model->addData('hotel_menu_category', $param);
					$this->session->set_flashdata('alert_success', lang('addsuccess'));
				else :
					$carBrandId					=	$this->input->post('CurrentDataID');
					$this->common_model->editData('hotel_menu_category', $param, 'id', $carBrandId);
					$this->session->set_flashdata('alert_success', lang('updatesuccess'));
				endif;
				redirect('restaurant/menu/menucategory');
			endif;
		endif;
		//////////////////		ADD EDIT SECTION   END 	////////////////

		$this->layouts->set_title('Menu Category');
		$this->layouts->restaurant_view('restaurant/menu/category', array(), $data);
	}
}