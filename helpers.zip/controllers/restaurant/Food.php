<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Food extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    ini_set('display_errors', 1);
    $this->load->model(array('resauth_model', 'vendor_model', 'owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->resauth_model->authCheck();
  }
  public function service($encrypt_id){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $CUSTDATA = $this->common_model->getDataByParticularField('customer_summary_book', 'encrypt_id', $encrypt_id);
    $Query = "SELECT * FROM ".getTablePrefix()."customer_summary_details WHERE hotel_manager_id='".$hotel_manager_id."' AND customer_id='".$CUSTDATA['summary_book_id']."' AND page_source = 'add_a_service' GROUP BY kot_number order by creation_date desc;";
    $data['FoodData'] = $this->common_model->getDataByQuery('multiple', $Query);
    $data['error'] = '';
    $data['activeMenu'] = 'Dashboard';
    $data['activeSubMenu'] = 'Dashboard';
    $data['encrypt_id'] = $encrypt_id;
    $data['CUSTDATA'] = $CUSTDATA;
    $this->layouts->set_title('Dashboard');
    $this->layouts->restaurant_view('restaurant/food/service', array(), $data);
  }
  public function booking($encrypt_id){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');

    $Query = "SELECT customer_name,encrypt_id,id FROM ".getTablePrefix()."customer_summary_book WHERE hotel_manager_id='".$hotel_manager_id."' AND encrypt_id='".$encrypt_id."' ";
    $data['CustomerData'] = $this->common_model->getDataByQuery('single', $Query);

    $Query = "SELECT id,category_name FROM ".getTablePrefix()."hotel_menu_category WHERE hotel_manager_id='".$hotel_manager_id."' order by id DESC;";
    $data['CategoryArr'] = $this->common_model->getDataByQuery('multiple', $Query);    
    //echo '<pre>';print_r($data['CustomerData']);die();
    $data['error'] = '';
    $data['activeMenu'] = 'Dashboard';
    $data['activeSubMenu'] = 'Dashboard';
    $data['encrypt_id'] = $encrypt_id;
    $this->layouts->set_title('Dashboard');
    $this->layouts->restaurant_view('restaurant/food/index', array(), $data);
  }
  public function FoodMenuList(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $category_id          = $_GET['menu_id'] ?? 0;
    $menu_name            = $_GET['menu_name'] ?? '';

    if($category_id>0){
      $Query = "SELECT id,menu_name,price FROM ".getTablePrefix()."hotel_menu WHERE category_id='".$category_id."' AND hotel_manager_id='".$hotel_manager_id."' order by id DESC;";
    }else{
      $Query = "SELECT id,menu_name,price FROM ".getTablePrefix()."hotel_menu WHERE (menu_name LIKE '%" . $menu_name . "%') AND hotel_manager_id='".$hotel_manager_id."' order by id DESC;";
    }

    $data['MenuArr'] = $this->common_model->getDataByQuery('multiple', $Query);
    $this->load->view('restaurant/food/menu', $data);
  }
  public function FoodMenuCart(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $customer_id      = $_GET['customer_id'] ?? 0;
    $Query = "SELECT cart.*,menu.menu_name,menu.price FROM ".getTablePrefix()."hotel_menu_cart as cart join ".getTablePrefix()."hotel_menu as menu on menu.id=cart.menu_id WHERE cart.customer_id='".$customer_id."' AND cart.hotel_manager_id='".$hotel_manager_id."' order by cart.id DESC";
    $data['MenuArr'] = $this->common_model->getDataByQuery('multiple', $Query);
    $data['customer_id'] = $customer_id;
    $this->load->view('restaurant/food/Cart', $data);
  }
  public function AddToCardMenu(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $customer_id      = $_GET['customer_id'] ?? 0;
    $menu_id          = $_GET['menu_id'] ?? 0;
    $qty              = $_GET['qty'] ?? 1;

    $Save['hotel_manager_id'] = $hotel_manager_id;
    $Save['customer_id'] = $customer_id;
    $Save['table_id'] = 0;
    //$Save['kot_no']   = 5;
    $Save['menu_id']  = $menu_id;
    $Save['qty']      = $qty;
    $Save['add_date'] = date('Y-m-d H:i:s');

    $sql = "SELECT id,qty FROM ".getTablePrefix()."hotel_menu_cart WHERE hotel_manager_id='".$hotel_manager_id."' AND menu_id='".$menu_id."' AND customer_id='".$customer_id."' ";
    $result = $this->common_model->getDataByQuery('single', $sql);
    if($result){
      $Save['qty']      = $qty+$result['qty'];
      $this->common_model->editData('hotel_menu_cart', $Save, 'id', $result['id']);
    }else{
      $Save['qty']      = $qty;
      $this->common_model->addData('hotel_menu_cart', $Save);
    }
  }
  public function FoodUpdateAddToCart(){
    $qty = $_POST['qty'];
    $id = $_POST['id'];
    $Save['qty']      = $qty;
    $this->common_model->editData('hotel_menu_cart', $Save, 'id', $id);
  }
  public function DeleteItem(){
    $id = $_GET['id'] ?? '';
    $this->common_model->deleteData('hotel_menu_cart', 'id', $id);
  }
  public function DeleteKOT($kot_number,$encrypt_id){
    $kot_number = base64_decode($kot_number);
    $this->common_model->deleteData('customer_summary_details', 'kot_number', $kot_number);

    $this->session->set_flashdata('alert_success', 'Delete Successfully');
    redirect('restaurant/food/service/'.$encrypt_id);
  }
  public function SaveKOT(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $Rest_id = sessionData('MHM_REST_ID');
    $customer_id = base64_decode($_GET['customer_id']);
    $settle_type = $_GET['settle_type'];
    $TotalAmount = $_GET['TotalAmount'];
    $GrandAmount = $_GET['GrandAmount'];
    $gst_type = $_GET['gst_type'];
    
    if($settle_type=='Settle_on_the_spot'){
      $cash = $_GET['amount_mode1'];
      $cash_paid = $_GET['payment_paid1'];
      $online = $_GET['amount_mode2'];
      $online_paid = $_GET['payment_paid2'];
      $discount = $_GET['discount'];
    }

    $Query = "SELECT cart.*,menu.menu_name,menu.price FROM ".getTablePrefix()."hotel_menu_cart as cart join ".getTablePrefix()."hotel_menu as menu on menu.id=cart.menu_id WHERE cart.customer_id='".$customer_id."' AND cart.hotel_manager_id='".$hotel_manager_id."' order by cart.id DESC;";
    $MenuArr = $this->common_model->getDataByQuery('multiple', $Query);


    $CustomerQuery = "SELECT summary_book_id,encrypt_id FROM ".getTablePrefix()."customer_summary_book WHERE hotel_manager_id='".$hotel_manager_id."' AND id='".$customer_id."' ";
    $CustomerData = $this->common_model->getDataByQuery('single', $CustomerQuery);

    $KOTNumber = $this->common_model->getDataByParticularField('restaurant','id', $Rest_id);
    $kot_number = $KOTNumber['kot_number'] + 1;

    foreach ($MenuArr as $row) {

      $advance_paid = $row['price'] * $row['qty'];
      if($gst_type=='gst_exclusive'){
        $GSTAmt   = round($advance_paid * 5) / 100;
        $advance_paid = $advance_paid + $GSTAmt;
      }

      $param['hotel_manager_name'] = sessionData('MHM_REST_NAME');
      $param['quantity'] = $row['qty'];
      $param['order_date'] = currentDateTime();
      $param['amount_mode'] = "offline";
      $param['service_id'] = $row['menu_id'];
      $param['advance_paid'] = $advance_paid;
      $param['menu_price'] = $row['price'] * $row['qty'];
      $param['gst_type'] = $gst_type;

      $param['settle_type'] = $settle_type;
      $param['total_amt'] = $TotalAmount;
      if($settle_type=='Settle_on_the_spot'){
        $param['cash'] = $cash;
        $param['cash_paid'] = $cash_paid;  
        $param['online'] = $online;
        $param['online_paid'] = $online_paid;
        $param['discount'] = $discount;
      }  
      $param['payment_paid'] = 0;
      $param['bill_item'] = $row['menu_name'];
      $param['kot_number'] = KOTPrefix.'/'.$kot_number;
      $param['user_type'] = 'Restaurant';
      $param['hotel_manager_id'] = sessionData('MHM_REST_HOTEL_ID');
      $param['customer_id'] = $CustomerData['summary_book_id'];
      $param['daybook_mode'] = "In";
      $param['page_source'] = "add_a_service";
      $param['creation_date'] = currentDateTime();
      $param['created_by'] = $this->session->userdata('MHM_REST_ID');
      $lastInsertId = $this->common_model->addData('customer_summary_details', $param);

      $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
      $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
      $Uwhere['id'] = $lastInsertId;
      $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
      //echo '<pre>';print_r($param);
    }
    $this->common_model->deleteData('hotel_menu_cart', 'customer_id', $customer_id);

    $vparam['kot_number'] = $kot_number;
    $this->common_model->editData('restaurant', $vparam, 'id',$Rest_id);

    $this->session->set_flashdata('alert_success', lang('statussuccess'));
    redirect('restaurant/food/service/'.$CustomerData['encrypt_id']);
  }
  public function UpdateKOT(){
    $kot_number = base64_decode($_GET['kot_number']);
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $settle_type = $_GET['settle_type'];
    $TotalAmount = $_GET['TotalAmount'];
    $GrandAmount = $_GET['GrandAmount'];
    $gst_type = $_GET['gst_type'];
    
    if($settle_type=='Settle_on_the_spot'){
      $cash = $_GET['amount_mode1'];
      $cash_paid = $_GET['payment_paid1'];
      $online = $_GET['amount_mode2'];
      $online_paid = $_GET['payment_paid2'];
      $discount = $_GET['discount'];
    }

    $Query = "SELECT details.*,menu.price FROM ".getTablePrefix()."customer_summary_details as details join ".getTablePrefix()."hotel_menu as menu on menu.id=details.service_id WHERE details.hotel_manager_id='".$hotel_manager_id."' AND details.kot_number='".$kot_number."' order by details.id DESC;";
    $ResultArr = $this->common_model->getDataByQuery('multiple', $Query);

    $CustomerQuery = "SELECT encrypt_id FROM ".getTablePrefix()."customer_summary_book WHERE summary_book_id='".$ResultArr[0]['customer_id']."' ";
    $CustomerData = $this->common_model->getDataByQuery('single', $CustomerQuery);
    
    foreach ($ResultArr as $row) {

      $advance_paid = $row['price'] * $row['quantity'];
      if($gst_type=='gst_exclusive'){
        $GSTAmt   = round($advance_paid * 5) / 100;
        $advance_paid = $advance_paid + $GSTAmt;
      }  

      $param['advance_paid'] = $advance_paid;
      $param['menu_price'] = $row['price'] * $row['quantity'];
      $param['gst_type'] = $gst_type;
      $param['total_amt'] = $TotalAmount;

      $param['settle_type'] = $settle_type;
      if($settle_type=='Settle_on_the_spot'){
        $param['cash'] = $cash;
        $param['cash_paid'] = $cash_paid;  
        $param['online'] = $online;
        $param['online_paid'] = $online_paid;
        $param['discount'] = $discount;
      }
      $Uwhere['id'] = $row['id'];
      $Uwhere['hotel_manager_id'] = $hotel_manager_id;
      $this->common_model->editDataByMultipleCondition('customer_summary_details', $param, $Uwhere);
    }
    $this->session->set_flashdata('alert_success', lang('statussuccess'));
    redirect('restaurant/food/service/'.$CustomerData['encrypt_id']);
  }
  public function viewkot($kot_number){
    $kot_number = base64_decode($kot_number);
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $Query = "SELECT * FROM ".getTablePrefix()."customer_summary_details WHERE hotel_manager_id='".$hotel_manager_id."' AND kot_number='".$kot_number."' order by creation_date ASC;";
    $data['FoodData'] = $this->common_model->getDataByQuery('multiple', $Query);
    //echo '<pre>';print_r($data['FoodData']);die();
    $data['error'] = '';
    $data['activeMenu'] = 'dashboard';
    $data['activeSubMenu'] = 'dashboard';
    $data['kot_number'] = $kot_number;
    $this->layouts->set_title('Dashboard');
    $this->layouts->restaurant_view('restaurant/food/view', array(), $data);
  }
  public function PrintKOT(){
    $kot_number = base64_decode($_GET['kot_number']);
    $print_type = $_GET['print_type'];
    $gst_type   = $_GET['gst_type'];
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $Rest_id = sessionData('MHM_REST_ID');

    $Query = "SELECT * FROM ".getTablePrefix()."customer_summary_details WHERE hotel_manager_id='".$hotel_manager_id."' AND kot_number='".$kot_number."' order by creation_date ASC;";
    $data['FoodData'] = $this->common_model->getDataByQuery('multiple', $Query);
    $data['VENDORDATA'] = $this->common_model->getDataByParticularField('vendor', 'vendor_id', $hotel_manager_id);
    $data['VENDORDETAIL'] = $this->common_model->getDataByParticularField('vendor_details', 'vendor_id', $hotel_manager_id);
    $data['CUSTDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'summary_book_id', $data['FoodData'][0]['customer_id']);
    $data['Restaurant'] = $this->common_model->getDataByParticularField('restaurant', 'id', $Rest_id);
    $data['RoomNo'] = $this->common_model->getDataByParticularField('room_number', 'room_id', $data['CUSTDATA']['assign_room_number']);
    //echo '<pre>';print_r($data);echo '</pre>';exit();
    $data['gst_type'] = $gst_type;
    $data['print_type'] = $print_type;
    $data['kot_number'] = $kot_number;
    
    $this->load->view('restaurant/food/PrintKOT', $data);
  }
}