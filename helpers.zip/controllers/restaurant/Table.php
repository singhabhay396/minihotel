<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Table extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    ini_set('display_errors', 1);
    $this->load->model(array('resauth_model', 'vendor_model', 'owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->resauth_model->authCheck();
  }
  public function index(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $MHM_REST_ID = sessionData('MHM_REST_ID');
    $Query = "SELECT * FROM ".getTablePrefix()."table WHERE restaurant_id='".$MHM_REST_ID."' order by sort asc;";
    $data['ALLDATA'] = $this->common_model->getDataByQuery('multiple', $Query);

    //////////////////    ADD EDIT SECTION   START  ////////////////
    $data['formError']          = 'No';
    $data['editid']           = '';
    if ($this->input->get('editid')) :
      $data['editid']         = $this->input->get('editid');
      $data['EDITDATA']       = $this->common_model->getDataByParticularField('table', 'id', $data['editid']);
    endif;

    if ($this->input->post('SaveChanges')) :
      $error                = 'NO';
      $data['formError']          = 'Yes';
      $this->form_validation->set_rules('table_name', 'table_name', 'required');

      if ($this->form_validation->run() && $error == 'NO') :
        $data['formError']          = 'No';
        $param['hotel_manager_id']  =   $hotel_manager_id;
        $param['restaurant_id']     =   $MHM_REST_ID;
        $param['table_name']        =   addslashes($this->input->post('table_name'));
        $param['sort']              =   addslashes($this->input->post('sort'));
        //echo '<pre>';print_r($param);die();
        if ($this->input->post('CurrentDataID') == '') :
          $param['add_Date']    = date('Y-m-d H:i:s');
          $alastInsertId        = $this->common_model->addData('table', $param);
          $this->session->set_flashdata('alert_success', lang('addsuccess'));
        else :
          $carBrandId         = $this->input->post('CurrentDataID');
          $this->common_model->editData('table', $param, 'id', $carBrandId);
          $this->session->set_flashdata('alert_success', lang('updatesuccess'));
        endif;
        redirect('restaurant/table');
      endif;
    endif;
    //////////////////    ADD EDIT SECTION   END  ////////////////

    $data['error'] = '';
    $data['activeMenu'] = 'Table';
    $data['activeSubMenu'] = 'Table';
    $this->layouts->set_title('Dashboard');
    $this->layouts->restaurant_view('restaurant/table/index', array(), $data);
  }
  public function booking($table_id){
    $table_id = base64_decode($table_id);
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');

    $Query = "SELECT id FROM ".getTablePrefix()."table WHERE id='".$table_id."' ";
    $data['TableData'] = $this->common_model->getDataByQuery('single', $Query);

    $Query = "SELECT id,category_name FROM ".getTablePrefix()."hotel_menu_category WHERE hotel_manager_id='".$hotel_manager_id."' order by id DESC;";
    $data['CategoryArr'] = $this->common_model->getDataByQuery('multiple', $Query);    
    //echo '<pre>';print_r($data['CustomerData']);die();
    $data['error'] = '';
    $data['activeMenu'] = 'dashboard';
    $data['activeSubMenu'] = 'dashboard';
    $data['table_id'] = $table_id;
    $this->layouts->set_title('Dashboard');
    $this->layouts->restaurant_view('restaurant/table/booking', array(), $data);
  }
  public function AddToCardMenu(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $table_id      = $_GET['table_id'] ?? 0;
    $menu_id          = $_GET['menu_id'] ?? 0;
    $qty              = $_GET['qty'] ?? 1;

    $Save['hotel_manager_id'] = $hotel_manager_id;
    $Save['customer_id'] = 0;
    $Save['table_id'] = $table_id;
    //$Save['kot_no']   = 5;
    $Save['menu_id']  = $menu_id;
    $Save['qty']      = $qty;
    $Save['add_date'] = date('Y-m-d H:i:s');

    $sql = "SELECT id,qty FROM ".getTablePrefix()."hotel_menu_cart WHERE hotel_manager_id='".$hotel_manager_id."' AND menu_id='".$menu_id."' AND customer_id='".$customer_id."' ";
    $result = $this->common_model->getDataByQuery('single', $sql);
    if($result){
      $Save['qty']      = $qty+$result['qty'];
      $this->common_model->editData('hotel_menu_cart', $Save, 'id', $result['id']);
    }else{
      $Save['qty']      = $qty;
      $this->common_model->addData('hotel_menu_cart', $Save);
    }
  }
  public function FoodUpdateAddToCart(){
    $qty = $_POST['qty'];
    $id = $_POST['id'];
    $Save['qty']      = $qty;
    $this->common_model->editData('hotel_menu_cart', $Save, 'id', $id);
  }
  public function DeleteItem(){
    $id = $_GET['id'] ?? '';
    $this->common_model->deleteData('hotel_menu_cart', 'id', $id);
  }
  public function FoodMenuCart(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $table_id      = $_GET['table_id'] ?? 0;
    $Query = "SELECT cart.*,menu.menu_name,menu.price FROM ".getTablePrefix()."hotel_menu_cart as cart join ".getTablePrefix()."hotel_menu as menu on menu.id=cart.menu_id WHERE cart.table_id='".$table_id."' AND cart.hotel_manager_id='".$hotel_manager_id."' order by cart.id DESC";
    $data['MenuArr'] = $this->common_model->getDataByQuery('multiple', $Query);
    $data['table_id'] = $table_id;
    $this->load->view('restaurant/table/Cart', $data);
  }
  public function SaveKOT(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $Rest_id = sessionData('MHM_REST_ID');
    $table_id = base64_decode($_GET['table_id']);

    $cash = $_GET['amount_mode1'];
    $cash_paid = $_GET['payment_paid1'];
    $online = $_GET['amount_mode2'];
    $online_paid = $_GET['payment_paid2'];
    $discount = $_GET['discount'];
    $TotalAmount = $_GET['TotalAmount'];
    $gst_type = $_GET['gst_type'];
    $GrandAmount = $_GET['GrandAmount'];

    $Query = "SELECT cart.*,menu.menu_name,menu.price FROM ".getTablePrefix()."hotel_menu_cart as cart join ".getTablePrefix()."hotel_menu as menu on menu.id=cart.menu_id WHERE cart.table_id='".$table_id."' order by cart.id DESC;";
    $MenuArr = $this->common_model->getDataByQuery('multiple', $Query);

    $TableData = $this->common_model->getDataByParticularField('table','id', $table_id);
    $KOTNumber = $this->common_model->getDataByParticularField('restaurant','id', $Rest_id);
    $kot_number = $KOTNumber['kot_number'] + 1;
    $bill_number = $KOTNumber['bill_number'] + 1;
    
    foreach ($MenuArr as $row) { 

      $advance_paid = $row['price'] * $row['qty'];
      if($gst_type=='gst_exclusive'){
        $GSTAmt   = round($advance_paid * 5) / 100;
        $advance_paid = $advance_paid + $GSTAmt;
      }

      $param['restaurant_id'] = $Rest_id; 
      $param['hotel_manager_id'] = $hotel_manager_id;
      $param['table_id'] = $table_id;
      $param['menu_name'] = $row['menu_name'];
      $param['qty'] = $row['qty'];
      $param['price'] = $row['price'];
      $param['sub_total'] = $row['price'] * $row['qty'];
      $param['gst_type'] = $gst_type;
      $param['cash'] = $cash;
      $param['cash_paid'] = $cash_paid;  
      $param['online'] = $online;
      $param['online_paid'] = $online_paid;
      $param['discount'] = $discount;
      $param['total_amt'] = $TotalAmount;
      $param['add_date'] = currentDateTime();
      $param['table_name'] = $TableData['table_name'];
      $param['kot_no'] = KOTPrefix.'/'.$kot_number;
      $param['bill_number'] = $bill_number;
      $lastInsertId = $this->common_model->addData('restaurant_kot', $param);
      //echo '<pre>';print_r($param);
    } 
    $this->common_model->deleteData('hotel_menu_cart', 'table_id', $table_id);
    $vparam['kot_number'] = $kot_number;
    $vparam['bill_number'] = $bill_number;
    $this->common_model->editData('restaurant', $vparam, 'id',$Rest_id);
    $this->session->set_flashdata('alert_success', lang('statussuccess'));
    redirect('restaurant/dashboard');
  }
}