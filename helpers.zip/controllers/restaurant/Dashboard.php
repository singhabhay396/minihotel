<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Dashboard extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    ini_set('display_errors', 1);
    $this->load->model(array('resauth_model', 'vendor_model', 'owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->resauth_model->authCheck();
  }

  public function index(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $MHM_REST_ID = sessionData('MHM_REST_ID');
    $Query = "SELECT csb.customer_name,csb.encrypt_id,rn.room_no FROM ".getTablePrefix()."customer_summary_book as csb join ".getTablePrefix()."room_number as rn on rn.room_id=csb.assign_room_number WHERE rn.room_no_use='Y' and csb.hotel_manager_id='".$hotel_manager_id."' AND csb.check_out_datetime IS NULL  order by rn.sort DESC;";
    //$Query = "SELECT csb.customer_name,csb.encrypt_id,rn.room_no FROM ".getTablePrefix()."customer_summary_book as csb join ".getTablePrefix()."room_number as rn on rn.room_id=csb.assign_room_number WHERE csb.hotel_manager_id='".$hotel_manager_id."' AND csb.check_out_datetime = " . null . " order by rn.sort DESC;";
    $data['CheckInData'] = $this->common_model->getDataByQuery('multiple', $Query);

    $restQuery = "SELECT * FROM ".getTablePrefix()."restaurant_setting WHERE vendor_id=".sessionData('MHM_REST_HOTEL_ID')." AND is_table = 1 ";
    $restInfo = $this->common_model->getDataByQuery('single', $restQuery);

    $tbl_query = "SELECT * FROM ".getTablePrefix()."table WHERE restaurant_id='".$MHM_REST_ID."' order by sort ASC;";
    $data['TableArr'] = $this->common_model->getDataByQuery('multiple', $tbl_query);

    //echo '<pre>';print_r($data['CheckInData']);die();
    $data['error'] = '';
    $data['activeMenu'] = 'Dashboard';
    $data['restInfo'] = $restInfo;
    $data['activeSubMenu'] = 'Dashboard';
    $data['hotel_manager_id'] = $hotel_manager_id;
    $this->layouts->set_title('Dashboard');
    $this->layouts->restaurant_view('restaurant/dashboard', array(), $data);
  }
  public function settings(){
    $hotel_manager_id = sessionData('MHM_REST_HOTEL_ID');
    $rest_id = sessionData('MHM_REST_ID');
    $data['error'] = '';
    $data['activeMenu'] = '';
    $data['activeSubMenu'] = '';
    $data['EDITDATA'] = $this->common_model->getDataByParticularField('restaurant', 'id', $rest_id);
    if ($this->input->post('SaveChanges')):
      $param['rest_name'] = addslashes($this->input->post('rest_name'));
      $param['rest_phone'] = addslashes($this->input->post('rest_phone'));
      $param['fssai_number'] = addslashes($this->input->post('fssai_number'));
      $param['unit_of'] = addslashes($this->input->post('unit_of'));
      $param['address'] = addslashes($this->input->post('address'));
      $param['gstin'] = addslashes($this->input->post('gstin'));
      $param['remarks'] = addslashes($this->input->post('remarks'));
      $param['logo'] = addslashes($this->input->post('logo'));
      $this->common_model->editData('restaurant', $param, 'id', $rest_id);
      $this->session->set_userdata(array(
        'MHM_REST_NAME' => $param['rest_name'],
        'MHM_REST_IMAGE' => $param['logo'],
      ));
      $this->session->set_flashdata('alert_success', lang('updatesuccess'));
      redirect('restaurant/dashboard/settings');
    endif;
    $this->layouts->set_title('Settings');
    $this->layouts->restaurant_view('restaurant/Settings', array(), $data);
  }

  function firstImageUpload(){
    if ($this->input->post('imageData')) :
      $imageData        =   $this->input->post('imageData');
      $imageName        =   time() . '.png';
      $imageFolder      = '';
      $imageType        = 'vendorImage';
      $this->load->library("upload_crop_img");
      $returnFileName   = $this->upload_crop_img->_upload_canvas_image($imageData, $imageName, $imageType, $imageFolder);
      if ($returnFileName) :
        echo $returnFileName;
        die;
      else :
        echo 'UPLODEERROR';
        die;
      endif;
    else :
      echo 'UPLODEERROR';
      die;
    endif;
  } // END OF FUNCTION
  function firstImageDelete(){
    $imageName  = $this->input->post('imageName');
    if ($imageName) :
      $this->load->library("upload_crop_img");
      $return = $this->upload_crop_img->_delete_image($imageName);
    endif;
    echo '1';
    die;
  } // END OF FUNCTION

  function UplodeImage(){
    $file_name          =   $_FILES['uploadfile']['name'];
    if ($file_name) :
      $tmp_name       =   $_FILES['uploadfile']['tmp_name'];
      $imageInformation     =   getimagesize($_FILES['uploadfile']['tmp_name']);
      if ($imageInformation[0] <= 800 && $imageInformation[1] <= 800) :
        $this->load->library("upload_crop_img");
        $return_file_name = $this->upload_crop_img->_upload_image($file_name, $tmp_name, 'vendorProofImage');
        echo $return_file_name;
        die;
      else :
        echo 'ERROR_____Image Must Be Max Width:800px And Height:800px.';
        die;
      endif;
    else :
      echo 'UPLODEERROR';
      die;
    endif;
  }
  function DeleteImage(){
    $imagename  = $this->input->post('imagename');
    if ($imagename) :
      $this->load->library("upload_crop_img");
      $return = $this->upload_crop_img->_delete_image($imagename);
    endif;
    echo '1';
    die;
  }
}