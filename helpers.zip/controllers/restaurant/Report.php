<?php defined('BASEPATH') or exit('No direct script access allowed');

class Report extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    ini_set('display_errors', 1);
    $this->load->model(array('resauth_model', 'vendor_model', 'owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor');
    $this->resauth_model->authCheck();
  }
  public function index(){  
    $data['hotel_manager_id'] = sessionData('MHM_REST_HOTEL_ID');

    $CurrentDate = $_GET['searchDate'] ?? date('Y-m-d');
    $sale_type = $_GET['sale_type'] ?? 'All';
    $CurrentDate = date('Y-m-d',strtotime($CurrentDate));
    $this->db->select('cbb.kot_number,cbb.total_amt,cbb.amount_mode,cbb.creation_date,rn.room_no');
    //$this->db->select('cbb.*,csb.assign_room_number');
    $this->db->from('customer_summary_details as cbb');
    $this->db->join('customer_summary_book as csb', 'csb.summary_book_id = cbb.customer_id', 'left');
    $this->db->join('room_number as rn', 'csb.assign_room_number = rn.room_id', 'left');
    $this->db->where("cbb.hotel_manager_id",$data['hotel_manager_id']); 
    $this->db->where("cbb.creation_date LIKE '%" . $CurrentDate . "%'");
    $this->db->where("cbb.settle_type",'Settle_on_the_spot'); 
    $this->db->group_by('cbb.kot_number');
    $this->db->order_by('cbb.id DESC');
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    $RoomResultArr = $query->result_array();


    $this->db->select('kot.*');
    $this->db->from('restaurant_kot as kot');
    $this->db->where("kot.hotel_manager_id",$data['hotel_manager_id']); 
    $this->db->where("kot.add_date LIKE '%" . $CurrentDate . "%'");
    $this->db->group_by('kot.kot_no');
    $this->db->order_by('kot.id DESC');
    $query4 = $this->db->get();
    //echo $this->db->last_query(); die;
    $TableResultArr = $query4->result_array();

    $data['error'] = '';
    $data['activeMenu'] = 'Sale';
    $data['activeSubMenu'] = 'Sale';
    $data['searchDate'] = $CurrentDate;
    $data['RoomResultArr'] = $RoomResultArr;
    $data['TableResultArr'] = $TableResultArr;
    $data['sale_type'] = $sale_type;
    $this->layouts->set_title('Manage KOT');
    $this->layouts->restaurant_view('restaurant/report/sales', array(), $data);
  }

}