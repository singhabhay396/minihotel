<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Welcome extends CI_Controller
{

    public function  __construct()
    {
        parent::__construct();
        error_reporting(E_ALL ^ E_NOTICE);
        $this->load->model(array('frontauth_model', 'front_model', 'emailtemplate_model', 'sms_model'));
        $this->lang->load('statictext', 'front');
        $this->load->helper('front');
        $this->session->set_userdata('MHM_FRONT_CURRENT_PATH', base_url());
    }

    /* * *********************************************************************
	 * * Function name : index
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for home page
	 * * Date : 25 APRIL 2022
	 * * **********************************************************************/
    public function index()
    {
        $data['error']                         =     '';
        $this->frontauth_model->checkOnlyUserLoginCookie();
        $data['userId']                     =     sessionData('MHM_USER_ID');

        $data['HeadingData']            = $this->front_model->getCMSHeadingData($type = "top-heading");
        $data['SliderData']             = $this->front_model->getSliderData();
        $data['TestimonialData']        = $this->front_model->getTestimonialData();
        $data['FeaturesData']            = $this->front_model->getCMSFeatureData($type = "feature");
        $data['AboutUsData']            = $this->front_model->getCMSData($pageUrl = "AboutUs");

        // Contact Us Form Data
        if ($this->input->post('currentPageFormSubmit') == '') :
            $error                    =    'NO';
            $this->form_validation->set_rules('first_name', 'First Name', 'trim|required');
            $this->form_validation->set_rules('last_name', 'Last Name', 'trim');
            $this->form_validation->set_rules('email', 'E-Mail', 'trim|required|valid_email');
            $this->form_validation->set_rules('subject', 'Reason', 'trim');
            $this->form_validation->set_rules('description', 'message', 'trim');

            if ($this->form_validation->run() && $error == 'NO') :
                $param['contact_f_name']        =     addslashes($this->input->post('first_name'));
                $param['contact_l_name']        =     addslashes($this->input->post('last_name'));
                $param['contact_email']         =     addslashes($this->input->post('email'));
                $param['contact_reason']        =     addslashes($this->input->post('subject'));
                $param['contact_message']       =     addslashes($this->input->post('description'));
                $param['creation_date']         =    currentDateTime();
                $param['status']                =    'Y';                
                $alastInsertId                  =    $this->common_model->addData('contact_us', $param);
                $Uparam['encrypt_id']           =    ashishEncript($alastInsertId);
                $Uparam['contact_us_id']        =    generateUniqueId($alastInsertId);
                $Uwhere['id']                   =    $alastInsertId;
                $this->common_model->editDataByMultipleCondition('contact_us', $Uparam, $Uwhere);
                //$this->sms_model->contactUsSmsToAdmin();
                $this->emailtemplate_model->ContactUsMailToAdmin($param);
                $this->session->set_flashdata('alert_success', lang('CONTACTUS_SUCCESS'));
             redirect($this->session->userdata('MHM_FRONT_CURRENT_PATH'));
            endif;
        endif;

        // END
        $this->layouts->set_title('MHM');
        $this->layouts->set_description('MHM');
        $this->layouts->set_keyword('MHM');
        $this->layouts->front_view('front/index', array(), $data);
    }

    /* * *********************************************************************
	 * * Function name : disclaimer
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for disclaimer
	 * * Date : 29 APRIL 2022
	 * * **********************************************************************/
	public function privecyPolicy()
	{
		$data['error'] 						= 	'';

		$data['PDATA']					=	$this->front_model->getCMSData('privacypolicy');

		$this->layouts->set_title('MHM');
        $this->layouts->set_description('MHM');
        $this->layouts->set_keyword('MHM');
		$this->layouts->front_view('front/privecypolicy',array(),$data);
	}

	/* * *********************************************************************
	 * * Function name : termsCondition
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for termsCondition
	 * * Date : 29 APRIL 2022
	 * * **********************************************************************/
	public function termsCondition()
	{
		$data['error'] 						= 	'';
		$data['TDATA']					=	$this->front_model->getCMSData('termsCondition');
		$this->layouts->set_title('MHM');
        $this->layouts->set_description('MHM');
        $this->layouts->set_keyword('MHM');
		$this->layouts->front_view('front/termsCondition',array(),$data);
	}
    // subscription

    /* * *********************************************************************
	 * * Function name : subscription
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for subscription
	 * * Date : 20 JUNE 2022
	 * * **********************************************************************/
	public function subscription()
	{
		$data['error'] 						= 	'';
		$data['TDATA']					=	$this->front_model->subscription();

		$this->layouts->set_title('MHM');
        $this->layouts->set_description('MHM');
        $this->layouts->set_keyword('MHM');
		$this->layouts->front_view('front/subscription',array(),$data);
	}
}
