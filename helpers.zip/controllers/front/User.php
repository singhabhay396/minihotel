<?php
defined('BASEPATH') or exit('No direct script access allowed');
class User extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        error_reporting(E_ALL ^ E_NOTICE);
        $this->load->model(array('frontauth_model', 'front_model', 'emailtemplate_model', 'sms_model'));
        $this->lang->load('statictext', 'front');
        $this->load->helper('front');
        $this->session->set_userdata('MHM_FRONT_CURRENT_PATH', base_url());
    }

    /* * *********************************************************************
     * * Function name : signup
     * * Developed By : Ashish Umrao
     * * Purpose  : This function used for user signup
     * * Date : 16  MAY 2022
     * * **********************************************************************/
    public function signup()
    {
        $data['error'] = '';
        if ($this->input->post('currentPageFormSubmit')) :
            $error = 'NO';
            $this->form_validation->set_rules('vendor_business_name', 'Business name', 'trim|required');
            $this->form_validation->set_rules('vendor_email', 'E-Mail', 'trim|valid_email|is_unique[vendor.vendor_email]');
            $vendoremail = str_replace(' ', '', $this->input->post('vendor_email'));
            if ($this->input->post('vendor_email') && !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
                if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
                    $error = 'YES';
                    $data['mobileerror'] = 'Please eneter correct email id.';
                endif;
            endif;
            $this->form_validation->set_rules('vendor_phone', 'Phone', 'trim|required|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('owner_secoundry_contact_number', 'Phone', 'trim|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('first_manager_contact_number', 'Phone', 'trim|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('secound_manager_contact_number', 'Phone', 'trim|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('you_are', 'you_are', 'trim|required');
            $this->form_validation->set_rules('referral_cpde', 'referral_cpde', 'trim');
            $this->form_validation->set_rules('accept_policy', 'accept_policy', 'trim|required');
            if ($this->form_validation->run() && $error == 'NO') :
                $captcha_response = trim($this->input->post('g-recaptcha-response'));

                if($captcha_response != '')
                {
                    
                    $keySecret = '6LfZO9EpAAAAAEDk3mty23W4UgiMabsDiM5NXNKm';

                    $check = array(
                        'secret'        =>  $keySecret,
                        'response'      =>  $this->input->post('g-recaptcha-response')
                    );

                    $startProcess = curl_init();

                    curl_setopt($startProcess, CURLOPT_URL, "https://www.google.com/recaptcha/api/siteverify");

                    curl_setopt($startProcess, CURLOPT_POST, true);

                    curl_setopt($startProcess, CURLOPT_POSTFIELDS, http_build_query($check));

                    curl_setopt($startProcess, CURLOPT_SSL_VERIFYPEER, false);

                    curl_setopt($startProcess, CURLOPT_RETURNTRANSFER, true);

                    $receiveData = curl_exec($startProcess);

                    $finalResponse = json_decode($receiveData, true);
                
                    if($finalResponse['success'])
                    {
                        $vendorPassword = generateRandomString(6, 'nl');
                        $vendorPasscode = generateRandomString(6, 'nl');
                        $param['vendor_business_name'] = addslashes($this->input->post('vendor_business_name'));
                        $param['vendor_email'] = addslashes($this->input->post('vendor_email'));
                        $param['vendor_phone'] = addslashes($this->input->post('vendor_phone'));
                        $param['owner_secoundry_contact_number'] = addslashes($this->input->post('owner_secoundry_contact_number'));
                        $param['first_manager_contact_number'] = addslashes($this->input->post('first_manager_contact_number'));
                        $param['secound_manager_contact_number'] = addslashes($this->input->post('secound_manager_contact_number'));
                        $param['referral_code'] = addslashes($this->input->post('referral_code'));
                        $param['vendor_otp'] = generateRandomString(4, 'n');
                        $param['accept_policy'] = addslashes($this->input->post('accept_policy'));
                        $param['vendor_passcode'] = $this->frontauth_model->encriptPassword($vendorPasscode);
                        $param['vendor_password'] = $this->frontauth_model->encriptPassword($vendorPassword);
                        $param['creation_date'] = currentDateTime();
                        $param['vendor_phone_verify']    =    'N';
                        $param['status'] = 'I';		
                        $param['is_owner'] = 1;			
                        $SDparam['you_are'] = addslashes($this->input->post('you_are'));
                        $SDparam['vendor_address'] = addslashes($this->input->post('vendor_address'));
                        $lastInsertId = $this->common_model->addData('vendor', $param);
                        $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
                        $Uparam['vendor_id'] = generateUniqueId($lastInsertId);
                        $Uparam['vendor_slug'] = strtolower(url_title(trim($this->input->post('vendor_business_name')))) . $lastInsertId;
                        $Uwhere['id'] = $lastInsertId;
                        $this->common_model->editDataByMultipleCondition('vendor', $Uparam, $Uwhere);
                        $vendorId = $Uparam['vendor_id'];
                        if ($vendorId) :
                            $SDparam['vendor_id'] = $vendorId;
                            $SDparam['creation_date'] = currentDateTime();
                        $SDlastInsertId = $this->common_model->addData('vendor_details', $SDparam);
                         $SDUparam['encrypt_id'] = ashishEncript($SDlastInsertId);
                         $SDUparam['vendor_detail_id'] = generateUniqueId($SDlastInsertId);
                         $SDUwhere['id'] = $SDlastInsertId;
                         $this->common_model->editDataByMultipleCondition('vendor_details', $SDUparam, $SDUwhere);
                        endif;
                        $this->sms_model->sendOtpSmsToVendor($param['vendor_phone'], $param['vendor_otp']);
                        //$this->emailtemplate_model->UserRegistrationMailToUser($vendorId, $vendorPassword, $vendorPasscode);
                        //$this->emailtemplate_model->UserRegistrationMailToAdmin($vendorId);
                        $this->session->set_userdata('USER_REGISTER_PHONE', $param['vendor_phone']);
                        $this->session->set_flashdata('alert_success', lang('SEND_OTP_TO_RMN'));
                        redirect($this->session->userdata('MHM_FRONT_CURRENT_PATH') . 'user/otp-verification');
                    }
                     else
                    {
                        $this->session->set_flashdata('message', 'Please checked captcha field.');
                        // $this->layouts->front_view('front/user/signup', array(), $data);
                    }
                }
                 else
                {
                    $this->session->set_flashdata('message', 'Captcha Validation Fail Try Again');
                     //$this->layouts->front_view('front/user/signup', array(), $data);
                }

            endif;
        endif;
        $this->layouts->set_title('Signup');
        $this->layouts->set_description('');
        $this->layouts->set_keyword('');
        $this->layouts->front_view('front/user/signup', array(), $data);
    }

    /* * *********************************************************************
	 * * Function name : otpverification
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for user otp verification
	 * * Date : 16 MAY 2021
	 * * **********************************************************************/
    public function otpverification()
    {
        $data['error']                         =     '';
        $data['formError']                     =    '';
        if ($this->input->post('currentPageFormSubmit')) :
            $error                    =    'NO';
            $this->form_validation->set_rules('vendor_phone', 'Phone', 'trim|required|min_length[10]|max_length[15]');
            $vendorphone        =    str_replace(' ', '', $this->input->post('vendor_phone'));
            if ($this->input->post('vendor_phone') && !preg_match('/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i', $vendorphone)) :
                if (!preg_match("/^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1})?([0-9]{10})$/", $vendorphone)) :
                    $error                        =    'YES';
                    $data['mobileerror']         =     'Please Eneter Correct Number.';
                endif;
            endif;
            $this->form_validation->set_rules('vendor_otp', 'OTP', 'trim|required');
            if ($this->form_validation->run() && $error == 'NO') :
                $userData        =    $this->frontauth_model->checkOTP(trim($this->input->post('vendor_phone')), trim($this->input->post('vendor_otp')));
                if ($userData <> "") :
                    if ($userData['status'] == 'I') :
                        $param['vendor_phone_verify']    =    'Y';
                        $param['vendor_otp']            =    '';
                        $param['status']            =    'I';
						$param['vendor_type'] = 'Verified';
                        $this->common_model->editData('vendor', $param, 'vendor_id', $userData['vendor_id']);
                        $this->session->unset_userdata('USER_REGISTER_PHONE');
                        $this->session->set_flashdata('alert_success', lang('VERIFY_OTP'));
                    //$data['formError']         =     lang('VERIFY_OTP');
                    //redirect($this->session->userdata('MHM_FRONT_CURRENT_PATH').'vendor/login');
                    else :
                        $data['formError']         =     lang('ACCOUNT_BLOCKED');
                    endif;
                else :
                    $data['formError']             =     lang('OTP_INCORRECT');
                endif;
            endif;
        endif;
        $this->layouts->set_title('OTP Verification');
        $this->layouts->set_description('');
        $this->layouts->set_keyword('');
        $this->layouts->front_view('front/user/otpverification', array(), $data);
    }

  public function WhatsAppStatus(){
    $PostData = json_decode(file_get_contents('php://input'), true);
    $whatsapp_id = $PostData['statuses'][0]['id'];
    $whatsapp_status = $PostData['statuses'][0]['status'];
    if($whatsapp_status=='failed'){
      $param['status'] = 0;
    }else{
      $param['status'] = 1;       
    }
    $param['response'] = json_encode($PostData);
    $Rwhere['whatsapp_id']  = $whatsapp_id;
    $this->common_model->editDataByMultipleCondition('customer_whatsapp', $param, $Rwhere);
  }
  public function WhatsAppSendBulkMsg(){
    $BulkQuery = "SELECT * FROM " . getTablePrefix() . "whatsapp_bulk WHERE status = '0' order by id asc limit 10";
    $BulkArr = $this->common_model->getDataByQuery('multiple', $BulkQuery);
    foreach ($BulkArr as $row) { 
      $template_id   = $row['template_id'];
      $SendBulkMsg['vendor_id']     = $row['vendor_id'];
      $SendBulkMsg['variable_name'] = $row['variable_name'];
      $SendBulkMsg['mobile']        = $row['mobile'];
      $SendBulkMsg['Name']          = $row['name'];
      if($template_id==1){
        $this->common_model->Bulk1($SendBulkMsg);
      } elseif ($template_id==2) {
        $this->common_model->Bulk2($SendBulkMsg);
      } elseif ($template_id==3) {
        $this->common_model->Bulk3($SendBulkMsg);
      } elseif ($template_id==4) {
        $this->common_model->Bulk4($SendBulkMsg);
      }
      $Save['status'] = 1;
      $Rwhere['id']  = $row['id'];
      $this->common_model->editDataByMultipleCondition('whatsapp_bulk', $Save, $Rwhere);
    }
  }
  public function WhatsAppDeleteBulkData(){
    $this->common_model->deleteParticularData('whatsapp_bulk', 'status', 1);
  }

  public function testing(){
    $msg = '{"messaging_product":"whatsapp","metadata":{"display_phone_number":"918882154109","phone_number_id":"138000062718922"},"statuses":[{"id":"wamid.HBgHOTExMTExMRUCABEYEjMyQUUxNDMwREVDNTJDOURENAA=","status":"failed","timestamp":"1697102424","recipient_id":"9111111","errors":[{"code":131026,"title":"Message Undeliverable."}]}]}';
    $PostData = json_decode($msg,true);
    echo '<pre>';print_r($PostData['statuses'][0]['status']);
    echo '<pre>';print_r($PostData);
  }  
}
