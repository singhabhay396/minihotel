<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Restaurant extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'owner_model', 'emailtemplate_model', 'sms_model','frontauth_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }

  public function index(){
    $data['error'] = '';
    $data['activeMenu'] = 'Restaurant';
    $data['activeSubMenu'] = 'Restaurant';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $data['HotelList'] = $this->owner_model->GetSubOwnerVendorList();
    }
    $restQuery = "SELECT * FROM ".getTablePrefix()."restaurant_setting WHERE owner_id=".sessionData('MHM_OWNER_ID')." AND is_restaurant = 1 ";
    $restInfo = $this->common_model->getDataByQuery('multiple', $restQuery);
    if(empty($restInfo)){
        redirect('owner/dashboard/');
        //$this->layouts->owner_view('owner/dashboard/', array(), $data);

    }
    else{
        $data['VDetails']   = count($restInfo);
        $data['restInfo']   = ($restInfo);
        $data['TotalRestaurant']   = $this->CountTotalRestaurant();
    // echo "<pre>"; print_r($restInfo); exit;
        $this->layouts->set_title('Restaurant List');
        $this->layouts->owner_view('owner/Restaurant/index', array(), $data);
    }
  }
  public function CountTotalRestaurant(){
    $vendor_id = $this->owner_model->GetAllHotelList();
    $this->db->from('restaurant as m');
    $this->db->where_in("m.hotel_manager_id",$vendor_id); 
    $query = $this->db->get();
    return $query->num_rows();
  }
   public function getTotalRestaurant(){
    $vendor_id = $this->owner_model->GetAllHotelList();
    $this->db->from('restaurant as m');
    $this->db->where_in("m.hotel_manager_id",$vendor_id); 
    $query = $this->db->get();
    return $query->result_array();
  }
  function RestaurantPagination(){
    $Search['hotel_name']     = $_GET['hotel_name'] ?? '';
    $Search['vendor_id']      = $_GET['vendor_id'] ?? 'All';
    $Search['m_name']         = $_GET['m_name'] ?? '';
    $Search['email']          = $_GET['email'] ?? '';
    $Search['mobile']         = $_GET['mobile'] ?? '';
    $Search['status']         = $_GET['status'] ?? 'All';
    $Search['page']           = $_GET['page'] ?? 1;
    $Search['numofrecords']   = $_GET['numofrecords'] ?? 100;
    //$Search['cur_page']       = $Search['page'];
    $Limitpage                = $Search['page']-1;
    $Search['start']          = $Limitpage * $Search['numofrecords'];
    
    $Search['action'] = 'count';
    $TotalData = $this->RestaurantPaginationData($Search);
    $data['PAGINATION'] = Pagination($Search['numofrecords'],$TotalData, $Search['page']);
    $Search['action'] = 'data';
    $data['ALLDATA'] = $this->RestaurantPaginationData($Search);
    //echo '<pre>';print_r($Search);die;
    $this->load->view('owner/Restaurant/Pagination', $data);
  }
  function RestaurantPaginationData($Search){
    $vendor_id = $this->owner_model->GetAllHotelList();
    
    $this->db->select('m.*,vendor.vendor_business_name');
    $this->db->from('restaurant as m');
    $this->db->join('vendor', 'vendor.vendor_id=m.hotel_manager_id', 'LEFT');
    if($Search['hotel_name']!=''){ $this->db->where("vendor.vendor_business_name LIKE '%" . $Search['hotel_name'] . "%'"); }
    if($Search['m_name']!=''){ $this->db->where("m.rest_name LIKE '%" . $Search['m_name'] . "%'"); }
    if($Search['email']!=''){ $this->db->where("m.rest_email LIKE '%" . $Search['email'] . "%'"); }
    if($Search['mobile']!=''){ $this->db->where("m.rest_phone LIKE '%" . $Search['mobile'] . "%'"); }
    if($Search['status']!='All'){ $this->db->where("m.status",$Search['status']); }
    if($Search['vendor_id']!='All'){ 
      $this->db->where("m.hotel_manager_id",$Search['vendor_id']); 
    }else{
      $this->db->where_in("m.hotel_manager_id",$vendor_id); 
    }

    $this->db->order_by('m.id DESC');
    if ($Search['action']=='data'){ $this->db->limit($Search['numofrecords'], $Search['start']); }
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($Search['action'] == 'data'){
      if ($query->num_rows() > 0){
        return $query->result_array();
      }else{
        return false;
      }
    }elseif ($Search['action'] == 'count'){
      return $query->num_rows();
    }
  }

  public function addeditdata($editId = ''){
    $data['error'] = '';
    $data['activeMenu'] = 'Manager';
    $data['activeSubMenu'] = 'Manager';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $data['custId'] = $editId;
    $restQuery = "SELECT * FROM ".getTablePrefix()."restaurant_setting WHERE owner_id=".sessionData('MHM_OWNER_ID')." AND is_restaurant = 1 ";
    $restInfo = $this->common_model->getDataByQuery('multiple', $restQuery);
    $restaurantStore   = $this->getTotalRestaurant();
    //echo "<pre>"; print_r($data); exit;
    $selRestView = $storeRest = [];
    if(!empty($restInfo)){
      $selRestView = array_column($restInfo, 'vendor_id');
    }
    $data['restView'] = $selRestView;
    if(!empty($restaurantStore)){
      $storeRest = array_column($restaurantStore, 'hotel_manager_id');
    }
    $data['storeRest'] = $storeRest;
     if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $data['HotelList'] = $this->owner_model->GetSubOwnerVendorList();
    }

    if($editId){
      $data['EDITDATA']   = $this->common_model->getDataByParticularField('restaurant', 'id', $editId);
    }

    if ($this->input->post('SaveChanges')) :
      $error          = 'NO';
      $this->form_validation->set_rules('vendor_id', 'Hotel name', 'trim');
      $vendoremail    = str_replace(' ', '', $this->input->post('manager_email'));
      if ($this->input->post('manager_email') && !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
        if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
          $error            = 'YES';
          $data['mobileerror']    =   'Please eneter correct email id.';
        endif;
      endif;
      if ($this->input->post('new_password') != '') :
        $this->form_validation->set_rules('new_password', 'New password', 'trim|required|min_length[6]|max_length[25]');
        $this->form_validation->set_rules('conf_password', 'Confirm password', 'trim|required|min_length[6]|matches[new_password]');
      endif;


      if ($this->form_validation->run() && $error == 'NO'):  

        $param['hotel_manager_id'] =   addslashes($this->input->post('vendor_id'));
        $param['rest_name'] = addslashes($this->input->post('rest_name'));
        $param['rest_phone'] = addslashes($this->input->post('rest_phone'));
        $param['rest_email'] = addslashes($this->input->post('rest_email'));
        $param['fssai_number'] = addslashes($this->input->post('fssai_number'));
        $param['address'] = addslashes($this->input->post('address'));
        $param['gstin'] = addslashes($this->input->post('gstin'));
        $param['kot_number'] = addslashes($this->input->post('kot_number'));
        $param['bill_number'] = addslashes($this->input->post('bill_number'));
        $param['remarks'] = addslashes($this->input->post('remarks'));
        $param['logo'] = addslashes($this->input->post('logo'));

        if ($this->input->post('new_password')) :
          $NewPassword        = $this->input->post('new_password');
          $param['rest_password'] =   $this->ownerauth_model->encriptPassword($NewPassword);
        endif;      
        if ($this->input->post('CurrentDataID') == '') :
          $param['add_date']   = currentDateTime();
          $param['status']      = 'A';

          $lastInsertId       = $this->common_model->addData('restaurant', $param);
          //echo '<pre>';print_r($param);die();
          $this->session->set_flashdata('alert_success', lang('addsuccess'));
        else :
          $Id         = $this->input->post('CurrentDataID');
          $this->common_model->editData('restaurant', $param, 'id', $Id);
          $this->session->set_flashdata('alert_success', lang('updatesuccess'));
        endif;
        redirect('owner/restaurant');
      endif;
    endif;
    $this->layouts->set_title('Edit Restaurant Details');
    $this->layouts->owner_view('owner/Restaurant/addedit', array(), $data);
  }
  function changestatus($changeStatusId = '', $statusType = ''){
    $param['status']    = $statusType;
    $this->common_model->editData('restaurant', $param, 'id', $changeStatusId);
    $this->session->set_flashdata('alert_success', lang('statussuccess'));
    redirect('owner/restaurant');
  }
}