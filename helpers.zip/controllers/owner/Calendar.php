<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Calendar extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'owner_model', 'emailtemplate_model', 'sms_model','frontauth_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }

  public function index(){
    $data['error'] = '';
    $data['activeMenu'] = 'calendarev';
    $data['activeSubMenu'] = 'calendarev';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    $data['vendor_id'] = $_GET['vendor_id'] ?? $data['HotelList'][0]['vendor_id'];
    $data['ALLDATA'] = $this->getAllReservationData($data['vendor_id']);
    $data['BlockRoomArr'] = $this->GetAllBlockRoomData($data['vendor_id']);
    $data['LabelRoomArr'] = $this->GetAllLabelRoomData($data['vendor_id']);
    $this->layouts->set_title('Manage Calendar');
    $this->layouts->owner_view('owner/Calendar/index', array(), $data);
  }
  public function GetReservationRoom(){
    $vendor_id = $_GET['vendor_id'];
    $checkin_date = $_GET['checkin_date'];
    $checkout_date = $_GET['checkout_date'];
    $hotelRoom = $this->getAllAvaiableRoomsByHotelId($vendor_id);
    echo '<label class="fancy-checkbox form-headings">Select Room <span class="required">*</span></label>';
    foreach ($hotelRoom as $Hinfo) {
      $checkdate = $this->GetCalendarReservationDate($vendor_id,$Hinfo['room_id'],$checkin_date,$checkout_date);
      if($checkdate>0){
        $checkRoom = 'disabled';
        $checkText = 'style="color: red;"';
      }else{
        $checkRoom = '';
        $checkText = '';
      }
      echo ' <input type="checkbox" name="RSelectedRoom" value="'.$Hinfo['room_id'].'_'.$Hinfo['room_no'].'" '.$checkRoom.' class="form-checkbox RCheckBox" onclick="RCheckboxData()" /> <label '.$checkText.' class="custom-control-label" >'.$Hinfo['room_no'].' </label> ';
    }
  }
  public function AddReservation(){
    if ($this->input->post('SaveChanges')){
      $totaldetails = $this->input->post('TotalFilterDefault');
      if ($totaldetails){
        $parent_id = 0;
        for ($i = 1; $i <= $totaldetails; $i++){
          $param['parent_id'] = $parent_id;
          $param['hotel_manager_name'] = 'Owner';
          $param['hotel_manager_id'] = addslashes($this->input->post('vendor_id'));
          $param['customer_name'] = addslashes($this->input->post('name'));
          $param['check_in_date'] = addslashes($this->input->post('checkin_date'));
          $param['check_out_date'] = addslashes($this->input->post('checkout_date'));
          $param['assign_room_number'] = addslashes($this->input->post('select_room_' . $i));
          $param['number_of_person'] = addslashes($this->input->post('number_of_person_' . $i));
          $param['amount'] = addslashes($this->input->post('amount_' . $i));
          $param['amount_mode'] = addslashes($this->input->post('amount_mode'));
          $param['prepaid_amount'] = addslashes($this->input->post('prepaid_amount'));
          $param['advance_paid'] = 0;
          $param['payment_paid'] = addslashes($this->input->post('prepaid_amount')/ $totaldetails);
          $param['remarks'] = addslashes($this->input->post('extr_remarks'));
          $param['add_date'] = date('Y-m-d H:i:s');
          $param['status'] = 'Y';
          $vendorId = $this->common_model->addData('calendar_reservations', $param);
          
          if($i==1){
            $parent_id = $vendorId;
          } 

          /*Save Date*/
          $UpdateCheckOutDate = date('Y-m-d',strtotime($param['check_out_date'].'- 1 days'));
          $TotalDays = $this->CalculateDays($param['check_in_date'],$UpdateCheckOutDate);
          $this->SaveCalendarDate('Reservation',$vendorId,$param['assign_room_number'],$param['check_in_date'],$TotalDays);
          /*Save Date*/
          
          $Uparam['encrypt_id'] = ashishEncript($vendorId);
          $Uparam['reservation_id'] = generateUniqueId($vendorId);
          $Uwhere['id'] = $vendorId;
          $ReservationId = $Uparam['reservation_id'];
          $this->common_model->editDataByMultipleCondition('calendar_reservations', $Uparam, $Uwhere);

          $this->session->set_flashdata('alert_success', lang('addsuccess'));
        }
        //redirect('owner/calendar/index');
        redirect($_SERVER['HTTP_REFERER']);
      }else{
        redirect($_SERVER['HTTP_REFERER']);
      }
    }else{
      redirect('owner/calendar/index');
    }
  }
  public function SaveCalendarDate($type,$calendar_id,$room_id,$check_in_date,$TotalDays){
    for ($i=0; $i <= $TotalDays; $i++) { 
      $SaveData['cal_date'] = date('Y-m-d', strtotime($check_in_date. ' + '.$i.' days'));
      $SaveData['type'] = $type;
      $SaveData['calendar_id'] = $calendar_id;
      $SaveData['room_id'] = $room_id;
      $this->common_model->addData('calendar_date', $SaveData);
    }
  }
  public function BlockRoom(){
    if ($this->input->post('SaveChanges')){
      $select_room = $_POST['block_room'];
      $parent_id = 0;
      foreach ($select_room as $key => $value) {
        $valueArr = explode('_', $value);

        $param['parent_id'] = $parent_id;
        $param['hotel_manager_name'] = 'Owner';
        $param['hotel_manager_id'] = addslashes($this->input->post('vendor_id'));
        $param['check_in_date'] = addslashes($this->input->post('block_checkin_date'));
        $param['check_out_date'] = addslashes($this->input->post('block_checkout_date'));
        $param['assign_room_number'] = $valueArr['0'];
        $param['remarks'] = addslashes($this->input->post('remarks'));
        
        $param['add_date'] = date('Y-m-d H:i:s');
        $param['status'] = 'Y';
        $vendorId = $this->common_model->addData('calendar_block_room', $param);

        if($key==0){
          $parent_id = $vendorId;
        }

        /*Save Date*/
        $TotalDays = $this->CalculateDays($param['check_in_date'],$param['check_out_date']);
        $this->SaveCalendarDate('BlockRoom',$vendorId,$param['assign_room_number'],$param['check_in_date'],$TotalDays);
        /*Save Date*/

        $Uparam['encrypt_id'] = ashishEncript($vendorId);
        $Uparam['block_id'] = generateUniqueId($vendorId);
        $Uwhere['id'] = $vendorId;
        $ReservationId = $Uparam['reservation_id'];
        $this->common_model->editDataByMultipleCondition('calendar_block_room', $Uparam, $Uwhere);
      
        $this->session->set_flashdata('alert_success', lang('addsuccess'));
        //echo '<pre>';print_r($param);
      }
      //echo '<pre>';print_r($_POST);die();
      redirect($_SERVER['HTTP_REFERER']);
    }else{
      redirect('owner/calendar/index');
    }
  }
  public function GetBlockRoom(){
    $vendor_id = $_GET['vendor_id'];
    $checkin_date = $_GET['checkin_date'];
    $checkout_date = $_GET['checkout_date'];
    $hotelRoom = $this->getAllAvaiableRoomsByHotelId($vendor_id);
    echo '<label class="fancy-checkbox form-headings">Select Room <span class="required">*</span></label>';
    foreach ($hotelRoom as $Hinfo) {
      $checkdate = $this->GetCalendarBlockDate($vendor_id,$Hinfo['room_id'],$checkin_date,$checkout_date);
      if($checkdate>0){
        $checkRoom = 'disabled';
        $checkText = 'style="color: red;"';
      }else{
        $checkRoom = '';
        $checkText = '';
      }
      echo ' <input type="checkbox" name="block_room[]" value="'.$Hinfo['room_id'].'_'.$Hinfo['room_no'].'" '.$checkRoom.' class="form-checkbox RCheckBox" /> <label '.$checkText.' class="custom-control-label" >'.$Hinfo['room_no'].' </label> ';
    }
  }
  public function GetCalendarBlockDate($hotel_manager_id,$assign_room_number,$checkin_date,$checkout_date){
    //$this->db->select('cdate.id');
    $this->db->from('calendar_date as cdate');
    $this->db->join('calendar_block_room as re', 're.id=cdate.calendar_id', 'LEFT');
    $this->db->where("cdate.type", 'BlockRoom');
    $this->db->where("re.hotel_manager_id", $hotel_manager_id);
    $this->db->where("re.assign_room_number", $assign_room_number);
    $this->db->where("cdate.cal_date BETWEEN '$checkin_date' AND '$checkout_date'");
    $this->db->where("re.status = 'Y'");
    $query = $this->db->get();
    //secho $this->db->last_query();die();
    return $query->num_rows();
  }
  public function LabelRoom(){
    if ($this->input->post('SaveChanges')){
      $select_room = $_POST['block_room'];
      $parent_id = 0;
      foreach ($select_room as $key => $value) {
        $valueArr = explode('_', $value);

        $param['parent_id'] = $parent_id;
        $param['hotel_manager_name'] = 'Owner';
        $param['hotel_manager_id'] = addslashes($this->input->post('vendor_id'));
        $param['check_in_date'] = addslashes($this->input->post('label_checkin_date'));
        $param['check_out_date'] = addslashes($this->input->post('label_checkout_date'));
        $param['assign_room_number'] = $valueArr['0'];
        $param['remarks'] = addslashes($this->input->post('remarks'));
        
        $param['add_date'] = date('Y-m-d H:i:s');
        $param['status'] = 'Y';
        $vendorId = $this->common_model->addData('calendar_label_room', $param);
        
        if($key==0){
          $parent_id = $vendorId;
        }

        /*Save Date*/
        $TotalDays = $this->CalculateDays($param['check_in_date'],$param['check_out_date']);
        $this->SaveCalendarDate('LabelRoom',$vendorId,$param['assign_room_number'],$param['check_in_date'],$TotalDays);
        /*Save Date*/

        $Uparam['encrypt_id'] = ashishEncript($vendorId);
        $Uparam['block_id'] = generateUniqueId($vendorId);
        $Uwhere['id'] = $vendorId;
        $ReservationId = $Uparam['reservation_id'];
        $this->common_model->editDataByMultipleCondition('calendar_label_room', $Uparam, $Uwhere);
      
        $this->session->set_flashdata('alert_success', lang('addsuccess'));
        //echo '<pre>';print_r($param);
      }
      //echo '<pre>';print_r($_POST);die();
      redirect($_SERVER['HTTP_REFERER']);
    }else{
      redirect('owner/calendar/index');
    }
  }
  public function GetLabelRoom(){
    $vendor_id = $_GET['vendor_id'];
    $checkin_date = $_GET['checkin_date'];
    $checkout_date = $_GET['checkout_date'];
    $hotelRoom = $this->getAllAvaiableRoomsByHotelId($vendor_id);
    echo '<label class="fancy-checkbox form-headings">Select Room <span class="required">*</span></label>';
    foreach ($hotelRoom as $Hinfo) {
      $checkdate = $this->GetCalendarLabelDate($vendor_id,$Hinfo['room_id'],$checkin_date,$checkout_date);
      if($checkdate>0){
        $checkRoom = 'disabled';
        $checkText = 'style="color: red;"';
      }else{
        $checkRoom = '';
        $checkText = '';
      }
      echo ' <input type="checkbox" name="block_room[]" value="'.$Hinfo['room_id'].'_'.$Hinfo['room_no'].'" '.$checkRoom.' class="form-checkbox RCheckBox" /> <label '.$checkText.' class="custom-control-label" >'.$Hinfo['room_no'].' </label> ';
    }
  }
  public function GetCalendarLabelDate($hotel_manager_id,$assign_room_number,$checkin_date,$checkout_date){
    //$this->db->select('cdate.id');
    $this->db->from('calendar_date as cdate');
    $this->db->join('calendar_label_room as re', 're.id=cdate.calendar_id', 'LEFT');
    $this->db->where("cdate.type", 'BlockRoom');
    $this->db->where("re.hotel_manager_id", $hotel_manager_id);
    $this->db->where("re.assign_room_number", $assign_room_number);
    $this->db->where("cdate.cal_date BETWEEN '$checkin_date' AND '$checkout_date'");
    $this->db->where("re.status = 'Y'");
    $query = $this->db->get();
    //secho $this->db->last_query();die();
    return $query->num_rows();
  }


  public function getAllAvaiableRoomsByHotelId($hotel_manager_id){
    $this->db->select('room_id,room_no,id,category_id');
    $this->db->from('room_number');
    $this->db->where("hotel_manager_id", $hotel_manager_id);
    //$this->db->where("room_no_use = 'N'");
    $this->db->where("status = 'Y'");
    $this->db->order_by("room_no ASC");
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
      return $query->result_array();
    else :
      return false;
    endif;
  }
  public function getAllReservationData($hotel_manager_id){
    //$this->db->select('room_id,room_no');
    $this->db->from('calendar_reservations');
    $this->db->where("hotel_manager_id", $hotel_manager_id);
    //$this->db->where("room_no_use = 'N'");
    $this->db->where("status = 'Y'");
    //$this->db->order_by("room_no ASC");
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
      return $query->result_array();
    else :
      return false;
    endif;
  }
  public function GetAllBlockRoomData($hotel_manager_id){
    $this->db->select('block.*,rn.room_no');
    $this->db->from('calendar_block_room as block');
    $this->db->join('room_number as rn', 'rn.room_id=block.assign_room_number', 'LEFT');
    $this->db->where("block.hotel_manager_id", $hotel_manager_id);
    $this->db->where("block.status = 'Y'");
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
      return $query->result_array();
    else :
      return false;
    endif;
  }
  public function GetAllLabelRoomData($hotel_manager_id){
    $this->db->select('block.*,rn.room_no');
    $this->db->from('calendar_label_room as block');
    $this->db->join('room_number as rn', 'rn.room_id=block.assign_room_number', 'LEFT');
    $this->db->where("block.hotel_manager_id", $hotel_manager_id);
    $this->db->where("block.status = 'Y'");
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
      return $query->result_array();
    else :
      return false;
    endif;
  }
  public function GetCalendarReservationDate($hotel_manager_id,$assign_room_number,$checkin_date,$checkout_date){
    //$this->db->select('cdate.id');
    $this->db->from('calendar_date as cdate');
    $this->db->join('calendar_reservations as re', 're.id=cdate.calendar_id', 'LEFT');
    $this->db->where("cdate.type", 'Reservation');
    $this->db->where("re.hotel_manager_id", $hotel_manager_id);
    $this->db->where("re.assign_room_number", $assign_room_number);
    $this->db->where("cdate.cal_date BETWEEN '$checkin_date' AND '$checkout_date'");
    $this->db->where("re.status = 'Y'");
    $query = $this->db->get();
    return $query->num_rows();
  }
  public function CalculateDays($FromDate,$ToDate){
    $date1 = strtotime($FromDate);
    $date2 = strtotime($ToDate);
    $difference = $date2 - $date1;
    $days = floor($difference / (60 * 60 * 24));
    if($days=='-1'){
      $days = 1;
    }
    return $days;
  }

  public function GetCalendarData(){
    $data['vendor_id']   = $_GET['vendor_id'];
    $data['SelectData']  = $_GET['SelectData'];
    $data['hotelRoom'] = $this->getAllAvaiableRoomsByHotelId($data['vendor_id']);
    //echo '<pre>';print_r($data);die;
    $this->load->view('owner/Calendar/GetCalendarData', $data);
  }
  public function ReservationDetails(){
    $data['vendor_id']  = $_GET['vendor_id'];
    $data['s_date']  = $_GET['s_date'];
    $data['room_id']  = $_GET['room_id'];
    
    $ResQuery = "SELECT reservation.* FROM ".getTablePrefix()."calendar_date as cdate join ".getTablePrefix()."calendar_reservations as reservation on cdate.calendar_id=reservation.id WHERE cdate.type='Reservation' AND cdate.cal_date='".$data['s_date']."' AND cdate.room_id='".$data['room_id']."' ";
    $ResData = $this->common_model->getDataByQuery('single', $ResQuery);
    //echo '<pre>';print_r($ResData);die;
    $data['ResData'] = $ResData;
    $this->load->view('owner/Calendar/ReservationDetails', $data);
  }
  public function DeleteReservationData(){
    $cal_id     = $_GET['cal_id'];
    $Query = "SELECT id,parent_id FROM ".getTablePrefix()."calendar_reservations WHERE id=".$cal_id." ";
    $Reser = $this->common_model->getDataByQuery('single', $Query);
    if($Reser['parent_id']==0){
      $ReserQuery = "SELECT id FROM ".getTablePrefix()."calendar_reservations WHERE parent_id=".$Reser['id']." ";
      $ReserData = $this->common_model->getDataByQuery('multiple', $ReserQuery);
      foreach ($ReserData as $row) {
        $this->db->delete('calendar_date',array('calendar_id'=>$row['id'],'type'=>'Reservation'));
      }
      $this->db->delete('calendar_date',array('calendar_id'=>$Reser['id'],'type'=>'Reservation'));

      $this->db->delete('calendar_reservations',array('parent_id'=>$Reser['id']));
      $this->db->delete('calendar_reservations',array('id'=>$Reser['id']));
    }else{
      $ReserQuery = "SELECT id FROM ".getTablePrefix()."calendar_reservations WHERE parent_id=".$Reser['parent_id']." ";
      $ReserData = $this->common_model->getDataByQuery('multiple', $ReserQuery);
      foreach ($ReserData as $row) {
        $this->db->delete('calendar_date',array('calendar_id'=>$row['id'],'type'=>'Reservation'));
      }
      $this->db->delete('calendar_date',array('calendar_id'=>$Reser['parent_id'],'type'=>'Reservation'));
      $this->db->delete('calendar_reservations',array('parent_id'=>$Reser['parent_id']));
      $this->db->delete('calendar_reservations',array('id'=>$Reser['parent_id']));
    }
    //echo '<pre>';print_r($Reser);die();
    return true;
  }
  public function PrintRservation($cal_id){
    $cal_id = base64_decode($cal_id);

    $ResQuery = "SELECT reservation.*,vendor.vendor_business_name,vendor.first_manager_contact_number,vendor.vendor_id FROM ".getTablePrefix()."calendar_reservations as reservation join ".getTablePrefix()."vendor as vendor on vendor.vendor_id=reservation.hotel_manager_id WHERE reservation.id='".$cal_id."' ";
    $ResData = $this->common_model->getDataByQuery('single', $ResQuery);
    $data['VendorDetails'] = $this->common_model->getDataByQuery('single', "SELECT vendor_address FROM ".getTablePrefix()."vendor_details WHERE vendor_id='".$ResData['vendor_id']."' ");
    $data['ResData'] = $ResData;
    //echo '<pre>';print_r($data);die;
    $this->load->view('owner/Calendar/PrintRservation', $data);
  }
  public function BlockRoomsDetails(){
    $data['vendor_id']  = $_GET['vendor_id'];
    $data['s_date']     = $_GET['s_date'];
    $data['room_id']    = $_GET['room_id'];
    
    $ResQuery = "SELECT block.* FROM ".getTablePrefix()."calendar_date as cdate join ".getTablePrefix()."calendar_block_room as block on cdate.calendar_id=block.id WHERE cdate.type='BlockRoom' AND cdate.cal_date='".$data['s_date']."' AND cdate.room_id='".$data['room_id']."' ";
    $ResData = $this->common_model->getDataByQuery('single', $ResQuery);
    //echo '<pre>';print_r($ResData);die;
    $data['ResData'] = $ResData;
    $this->load->view('owner/Calendar/BlockRoomsDetails', $data);
  }
  public function DeleteBlockRoomData(){
    $cal_id     = $_GET['cal_id'];
    $Query = "SELECT id,parent_id FROM ".getTablePrefix()."calendar_block_room WHERE id=".$cal_id." ";
    $Reser = $this->common_model->getDataByQuery('single', $Query);
    if($Reser['parent_id']==0){
      $ReserQuery = "SELECT id FROM ".getTablePrefix()."calendar_block_room WHERE parent_id=".$Reser['id']." ";
      $ReserData = $this->common_model->getDataByQuery('multiple', $ReserQuery);
      foreach ($ReserData as $row) {
        $this->db->delete('calendar_date',array('calendar_id'=>$row['id'],'type'=>'BlockRoom'));
      }
      $this->db->delete('calendar_date',array('calendar_id'=>$Reser['id'],'type'=>'BlockRoom'));

      $this->db->delete('calendar_block_room',array('parent_id'=>$Reser['id']));
      $this->db->delete('calendar_block_room',array('id'=>$Reser['id']));
    }else{
      $ReserQuery = "SELECT id FROM ".getTablePrefix()."calendar_block_room WHERE parent_id=".$Reser['parent_id']." ";
      $ReserData = $this->common_model->getDataByQuery('multiple', $ReserQuery);
      foreach ($ReserData as $row) {
        $this->db->delete('calendar_date',array('calendar_id'=>$row['id'],'type'=>'BlockRoom'));
      }
      $this->db->delete('calendar_date',array('calendar_id'=>$Reser['parent_id'],'type'=>'BlockRoom'));
      $this->db->delete('calendar_block_room',array('parent_id'=>$Reser['parent_id']));
      $this->db->delete('calendar_block_room',array('id'=>$Reser['parent_id']));
    }
    //echo '<pre>';print_r($Reser);die();
    return true;
  }
  public function LabelRoomsDetails(){
    $data['vendor_id']  = $_GET['vendor_id'];
    $data['s_date']     = $_GET['s_date'];
    $data['room_id']    = $_GET['room_id'];
    
    $ResQuery = "SELECT label.* FROM ".getTablePrefix()."calendar_date as cdate join ".getTablePrefix()."calendar_label_room as label on cdate.calendar_id=label.id WHERE cdate.type='LabelRoom' AND cdate.cal_date='".$data['s_date']."' AND cdate.room_id='".$data['room_id']."' ";
    $ResData = $this->common_model->getDataByQuery('single', $ResQuery);
    //echo '<pre>';print_r($ResData);die;
    $data['ResData'] = $ResData;
    $this->load->view('owner/Calendar/LabelRoomsDetails', $data);
  }
  public function DeleteLabelRoomData(){
    $cal_id     = $_GET['cal_id'];
    $Query = "SELECT id,parent_id FROM ".getTablePrefix()."calendar_label_room WHERE id=".$cal_id." ";
    $Reser = $this->common_model->getDataByQuery('single', $Query);
    if($Reser['parent_id']==0){
      $ReserQuery = "SELECT id FROM ".getTablePrefix()."calendar_label_room WHERE parent_id=".$Reser['id']." ";
      $ReserData = $this->common_model->getDataByQuery('multiple', $ReserQuery);
      foreach ($ReserData as $row) {
        $this->db->delete('calendar_date',array('calendar_id'=>$row['id'],'type'=>'LabelRoom'));
      }
      $this->db->delete('calendar_date',array('calendar_id'=>$Reser['id'],'type'=>'LabelRoom'));

      $this->db->delete('calendar_label_room',array('parent_id'=>$Reser['id']));
      $this->db->delete('calendar_label_room',array('id'=>$Reser['id']));
    }else{
      $ReserQuery = "SELECT id FROM ".getTablePrefix()."calendar_label_room WHERE parent_id=".$Reser['parent_id']." ";
      $ReserData = $this->common_model->getDataByQuery('multiple', $ReserQuery);
      foreach ($ReserData as $row) {
        $this->db->delete('calendar_date',array('calendar_id'=>$row['id'],'type'=>'LabelRoom'));
      }
      $this->db->delete('calendar_date',array('calendar_id'=>$Reser['parent_id'],'type'=>'LabelRoom'));
      $this->db->delete('calendar_label_room',array('parent_id'=>$Reser['parent_id']));
      $this->db->delete('calendar_label_room',array('id'=>$Reser['parent_id']));
    }
    //echo '<pre>';print_r($Reser);die();
    return true;
  }
}