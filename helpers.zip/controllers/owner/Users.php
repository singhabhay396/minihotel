<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Users extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'owner_model', 'emailtemplate_model', 'sms_model','frontauth_model','adminauth_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }
   public function changepassword(){
        $data['error'] = '';
        $data['activeMenu'] = 'Changepassword';
        $data['activeSubMenu'] = 'Changepassword';
        $owner_id = $this->session->userdata('MHM_OWNER_ID');
      if ($this->input->post('SaveChanges')){
        $error          = 'NO';
      
        if ($this->input->post('new_password') != '') :
          $this->form_validation->set_rules('new_password', 'New password', 'trim|required|min_length[6]|max_length[25]');
          $this->form_validation->set_rules('conf_password', 'Confirm password', 'trim|required|min_length[6]|matches[new_password]');
        endif;
        if ($this->input->post('new_password')) :
          $NewPassword        = $this->input->post('new_password');
          $param['vendor_password'] =   $this->adminauth_model->encriptPassword($NewPassword);
          //echo "<pre>"; print_r($owner_id); exit; 
          $this->common_model->editData('vendor', $param, 'vendor_id', $owner_id);
          //$this->common_model->editDataByMultipleCondition('vendor', $param, $Uwhere);
          $this->session->set_flashdata('alert_success', lang('updatesuccess'));
        endif;
         redirect('owner/dashboard');
    }
        //$this->owner_model->GetAllHotelList();
        $this->layouts->set_title('Change Password');
        //redirect('owner/users/changepassword');
        $this->layouts->owner_view('owner/Users/changepassword', array(), $data);
    }
  // function changestatus($changeStatusId = '', $statusType = ''){
  //   $param['status']    = $statusType;
  //   $this->common_model->editData('restaurant', $param, 'id', $changeStatusId);
  //   $this->session->set_flashdata('alert_success', lang('statussuccess'));
  //   redirect('owner/restaurant');
  // }
}