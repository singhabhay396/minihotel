<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Subowner extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('adminauth_model','ownerauth_model', 'vendor_model', 'owner_model', 'emailtemplate_model', 'sms_model','frontauth_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }

  public function index(){
    $data['error'] = '';
    $data['activeMenu'] = 'SubOwner';
    $data['activeSubMenu'] = 'SubOwner';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');

    $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    $this->layouts->set_title('Sub Owner List');
    $this->layouts->owner_view('owner/subowner/index', array(), $data);
  }
  function ManagerPagination(){
    $Search['hotel_name']     = $_GET['hotel_name'] ?? '';
    $Search['vendor_id']      = $_GET['vendor_id'] ?? 'All';
    $Search['m_name']         = $_GET['m_name'] ?? '';
    $Search['email']          = $_GET['email'] ?? '';
    $Search['mobile']         = $_GET['mobile'] ?? '';
    $Search['status']         = $_GET['status'] ?? 'All';
    $Search['page']           = $_GET['page'] ?? 1;
    $Search['numofrecords']   = $_GET['numofrecords'] ?? 100;
    //$Search['cur_page']       = $Search['page'];
    $Limitpage                = $Search['page']-1;
    $Search['start']          = $Limitpage * $Search['numofrecords'];
    
    $Search['action'] = 'count';
    $TotalData = $this->ManagerPaginationData($Search);
    $data['PAGINATION'] = Pagination($Search['numofrecords'],$TotalData, $Search['page']);
    $Search['action'] = 'data';
    $data['ALLDATA'] = $this->ManagerPaginationData($Search);
    //echo '<pre>';print_r($data);die;
    $this->load->view('owner/subowner/Pagination', $data);
  }
  function ManagerPaginationData($Search){
    $vendor_id = $this->owner_model->GetAllHotelList();
    $this->db->select('vendor.*');
    $this->db->from('vendor');
   // $this->db->join('sub_owner', 'sub_owner.vendor_id=vendor.vendor_id', 'INNER');
    if($Search['hotel_name']!=''){ $this->db->where("vendor.vendor_business_name LIKE '%" . $Search['hotel_name'] . "%'"); }
    if($Search['email']!=''){ $this->db->where("vendor.email LIKE '%" . $Search['email'] . "%'"); }
    if($Search['mobile']!=''){ $this->db->where("vendor.mobile LIKE '%" . $Search['mobile'] . "%'"); }
    if($Search['status']!='All'){ $this->db->where("vendor.status",$Search['status']); }
   $this->db->where("vendor.parent_owner",sessionData('MHM_OWNER_ID')); 
    $this->db->where('vendor.is_owner', 0);
    $this->db->order_by('vendor.id DESC');
    if ($Search['action']=='data'){ $this->db->limit($Search['numofrecords'], $Search['start']); }
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($Search['action'] == 'data'){
      if ($query->num_rows() > 0){
        return $query->result_array();
      }else{
        return false;
      }
    }elseif ($Search['action'] == 'count'){
      return $query->num_rows();
    }
  }

  public function addeditdata($editId = ''){
    $data['error'] = '';
    $data['activeMenu'] = 'Subowner';
    $data['activeSubMenu'] = 'Subowner';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $data['custId'] = $editId;
    $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    if($editId){
       $data['EDITDATA']        =   $this->common_model->getDataByParticularField('vendor', 'vendor_id', $editId);
    }
    $vendorQuery = "SELECT * FROM ".getTablePrefix()."vendor as `ven` INNER JOIN ".getTablePrefix()."vendor_details as `vd` ON `vd`.vendor_id =`ven`.vendor_id WHERE `ven`.`vendor_id` = '".sessionData('MHM_OWNER_ID')."' ORDER BY `ven`.`vendor_id` DESC";
    $data['vendorInfo'] = $this->common_model->getDataByQuery('single', $vendorQuery);  
    //echo "<pre>"; print_r($data); exit;
    $data['error'] = '';
        if ($this->input->post('currentPageFormSubmit')){
            $error = 'NO';
            $this->form_validation->set_rules('vendor_business_name', 'Business name', 'trim|required');
            $this->form_validation->set_rules('vendor_email', 'E-Mail', 'trim|valid_email|is_unique[vendor.vendor_email]');
            $vendoremail = str_replace(' ', '', $this->input->post('vendor_email'));
            if ($this->input->post('vendor_email') && !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
                if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
                    $error = 'YES';
                    $data['mobileerror'] = 'Please eneter correct email id.';
                endif;
            endif;
            $this->form_validation->set_rules('vendor_phone', 'Phone', 'trim|required|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('owner_secoundry_contact_number', 'Phone', 'trim|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('first_manager_contact_number', 'Phone', 'trim|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('secound_manager_contact_number', 'Phone', 'trim|min_length[10]|max_length[15]');
            $this->form_validation->set_rules('you_are', 'you_are', 'trim|required');
            $this->form_validation->set_rules('referral_cpde', 'referral_cpde', 'trim');
            $this->form_validation->set_rules('accept_policy', 'accept_policy', 'trim|required');
            //echo "<pre>"; print_r($form_error); exit;
            if ($this->form_validation->run() && $error == 'NO'){ 
                //$vendorPassword = generateRandomString(6, 'nl');
                //$vendorPasscode = generateRandomString(6, 'nl');
                $param['vendor_business_name'] = addslashes($this->input->post('vendor_business_name'));
                $param['vendor_email'] = addslashes($this->input->post('vendor_email'));
                $param['vendor_phone'] = addslashes($this->input->post('vendor_phone'));
                $param['owner_secoundry_contact_number'] = addslashes($this->input->post('owner_secoundry_contact_number'));
                $param['first_manager_contact_number'] = addslashes($this->input->post('first_manager_contact_number'));
                $param['secound_manager_contact_number'] = addslashes($this->input->post('secound_manager_contact_number'));
                $param['referral_code'] = addslashes($this->input->post('referral_code'));

                $param['accept_policy'] = addslashes($this->input->post('accept_policy'));
                $vendorPassword = generateRandomString(6, 'nl');
                $vendorPasscode = generateRandomString(6, 'nl');
                $param['vendor_passcode'] = $this->frontauth_model->encriptPassword($vendorPasscode);
                $param['vendor_password'] = $this->frontauth_model->encriptPassword($vendorPassword);
                $param['creation_date'] = currentDateTime();
                $param['vendor_phone_verify']    = $this->input->post('vendor_business_name');
                $param['status'] = $this->input->post('status');       
                $param['is_owner'] = $this->input->post('is_owner');             
                $param['sub_owner_num'] = $this->input->post('sub_owner_num');             
                $param['vendor_name'] = $this->input->post('vendor_name');             
                $param['parent_owner'] = sessionData('MHM_OWNER_ID');             
                $SDparam['you_are'] = addslashes($this->input->post('you_are'));
                $SDparam['vendor_kyc_status'] = addslashes($this->input->post('vendor_kyc_status'));
                $SDparam['other_details'] = addslashes($this->input->post('other_details'));
                $SDparam['no_of_restaurant'] = addslashes($this->input->post('no_of_restaurant'));
                $SDparam['kot_number'] = addslashes($this->input->post('kot_number'));
                $SDparam['entry_number'] = addslashes($this->input->post('entry_number'));
                $SDparam['bill_number'] = addslashes($this->input->post('bill_number'));
                $SDparam['managed_by'] = addslashes($this->input->post('managed_by'));
                $SDparam['vendor_gst'] = addslashes($this->input->post('vendor_gst'));
                $SDparam['website_url'] = addslashes($this->input->post('website_url'));
                $SDparam['vendor_address'] = addslashes($this->input->post('vendor_address'));
                $lastInsertId = $this->common_model->addData('vendor', $param);
                $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
                $Uparam['vendor_id'] = generateUniqueId($lastInsertId);
                $Uparam['vendor_slug'] = strtolower(url_title(trim($this->input->post('vendor_business_name')))) . $lastInsertId;
                $Uwhere['id'] = $lastInsertId;
                $this->common_model->editDataByMultipleCondition('vendor', $Uparam, $Uwhere);
                $vendorId = $Uparam['vendor_id'];
                if ($vendorId){
                    $SDparam['vendor_id'] = $vendorId;
                    $SDparam['creation_date'] = currentDateTime();
                    $SDlastInsertId = $this->common_model->addData('vendor_details', $SDparam);
                    $SDUparam['encrypt_id'] = ashishEncript($SDlastInsertId);
                    $SDUparam['vendor_detail_id'] = generateUniqueId($SDlastInsertId);
                    $SDUwhere['id'] = $SDlastInsertId;
                    $this->common_model->editDataByMultipleCondition('vendor_details', $SDUparam, $SDUwhere);
                    $this->common_model->deleteParticularData('sub_owner', 'owner_id', $vendorId);
                    if(!empty($this->input->post('vendor_id'))){
                        $subOwner = $this->input->post('vendor_id');
                        foreach ($subOwner as $key => $value) {
                            $SOparam['owner_id'] = $vendorId;
                            $SOparam['vendor_id'] = $value;
                            $SOparam['status'] = 1;
                            $lastInsertId = $this->common_model->addData('sub_owner', $SOparam);
                        }
                    }
                }
            }
            if ($this->input->post('CurrentDataID') == '') :

                $this->session->set_flashdata('alert_success', lang('addsuccess'));
            else :
                $this->session->set_flashdata('alert_success', lang('updatesuccess'));
            endif;
            redirect('owner/subowner');
        }
        
    $this->layouts->set_title('Edit Sub Owner Details');
    $this->layouts->owner_view('owner/subowner/addedit', array(), $data);
    
  }
  function changestatus($changeStatusId = '', $statusType = ''){
    $param['status']    = $statusType;
    $this->common_model->editData('vendor', $param, 'id', $changeStatusId);
    $this->session->set_flashdata('alert_success', lang('statussuccess'));
    redirect('owner/subowner');
  }
  public function addeditdatas($editId = '')
    {
        $data['error']              =   '';
        $data['activeMenu']         =   'subowner';
        $data['activeSubMenu']      =   'subowner';

        if ($editId) :
            $data['EDITDATA']       =   $this->common_model->getDataByParticularField('vendor', 'vendor_id', $editId);
           
      $vendorPassword =     $this->adminauth_model->decryptsPassword($data['EDITDATA']['vendor_password']);
       
      if($data['EDITDATA']['vendor_passcode']){
        $VendorPassCode = $data['EDITDATA']['vendor_passcode'];
      }else{
        $VendorPassCode = 'qMkDUqAxYsRPXHz/UUHW1OL+dY1MLlW47XO8mygMC/9xYkt0WUo1emllcEFaUldmbHBJbWhyL1N0OUZvUEE9PQ==';
      }
      $vendorPasscode = $this->adminauth_model->decryptsPassword($VendorPassCode);
            $kycQuery               =   "SELECT * FROM " . getTablePrefix() . "vendor_details
                                         WHERE vendor_id = '" . $editId . "'";
            $data['KYCDATA']        =   $this->common_model->getDataByQuery('single', $kycQuery);
        else :
            $this->adminauth_model->authCheck('admin', 'add_data');
        endif;

        if ($this->input->post('SaveChanges')) :
            $error                  =   'NO';
            $this->form_validation->set_rules('vendor_business_name', 'Business name', 'trim');
            $this->form_validation->set_rules('vendor_title', 'Title', 'trim');
            $this->form_validation->set_rules('vendor_name', 'Name', 'trim');
            //$this->form_validation->set_rules('vendor_email', 'E-Mail', 'trim|required|valid_email|is_unique[vendor.vendor_email]');
            $this->form_validation->set_rules('admin_mobile_number', 'Phone', 'trim|required|min_length[10]|max_length[15]');
            $vendoremail        =   str_replace(' ', '', $this->input->post('vendor_email'));
            if ($this->input->post('vendor_email') && !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
                if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
                    $error                      =   'YES';
                    $data['mobileerror']        =   'Please eneter correct email id.';
                endif;
            endif;
            $this->form_validation->set_rules('vendor_image', 'Image', 'trim');
            if ($this->input->post('new_password') != '') :
                $this->form_validation->set_rules('new_password', 'New password', 'trim|required|min_length[6]|max_length[25]');
                $this->form_validation->set_rules('conf_password', 'Confirm password', 'trim|required|min_length[6]|matches[new_password]');
            endif;

            $this->form_validation->set_rules('vendor_address', 'Address', 'trim');
            $this->form_validation->set_rules('vendor_city', 'City', 'trim');
            $this->form_validation->set_rules('vendor_pincode', 'Pincode', 'trim');
            $this->form_validation->set_rules('vendor_nationality', 'Nationality', 'trim');
            $this->form_validation->set_rules('vendor_pan', 'Pan no', 'trim');
            $this->form_validation->set_rules('uploadimage0', 'Pan image', 'trim');
            $this->form_validation->set_rules('vendor_gst', 'GST no', 'trim');
            $this->form_validation->set_rules('uploadimage1', 'GST image', 'trim');
            $this->form_validation->set_rules('vendor_address_proof', 'Address proof type', 'trim');
            $this->form_validation->set_rules('uploadimage2', 'Address proof image', 'trim');

            $this->form_validation->set_rules('vendor_kyc_status', 'KYC verify', 'trim');

            if ($this->form_validation->run() && $error == 'NO'):  
           
              
                $param['vendor_title']          =   addslashes($this->input->post('vendor_title'));
                $param['vendor_name']           =   addslashes($this->input->post('vendor_name'));
                $param['vendor_business_name']  =   addslashes($this->input->post('vendor_business_name'));
                $param['vendor_email']          =   addslashes($this->input->post('vendor_email'));
                $param['vendor_phone']          =   addslashes($this->input->post('admin_mobile_number'));
                $param['whatsapp_checkin']      =   addslashes($this->input->post('whatsapp_checkin'));
                $param['feedback_link']         =   addslashes($this->input->post('feedback_link'));
                $param['contact_owner']         =   addslashes($this->input->post('contact_owner'));
                $param['whatsapp_checkout']     =   addslashes($this->input->post('whatsapp_checkout'));
                $param['whatsapp_bulk']         =   addslashes($this->input->post('whatsapp_bulk'));

                if ($this->input->post('new_password')) :
                    $NewPassword                =   $this->input->post('new_password');
                    $param['vendor_password']   =   $this->adminauth_model->encriptPassword($NewPassword);
                endif;

                if ($this->input->post('vendor_passcode')) :
                    $vendor_passcode                =   $this->input->post('vendor_passcode');
                    $param['vendor_passcode']   =   $this->adminauth_model->encriptPassword($vendor_passcode);
                endif;    


                //$vendorPassword = generateRandomString(6, 'nl');
                //$vendorPasscode = generateRandomString(6, 'nl');
                //$param['vendor_passcode'] = $this->frontauth_model->encriptPassword($vendorPasscode);
                //$param['vendor_password'] = $this->frontauth_model->encriptPassword($vendorPassword);
                $param['vendor_image']          =   addslashes($this->input->post('vendor_image'));
                $SDparam['vendor_address']      =   addslashes($this->input->post('vendor_address'));
                $SDparam['vendor_city']         =   addslashes($this->input->post('vendor_city'));
                $SDparam['vendor_pincode']      =   addslashes($this->input->post('vendor_pincode'));
                $SDparam['vendor_nationality']  =   addslashes($this->input->post('vendor_nationality'));
                $SDparam['vendor_pan']          =   addslashes($this->input->post('vendor_pan'));
                $SDparam['vendor_pan_attach']   =   addslashes($this->input->post('uploadimage0'));
                $SDparam['vendor_gst']          =   addslashes($this->input->post('vendor_gst'));
                $SDparam['vendor_gst_attach']   =   addslashes($this->input->post('uploadimage1'));
                $SDparam['vendor_address_proof'] =  addslashes($this->input->post('vendor_address_proof'));
                $SDparam['vendor_address_proof_attach'] =   addslashes($this->input->post('uploadimage2'));
                $SDparam['vendor_kyc_status']   =   $this->input->post('vendor_kyc_status');
                $SDparam['no_of_restaurant']    =   $this->input->post('no_of_restaurant'); 

                if ($this->input->post('CurrentDataID') == '') :
                    $param['creation_date']     =   currentDateTime();
                    $param['created_by']        =   $this->session->userdata('MHM_ADMIN_ID');
                    $param['vendor_type']       =   'Verified';
                    $param['status']            =   'A';
                    $lastInsertId               =   $this->common_model->addData('vendor', $param);
                    $Uparam['encrypt_id']       =   ashishDecript($lastInsertId);
                    $Uparam['vendor_id']        =   generateUniqueId($lastInsertId);
                    $Uparam['vendor_slug']      =   strtolower(url_title(trim($this->input->post('vendor_business_name')))) . $lastInsertId;
                    $Uwhere['id']               =   $lastInsertId;
                    $this->common_model->editDataByMultipleCondition('vendor', $Uparam, $Uwhere);
                    $vendorId                   =   $Uparam['vendor_id'];
                    if ($vendorId) :
                        $SDparam['vendor_id']       =   $vendorId;
                        $SDparam['creation_date']   =   currentDateTime();
                        $SDparam['created_by']      =   $this->session->userdata('MHM_ADMIN_ID');
                        $SDlastInsertId             =   $this->common_model->addData('vendor_details', $SDparam);
                        $SDUparam['encrypt_id']     =   ashishDecript($SDlastInsertId);
                        $SDUparam['vendor_detail_id'] = generateUniqueId($SDlastInsertId);
                        $SDUwhere['id']             =   $SDlastInsertId;
                        $this->common_model->editDataByMultipleCondition('vendor_details', $SDUparam, $SDUwhere);
                    endif;
                    $this->session->set_flashdata('alert_success', lang('addsuccess'));
                else :
                    $vendorId                   =   $this->input->post('CurrentDataID');
                    $param['update_date']       =   currentDateTime();
                    $param['vendor_type']       =   'Verified';
                    $param['updated_by']        =   $this->session->userdata('MHM_ADMIN_ID');
                    $this->common_model->editData('vendor', $param, 'vendor_id', $vendorId);
                        // START SENDING CRED
                        if($data['KYCDATA']['vendor_kyc_status'] != 'Y'):
                        $this->emailtemplate_model->UserRegistrationMailToUser($vendorId, $vendorPassword, $vendorPasscode);
                        $this->emailtemplate_model->UserRegistrationMailToAdmin($vendorId);
                        endif;
                        // end of red
                    if ($vendorId) :
                        $SDparam['update_date'] =   currentDateTime();
                        $SDparam['updated_by']  =   $this->session->userdata('MHM_ADMIN_ID');
                        $this->common_model->editData('vendor_details', $SDparam, 'vendor_id', $vendorId);
                    endif;
                    $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                endif;
                 redirect('owner/subowner');
            endif;
        endif;

        $this->layouts->set_title('Edit Seller Details');
        $this->layouts->owner_view('owner/subowner/addeditdata', array(), $data);
    }   // END OF FUNCTION
}