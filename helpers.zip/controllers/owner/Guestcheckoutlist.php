<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Guestcheckoutlist extends CI_Controller
{
  public function __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'emailtemplate_model', 'sms_model','owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }
  public function index(){
    $data['error'] = '';
    $data['activeMenu'] = 'CheckedOut';
    $data['activeSubMenu'] = 'CheckedOut';
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $data['HotelList'] = $this->owner_model->GetSubOwnerVendorList();
    }
    //$this->owner_model->GetAllHotelList();
    $this->layouts->set_title('Manage Check Out Data');
    $this->layouts->owner_view('owner/checkout/index', array(), $data);
  }
  function CheckedOutPagination(){
    $Search['m_name']         = $_GET['m_name'] ?? '';
    $Search['c_name']         = $_GET['c_name'] ?? '';
    $Search['entry_no']       = $_GET['entry_no'] ?? '';
    $Search['check_in']       = $_GET['check_in'] ?? '';
    $Search['check_out']      = $_GET['check_out'] ?? '';
    $Search['mobile']         = $_GET['mobile'] ?? '';
    $Search['VendorArr']      = $_GET['VendorArr'] ?? '';
    $Search['room_no']        = $_GET['room_no'] ?? '';
    $Search['page']           = $_GET['page'] ?? 1;
    $Search['numofrecords']   = $_GET['numofrecords'] ?? 100;
    $Search['cur_page']       = $Search['page'];
    $Limitpage                = $Search['page']-1;
    $Search['start']          = $Limitpage * $Search['numofrecords'];

    $Search['action'] = 'count';
    $TotalData = $this->CheckedOutPaginationData($Search);
    $data['PAGINATION'] = Pagination($Search['numofrecords'],$TotalData, $Search['page']);
     $data['noOfContent'] = 'Showing ' . $Search['page'] . '-' . $Search['numofrecords'] . ' of ' . $TotalData . ' items';
    $Search['action'] = 'data';
    $data['ALLDATA'] = $this->CheckedOutPaginationData($Search);

    $this->load->view('owner/checkout/CheckedOutPagination', $data);
  }
  function CheckedOutPaginationData($Search){
    $LoginVenderId = sessionData('MHM_OWNER_ID');
    if($Search['VendorArr']!=''){ 
      $hotel_manager_id = explode(',', $Search['VendorArr']);
    }else{
      $hotel_manager_id = $this->owner_model->GetAllHotelList();
    }
    $this->db->select('csb.*,rn.room_no');
    $this->db->from('customer_summary_book as csb');
    $this->db->join('room_number as rn', 'rn.room_id=csb.assign_room_number', 'LEFT');
    if($Search['m_name']!=''){ $this->db->where("csb.hotel_manager_name LIKE '%" . $Search['m_name'] . "%'"); }
    if($Search['c_name']!=''){ $this->db->where("csb.customer_name LIKE '%" . $Search['c_name'] . "%'"); }
    if($Search['entry_no']!=''){ $this->db->where("csb.entry_number LIKE '%" . $Search['entry_no'] . "%'"); }
    if($Search['check_in']!=''){ $this->db->where("csb.check_in_datetime LIKE '%" . $Search['check_in'] . "%'"); }
    if($Search['check_out']!=''){ $this->db->where("csb.check_out_datetime LIKE '%" . $Search['check_out'] . "%'"); }
    if($Search['mobile']!=''){ $this->db->where("csb.customer_mobile_number LIKE '%" . $Search['mobile'] . "%'"); }
    if($Search['room_no']!=''){ $this->db->where("rn.room_no LIKE '%" . $Search['room_no'] . "%'"); }
    $this->db->where_in("csb.hotel_manager_id",$hotel_manager_id); 
    $this->db->where("csb.check_out_datetime != 'NULL' AND csb.status ='Y'");
    $this->db->order_by('csb.check_out_datetime DESC');
    if ($Search['action']=='data'){$this->db->limit($Search['numofrecords'], $Search['start']); }
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($Search['action'] == 'data'){
      //echo $this->db->last_query(); die;
      if ($query->num_rows() > 0){
        return $query->result_array();
      }else{
        return false;
      }
    }elseif ($Search['action'] == 'count'){
      return $query->num_rows();
    }
  }
  function editcheckout($editId){
    $data['error'] = '';
    $data['activeMenu'] = 'CheckedOut';
    $data['activeSubMenu'] = 'CheckedOut';

    $EDITDATA = $this->common_model->getDataByParticularField('customer_summary_book', 'encrypt_id', $editId);
    $hotel_manager_id = $EDITDATA['hotel_manager_id'];
    $delQuery = "SELECT room_no FROM " . getTablePrefix() . "room_number WHERE room_id = '" . $data['EDITDATA']['assign_room_number'] . "' AND hotel_manager_id = '" . $hotel_manager_id . "'";
    $data['ASSIGNROOM'] = $this->common_model->getDataByQuery('single', $delQuery);
    $docQuery = "SELECT * FROM " . getTablePrefix() . "customer_id_proof WHERE customer_id = '" . $data['EDITDATA']['summary_book_id'] . "' AND hotel_manager_id = '" . $hotel_manager_id . "'";
    $data['DOCUDATA'] = $this->common_model->getDataByQuery('multiple', $docQuery);

    $HourlyQuery = "SELECT * FROM ".getTablePrefix()."hourly_check_outs WHERE status='Y' AND hotel_manager_id='".$hotel_manager_id."' ORDER BY id DESC";

    if ($this->input->post('SaveChanges')){

      $vendorId = $this->input->post('CurrentDataID');
      $customerId = $vendorId;

      $param['customer_name'] = addslashes($this->input->post('customer_name'));
      $param['customer_email'] = addslashes($this->input->post('customer_email'));
      $param['customer_mobile_number'] = addslashes($this->input->post('customer_mobile_number'));
      $param['check_in_datetime'] = addslashes($this->input->post('check_in_datetime'));
      $param['check_out_datetime'] = addslashes($this->input->post('check_out_datetime'));
      $param['hourly_check_out_id'] = addslashes($this->input->post('hourly_check_out_id'));
      if ($this->input->post('assign_room_number') != "") :
          $param['assign_room_number'] = addslashes($this->input->post('assign_room_number'));
      endif;
      $param['address'] = addslashes($this->input->post('address'));
      $param['remarks'] = addslashes($this->input->post('remarks'));
      $param['number_of_person'] = addslashes($this->input->post('number_of_person'));
      $param['age'] = addslashes($this->input->post('age'));
      $param['other_person_details'] = addslashes($this->input->post('other_person_details'));
      $param['person_address'] = addslashes($this->input->post('person_address'));
      $param['reffer_mode'] = addslashes($this->input->post('reffer_mode'));
      $param['booking_id'] = addslashes($this->input->post('booking_id'));
      $param['direct_mode'] = addslashes($this->input->post('direct_mode'));
      $param['online_mode'] = addslashes($this->input->post('online_mode'));
      $param['ots_id'] = addslashes($this->input->post('ots_id'));
      $param['commission_amount'] = $this->input->post('commission_amount');
      //$param['amount_mode'] = $this->input->post('amount_mode');
      $param['prepaid_amount'] = $this->input->post('prepaid_amount');
      $param['entry_number'] = addslashes($this->input->post('entry_number'));
      $param['remarks'] = addslashes($this->input->post('remarks'));
      $param['room_rent_type'] = addslashes($this->input->post('room_rent_type'));
      $param['amount'] = addslashes($this->input->post('amount'));
      $param['gst_number'] = addslashes($this->input->post('gst_number'));
      $param['company_name'] = addslashes($this->input->post('company_name'));
      $param['company_slug'] = strtolower(url_title(trim($this->input->post('company_name'))));
      $param['company_address'] = addslashes($this->input->post('company_address'));
      $param['choose_plan'] = addslashes($this->input->post('choose_plan'));

      $param['update_date'] = currentDateTime();
      $param['updated_by'] = $this->session->userdata('MHM_OWNER_ID');
      $this->common_model->editData('customer_summary_book', $param, 'summary_book_id', $vendorId);
      if (isset($_FILES['uploadfile']) && !empty($_FILES['uploadfile']['name'])) {
        $files = $_FILES;
        $totalimage = count($_FILES['uploadfile']['name']);
        if ($totalimage) {
          for ($i = 0; $i < $totalimage; $i++) {
            $_FILES['uploadfile']['name'] = $files['uploadfile']['name'][$i];
            $_FILES['uploadfile']['type'] = $files['uploadfile']['type'][$i];
            $_FILES['uploadfile']['tmp_name'] = $files['uploadfile']['tmp_name'][$i];
            $_FILES['uploadfile']['error'] = $files['uploadfile']['error'][$i];
            $_FILES['uploadfile']['size'] = $files['uploadfile']['size'][$i];
            $file_name = $files['uploadfile']['name'][$i];
            $tmp_name = $files['uploadfile']['tmp_name'][$i];
            if ($file_name) :
              $this->load->library('upload');
              $path = $config['root_path'] . "assets/customerDocuments/";
              $filename = str_replace(' ', '_', strtolower(stripcslashes(time() . $_FILES['uploadfile']['name'])));
              $extension = pathinfo($path . $_FILES['uploadfile']['name'], PATHINFO_EXTENSION);
              if (move_uploaded_file($_FILES['uploadfile']['tmp_name'], $path . $filename)) :
                $trainingparams['customer_id'] = $customerId;
                $trainingparams['hotel_manager_id'] = sessionData('MHM_VENDOR_ID');
                $trainingparams['doc_url'] = 'assets/customerDocuments/' . $filename;
                $trainingparams['creation_date'] = currentDateTime();
                //$trainingparams['active']    =    'A';
                $lastTraingId = $this->common_model->addData('customer_id_proof', $trainingparams);
                $this->upload->do_upload();
                $UDparam['encrypt_id'] = ashishEncript($lastTraingId);
                $UDwhere['id'] = $lastTraingId;
                $this->common_model->editDataByMultipleCondition('customer_id_proof', $UDparam, $UDwhere);
              endif;
            endif;
          }
        }
      }
      $this->session->set_flashdata('alert_success', lang('updatesuccess'));
      redirect('owner/guestcheckoutlist/index');
      //echo '<pre>';print_r($_POST);die();
    }

    $data['HourlyCheckOutArr'] = $this->common_model->getDataByQuery('multiple', $HourlyQuery);
    $data['EDITDATA'] = $EDITDATA;    
    $data['hotel_manager_id'] = $hotel_manager_id;    
    $this->layouts->set_title('Edit Check Out Data');
    $this->layouts->owner_view('owner/checkout/edit', array(), $data);
  }
  public function SaveGSTIN(){
    if ($this->input->post('SaveChanges')) :
      $error = 'NO';
      $data['formError'] = 'Yes';
      if ($this->input->post('CurrentDataID') == '') :
        $this->form_validation->set_rules('company_gst', 'company_gst', 'required|callback_check_company_gst');
      else :
        $this->form_validation->set_rules('company_gst', 'company_gst', 'required');
      endif;
      $this->form_validation->set_rules('company_name', 'company_name', 'trim');
      $this->form_validation->set_rules('company_address', 'company_address', 'trim');
      if ($this->form_validation->run() && $error == 'NO') :
        $data['formError'] = 'No';
        $param['hotel_manager_id'] = addslashes($this->input->post('hotel_manager_id'));
        $param['company_name'] = addslashes($this->input->post('company_name'));
        $param['company_slug'] = strtolower(url_title(trim($this->input->post('company_name'))));
        $param['company_gst'] = addslashes($this->input->post('company_gst'));
        $param['company_address'] = addslashes($this->input->post('company_address'));
        if ($this->input->post('CurrentDataID') == '') :
          $param['creation_date'] = currentDateTime();
          $param['created_by'] = $this->session->userdata('MHM_OWNER_ID');
          $param['status'] = 'Y';
          $currentDataID = $this->common_model->addData('company_info', $param);
          $Uparam['encrypt_id'] = ashishEncript($currentDataID);
          $Uparam['company_id'] = generateUniqueId($currentDataID);
          $Uwhere['id'] = $currentDataID;
          $this->common_model->editDataByMultipleCondition('company_info', $Uparam, $Uwhere);
          $this->session->set_flashdata('alert_success', lang('addsuccess'));
        else :
          $currentDataID = $this->input->post('CurrentDataID');
          $param['update_date'] = currentDateTime();
          $param['updated_by'] = $this->session->userdata('MHM_OWNER_ID');
          $this->common_model->editData('company_info', $param, 'company_id', $currentDataID);
          $this->session->set_flashdata('alert_success', lang('updatesuccess'));
        endif;
        $query = "SELECT company_gst, company_name, company_address FROM " . getTablePrefix() . "company_info WHERE id = '" . $currentDataID . "' AND hotel_manager_id = '" . $this->input->post('hotel_manager_id') . "'";
        $data['company'] = $this->common_model->getDataByQuery('single', $query);
      endif;
    endif;
    header('Content-Type: application/json');
    echo json_encode($data);
  }
  public function DeleteContent(){
    $contentname = $this->input->post('contentname');
    if ($contentname) :
      $this->load->library("upload_crop_img");
      $return = $this->upload_crop_img->_delete_image(trim($contentname));
      $this->vendor_model->delete_content($contentname);
    endif;
    echo '1';die;
  }
  public function GetDetailsByCompanyName(){
    $companyName = $this->input->post('companyName');
    if ($companyName) :
      $delQuery = "SELECT company_name,company_address FROM " . getTablePrefix() . "company_info WHERE company_gst = '" . $companyName . "' AND hotel_manager_id = '" . $this->session->userdata('MHM_VENDOR_ID') . "'";
      $COMPANYDETAILS = $this->common_model->getDataByQuery('single', $delQuery);
      //return $COMPANYDETAILS;
      echo json_encode($COMPANYDETAILS);
      exit;
    endif;
  }
  function changeStatus(){
    //$idArray  =  $_POST['id'];
    $idArray  =  explode(',',$_POST['id']);
    if(!empty($idArray)): foreach($idArray as $changeStatusId):
    $param['status']        =    'D';
    $this->common_model->editData('customer_summary_book', $param, 'summary_book_id', $changeStatusId);
    endforeach;endif;
    $this->session->set_flashdata('alert_success', lang('deletesuccess'));
    $this->session->unset_userdata('MHM_VENDOR_OWNER_PASSCODE');
    redirect(base_url('owner/guestcheckoutlist/index'));
  }
  public function get_view_data(){
    $html = '';
    if ($this->input->post('viewid')) :
        $viewId = $this->input->post('viewid');
        $viewData = $this->common_model->getDataByParticularField('customer_summary_book', 'summary_book_id', $viewId);
        $roomNumber = $this->common_model->getDataByParticularField('room_number', 'room_id', $viewData['assign_room_number']);
        if ($viewData != "") :
            $kycData = $this->common_model->getArrayDataByParticularField('customer_id_proof', 'customer_id', $viewId);
            $html .= '<table class="table border-none">
                    <tbody>
                    <tr>
                      <td>';
            $html .= '<table class="table border-none">
                    <thead>
                    <tr>
                      <th align="left" colspan="2"><strong>Personal details</strong></th>
                    </tr>
                    </thead>
                    <tbody><tr>
                    <td align="left" width="30%"><strong>Hotel Manager Name</strong></td>
                    <td align="left" width="70%">' . stripslashes($viewData['hotel_manager_name']) . '</td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Customer Name</strong></td>
                    <td align="left" width="70%">' . stripslashes($viewData['customer_name']) . '</td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Customer Mobile Number</strong></td>
                    <td align="left" width="70%">' . stripslashes($viewData['customer_mobile_number']) . '</td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Email</strong></td>
                    <td align="left" width="70%">' . stripslashes($viewData['customer_email']) . '</td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Check-in Date Time</strong></td>
                    <td align="left" width="70%">' . date('d-m-Y H:i:s A', strtotime($viewData['check_in_datetime'])) . '</td>
                  </tr>
                                    <tr>
                    <td align="left" width="30%"><strong>Check-out Date Time</strong></td>';
            if ($viewData['check_out_datetime'] != "") :
                $html .= '<td align="left" width="70%">' . date('d-m-Y H:i:s A', strtotime($viewData['check_out_datetime'])) . '</td>';
            else :
                $html .= '<td align="left" width="70%">N/A</td>';
            endif;
            $html .= '</tr>
                                    <tr>
                    <td align="left" width="30%"><strong>GRC No.</strong></td>
                    <td align="left" width="70%">' . stripslashes($viewData['entry_number']) . '</td>
                  </tr>
                                    <tr>
                    <td align="left" width="30%"><strong>Room Number</strong></td>
                    <td align="left" width="70%">' . stripslashes($roomNumber['room_no']) . '</td>
                  </tr>
                                    <tr>
                    <td align="left" width="30%"><strong>Number Of Person</strong></td>
                    <td align="left" width="70%">' . stripslashes($viewData['number_of_person']) . '</td>
                  </tr>
                                    <tr>
                    <td align="left" width="30%"><strong>Amount</strong></td>
                    <td align="left" width="70%">' . stripslashes($viewData['amount']) . '</td>
                  </tr>
                                    <tr>
                    <td align="left" width="30%"><strong>Address</strong></td>
                    <td align="left" width="70%">' . stripslashes($viewData['address']) . '</td>
                  </tr>
                                        <tr>
                    <td align="left" width="30%"><strong>Booking Mode</strong></td>
                    <td align="left" width="70%">' . stripslashes(ucfirst($viewData['reffer_mode'])) . '</td>
                  </tr>';
            $DIRECT_MODE  = $viewData['direct_mode'] ?? 'N/A';
            $ONLINE_MODE  = $viewData['online_mode'] ?? 'N/A';
            $COMMISSION_AMOUNT  = $viewData['commission_amount'] ?? '0.00';
            $PREPAID_AMOUNT  = $viewData['prepaid_amount'] ?? '0.00';
            if ($viewData['reffer_mode'] == "online") :
                $html  .=  '<tr>
                                      <td align="left" width="30%"><strong>Payment Mode </strong></td>
                                      <td align="left" width="70%">' . ucfirst($ONLINE_MODE) . '</td>
                                    </tr>';
                if ($ONLINE_MODE == "prepaid") :
                    $html  .=  '<tr>
                                                <td align="left" width="30%"><strong>How Much Prepaid?</strong></td>
                                                <td align="left" width="70%">' . $PREPAID_AMOUNT . '</td>
                                            </tr>';
                endif;
            elseif ($viewData['reffer_mode'] == "offline") :
                $html  .=  '<td align="left" width="30%"><strong>Tick Mark on</strong></td>
                                            <td align="left" width="70%">' . ucfirst($DIRECT_MODE) . '</td>
                                          </tr>';
                if ($DIRECT_MODE == "commission") :
                    $html  .=  '<tr>
                                                      <td align="left" width="30%"><strong>How Much Commision?</strong></td>
                                                      <td align="left" width="70%">' . $COMMISSION_AMOUNT . '</td>
                                                  </tr>';
                endif;
            endif;
            $html  .=  '<tr>
                    <td align="left" width="30%"><strong>Remarks</strong></td>
                    <td align="left" width="70%"><textarea cols="80" rows="3">' . stripslashes($viewData['remarks']) . '</textarea></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Status</strong></td>
                    <td align="left" width="70%">' . showStatus($viewData['status']) . '</td>
                  </tr>
                  </tbody>
                    </table></td>
                  </tr>';
            $html .= '<tr>
                      <td>
                    <table class="table border-none">
                    <thead>
                    <tr>
                      <th align="left" colspan="2"><strong>Identity Proof details</strong></th>
                    </tr>
                    </thead>
                    <tbody>';
            if ($kycData != "") : foreach ($kycData as $kData) :
                    $html .= '<tr>
                        <td align="left" width="70%"><img src="' . base_url() . $kData['doc_url'] . '" alt="Identity Proof" width="100"></td>
                                        </tr>';
                endforeach;
            endif;
            $html .= '</tbody>
                    </table></td>
                  </tr>';
            $html .= '</td>
                    </tr></tbody>
                  </table>';
        endif;
    endif;
    echo $html;
    die;
  }
  public function DownloadCheckOutData(){
    $fromDate = $_GET['fromDate'];
    $toDate = $_GET['toDate'];
    $VendorArr = $_GET['VendorArr'];
    $whereCon['where'] = "csb.hotel_manager_id = '" . sessionData('MHM_VENDOR_ID') . "' AND csb.check_out_datetime != 'NULL' AND csb.status ='Y'";
    $shortField = 'csb.check_out_datetime DESC';
    $tblName = 'customer_summary_book as csb';
    $ALLDATA = $this->owner_model->DownloadCheckOutDataOwner($VendorArr,$fromDate,$toDate);
    //echo '<pre>';print_r($ALLDATA);die;
    $fileName = 'CheckOutCustomer.csv';
    $delimiter = ","; 
    $f = fopen('php://memory', 'w'); 
    $fields = ['Name','Phone number','Check in','Check out','Room rent'];
    fputcsv($f, $fields, $delimiter);
    foreach ($ALLDATA as $rows) {
      $row['Name']                = $rows['customer_name'];
      $row['Phone number']        = $rows['customer_mobile_number'];
      $row['Check in']            = date('d-m-Y h:i a',strtotime($rows['check_in_datetime']));
      $row['Check out']           = date('d-m-Y h:i a',strtotime($rows['check_out_datetime']));
      $row['Room rent']           = $rows['amount'];
      fputcsv($f, $row, $delimiter);
      //echo '<pre>';print_r($row);
    }
    fseek($f, 0);
    header('Content-Type: text/csv'); 
    header('Content-Disposition: attachment; filename="' . $fileName . '";'); 
    fpassthru($f); 
    exit();
  }
  public function addopenerbalance(){
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $Hotel_managerArr_List = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $Hotel_managerArr_List = $this->owner_model->GetSubOwnerVendorList();
    }
    if ($this->input->post('SaveChanges')){
      $date = date('Y-m-d',strtotime("-1 days"));
      $total_cash = $_POST['total_cash'] ?? 0;
      $vendor_id = $_POST['vendor_id'];
      if($total_cash>0){
        $totalAmount = $total_cash;
      }
      $kycQuery = "SELECT `in_comming_amount` FROM " . getTablePrefix() . "total_sale WHERE record_date LIKE '%" . $date . "%' AND hotel_manager_id=" . $vendor_id . "";
         
      $checkEntry = $this->common_model->getDataByQuery('single', $kycQuery);
      if(!empty($checkEntry) && !empty($totalAmount) && !empty($vendor_id)){
        $param['hotel_manager_id']        =     $vendor_id;
        $param['record_date']             =     $date;
        $param['total_in']                =     $totalAmount;
        $param['total_out']               =     0;
        $param['in_comming_amount']       =     $totalAmount;
        $param['update_date']   = currentDateTime(); 
        $param['updated_by']    = $this->session->userdata('MHM_VENDOR_ID');
        $param['update_case']    = 1;

        $Uwhere['record_date']            =    $date;
        $Uwhere['hotel_manager_id']       =    $vendor_id;
        $this->common_model->editDataByMultipleCondition('total_sale', $param, $Uwhere);
        //$this->common_model->editData('total_sale', $param, 'record_date', $date);
        $this->session->set_flashdata('alert_success', lang('addsuccess'));
        redirect('owner/guestcheckoutlist');
      }else{ 
        if (!empty($totalAmount) && !empty($vendor_id)){
          $param['hotel_manager_id']        =     $vendor_id;
          $param['record_date']             =     $date;
          $param['total_in']                =     $totalAmount;
          $param['total_out']               =     0;
          $param['in_comming_amount']       =     $totalAmount;
          $param['creation_date']           =    currentDateTime();
          $param['created_by']              =    $this->session->userdata('MHM_VENDOR_ID');
          $param['status']                  =    'Y';
          $param['update_case']             = 1;
          $alastInsertId                    =    $this->common_model->addData('total_sale', $param);
          $Uparam['encrypt_id']             =    ashishEncript($alastInsertId);
          $Uparam['total_sale_id']          =    generateUniqueId($alastInsertId);
          $Uwhere['id']                     =    $alastInsertId;
          $this->common_model->editDataByMultipleCondition('total_sale', $Uparam, $Uwhere);
          $this->session->set_flashdata('alert_success', lang('addsuccess'));
          redirect('owner/guestcheckoutlist');
        }
      }    
    }
    $data['error'] = '';
    $data['activeMenu'] = 'CheckedOut';
    $data['activeSubMenu'] = 'CheckedOut';
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $data['HotelList'] = $this->owner_model->GetSubOwnerVendorList();
    }
    //echo "<pre>"; print_r($Hotel_managerArr_List); exit;    
    //$this->owner_model->GetAllHotelList();
    $this->layouts->set_title('Manage Check Out Data');
    $this->layouts->owner_view('owner/checkout/addopenerbalance', array(), $data);
  }
  public function viewsummarydetails($editId = '')
    {
        //$this->vendorauth_model->authCheck();
        $data['error'] = '';
        $data['activeMenu'] = 'summarybook';
        $data['activeSubMenu'] = 'summarybook';
        
        $data['editId'] = $editId;

        $data['CUSTDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'encrypt_id', $editId);

        $data['checkCheckInOut'] = $data['CUSTDATA']['check_out_datetime'];
        $whereCon['where'] = "csd.customer_id = '" . $data['CUSTDATA']['summary_book_id'] . "'";
        $shortField = 'csd.creation_date asc';
        $tblName = 'customer_summary_details as csd';
        $data['ALLDATA'] = $this->vendor_model->selectCustomerSummaryDetailsData('data', $tblName, $whereCon, $shortField, 0, 0);

        $data['LoginVenderId'] = $data['CUSTDATA']['hotel_manager_id'];
        $Query = "SELECT * FROM ".getTablePrefix()."customer_summary_details WHERE hotel_manager_id='".$data['CUSTDATA']['hotel_manager_id']."' AND customer_id='".$data['CUSTDATA']['summary_book_id']."' AND page_source = 'add_a_service' GROUP BY kot_number order by creation_date desc;";
        $data['FoodData'] = $this->common_model->getDataByQuery('multiple', $Query);
        $data['hotel_manager_id'] = $data['CUSTDATA']['hotel_manager_id']; 
        //echo "<pre>"; print_r($data['ALLDATA']); exit;
        $this->layouts->set_title('View Summary Book Details');
        $this->layouts->owner_view('owner/checkout/viewsummarydetails', array(), $data);
    } // END OF FUNCTION
  

    public function addAnAdvance($custId = '', $editId = '')
    {
        $data['error'] = '';
        $data['activeMenu'] = 'summarybook';
        $data['activeSubMenu'] = 'summarybook';
        $data['custumId'] = $custId;
        $data['CUSTDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'encrypt_id', $custId);
        $hotel_manager_id = $data['CUSTDATA']['hotel_manager_id'];
        
        $data['custId'] = $data['CUSTDATA']['summary_book_id'];
        if ($editId) :
            $this->ownerauth_model->authCheck();
            $delQuery = "SELECT * FROM " . getTablePrefix() . "customer_summary_details
                                                    WHERE encrypt_id = '" . $editId . "'";
            $data['EDITTASKDATA'] = $this->common_model->getDataByQuery('single', $delQuery);
            //echo "<pre>"; print_r($data); exit;
        endif;
        try {

            if ($this->input->post('SaveChanges')) :
                $this->generatelogs->putLog('ADDANADWANCE', logOutPut($_POST));
                $error = 'NO';
                     
                $this->form_validation->set_rules('manager_name', 'manager name', 'trim|required');
                $this->form_validation->set_rules('amount_mode', 'amount    mode', 'trim');
                $this->form_validation->set_rules('payment_paid', 'advance amount', 'trim');

                if ($this->form_validation->run() && $error == 'NO') :
                    $order_date = $this->input->post('order_date') ?? '';
                    $orderDate = !empty($order_date) ? date("Y-m-d H:i:s",strtotime($order_date)) : currentDateTime();
                    $param['hotel_manager_name'] = addslashes($this->input->post('manager_name'));
                    $param['order_date'] = $orderDate;
                    $param['amount_mode'] = addslashes($this->input->post('amount_mode'));
                    $param['advance_paid'] = 0;
                    $param['payment_paid'] = addslashes($this->input->post('payment_paid'));
                    $param['bill_item'] = "Advance Paid";
                    $param['room_rent_status'] = '';
                    $param['hotel_manager_id'] = $hotel_manager_id;
                    $param['customer_id'] = addslashes($this->input->post('CustomerID'));
                    $param['daybook_mode'] = "In";
                    $param['page_source'] = "add_an_advance";

                    if ($this->input->post('CurrentDataID') == '') :
                        $param['creation_date'] = currentDateTime();
                        $param['created_by'] = $this->session->userdata('MHM_ADMIN_ID');
                        $lastInsertId = $this->common_model->addData('customer_summary_details', $param);
                        $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
                        $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
                        $Uwhere['id'] = $lastInsertId;
                        
                        $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
                        $this->session->set_flashdata('alert_success', lang('addsuccess'));
                    else :

                        /*Log Generate*/
                        $SaveLog = [];
                        $SaveLog['Customer Name'] = $data['CUSTDATA']['customer_name'];
                        $SaveLog['Amount Paid'] = addslashes($this->input->post('amount_mode'));
                        $SaveLog['Amount Mode'] = addslashes($this->input->post('payment_paid'));
                        $this->common_model->SaveVendorLog($SaveLog,11);
                        /*Log Generate*/

                        $menuId = $this->input->post('CurrentDataID');
                        $param['updation_date'] = currentDateTime();
                        $param['updated_by'] = $this->session->userdata('MHM_VENDOR_ID');
                        $this->common_model->editData('customer_summary_details', $param, 'detail_book_id', $menuId);
                        $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                    endif;
                    redirect($this->session->userdata('MHM_OWNER_CURRENT_PATH') . $this->router->fetch_class() . '/viewsummarydetails/' . $custId);
                endif;
            endif;

            if($this->input->post('AddNewChanges')){
              $manager_name = addslashes($this->input->post('manager_name'));
              $payment_paid1 = $this->input->post('payment_paid1') ?? '';
              $payment_paid2 = $this->input->post('payment_paid2') ?? '';
              $payment_paid3 = $this->input->post('payment_paid3') ?? '';
              $payment_paid4 = $this->input->post('payment_paid4') ?? '';
              $order_date = $this->input->post('order_date') ?? '';
              $orderDate = !empty($order_date) ? date("Y-m-d H:i:s",strtotime($order_date)) : currentDateTime();
              $param['hotel_manager_name'] = $manager_name;
              $param['order_date'] = $orderDate;
              $param['advance_paid'] = 0;
              $param['bill_item'] = "Advance Paid";
              $param['room_rent_status'] = '';
              $param['hotel_manager_id'] = $hotel_manager_id;
              $param['customer_id'] = addslashes($this->input->post('CustomerID'));
              $param['daybook_mode'] = "In";
              $param['page_source'] = "add_an_advance";
              $param['creation_date'] = currentDateTime();
              $param['created_by'] = $this->session->userdata('MHM_ADMIN_ID');
              
              if($payment_paid1!=''){
                $param['amount_mode'] = addslashes($this->input->post('amount_mode1'));
                $param['payment_paid'] = $payment_paid1;
                $lastInsertId = $this->common_model->addData('customer_summary_details', $param);
                $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
                $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
                $Uwhere['id'] = $lastInsertId;
                $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
              }
              if($payment_paid2!=''){
                $param['amount_mode'] = addslashes($this->input->post('amount_mode2'));
                $param['payment_paid'] = $payment_paid2;
                $lastInsertId = $this->common_model->addData('customer_summary_details', $param);
                $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
                $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
                $Uwhere['id'] = $lastInsertId;
                $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
              }
              if($payment_paid3!=''){
                $param['amount_mode'] = addslashes($this->input->post('amount_mode3'));
                $param['payment_paid'] = $payment_paid3;
                $lastInsertId = $this->common_model->addData('customer_summary_details', $param);
                $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
                $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
                $Uwhere['id'] = $lastInsertId;
                $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
              }
              if($payment_paid4!=''){
                $param['amount_mode'] = addslashes($this->input->post('amount_mode4'));
                $param['payment_paid'] = $payment_paid4;
                $lastInsertId = $this->common_model->addData('customer_summary_details', $param);
                $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
                $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
                $Uwhere['id'] = $lastInsertId;
                $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
              }

            /*Log Generate*/
            $SaveLog = [];
            $SaveLog['Customer Name'] = $data['CUSTDATA']['customer_name'];
            if($payment_paid1!=''){
              $SaveLog['Amount Mode1'] = addslashes($this->input->post('amount_mode1'));
              $SaveLog['Payment Paid1'] = $payment_paid1;
            }
            if($payment_paid2!=''){
              $SaveLog['Amount Mode2'] = addslashes($this->input->post('amount_mode2'));
              $SaveLog['Payment Paid2'] = $payment_paid2;
            }
            if($payment_paid3!=''){
              $SaveLog['Amount Mode3'] = addslashes($this->input->post('amount_mode3'));
              $SaveLog['Payment Paid3'] = $payment_paid3;
            }
            if($payment_paid4!=''){
              $SaveLog['Amount Mode4'] = addslashes($this->input->post('amount_mode4'));
              $SaveLog['Payment Paid4'] = $payment_paid4;
            }
            $this->common_model->SaveVendorLog($SaveLog,2);
            /*Log Generate*/

            $this->session->set_flashdata('alert_success', lang('addsuccess'));
            redirect($this->session->userdata('MHM_OWNER_CURRENT_PATH') . $this->router->fetch_class() .'/viewsummarydetails/'.$custId);
          }
        } catch (\Throwable $th) {
            throw $th;
            $this->generatelogs->putLog('ADDANADWANCE', logOutPut($_POST));
        }
        $this->layouts->set_title('Add An Advance');
        // echo "<pre>"; print_r($data); exit;
        if ($editId){
          $this->layouts->owner_view('owner/checkout/EditAnadvance', array(), $data);
        }else{
          $this->layouts->owner_view('owner/checkout/addanadvance', array(), $data);
        }
    }

    public function addaservice($custId = '', $editId = '')
    {
        $data['error'] = '';
        $data['activeMenu'] = 'summarybook';
        $data['activeSubMenu'] = 'summarybook';
        //$data['custumId'] = $custId;
        $data['CUSTDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'encrypt_id', $custId);

        $data['custId'] = $data['CUSTDATA']['summary_book_id'];
        $hotel_manager_id = $data['CUSTDATA']['hotel_manager_id'];
        if ($editId) :
            $this->ownerauth_model->authCheck();
            $delQuery = "SELECT * FROM " . getTablePrefix() . "customer_summary_details
                                                    WHERE encrypt_id = '" . $editId . "'";
            $data['EDITTASKDATA'] = $this->common_model->getDataByQuery('single', $delQuery);
        endif;
        if ($this->input->post('SaveChanges')) :

            $error = 'NO';
            $this->form_validation->set_rules('manager_name', 'manager name', 'trim|required');
            $this->form_validation->set_rules('TotalFilterDefault', 'lang:TotalDetails', 'trim');
            $totaldetails = $this->input->post('TotalFilterDefault');
            if ($totaldetails) :
                for ($i = 1; $i <= $totaldetails; $i++) :
                    if ($i == 1) :
                        $this->form_validation->set_rules('filter_details_id_' . $i, 'lang:Filter Details', 'trim');
                        $this->form_validation->set_rules('service_id_' . $i, 'lang:service_id_', 'trim|required');
                        $this->form_validation->set_rules('quantity_' . $i, 'lang:advance amount', 'trim|required');
                    else :
                        $this->form_validation->set_rules('filter_details_id_' . $i, 'lang:Filter Details', 'trim');
                        $this->form_validation->set_rules('service_id_' . $i, 'lang:service_id_', 'trim|required');
                        $this->form_validation->set_rules('quantity_' . $i, 'lang:advance amount', 'trim|required');
                    endif;
                    $data['filter_details_id_' . $i] = $this->input->post('filter_details_id_' . $i);
                    $data['service_id_' . $i] = $this->input->post('service_id_' . $i);
                    $data['quantity_'] = $this->input->post('quantity_');
                endfor;
                $data['TotalFilterDefault'] = $this->input->post('TotalFilterDefault');
            endif;
            $SaveLog['Customer Name']   = $data['CUSTDATA']['customer_name'];
            if ($this->form_validation->run() && $error == 'NO') :
                $totaldetails = $this->input->post('TotalFilterDefault');
                for ($i = 1; $i <= $totaldetails; $i++) :
                    $serviceId = $this->input->post('service_id_' . $i);
                    $quantity = addslashes($this->input->post('quantity_' . $i));
                    $data = explode('__', $serviceId);
                    $serviceId = $data['0'];
                    $priceId = $data['1'];
                    $serviceName = $data['2'];
                    $param['hotel_manager_name'] = addslashes($this->input->post('manager_name'));
                    $param['quantity'] = addslashes($this->input->post('quantity_' . $i));
                    $param['order_date'] = currentDateTime();
                    $param['amount_mode'] = "offline";
                    $param['service_id'] = $serviceId;
                    $param['advance_paid'] = $priceId * $quantity;
                    $param['payment_paid'] = 0;
                    $param['bill_item'] = $serviceName . '_' . $quantity;
                    $param['hotel_manager_id'] = $hotel_manager_id;
                    $param['customer_id'] = addslashes($this->input->post('CustomerID'));
                    $param['daybook_mode'] = "In";
                    $param['page_source'] = "add_a_service";
                    $param['creation_date'] = currentDateTime();
                    $param['created_by'] = $this->session->userdata('MHM_ADMIN_ID');
                    $lastInsertId = $this->common_model->addData('customer_summary_details', $param);
                    $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
                    $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
                    $Uwhere['id'] = $lastInsertId;
                    $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);

                    $SaveLog['Service '.$i]   = $serviceName;
                    $SaveLog['Quantity '.$i]  = $quantity;

                endfor;

                /*Log Generate*/                
                $this->common_model->SaveVendorLog($SaveLog,3);
                /*Log Generate*/

                $this->session->set_flashdata('alert_success', lang('addsuccess'));
                // else :
                //     $menuId                    =    $this->input->post('CurrentDataID');
                //     $param['updation_date']        =    currentDateTime();
                //     $param['updated_by']        =    $this->session->userdata('MHM_VENDOR_ID');
                //     $this->common_model->editData('customer_summary_details', $param, 'detail_book_id', $menuId);
                //     $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                // endif;
                redirect($this->session->userdata('MHM_OWNER_CURRENT_PATH') . $this->router->fetch_class() . '/viewsummarydetails/' . $custId);
            endif;
        endif;
        $this->layouts->set_title('Add A Service');
        $this->layouts->owner_view('owner/checkout/addaservice', array(), $data);
    }
    public function addaservices($custId = '', $editId = ''){ 
      $data['error'] = '';
      $data['activeMenu'] = 'summarybook';
      $data['activeSubMenu'] = 'summarybook';
      $data['custumId'] = $custId;
      $data['CUSTDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'encrypt_id', $custId);
      $data['custId'] = $data['CUSTDATA']['summary_book_id'];

      if ($editId) :
          $this->ownerauth_model->authCheck();
          $delQuery = "SELECT * FROM " . getTablePrefix() . "customer_summary_details
                              WHERE encrypt_id = '" . $editId . "'";
          $data['EDITTASKDATA'] = $this->common_model->getDataByQuery('single', $delQuery);
      endif;

      if($this->input->post('SaveChanges')){
        $serviceId = '';
        $param['hotel_manager_name'] = addslashes($this->input->post('manager_name'));
        $param['quantity'] = '';
        $param['order_date'] = currentDateTime();
        $param['amount_mode'] = "offline";
        $param['service_id'] = $serviceId;
        $param['advance_paid'] = $this->input->post('total_amt');
        $param['payment_paid'] = 0;
        $param['bill_item'] = $this->input->post('bill_items');
        $param['hotel_manager_id'] = sessionData('MHM_VENDOR_ID');
        $param['customer_id'] = addslashes($this->input->post('CustomerID'));
        $param['daybook_mode'] = "In";
        $param['page_source'] = "add_a_services";
        $param['creation_date'] = currentDateTime();
        $param['created_by'] = $this->session->userdata('MHM_ADMIN_ID');

        /*Log Generate*/  
        $SaveLog['Customer Name'] = $data['CUSTDATA']['customer_name'];
        $SaveLog['Bill Items'] = $this->input->post('bill_items');
        $SaveLog['Total Amount'] = $this->input->post('total_amt');
        $this->common_model->SaveVendorLog($SaveLog,4);
        /*Log Generate*/

        $CurrentIdForUnique = $this->input->post('CurrentIdForUnique');
        if($CurrentIdForUnique){
          $Uwhere['encrypt_id'] = $CurrentIdForUnique;
          $this->common_model->editDataByMultipleCondition('customer_summary_details', $param, $Uwhere);
        }else{
          $lastInsertId = $this->common_model->addData('customer_summary_details', $param);
          $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
          $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
          $Uwhere['id'] = $lastInsertId;
          $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
        }
        //echo '<pre>';print_r($this->input->post());die;
        redirect($this->session->userdata('MHM_OWNER_CURRENT_PATH') . $this->router->fetch_class() . '/viewsummarydetails/' . $custId);
      }
      $this->layouts->set_title('Add A Service');
      $this->layouts->owner_view('owner/checkout/addaservices', array(), $data);
    }
    /***********************************************************************
     ** Function name : extendStay
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for add An Advance
     ** Date : 31 October 2022
     ************************************************************************/
    public function extendStay($custId = '', $editId = '')
    {

        $data['error'] = '';
        $data['activeMenu'] = 'summarybook';
        $data['activeSubMenu'] = 'summarybook';
        $data['custumId'] = $custId;
        $data['CUSTDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'encrypt_id', $custId);
        $data['custId'] = $data['CUSTDATA']['summary_book_id'];
        $hotel_manager_id = $data['CUSTDATA']['hotel_manager_id'];
        if ($editId) :
            $this->ownerauth_model->authCheck();
            $delQuery = "SELECT * FROM " . getTablePrefix() . "customer_summary_details WHERE encrypt_id = '" . $editId . "'";
            $data['EDITTASKDATA'] = $this->common_model->getDataByQuery('single', $delQuery);
            
        endif;
        $roomRent = $this->vendor_model->getRoomRent($data['custId']);

        if ($this->input->post('SaveChanges')) :
            $error = 'NO';
            $this->form_validation->set_rules('manager_name', 'manager name', 'trim|required');
            if ($this->form_validation->run() && $error == 'NO') :
                if ($this->input->post('CurrentDataID') == '') {
                    $selectedDates = explode(',', $this->input->post('select_date'));
                    foreach ($selectedDates as $dtInfo) :
                        $param['hotel_manager_name'] = addslashes($this->input->post('manager_name'));
                        $param['amount_mode'] = "offline";
                        $param['order_date'] = currentDateTime();
                        $param['advance_paid'] = $roomRent['amount'];
                        $param['payment_paid'] = 0;
                        $param['bill_item'] = "Room Rent (" . date('d/m/Y', strtotime($dtInfo)) . ")";
                        $param['room_rent_status'] = addslashes($this->input->post('room_rent_status'));
                        $param['hotel_manager_id'] = $hotel_manager_id;
                        $param['customer_id'] = addslashes($this->input->post('CustomerID'));
                        $param['daybook_mode'] = "In";
                        $param['page_source'] = "extend_stay";
                        $param['creation_date'] = currentDateTime();
                        $param['created_by'] = $this->session->userdata('MHM_ADMIN_ID');
                        if ($this->input->post('manager_name') != 'System') {
                            $this->session->set_flashdata('alert_success', lang('addsuccess'));
                        }
                        $lastInsertId = $this->common_model->addData('customer_summary_details', $param);
                        $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
                        $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
                        $Uwhere['id'] = $lastInsertId;
                        $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
                    endforeach;
                    if ($this->input->post('manager_name') != 'System') {
                        $this->session->set_flashdata('alert_success', lang('addsuccess'));
                    }
                } else {
                    $param['hotel_manager_name'] = addslashes($this->input->post('manager_name'));
                    $param['order_date'] = currentDateTime();
                    $param['advance_paid'] = addslashes($this->input->post('room_rent'));
                    $menuIdA = $this->input->post('CurrentDataID');
                    $param['updation_date'] = currentDateTime();
                    $param['updated_by'] = $this->session->userdata('MHM_VENDOR_ID');
                    $this->common_model->editData('customer_summary_details', $param, 'detail_book_id', $menuIdA);
                    $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                }
                redirect($this->session->userdata('MHM_OWNER_CURRENT_PATH') . $this->router->fetch_class() . '/viewsummarydetails/' . $custId);
            endif;
        endif;
        $this->layouts->set_title('extend Stay');
        $this->layouts->owner_view('owner/checkout/extendstay', array(), $data);
    }

     public function deleteData($deleteId = '')
    {
        $this->ownerauth_model->authCheck();
      //new code by ashish backup data when deleted recoed we stored in 'customer_summary_details_deleted' this table for 
        // geneating automatic extend stay entry
        $getData = $this->common_model->getDataByParticularField('customer_summary_details', 'detail_book_id', $deleteId);
        $customer_id = $getData['customer_id'];
        $CUSTDATA = $this->common_model->getDataByParticularField('customer_summary_book', 'summary_book_id', $customer_id);
        
        /*Save Log*/
        $SaveLog = [];
        $SaveLog['Customer Name'] = $CUSTDATA['customer_name'];
        $SaveLog['Bill Items'] = $getData['bill_item'];
        $SaveLog['Amount Paid'] = $getData['payment_paid'];
        $SaveLog['Amount Mode'] = $getData['amount_mode'];
        $custId = $CUSTDATA['encrypt_id'];
        $this->common_model->SaveVendorLog($SaveLog,12);
        /*Save Log*/
        
        //echo '<pre>';print_r($getData);die();

        $DLparam['hotel_manager_name'] = $getData['hotel_manager_name'];
        $DLparam['amount_mode'] = "offline";
        $DLparam['order_date'] = $getData['order_date'];
        $DLparam['advance_paid'] = $getData['advance_paid'];
        $DLparam['payment_paid'] = 0;
        $DLparam['bill_item'] = $getData['bill_item'];
        $DLparam['room_rent_status'] = $getData['room_rent_status'];
        $DLparam['hotel_manager_id'] = $getData['hotel_manager_id'];
        $DLparam['customer_id'] = $getData['customer_id'];
        $DLparam['daybook_mode'] = "In";
        $DLparam['page_source'] = "extend_stay";
        $DLparam['creation_date'] = currentDateTime();
        $DLparam['created_by'] = $getData['created_by'];
        $lastInsertId = $this->common_model->addData('customer_summary_details_deleted', $DLparam);
        //end



        $this->common_model->deleteParticularData('customer_summary_details', 'detail_book_id', $deleteId);
        $this->session->set_flashdata('alert_success', lang('deletesuccess'));
        $this->session->set_flashdata('alert_success', lang('addsuccess'));
        redirect($this->session->userdata('MHM_OWNER_CURRENT_PATH') . $this->router->fetch_class() .'/viewsummarydetails/'.$custId);
        //redirect('owner/hotel');
        //$this->layouts->owner_view('owner/guestcheckoutlist/', array(), $data);
        //redirect(correctLink('summaryBookVendorData', $this->session->userdata('MHM_OWNER_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
    }
    public function booking($encrypt_id){

    $Query = "SELECT customer_name,encrypt_id,id,hotel_manager_id FROM ".getTablePrefix()."customer_summary_book WHERE  encrypt_id='".$encrypt_id."' ";
    $data['CustomerData'] = $this->common_model->getDataByQuery('single', $Query);

    $Query = "SELECT id,category_name FROM ".getTablePrefix()."hotel_menu_category WHERE hotel_manager_id='".$data['CustomerData']['hotel_manager_id']."' order by id DESC;";
    $data['CategoryArr'] = $this->common_model->getDataByQuery('multiple', $Query);    
    //echo '<pre>';print_r($data['CustomerData']);die();
    $data['error'] = '';
    $data['activeMenu'] = 'Dashboard';
    $data['activeSubMenu'] = 'Dashboard';
    $data['encrypt_id'] = $encrypt_id;
    $this->layouts->set_title('Dashboard');
    $this->layouts->owner_view('owner/checkout/food/index', array(), $data);
  }
  public function FoodMenuList(){
    $category_id         = $_GET['menu_id'] ?? 0;
    $menu_name           = $_GET['menu_name'] ?? '';
    $hotel_manager_id    = $_GET['hotel_manager_id'] ?? '';

    if($category_id>0){
      $Query = "SELECT id,menu_name,price FROM ".getTablePrefix()."hotel_menu WHERE category_id='".$category_id."' AND hotel_manager_id='".$hotel_manager_id."' order by id DESC;";
    }else{
      $Query = "SELECT id,menu_name,price FROM ".getTablePrefix()."hotel_menu WHERE  (menu_name LIKE '%" . $menu_name . "%') AND hotel_manager_id='".$hotel_manager_id."' order by id DESC;";
    }

    $data['MenuArr'] = $this->common_model->getDataByQuery('multiple', $Query);
    $this->load->view('owner/checkout/food/menu', $data);
  }
  public function FoodUpdateAddToCart(){
    $qty = $_POST['qty'];
    $id = $_POST['id'];
    $Save['qty']      = $qty;
    $this->common_model->editData('hotel_menu_cart', $Save, 'id', $id);
  }
  public function SaveKOT(){
    //$hotel_manager_id = sessionData('MHM_VENDOR_ID');
    
    $customer_id = base64_decode($_GET['customer_id']);
    $settle_type = $_GET['settle_type'];
    $TotalAmount = $_GET['TotalAmount'];
    $GrandAmount = $_GET['GrandAmount'];
    $hotel_manager_id = $_GET['hotel_manager_id'];
    $gst_type = $_GET['gst_type'];
    
    if($settle_type=='Settle_on_the_spot'){
      $cash = $_GET['amount_mode1'];
      $cash_paid = $_GET['payment_paid1'];
      $online = $_GET['amount_mode2'];
      $online_paid = $_GET['payment_paid2'];
      $discount = $_GET['discount'];
    }

    $Query = "SELECT cart.*,menu.menu_name,menu.price FROM ".getTablePrefix()."hotel_menu_cart as cart join ".getTablePrefix()."hotel_menu as menu on menu.id=cart.menu_id WHERE cart.customer_id='".$customer_id."' AND cart.hotel_manager_id='".$hotel_manager_id."' order by cart.id DESC;";
    $MenuArr = $this->common_model->getDataByQuery('multiple', $Query);

    $CustomerQuery = "SELECT summary_book_id,encrypt_id,hotel_manager_name,customer_name FROM ".getTablePrefix()."customer_summary_book WHERE hotel_manager_id='".$hotel_manager_id."' AND id='".$customer_id."' ";
    $CustomerData = $this->common_model->getDataByQuery('single', $CustomerQuery);

    $KOTNumber = $this->common_model->getDataByParticularField('restaurant','hotel_manager_id', $hotel_manager_id);
    $kot_number = $KOTNumber['kot_number'] + 1;
    
    foreach ($MenuArr as $row) {

      $advance_paid = $row['price'] * $row['qty'];
      if($gst_type=='gst_exclusive'){
        $GSTAmt   = round($advance_paid * 5) / 100;
        $advance_paid = $advance_paid + $GSTAmt;
      }

      $param['hotel_manager_name'] = $CustomerData['hotel_manager_name'];
      $param['quantity'] = $row['qty'];
      $param['order_date'] = currentDateTime();
      $param['amount_mode'] = "offline";
      $param['service_id'] = $row['menu_id'];
      $param['advance_paid'] = $advance_paid;
      $param['menu_price'] = $row['price'] * $row['qty'];
      $param['gst_type'] = $gst_type; 

      $param['settle_type'] = $settle_type;
      $param['total_amt'] = $TotalAmount;
      if($settle_type=='Settle_on_the_spot'){
        $param['cash'] = $cash;
        $param['cash_paid'] = $cash_paid;  
        $param['online'] = $online;
        $param['online_paid'] = $online_paid;
        $param['discount'] = $discount;
      } 

      $param['payment_paid'] = 0;
      $param['bill_item'] = $row['menu_name'];
      $param['kot_number'] = KOTPrefix.'/'.$kot_number;
      $param['user_type'] = 'Restaurant';
      $param['hotel_manager_id'] = $hotel_manager_id;
      $param['customer_id'] = $CustomerData['summary_book_id'];
      $param['daybook_mode'] = "In";
      $param['page_source'] = "add_a_service";
      $param['creation_date'] = currentDateTime();
      $param['created_by'] = $this->session->userdata('MHM_OWNER_ID');
      $lastInsertId = $this->common_model->addData('customer_summary_details', $param);

      $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
      $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
      $Uwhere['id'] = $lastInsertId;
      $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
      //echo '<pre>';print_r($param);
    }
    //die();
    $this->common_model->deleteData('hotel_menu_cart', 'customer_id', $customer_id);

    $vparam['kot_number'] = $kot_number;
    $this->common_model->editData('restaurant', $vparam, 'hotel_manager_id',$hotel_manager_id);

    $this->session->set_flashdata('alert_success', lang('statussuccess'));
    //redirect('restaurant/food/service/'.$CustomerData['encrypt_id']);
    redirect($this->session->userdata('MHM_OWNER_CURRENT_PATH') . 'guestcheckoutlist/viewsummarydetails/'.$CustomerData['encrypt_id']);
  }

  public function UpdateKOT(){
   
    $kot_number = base64_decode($_GET['kot_number']);
    $settle_type = $_GET['settle_type'];
    $TotalAmount = $_GET['TotalAmount'];
    $GrandAmount = $_GET['GrandAmount'];
    $hotel_manager_id = $_GET['hotel_manager_id'];
    $gst_type = $_GET['gst_type'];

    if($settle_type=='Settle_on_the_spot'){
      $cash = $_GET['amount_mode1'];
      $cash_paid = $_GET['payment_paid1'];
      $online = $_GET['amount_mode2'];
      $online_paid = $_GET['payment_paid2'];
      $discount = $_GET['discount'];
    }

    $Query = "SELECT details.*,menu.price FROM ".getTablePrefix()."customer_summary_details as details join ".getTablePrefix()."hotel_menu as menu on menu.id=details.service_id WHERE details.kot_number='".$kot_number."' order by details.id DESC;";
    $ResultArr = $this->common_model->getDataByQuery('multiple', $Query);

    $CustomerQuery = "SELECT encrypt_id FROM ".getTablePrefix()."customer_summary_book WHERE summary_book_id='".$ResultArr[0]['customer_id']."' ";
    $CustomerData = $this->common_model->getDataByQuery('single', $CustomerQuery);
    
    foreach ($ResultArr as $row) {

      $advance_paid = $row['price'] * $row['quantity'];
      if($gst_type=='gst_exclusive'){
        $GSTAmt   = round($advance_paid * 5) / 100;
        $advance_paid = $advance_paid + $GSTAmt;
      }  

      $param['advance_paid'] = $advance_paid;
      $param['menu_price'] = $row['price'] * $row['quantity'];
      $param['gst_type'] = $gst_type;
      $param['total_amt'] = $TotalAmount;

      $param['settle_type'] = $settle_type;
      if($settle_type=='Settle_on_the_spot'){
        $param['cash'] = $cash;
        $param['cash_paid'] = $cash_paid;  
        $param['online'] = $online;
        $param['online_paid'] = $online_paid;
        $param['discount'] = $discount;
      }
      $Uwhere['id'] = $row['id'];
      //echo "<pre>"; print_r($param); exit;
      $this->common_model->editDataByMultipleCondition('customer_summary_details', $param, $Uwhere);
    }
    $this->session->set_flashdata('alert_success', lang('statussuccess'));
    redirect($this->session->userdata('MHM_OWNER_CURRENT_PATH') . 'guestcheckoutlist/viewsummarydetails/'.$CustomerData['encrypt_id']);
  }

  public function AddToCardMenu(){
    //$hotel_manager_id = sessionData('MHM_VENDOR_ID');
    $customer_id      = $_GET['customer_id'] ?? 0;
    $menu_id          = $_GET['menu_id'] ?? 0;
    $qty              = $_GET['qty'] ?? 1;
    $hotel_manager_id              = $_GET['hotel_manager_id'] ?? 1;

    $Save['hotel_manager_id'] = $hotel_manager_id;
    $Save['customer_id'] = $customer_id;
    $Save['table_id'] = 0;
    //$Save['kot_no']   = 5;
    $Save['menu_id']  = $menu_id;
    $Save['qty']      = $qty;
    $Save['add_date'] = date('Y-m-d H:i:s');

    $sql = "SELECT id,qty FROM ".getTablePrefix()."hotel_menu_cart WHERE hotel_manager_id='".$hotel_manager_id."' AND menu_id='".$menu_id."' AND customer_id='".$customer_id."' ";
    $result = $this->common_model->getDataByQuery('single', $sql);
    if($result){
      $Save['qty']      = $qty+$result['qty'];
      $this->common_model->editData('hotel_menu_cart', $Save, 'id', $result['id']);
    }else{
      $Save['qty']      = $qty;
      $this->common_model->addData('hotel_menu_cart', $Save);
    }
  }
  public function FoodMenuCart(){
    $customer_id      = $_GET['customer_id'] ?? 0;
    $hotel_manager_id      = $_GET['hotel_manager_id'] ?? 0;
    $Query = "SELECT cart.*,menu.menu_name,menu.price FROM ".getTablePrefix()."hotel_menu_cart as cart join ".getTablePrefix()."hotel_menu as menu on menu.id=cart.menu_id WHERE cart.customer_id='".$customer_id."' AND cart.hotel_manager_id='".$hotel_manager_id."' order by cart.id DESC";
    $data['MenuArr'] = $this->common_model->getDataByQuery('multiple', $Query);
    $data['customer_id'] = $customer_id;
    $data['SaveKOT'] = $this->session->userdata('MHM_OWNER_CURRENT_PATH') . 'guestcheckoutlist/SaveKOT/'.base64_encode($customer_id);
    $this->load->view('owner/checkout/food/Cart', $data);
  }

  public function DeleteKOT($kot_number,$encrypt_id){
    $kot_number = base64_decode($kot_number);
    $this->common_model->deleteData('customer_summary_details', 'kot_number', $kot_number);
    $this->session->set_flashdata('alert_success', 'Delete Successfully');
    redirect($this->session->userdata('MHM_OWNER_CURRENT_PATH') . 'guestcheckoutlist/viewsummarydetails/'.$encrypt_id);
  }

  public function PrintKOT(){
    $kot_number = base64_decode($_GET['kot_number']);
    $print_type = $_GET['print_type'];
    $gst_type   = $_GET['gst_type'];
    $hotel_manager_id   = base64_decode($_GET['hotel_manager_id']);
    $Query = "SELECT * FROM ".getTablePrefix()."customer_summary_details WHERE hotel_manager_id='".$hotel_manager_id."' AND kot_number='".$kot_number."' order by creation_date ASC;";
    $data['FoodData'] = $this->common_model->getDataByQuery('multiple', $Query);
    $data['VENDORDATA'] = $this->common_model->getDataByParticularField('vendor', 'vendor_id', $hotel_manager_id);
    $data['VENDORDETAIL'] = $this->common_model->getDataByParticularField('vendor_details', 'vendor_id', $hotel_manager_id);
    $data['CUSTDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'summary_book_id', $data['FoodData'][0]['customer_id']);
    $data['Restaurant'] = $this->common_model->getDataByParticularField('restaurant', 'hotel_manager_id', $hotel_manager_id);
    $data['gst_type'] = $gst_type;
    $data['print_type'] = $print_type;
    $data['kot_number'] = $kot_number;
    
    $this->load->view('owner/checkout/food/PrintKOT', $data);
  }
  public function viewkot($kot_number,$hotel_manager_id){
    error_reporting(E_ALL ^ E_NOTICE);
    $kot_number = base64_decode($kot_number);
    $hotel_manager_id = base64_decode($hotel_manager_id); 
    $Query = "SELECT * FROM ".getTablePrefix()."customer_summary_details WHERE hotel_manager_id='".$hotel_manager_id."' AND kot_number='".$kot_number."' order by creation_date ASC;";
    $data['FoodData'] = $this->common_model->getDataByQuery('multiple', $Query);
    
    $data['error'] = '';
    $data['activeMenu'] = 'dashboard';
    $data['activeSubMenu'] = 'dashboard';
    $data['kot_number'] = $kot_number;
    $data['hotel_manager_id'] = base64_encode($hotel_manager_id);
    $this->layouts->set_title('View Kot');
    $this->layouts->owner_view('owner/checkout/food/view', array(), $data);
  }
  function deletehard(){
    //$idArray  =  $_POST['id'];
    $idArray  =  explode(',',$_POST['id']);
   
    if(!empty($idArray)): foreach($idArray as $changeStatusId):
      $this->common_model->deleteParticularData('customer_summary_book','summary_book_id',$changeStatusId);
      $this->common_model->deleteParticularData('customer_summary_details','customer_id',$changeStatusId);
    //$param['status']        =    'D';
    //$this->common_model->editData('customer_summary_book', $param, 'summary_book_id', $changeStatusId);
    endforeach;endif;
    $this->session->set_flashdata('alert_success', lang('deletesuccess'));
    $this->session->unset_userdata('MHM_VENDOR_OWNER_PASSCODE');
    redirect(base_url('owner/guestcheckoutlist/index'));
  }

  public function hard(){
    $data['error'] = '';
    $data['activeMenu'] = 'CheckedOut';
    $data['activeSubMenu'] = 'CheckedOut';
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $data['HotelList'] = $this->owner_model->GetSubOwnerVendorList();
    }
    //$this->owner_model->GetAllHotelList();
    $this->layouts->set_title('Manage Check Out Data');
    $this->layouts->owner_view('owner/checkout/hard', array(), $data);
  }
}