<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Dashboard extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->ownerauth_model->authCheck();
  }

  public function index(){

    $dates = date('Y-m-d',strtotime("-30 days"));
    $Query = "SELECT id FROM ".getTablePrefix()."log WHERE add_date < '".$dates."' order by add_date ASC";
    $date= $this->common_model->getDataByQuery('multiple', $Query);
    if(!empty($date)){
        $delId = array_column($date, 'id');
        $this->db->where_in('id', $delId);
         $this->db->delete('log');
    }
    $date = date('Y-m-d');
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $Hotel_managerArr = $this->owner_model->GetAllHotelList();
        $Hotel_managerArr_List = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $Hotel_managerArr = $this->owner_model->GetAllSubOwnerList();
        $Hotel_managerArr_List = $this->owner_model->GetSubOwnerVendorList();
    }
    
    
    // $hotel_manager_id = implode(',', $Hotel_managerArr);

    
    // if(!empty($this->session->userdata('MHM_IS_OWNER'))){
    //     $tblName = 'vendor as ven';
    //     $whereCon['where'] =   "";
    //     $shortField =   'ven.vendor_id DESC';
    //     $grField  =   'ven.vendor_id';
    //     $ALLHotel = $this->owner_model->selectSelletData('data', $tblName, $whereCon, $shortField, 100, 0,$grField);
    //     $allHotel = array_column($ALLHotel, 'vendor_business_name', 'vendor_id');
    // }
    // else{
    //     $tblName = 'sub_owner as so';
    //     $whereCon['where'] =   "";
    //     $shortField =   'so.vendor_id DESC';
    //     $grField  =   'so.vendor_id';
    //     $ALLHotel = $this->owner_model->selectSelletOwnerData('data', $tblName, $whereCon, $shortField, 100, 0,$grField);
    //     $allHotel = array_column($ALLHotel, 'vendor_business_name', 'vendor_id');
    // }
    
    
    //$data['ALLHotel'] = $allHotel;
    //$vendorList = array_keys($allHotel);
    //$vendorListId = implode(',', $vendorList);
    //if(!empty($this->session->userdata('MHM_IS_OWNER'))){
    //     $mainHotelList = $this->common_model->getDataByParticularField('vendor', 'vendor_id', sessionData('MHM_OWNER_ID'));
    //     $mailHotels['vendor_business_name'] = $mainHotelList['vendor_business_name'];
    //     $mailHotels['vendor_id'] = $mainHotelList['vendor_id'];
    //     $data['MainHotel'] = $mailHotels;
    //     $totalChkOWN = "SELECT sum(`checkin_count`) as checkinCount FROM ".getTablePrefix()."vendors_checkin_count WHERE hotel_manager_id = '".$mainHotelList['vendor_id']."' ";
    //     $totalCheckinOwn = $this->common_model->getDataByQuery('single', $totalChkOWN);

    //     $totalChkOutOWN = "SELECT sum(`checkin_count`) as checkOutCount FROM ".getTablePrefix()."vendor_checkout_count WHERE hotel_manager_id = '".$mainHotelList['vendor_id']."' ";
    //     $totalCheckOutOwn = $this->common_model->getDataByQuery('single', $totalChkOutOWN);

    //     $totalSaleOwn = "SELECT sum(`totalAmount`) as totalAmount FROM ".getTablePrefix()."vendor_today_total_sales WHERE hotel_manager_id = '".$mainHotelList['vendor_id']."' ";
    //     $totalSalesOwn = $this->common_model->getDataByQuery('single', $totalSaleOwn);

    //     $ExpensesArrOwn = "SELECT sum(`totalAmount`) as totalAmount FROM ".getTablePrefix()."vendor_today_expense_sales WHERE hotel_manager_id  = '".$mainHotelList['vendor_id']."' ";
    //     $TotalExpensesOwn = $this->common_model->getDataByQuery('single', $ExpensesArrOwn);

    //     $data['totalChkOutOWN'] = !empty($totalCheckOutOwn) ? $totalCheckOutOwn: 0;
    //     $data['totalCheckinOwn'] = !empty($totalCheckinOwn) ? $totalCheckinOwn: 0;
    //     $data['totalSalesOwn'] = !empty($totalSalesOwn) ? $totalSalesOwn: 0;
    //     $data['TotalExpensesOwn'] = !empty($TotalExpensesOwn) ? $TotalExpensesOwn: 0;
     
    
    // $totalSale = "SELECT sum(`totalAmount`) as totalAmount FROM ".getTablePrefix()."vendor_today_total_sales WHERE hotel_manager_id IN (".$hotel_manager_id.") ";
    // $totalSales = $this->common_model->getDataByQuery('single', $totalSale);

    // $data['TotalSale'] = !empty($totalSales['totalAmount']) ? $totalSales['totalAmount']: 0;
    
    // $ExpensesArr = "SELECT sum(`totalAmount`) as totalAmount FROM ".getTablePrefix()."vendor_today_expense_sales WHERE hotel_manager_id IN (".$hotel_manager_id.") ";
    // $TotalExpenses = $this->common_model->getDataByQuery('single', $ExpensesArr);
    
    // $data['TotalExpenses'] = !empty($TotalExpenses['totalAmount']) ? $TotalExpenses['totalAmount']: 0;
    // /*Total Expenses*/

    // $totalChk = "SELECT sum(`checkin_count`) as checkinCount FROM ".getTablePrefix()."vendors_checkin_count WHERE hotel_manager_id IN (".$hotel_manager_id.") ";
    // $totalCheckin = $this->common_model->getDataByQuery('single', $totalChk);

    // $totalChkOut = "SELECT sum(`checkin_count`) as checkOutCount FROM ".getTablePrefix()."vendor_checkout_count WHERE hotel_manager_id IN (".$hotel_manager_id.") ";
    // $totalCheckOut = $this->common_model->getDataByQuery('single', $totalChkOut);
    //Vendor Code
    // if(!empty($vendorListId)){
    //     $totalChkVendor = "SELECT * FROM ".getTablePrefix()."vendors_checkin_count WHERE hotel_manager_id IN (".$vendorListId.") ";
    //     $totalCheckinVendor = $this->common_model->getDataByQuery('multiple', $totalChkVendor);
    //     $totalCheckinVendor = array_column($totalCheckinVendor, 'checkin_count', 'hotel_manager_id');

    //     $totalChkOutVendor = "SELECT * FROM ".getTablePrefix()."vendor_checkout_count WHERE hotel_manager_id IN (".$vendorListId.") ";
    //     $totalCheckOutVendor = $this->common_model->getDataByQuery('multiple', $totalChkOutVendor);
    //     $totalCheckOutVendor = array_column($totalCheckOutVendor, 'checkin_count', 'hotel_manager_id');

    //     $ExpensesArrVen = "SELECT * FROM ".getTablePrefix()."vendor_today_expense_sales WHERE hotel_manager_id IN (".$vendorListId.") ";
    //     $TotalExpensesVendor = $this->common_model->getDataByQuery('multiple', $ExpensesArrVen);
    //     $TotalExpensesVendor = array_column($TotalExpensesVendor, 'totalAmount', 'hotel_manager_id');

    //     $totalSaleVen = "SELECT * FROM ".getTablePrefix()."vendor_today_total_sales WHERE hotel_manager_id IN (".$vendorListId.") ";
    //     $totalSalesVendor= $this->common_model->getDataByQuery('multiple', $totalSaleVen);
    //     $totalSalesVendor = array_column($totalSalesVendor, 'totalAmount', 'hotel_manager_id');
    // }

    // $data['TotalCheckIn'] = !empty($totalCheckin['checkinCount']) ? $totalCheckin['checkinCount']: 0;
    // $data['TotalCheckOut'] = !empty($totalCheckOut['checkOutCount']) ? $totalCheckOut['checkOutCount']: 0;
    // $data['totalCheckinVendor'] = !empty($totalCheckinVendor) ? $totalCheckinVendor: 0;
    // $data['totalCheckOutVendor'] = !empty($totalCheckOutVendor) ? $totalCheckOutVendor: 0;
    // $data['TotalExpensesVendor'] = !empty($TotalExpensesVendor) ? $TotalExpensesVendor: 0;
    // $data['totalSalesVendor'] = !empty($totalSalesVendor) ? $totalSalesVendor: 0;
   
    $i = 0;
    //Continued
    $Date = date("Y-m-d");
    $dateFormate = "Room Rent (".date("d/m/Y",strtotime($Date)).')';
    $details = array();
    
    $data['TotalValidCheckout'] = count($details);
    //echo "<pre>"; print_r($Hotel_managerArr_List); exit;
    $data['error'] = '';
    $data['hotel_list'] = $Hotel_managerArr_List;
    $data['activeMenu'] = 'dashboard';
    $data['activeSubMenu'] = 'dashboard';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $this->layouts->set_title('Dashboard');
    $this->layouts->owner_view('owner/dashboard', array(), $data);
  }
  public function editprofile($editId){
    $data['error'] = '';
    $data['activeMenu'] = '';
    $data['activeSubMenu'] = '';
    $data['EDITDATA'] = $this->common_model->getDataByParticularField('vendor', 'vendor_id', $editId);
    if ($data['EDITDATA'] == ''):
        redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . 'dashboard');
    endif;
    $kycQuery = "SELECT * FROM " . getTablePrefix() . "vendor_details
               WHERE vendor_id = '" . $editId . "'";
    $data['KYCDATA'] = $this->common_model->getDataByQuery('single', $kycQuery);
    if ($this->input->post('SaveChanges')):
        $error = 'NO';
        $this->form_validation->set_rules('vendor_business_name', 'Business name', 'trim|required');
        $this->form_validation->set_rules('vendor_title', 'Title', 'trim|required');
        $this->form_validation->set_rules('vendor_name', 'Name', 'trim|required');
        $this->form_validation->set_rules('vendor_email', 'E-Mail', 'trim|required');
        $this->form_validation->set_rules('admin_mobile_number', 'Phone', 'trim|required|min_length[10]|max_length[15]');
        $adminmobile = str_replace(' ', '', $this->input->post('admin_mobile_number'));
        if ($this->input->post('admin_mobile_number') && !preg_match('/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i', $adminmobile)):
            if (!preg_match("/^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1})?([0-9]{10})$/", $adminmobile)):
                $error = 'YES';
                $data['mobileerror'] = 'Please Eneter Correct Number.';
            endif;
        endif;
        $this->form_validation->set_rules('owner_secoundry_contact_number', 'Phone', 'trim|min_length[10]|max_length[15]');
        /*$ownerSecndmobile        =    str_replace(' ', '', $this->input->post('owner_secoundry_contact_number'));
        if ($this->input->post('owner_secoundry_contact_number') && !preg_match('/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i', $ownerSecndmobile)) :
        if (!preg_match("/^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1})?([0-9]{10})$/", $ownerSecndmobile)) :
        $error                        =    'YES';
        $data['owner_secoundry_contact_number']         =     'Please Eneter Correct Number.';
        endif;
        endif;*/
        $this->form_validation->set_rules('manager_contact_number_first', 'Phone', 'trim|required|min_length[10]|max_length[15]');
        /*$mngrmobile        =    str_replace(' ', '', $this->input->post('manager_contact_number_first'));
        if ($this->input->post('manager_contact_number_first') && !preg_match('/^(\d[\s-]?)?[\(\[\s-]{0,2}?\d{3}[\)\]\s-]{0,2}?\d{3}[\s-]?\d{4}$/i', $mngrmobile)) :
        if (!preg_match("/^((\+){0,1}91(\s){0,1}(\-){0,1}(\s){0,1})?([0-9]{10})$/", $mngrmobile)) :
        $error                        =    'YES';
        $data['manager_contact_number_first']         =     'Please Eneter Correct Number.';
        endif;
        endif;*/
        $this->form_validation->set_rules('manager_contact_number_secound', 'Phone', 'trim|min_length[10]|max_length[15]');
        $this->form_validation->set_rules('vendor_image', 'Image', 'trim');
        $this->form_validation->set_rules('vendor_address', 'Address', 'trim|required');
        $this->form_validation->set_rules('gst_number', 'Gst Number', 'trim');
        if ($this->form_validation->run() && $error == 'NO'):
            $param['vendor_title'] = addslashes($this->input->post('vendor_title'));
            $param['vendor_name'] = addslashes($this->input->post('vendor_name'));
            $param['vendor_business_name'] = addslashes($this->input->post('vendor_business_name'));
            $param['vendor_email'] = addslashes($this->input->post('vendor_email'));
            $param['vendor_phone'] = addslashes($this->input->post('admin_mobile_number'));
            $param['owner_secoundry_contact_number'] = addslashes($this->input->post('owner_secoundry_contact_number'));
            $param['first_manager_contact_number'] = addslashes($this->input->post('manager_contact_number_first'));
            $param['secound_manager_contact_number'] = addslashes($this->input->post('manager_contact_number_secound'));
            $param['vendor_image'] = addslashes($this->input->post('vendor_image'));
            $SDparam['vendor_address'] = addslashes($this->input->post('vendor_address'));
            //$SDparam['vendor_city']                            =     addslashes($this->input->post('vendor_city'));
            //$SDparam['vendor_pincode']                        =     addslashes($this->input->post('vendor_pincode'));
            $SDparam['you_are'] = addslashes($this->input->post('you_are')); //entry_number
            $SDparam['bill_number'] = addslashes($this->input->post('bill_number'));
            $SDparam['entry_number'] = addslashes($this->input->post('entry_number'));
            $SDparam['vendor_gst'] = addslashes($this->input->post('gst_number'));
            $SDparam['website_url'] = addslashes($this->input->post('website'));
            $SDparam['managed_by'] = addslashes($this->input->post('managed_by'));
            $SDparam['other_details'] = addslashes($this->input->post('other_details'));
            $vendorId = $this->input->post('CurrentDataID');
            $param['update_date'] = currentDateTime();
            $this->common_model->editData('vendor', $param, 'vendor_id', $vendorId);
            if ($vendorId):
                $SDparam['update_date'] = currentDateTime();
                $this->common_model->editData('vendor_details', $SDparam, 'vendor_id', $vendorId);
            endif;
            $result = $this->vendorauth_model->Authenticate($param['vendor_phone']);
            if ($result):
                $vendorCurrentPath = base_url() . 'vendor/' . $result['vendor_slug'] . '/';
                $this->session->set_userdata(array(
                    'MHM_VENDOR_LOGGED_IN' => true,
                    'MHM_VENDOR_ID' => $result['vendor_id'],
                    'MHM_VENDOR_SLUG' => $result['vendor_slug'],
                    'MHM_VENDOR_TITLE' => $result['vendor_title'],
                    'MHM_VENDOR_NAME' => $result['vendor_name'],
                    'MHM_VENDOR_BUSINESS_NAME' => $result['vendor_business_name'],
                    'MHM_VENDOR_PHONE' => $result['vendor_phone'],
                    'MHM_VENDOR_OWNER_PHONE_SECOUNDRY' => $result['owner_secoundry_contact_number'],
                    'MHM_VENDOR_MANAGER_PHONE_FIRST' => $result['manager_contact_number_first'],
                    'MHM_VENDOR_MANAGER_PHONE_SECOUND' => $result['manager_contact_number_secound'],
                    'MHM_VENDOR_EMAIL' => $result['vendor_email'],
                    'MHM_VENDOR_IMAGE' => $result['vendor_image'],
                    'MHM_VENDOR_CURRENT_PATH' => $vendorCurrentPath,
                    'MHM_VENDOR_ADDRESS' => $result['vendor_address'],
                    'MHM_VENDOR_NATIONALITY' => $result['vendor_nationality'],
                    'MHM_VENDOR_PAN' => $result['vendor_pan'],
                    'MHM_VENDOR_ADDRESS_PROOF' => $result['vendor_address_proof'],
                    'MHM_VENDOR_PINCODE' => $result['vendor_pincode'],
                    'MHM_VENDOR_KYC_STATUS' => $result['vendor_kyc_status'],
                    'MHM_VENDOR_LAST_LOGIN' => $result['vendor_last_login'] . ' (' . $result['vendor_last_login_ip'] . ')',
                ));
                setcookie('MHM_VENDOR_LOGIN_EMAIL', $result['vendor_email'], time() + 60 * 60 * 24 * 100, '/');
            endif;
            $this->session->set_flashdata('alert_success', lang('updatesuccess'));
            redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . 'profile');
        endif;
    endif;
    $this->layouts->set_title('Edit Profile');
    $this->layouts->vendor_view('vendor/editprofile', array(), $data);
  }
  public function MangerLogin($vendor_id){
    $this->db->select('ven.*, vende.vendor_address, vende.vendor_nationality,
               vende.vendor_pan, vende.vendor_address_proof, vende.vendor_pincode,
               vende.vendor_kyc_status,vende.bill_number,manager.manager_name,manager.manager_password,manager.id as manager_id');
    $this->db->from('manager as manager');
    $this->db->join("vendor as ven", "ven.vendor_id=manager.vendor_id");
    $this->db->join("vendor_details as vende", "ven.vendor_id=vende.vendor_id", "LEFT");
    $this->db->where('manager.vendor_id', $vendor_id);
    $this->db->where("ven.vendor_type = 'Verified'");
    $this->db->where("manager.status = 'A'");
    $query  = $this->db->get();
    $result = $query->row_array();
    if($result['status'] == 'I'){
         $vendorCurrentPath = base_url() . 'vendor/login/logout';
         redirect($vendorCurrentPath);
    }
    else{
        $vendorCurrentPath = base_url() . 'vendor/' . $result['vendor_slug'] . '/';
        $this->session->set_userdata(array(
            'MHM_VENDOR_LOGGED_IN' => true,
            'MHM_VENDOR_MANAGER_NAME' => $result['manager_name'],
            'MHM_VENDOR_MANAGER_ID' => $result['manager_id'],
            'MHM_VENDOR_ID' => $result['vendor_id'],
            'MHM_VENDOR_SLUG' => $result['vendor_slug'],
            'MHM_VENDOR_TITLE' => $result['vendor_title'],
            'MHM_VENDOR_NAME' => $result['vendor_name'],
            'MHM_VENDOR_BUSINESS_NAME' => $result['vendor_business_name'],
            'MHM_VENDOR_PHONE' => $result['vendor_phone'],
            'MHM_VENDOR_EMAIL' => $result['vendor_email'],
            'MHM_VENDOR_IMAGE' => $result['vendor_image'],
            'MHM_VENDOR_CURRENT_PATH' => $vendorCurrentPath,
            'MHM_VENDOR_ADDRESS' => $result['vendor_address'],
            'MHM_VENDOR_NATIONALITY' => $result['vendor_nationality'],
            'MHM_VENDOR_PAN' => $result['vendor_pan'],
            'MHM_VENDOR_ADDRESS_PROOF' => $result['vendor_address_proof'],
            'MHM_VENDOR_PINCODE' => $result['vendor_pincode'],
            'MHM_VENDOR_KYC_STATUS' => $result['vendor_kyc_status'],
            'MHM_VENDOR_LAST_LOGIN' => $result['vendor_last_login'] . ' (' . $result['vendor_last_login_ip'] . ')',
        ));
        redirect($vendorCurrentPath . 'dashboard');
    }    
  }
  public function get_ajax_data(){
    $date = date('Y-m-d');
    $id = isset($_POST['id']) && !empty($_POST['id']) ?  $_POST['id'] :'';
    $Hotel_managerArr = $this->owner_model->GetAllHotelList();
    if(!empty($id)){
        $data['LoginVenderId'] = $id;
        $data['id'] = $id;
        $hotel_manager_id = $id;
    }
    else{
        $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
         $hotel_manager_id = implode(',', $Hotel_managerArr);
    }
   // ====== New Boxes Start Here---
    // Total Amount Pending--
    $totalAmount = 0;
    $AmountPaid = 0;
    $totalDueAmount = 0;
    if(!empty($id)){

        $BookQuery = "SELECT summary_book_id FROM ".getTablePrefix()."customer_summary_book as `csb`  WHERE `csb`.`hotel_manager_id` = '".$id."'  AND `csb`.`check_out_datetime` IS NULL AND `csb`.check_in_datetime <= '".$date."' ORDER BY `csb`.`check_in_datetime` DESC";
        $Result = $this->common_model->getDataByQuery('multiple', $BookQuery);
        foreach ($Result as $key => $values) {
            $whereCon['where'] = "csd.hotel_manager_id = '" . $id . "' AND csd.customer_id = '" . $values['summary_book_id'] . "'";
            $shortField = 'csd.creation_date asc';
            $tblName = 'customer_summary_details as csd';
            $ALLDATA = $this->vendor_model->selectCustomerSummaryDetailsData('data', $tblName, $whereCon, $shortField, 0, 0);
            foreach ($ALLDATA as $key=>$ALLDATAINFO){
                $totalAmount  +=  (int)$ALLDATAINFO['advance_paid'];
                $AmountPaid  +=  (int)$ALLDATAINFO['payment_paid'];
            }
            
        }
        $totalDueAmount   .=   $totalAmount - $AmountPaid;
        
    }
    else{
        foreach ($Hotel_managerArr as $key => $value) {

            $BookQuery = "SELECT `summary_book_id` FROM ".getTablePrefix()."customer_summary_book as `csb`  WHERE `csb`.`hotel_manager_id` = '".$value."'  AND `csb`.`check_out_datetime` IS NULL AND `csb`.check_in_datetime <= '".$date."' ORDER BY `csb`.`check_in_datetime` DESC";
            
            $Result = $this->common_model->getDataByQuery('multiple', $BookQuery);
            
            foreach ($Result as $key => $values) {
                $whereCon['where'] = "csd.hotel_manager_id = '" . $value . "' AND csd.customer_id = '" . $values['summary_book_id'] . "'";
                $shortField = 'csd.creation_date asc';
                $tblName = 'customer_summary_details as csd';
                $ALLDATA = $this->vendor_model->selectCustomerSummaryDetailsData('data', $tblName, $whereCon, $shortField, 0, 0);
                foreach ($ALLDATA as $key=>$ALLDATAINFO){
                    $totalAmount  +=  (int)$ALLDATAINFO['advance_paid'];
                    $AmountPaid  +=  (int)$ALLDATAINFO['payment_paid'];
                }    
            }
        }
        $totalDueAmount   .=   $totalAmount - $AmountPaid;
    }
    $data['AmountPending'] = $totalDueAmount;
    $OwnerData   = $this->common_model->getDataByParticularField('vendor', 'vendor_id', sessionData('MHM_OWNER_ID'));
    $tblName = 'vendor as ven';
    $whereCon['where'] =   "";
    $shortField =   'ven.vendor_id DESC';
    $grField  =   'ven.vendor_id';
    $ALLDATA = $this->owner_model->selectSelletData('data', $tblName, $whereCon, $shortField, 100, 0,$grField);
 
    $data['totalHotel'] = $ALLDATA;
    
    /*Total Sales*/
    $data['TotalSale'] = $this->owner_model->getTotalSalesAjax($id);
    /*Total Sales*/

    /*Total Expenses*/
    $data['TotalExpenses'] = $this->owner_model->getTotalExpanseAjax($id);;
    /*Total Expenses*/
    $data['TotalCheckIn'] = $this->owner_model->GetTotalCheckInCount($id);
    $data['TotalCheckOut'] = $this->owner_model->GetTotalCheckOutCount($id);
    //echo "<pre>"; print_r($data); exit;
    // Total No of Romm
    $kycQuery1 = "SELECT room_id,room_no,room_no_use,encrypt_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id IN (".$hotel_manager_id.") AND status = 1 ";
    $availableRooms = $this->common_model->getDataByQuery('multiple', $kycQuery1);
    $data['totlaRoomsCount'] = count($availableRooms);

    $kycQuery = "SELECT room_id,room_no,room_no_use,encrypt_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id IN (".$hotel_manager_id.") AND room_no_use='Y' AND status = 1 ";
    $availableRooms = $this->common_model->getDataByQuery('multiple', $kycQuery);
    $data['fillRoomsCount'] = count($availableRooms);
    //echo '<pre>';print_r($availableRooms);die;
    $i = 0;
    //Continued
    $Date = date("Y-m-d");
    $dateFormate = "Room Rent (".date("d/m/Y",strtotime($Date)).')';
    if(!empty($id)){
       $customeQuery = "SELECT `id`,`customer_id` from ".getTablePrefix()."customer_summary_details as `csd` WHERE `csd`.`hotel_manager_id` = '".$id."' AND `csd`.page_source ='extend_stay' AND `csd`.bill_item = '".$dateFormate."'";
        $curtomerResult = $this->common_model->getDataByQuery('multiple', $customeQuery);
        $customeId = [];
        foreach ($curtomerResult as $key => $value) {
            $customeId[] = $value['customer_id'];
            $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`hotel_manager_id` = '".$id."' AND `csb`.`summary_book_id` = '".$value['customer_id']."' AND `csb`.`check_out_datetime` >= '".$Date."' AND `csb`.check_in_datetime < '".$Date."' ORDER BY `csb`.`check_in_datetime` DESC";
            $Result = $this->common_model->getDataByQuery('single', $BookQuery); 
            $check_out_datetime = date('Y-m-d',strtotime($Result['check_out_datetime']));
            if(!empty($Result) && $check_out_datetime == $dateFormate){
                $details[] = $Result;
            }
        }
        $kycQuery = "SELECT room_id,room_no,room_no_use,encrypt_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id=".$id." AND room_no_use='Y' ";
        $AvailableRoomsArr = $this->common_model->getDataByQuery('multiple', $kycQuery);
        
        $Result = array();
        foreach ($AvailableRoomsArr as $key=>$Arooms) {
            $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`assign_room_number` = '".$Arooms['room_id']."' AND `csb`.`hotel_manager_id` = '".$id."' AND `csb`.check_in_datetime < '".$Date."' AND `csb`.`check_out_datetime` IS NULL AND `csb`.summary_book_id NOT IN('".$customeId."') ORDER BY `csb`.`check_in_datetime` DESC";
            $Result = $this->common_model->getDataByQuery('single', $BookQuery);
            if(!empty($Result)){
                $details[] = $Result;
            }
            
        }

    }
    else{
        $Hotel_managerArr = $this->owner_model->GetAllHotelList();
        foreach ($Hotel_managerArr as $key => $values) {
            $count = 0;
            $customeQuery = "SELECT `id`,`customer_id` from ".getTablePrefix()."customer_summary_details as `csd` WHERE `csd`.`hotel_manager_id` = '".$values."' AND `csd`.page_source ='extend_stay' AND `csd`.bill_item = '".$dateFormate."'";
            $curtomerResult = $this->common_model->getDataByQuery('multiple', $customeQuery);
            $customeId = [];
            foreach ($curtomerResult as $key => $value) {
                $customeId[] = $value['customer_id'];
                $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`hotel_manager_id` = '".$values."' AND `csb`.`summary_book_id` = '".$value['customer_id']."' AND `csb`.`check_out_datetime` >= '".$Date."' AND `csb`.check_in_datetime < '".$Date."' ORDER BY `csb`.`check_in_datetime` DESC";
                $Result = $this->common_model->getDataByQuery('single', $BookQuery); 
                $check_out_datetime = date('Y-m-d',strtotime($Result['check_out_datetime']));
                if(!empty($Result) && $check_out_datetime == $dateFormate){
                    $details[] = $Result;
                }
            }
            $kycQuery = "SELECT room_id,room_no,room_no_use,encrypt_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id=".$values." AND room_no_use='Y' ";
            $AvailableRoomsArr = $this->common_model->getDataByQuery('multiple', $kycQuery);
            $Result = array();
            foreach ($AvailableRoomsArr as $key=>$Arooms) {
                $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`assign_room_number` = '".$Arooms['room_id']."' AND `csb`.`hotel_manager_id` = '".$values."' AND `csb`.check_in_datetime < '".$Date."' AND `csb`.`check_out_datetime` IS NULL AND `csb`.summary_book_id NOT IN('".$customeId."') ORDER BY `csb`.`check_in_datetime` DESC";
                $Result = $this->common_model->getDataByQuery('single', $BookQuery);
                $details[] = $Result;
            }
        }
    }
    $data['TotalValidCheckout'] = count($details);
    //$data['TotalValidCheckout'] = $i;
    

    /*$tblName = 'vendor as ven';
    $whereCon['where'] =   "";
    $shortField =   'ven.vendor_id DESC';
    $grField  =   'ven.vendor_id';
    $data['ALLHotel'] = $this->owner_model->selectSelletData('data', $tblName, $whereCon, $shortField, 100, 0,$grField);
    $data['MainHotel'] = $this->common_model->getDataByParticularField('vendor', 'vendor_id', sessionData('MHM_OWNER_ID'));*/

    // Cash in Hand
    $RPrepaid = 0;
    $ROnline = 0;
    $ROffline = 0;
    $RBTC = 0;
    $ResQuery = "SELECT amount_mode,payment_paid FROM ".getTablePrefix()."calendar_reservations WHERE hotel_manager_id IN (".$hotel_manager_id.") AND (add_date LIKE '%" . date('Y-m-d') . "%') order by id desc";
    //$ResData = $this->common_model->getDataByQuery('multiple', $ResQuery);
    $query = $this->db->query($ResQuery);
    if ($query->num_rows() > 0){
      $ResData = $query->result_array();
      foreach ($ResData as $row) {
        if($row['amount_mode']=='prepaid'){
          $RPrepaid += (int)$row['payment_paid'];
        }
        if($row['amount_mode']=='online'){
          $ROnline += (int)$row['payment_paid'];
        }
        if($row['amount_mode']=='offline'){
          $ROffline += (int)$row['payment_paid'];
        }
        if($row['amount_mode']=='BTC'){
          $RBTC += (int)$row['payment_paid'];
        }
      }
    }
    $dayWiseOfflineSales  = $this->owner_model->getDayWiseTotalSalesCount("vendor_today_offline_sales", $date,$id);
    $dayWiseOnlineSales  = $this->owner_model->getDayWiseTotalSalesCount("vendor_today_online_sales", $date,$id);
    $dayWisePrepaidSales  = $this->owner_model->getDayWiseTotalSalesCount("vendor_today_prepaid_sales", $date,$id);
    $dayWiseB2CSales  =  $this->owner_model->getDayWiseTotalSalesCount("vendor_today_btc_sales", $date,$id);

    $TotalCash = $dayWiseOfflineSales ?? 0 ;
    $TotalOnline = $dayWiseOnlineSales ?? 0 ;
    $TotalPrepaid = $dayWisePrepaidSales ?? 0 ;
    $TotalBTC = $dayWiseB2CSales ?? 0 ;

    $totSals = ($TotalCash+$TotalOnline+$TotalPrepaid+$TotalBTC);

    $totalSalesMonthly = ($TotalCash+$TotalOnline+$TotalPrepaid+$TotalBTC);
  
    $data['cashInHand'] = number_format(($TotalCash-$TotalExpenses),2);
    $data['todayCash'] = number_format($TotalCash,2);
    $data['TotalOnline'] = number_format($TotalOnline, 2);
    $data['TotalPrepaid'] = number_format($TotalPrepaid, 2);
    $data['TotalBTC'] = number_format($TotalBTC, 2);
    
    $data['totalSales'] = number_format($totSals, 2);
    $data['totalSalesMonthly'] = number_format($totalSalesMonthly, 2);

    // === Monthly
    $RPrepaidM = 0;
    $ROnlineM = 0;
    $ROfflineM = 0;
    $RBTCM = 0;
    $ResQuery = "SELECT * FROM ".getTablePrefix()."calendar_reservations WHERE 1 AND (add_date >= '".date('Y-m-01 00:00:00')."' AND add_date < '" . date('Y-m-d H:i:s') . "') order by id desc";
    //$ResData = $this->common_model->getDataByQuery('multiple', $ResQuery);
    $query = $this->db->query($ResQuery);
  
    if ($query->num_rows() > 0){
      
      $ResData = $query->result_array();
      foreach ($ResData as $row) {
        
        if($row['amount_mode']=='prepaid'){
          $RPrepaidM += (int)$row['payment_paid'];
        }
        if($row['amount_mode']=='online'){
          $ROnlineM += (int)$row['payment_paid'];
        }
        if($row['amount_mode']=='offline'){
          $ROfflineM += (int)$row['payment_paid'];
        }
        if($row['amount_mode']=='BTC'){
          $RBTCM += (int)$row['payment_paid'];
        }
      }
    }

    $dayWiseOfflineSalesM  = $this->vendor_model->getDayWiseTotalSalesOwnerM("offline", date('Y-m-d'), $hotel_manager_id);
    $dayWiseOnlineSalesM  = $this->vendor_model->getDayWiseTotalSalesOwnerM("online", date('Y-m-d'), $hotel_manager_id);
    $dayWisePrepaidSalesM  = $this->vendor_model->getDayWiseTotalSalesOwnerM("prepaid", date('Y-m-d'), $hotel_manager_id);
    $dayWiseB2CSalesM  = $this->vendor_model->getDayWiseTotalSalesOwnerM("BTC", date('Y-m-d'), $hotel_manager_id);

    $CashMonth = $dayWiseOfflineSalesM['totalAmount'] ?? 0;
    $OnlineMonth = $dayWiseOnlineSalesM['totalAmount'] ?? 0;
    $PrepaidMonth = $dayWisePrepaidSalesM['totalAmount'] ?? 0;
    $BTCMonth = $dayWiseB2CSalesM['totalAmount'] ?? 0;

    $TotalCashMonth = $CashMonth ;
    $TotalOnlineMonth = $OnlineMonth;
    $TotalPrepaidMonth = $PrepaidMonth;
    $TotalBTCMonth = $BTCMonth;

    $totalSalesMonthly = ($TotalCashMonth+$TotalOnlineMonth+$TotalPrepaidMonth+$TotalBTCMonth);


    $data['cashInHandMonth'] = number_format(($TotalCashMonth-$TotalExpensesMonth),2);
    $data['todayCashMonth'] = $TotalCashMonth > 0 ? number_format($TotalCashMonth,2) : 0;
    $data['TotalOnlineMonth'] = $TotalOnlineMonth > 0 ? number_format($TotalOnlineMonth, 2) : 0;
    $data['TotalPrepaidMonth'] = $TotalPrepaidMonth > 0 ? number_format($TotalPrepaidMonth, 2) : 0;
    $data['TotalBTCMonth'] = $TotalBTCMonth > 0 ? number_format($TotalBTCMonth, 2) : 0;
    $data['totalSalesMonthly'] = $totalSalesMonthly > 0 ? number_format($totalSalesMonthly, 2) : 0;
    // Monthly Expence ---
    //creation_date --. this month only----
    if(!empty($hotel_manager_id)){
        $Hotel_managerArr = $hotel_manager_id;
    }
    else{
        $Hotel_managerArr = $this->owner_model->GetAllHotelList();
        //print_r($Hotel_managerArr);
    }
    $monthlyExp = 0;
    //echo "<pre>"; print_r($hotel_manager_id); exit;
    $tblName = 'customer_summary_details as hdbo';
    $whereCon['where'] = "hdbo.hotel_manager_id IN (".$Hotel_managerArr.") AND  hdbo.daybook_mode = 'Out' AND (hdbo.creation_date >= '".date('Y-m-01 00:00:00')."' AND  hdbo.creation_date <= '".date('Y-m-d H:i:s')."')";
    $tot_vendor  = $this->vendor_model->selectDayBookOutManagerDataShree('data', $tblName, $whereCon);
    foreach($tot_vendor as $row){
        $monthlyExp += $row['amount_out'];
    }
    $data['monthlyExp'] = $monthlyExp;
    $Date = date('Y-m-d');
    // ==== New Boxes --- 

    $data['error'] = '';
    $data['activeMenu'] = 'dashboard';
    $data['activeSubMenu'] = 'dashboard';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $this->layouts->set_title('Dashboard');
    $this->load->view('owner/dashboard_ajax_data', $data);
  }

    public function get_dashboard_data(){
        $date = date('Y-m-d');
        $id = isset($_POST['id']) && !empty($_POST['id']) ?  $_POST['id'] :'';
        $calltype = isset($_POST['calltype']) && !empty($_POST['calltype']) ?  $_POST['calltype'] :'';
        $Hotel_managerArr = $this->owner_model->GetAllHotelList();
        $data['calltype'] = $calltype;
        $hotel_manager_id = !empty($id) ? $hmd[] = $id : implode(',', $Hotel_managerArr);
        if(!empty($id)){
            $data['LoginVenderId'] = $id;
            $data['id'] = $id;
        }
        else{
            $id = '';
            $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
        }
        if($calltype == 'checkin' || $calltype == 'checkout'){
            $data['OtsInfo'] = $this->owner_model->getAllOtsByHotelIds($id);

            foreach ($data['OtsInfo'] as $key => $value) {
                
                $data['otsDetails'][$value['ots_name']][$value['ots_id']] = $this->owner_model->GetBookingMode($value['hotel_manager_id'],$value['ots_id']);
                if($calltype == 'checkin'){
                    $data['CheckInDetails'][$value['ots_name']][$value['ots_id']] = $this->owner_model->GetTotalCheckIn($value['hotel_manager_id'], 'view',$value['ots_id']);
                }
                elseif ($calltype == 'checkout') {
                    $data['CheckInDetails'][$value['ots_name']][$value['ots_id']] = $this->owner_model->GetTotalCheckOut($value['hotel_manager_id'], 'view',$value['ots_id']);
                } 
            }
       
            $OffLineCount = 0;
            if($calltype == 'checkin'){
                $data['CheckInDetailsOffLine'] = $this->owner_model->GetTotalCheckInOffLine($id, 'view','offline');
                $data['OffLineCount'] =  count($data['CheckInDetailsOffLine']); 
            }
            elseif ($calltype == 'checkout') {
                $date = date('Y-m-d');
                $tblName = 'customer_summary_book as csb';
                $shortField = 'csb.check_out_datetime DESC';
                if(!empty($id)){

                    $whereCon['where'] = "csb.hotel_manager_id = '" . $id . "'";
                        $whereCon['like'] = "(csb.check_out_datetime LIKE '%" . $date . "%')";
                    $data['GetCheckOutArr'][$id] = $this->vendor_model->selectCustomerSummaryBookDataCount('data', $tblName, $whereCon, $shortField, '0', '0');
                }
                else{
                    $Hotel_managerArr = $this->owner_model->GetAllHotelList();

                   foreach ($Hotel_managerArr as $key => $value) {
                        
                        $whereCon['where'] = "csb.hotel_manager_id = '" . $value . "'";
                        $whereCon['like'] = "(csb.check_out_datetime LIKE '%" . $date . "%')";
                        $data['GetCheckOutArr'][$value] = $this->vendor_model->selectCustomerSummaryBookDataCount('data', $tblName, $whereCon, $shortField, '0', '0');
                   }
                //echo "<pre>"; print_r($data); exit;
                }
                
                $data['CheckInDetailsOffLine'] = $this->owner_model->GetTotalCheckOutOffLine($id, 'view','offline');
                $data['OffLineCount'] =  count($data['CheckInDetailsOffLine']); 

            }
        }
        elseif($calltype == 'offline' || $calltype == 'BTC' || $calltype == 'online' || $calltype == 'prepaid'){
            
            if(!empty($id)){
                 $data['TotalSales'][$id] = $this->owner_model->GetTotalSales($id,$calltype);
            }
            else{
                $Hotel_managerArr = $this->owner_model->GetAllHotelList();

               foreach ($Hotel_managerArr as $key => $value) {
               
                   $data['TotalSales'][$value] = $this->owner_model->GetTotalSales($value,$calltype);
               }
                //echo "<pre>"; print_r($data); exit;
            }
            //$data['TotalSales'][] = $this->owner_model->GetTotalSales($id, $calltype);

        }
        elseif($calltype == 'expense'){
            $data['ExpensesArr'] = $this->owner_model->selectDayBookOutManagerData($id,'view');
        } 
        elseif($calltype == 'sale'){
            if(!empty($id)){
                 $data['SaleDetails'][$id] = $this->owner_model->GetTotalSales($id,'');
            }
            else{
                $Hotel_managerArr = $this->owner_model->GetAllHotelList();

               foreach ($Hotel_managerArr as $key => $value) {
               
                   $data['SaleDetails'][$value] = $this->owner_model->GetTotalSales($value,'');
               }
                //echo "<pre>"; print_r($data); exit;
            }           
        }
        elseif($calltype == 'cash_in_hand'){ 
            if(!empty($id)){
                 $data['CashDetails'][$id] = $this->owner_model->GetTotalSales($id,'offline');
                 $data['ExpensesDetails'][$id] = $this->owner_model->selectDayBookOutManagerData($id,'view');
            }
            else{
                $Hotel_managerArr = $this->owner_model->GetAllHotelList();

               foreach ($Hotel_managerArr as $key => $value) {

                    $data['CashDetails'][$value] = $this->owner_model->GetTotalSales($value,'offline');
                    $data['ExpensesDetails'][$value] = $this->owner_model->selectDayBookOutManagerData($value,'view');
               }
                //echo "<pre>"; print_r($data); exit;
            }           
        } 
        elseif($calltype == 'occupied'){
            
            if(!empty($id)){
                $kycQuery = "SELECT room_id,room_no,room_no_use,hotel_manager_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id = '".$id."' AND room_no_use='Y' AND status = 1 ";
                $availableRooms = $this->common_model->getDataByQuery('multiple', $kycQuery);
                $data['OccupiedRoom'][$id] = count($availableRooms);
            }
            else{
                $Hotel_managerArr = $this->owner_model->GetAllHotelList();
                foreach ($Hotel_managerArr as $key => $value) {

                    $kycQuery = "SELECT room_id,room_no,room_no_use,hotel_manager_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id = '".$value."' AND room_no_use='Y' AND status = 1 ";
                    $availableRooms = $this->common_model->getDataByQuery('multiple', $kycQuery);
                    $data['OccupiedRoom'][$value] = count($availableRooms);
                }
            }
            
        }
        elseif($calltype == 'continued'){
            $Date = date("Y-m-d");
            $dateFormate = "Room Rent (".date("d/m/Y",strtotime($Date)).')';
            if(!empty($id)){
                $customeQuery = "SELECT `id`,`customer_id` from ".getTablePrefix()."customer_summary_details as `csd` WHERE `csd`.`hotel_manager_id` = '".$id."' AND `csd`.page_source ='extend_stay' AND `csd`.bill_item = '".$dateFormate."'";
                $curtomerResult = $this->common_model->getDataByQuery('multiple', $customeQuery);
                $dateFormate = date("Y-m-d");
                $customeId = [];
                foreach ($curtomerResult as $key => $value) {
                    $customeId[] = $value['customer_id'];
                    $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`hotel_manager_id` = '".$id."' AND `csb`.`summary_book_id` = '".$value['customer_id']."' AND `csb`.`check_out_datetime` >= '".$Date."' AND `csb`.check_in_datetime < '".$Date."' ORDER BY `csb`.`check_in_datetime` DESC";
                    $Result = $this->common_model->getDataByQuery('single', $BookQuery); 
                    $check_out_datetime = date('Y-m-d',strtotime($Result['check_out_datetime']));
                    if(!empty($Result) && $check_out_datetime == $dateFormate){
                        $details[] = $Result;
                    }
                }
                //echo "<pre>"; print_r($details); exit;
                $kycQuery = "SELECT room_id,room_no,room_no_use,encrypt_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id=".$id." AND room_no_use='Y' ";
                $AvailableRoomsArr = $this->common_model->getDataByQuery('multiple', $kycQuery);
                $Result = array();
                foreach ($AvailableRoomsArr as $key=>$Arooms) {
                    $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`assign_room_number` = '".$Arooms['room_id']."' AND `csb`.`hotel_manager_id` = '".$id."' AND `csb`.check_in_datetime < '".$Date."' AND `csb`.`check_out_datetime` IS NULL AND `csb`.summary_book_id NOT IN('".$customeId."') ORDER BY `csb`.`check_in_datetime` DESC";
                    $Result = $this->common_model->getDataByQuery('single', $BookQuery);
                    if(!empty($Result)){
                        $details[] = $Result;
                    }
                    
                }
                 $data['Continueds'][$id] = $details;
            }
            else{
                $Hotel_managerArr = $this->owner_model->GetAllHotelList();
                foreach ($Hotel_managerArr as $key => $values) {
                    $count = 0;
                    $customeQuery = "SELECT `id`,`customer_id` from ".getTablePrefix()."customer_summary_details as `csd` WHERE `csd`.`hotel_manager_id` = '".$values."' AND `csd`.page_source ='extend_stay' AND `csd`.bill_item = '".$dateFormate."'";
                    $curtomerResult = $this->common_model->getDataByQuery('multiple', $customeQuery);
                    $customeId = [];
                    //echo "<pre>"; print_r($customeId); exit;
                    foreach ($curtomerResult as $key => $value) {
                        $customeId[] = $value['customer_id'];
                        $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`hotel_manager_id` = '".$values."' AND `csb`.`summary_book_id` = '".$value['customer_id']."' AND `csb`.`check_out_datetime` >= '".$Date."' AND `csb`.check_in_datetime < '".$Date."' ORDER BY `csb`.`check_in_datetime` DESC";
                        $Result = $this->common_model->getDataByQuery('single', $BookQuery); 
                        $check_out_datetime = date('Y-m-d',strtotime($Result['check_out_datetime']));
                        if(!empty($Result) && $check_out_datetime == $dateFormate){
                            $details[] = $Result;
                        }
                    }
                    $kycQuery = "SELECT room_id,room_no,room_no_use,encrypt_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id=".$values." AND room_no_use='Y' ";
                    $AvailableRoomsArr = $this->common_model->getDataByQuery('multiple', $kycQuery);
                    $Result = array();
                    foreach ($AvailableRoomsArr as $key=>$Arooms) {
                        $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`assign_room_number` = '".$Arooms['room_id']."' AND `csb`.`hotel_manager_id` = '".$values."' AND `csb`.check_in_datetime < '".$Date."' AND `csb`.`check_out_datetime` IS NULL AND `csb`.summary_book_id NOT IN('".$customeId."') ORDER BY `csb`.`check_in_datetime` DESC";
                        $Result = $this->common_model->getDataByQuery('single', $BookQuery);
                        if(!empty($Result)){
                            $details[] = $Result;
                        }
                    }
                     $data['Continueds'][$values] = $details;
                }
            }
        } 

        elseif($calltype == 'pending'){ 
            // Total Amount Pending--
            $totalAmount = 0;
            $AmountPaid = 0;
            $totalDueAmount = 0;
            $date = date('Y-m-d');
            if(!empty($id)){

                $BookQuery = "SELECT summary_book_id,`customer_name` FROM ".getTablePrefix()."customer_summary_book as `csb`  WHERE `csb`.`hotel_manager_id` = '".$id."'  AND `csb`.`check_out_datetime` IS NULL AND `csb`.check_in_datetime <= '".$date."' ORDER BY `csb`.`check_in_datetime` DESC";
                $Result = $this->common_model->getDataByQuery('multiple', $BookQuery);
                
                foreach ($Result as $key => $values) {
                    $totalDueAmount = $totalAmount = $AmountPaid = 0;
                    $whereCon['where'] = "csd.hotel_manager_id = '" . $id . "' AND csd.customer_id = '" . $values['summary_book_id'] . "'";
                    $shortField = 'csd.creation_date asc';
                    $tblName = 'customer_summary_details as csd';
                    $ALLDATA = $this->vendor_model->selectCustomerSummaryDetailsData('data', $tblName, $whereCon, $shortField, 0, 0);
                    foreach ($ALLDATA as $key=>$ALLDATAINFO){

                        $totalAmount  +=  (int)$ALLDATAINFO['advance_paid'];
                        $AmountPaid  +=  (int)$ALLDATAINFO['payment_paid'];
                    }  
                    $totalDueAmount   =   $totalAmount - $AmountPaid; 
                    $data['Pending'][$id][$values['summary_book_id']]['customer_name'] = $values['customer_name'];  
                        $data['Pending'][$id][$values['summary_book_id']]['amount'] = $totalDueAmount;  
                }
            }
            else{ 
                 $Hotel_managerArr = $this->owner_model->GetAllHotelList();
                foreach ($Hotel_managerArr as $key => $value) {
                    
                    $BookQuery = "SELECT `summary_book_id`,`customer_name` FROM ".getTablePrefix()."customer_summary_book as `csb`  WHERE `csb`.`hotel_manager_id` = '".$value."'  AND `csb`.`check_out_datetime` IS NULL AND `csb`.check_in_datetime <= '".$date."' ORDER BY `csb`.`check_in_datetime` DESC";
                    //echo "<pre>"; print_r($BookQuery); exit;
                    $Result = $this->common_model->getDataByQuery('multiple', $BookQuery);
                    
                    foreach ($Result as $key => $values) {
                        $totalDueAmount = $totalAmount = $AmountPaid = 0;
                        $whereCon['where'] = "csd.hotel_manager_id = '" . $value . "' AND csd.customer_id = '" . $values['summary_book_id'] . "'";
                        $shortField = 'csd.creation_date asc';
                        $tblName = 'customer_summary_details as csd';
                        $ALLDATA = $this->vendor_model->selectCustomerSummaryDetailsData('data', $tblName, $whereCon, $shortField, 0, 0);
                        foreach ($ALLDATA as $key=>$ALLDATAINFO){
                            $totalAmount  +=  (int)$ALLDATAINFO['advance_paid'];
                            $AmountPaid  +=  (int)$ALLDATAINFO['payment_paid'];
                        }
                        $totalDueAmount  =   $totalAmount - $AmountPaid;
                        $data['Pending'][$value][$values['summary_book_id']]['customer_name'] = $values['customer_name'];  
                        $data['Pending'][$value][$values['summary_book_id']]['amount'] = $totalDueAmount;    
                    }
                }
                
            }
        }   
        // ==== New Boxes --- 
        $data['error'] = '';
        $data['activeMenu'] = 'dashboard';
        $data['activeSubMenu'] = 'dashboard';
        $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
        $this->layouts->set_title('Dashboard');
        $this->load->view('owner/pop_ajax_data', $data);
    }

    public function get_ajax_dashboard(){
    $date = date('Y-m-d');
    $id = '';
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){

       $ReserQuery = "SELECT id,vendor_business_name,vendor_id FROM ".getTablePrefix()."vendor WHERE parent_id=".sessionData('MHM_OWNER_ID')." ";
       $ALLHotel = $this->common_model->getDataByQuery('multiple', $ReserQuery);
        $vendorList = array_column($ALLHotel, 'vendor_id');
    }
    else{
        $tblName = 'sub_owner as so';
        $whereCon['where'] =   "";
        $shortField =   'so.vendor_id DESC';
        $grField  =   'so.vendor_id';
        $ALLHotel = $this->owner_model->selectSelletOwnerData('data', $tblName, $whereCon, $shortField, 100, 0,$grField);
        $vendorList = array_column($ALLHotel,'vendor_id');
    }
    
    
    $data['ALLHotel'] = $allHotel;
    $vendorListId = implode(',', $vendorList);
    $Hotel_managerArr = $this->owner_model->GetAllHotelList();
     $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $hotel_manager_id = implode(',', $Hotel_managerArr);
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        //$mainHotelList = $this->common_model->getDataByParticularField('vendor', 'vendor_id', sessionData('MHM_OWNER_ID'));
        $mailHotels['vendor_business_name'] = sessionData('MHM_OWNER_BUSINESS_NAME');
        $mailHotels['vendor_id'] = sessionData('MHM_OWNER_ID');
        $data['MainHotel'] = $mailHotels;
        $totalCheckinOwn = $this->owner_model->GetTotalCheckInCount(sessionData('MHM_OWNER_ID'));
        $totalCheckOutOwn = $this->owner_model->GetTotalCheckOutCount(sessionData('MHM_OWNER_ID'));
        $totalSalesOwn = $this->owner_model->getTotalSalesAjax(sessionData('MHM_OWNER_ID'));
        $TotalExpensesOwn = $this->owner_model->getTotalExpanseAjax(sessionData('MHM_OWNER_ID'));
        $data['totalChkOutOWN'] = !empty($totalCheckOutOwn) ? $totalCheckOutOwn: 0;
        $data['totalCheckinOwn'] = !empty($totalCheckinOwn) ? $totalCheckinOwn: 0;
        $data['totalSalesOwn'] = !empty($totalSalesOwn) ? $totalSalesOwn: 0;
        $data['TotalExpensesOwn'] = !empty($TotalExpensesOwn) ? $TotalExpensesOwn: 0;
    }
    //Vendor Code
    if(!empty($vendorListId)){

        $totalChkVendors = "SELECT * FROM ".getTablePrefix()."vendors_info_count WHERE hotel_manager_id IN (".$vendorListId.") ";
        $totalVendor = $this->common_model->getDataByQuery('multiple', $totalChkVendors);
    }
    $data['totalVendor'] = $totalVendor;
    /*Total Sales*/
    $data['TotalSale'] = $this->owner_model->getTotalSalesAjax($id);
    /*Total Sales*/

    /*Total Expenses*/
    $data['TotalExpenses'] = $this->owner_model->getTotalExpanseAjax($id);;
    /*Total Expenses*/
    $data['TotalCheckIn'] = $this->owner_model->GetTotalCheckInCount($id);
    $data['TotalCheckOut'] = $this->owner_model->GetTotalCheckOutCount($id);

    $Date = date('Y-m-d');
    // ==== New Boxes --- 

    $data['error'] = '';
    $data['activeMenu'] = 'dashboard';
    $data['activeSubMenu'] = 'dashboard';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $this->layouts->set_title('Dashboard');
    $this->load->view('owner/get_ajax_dashboard', $data);
  }
}