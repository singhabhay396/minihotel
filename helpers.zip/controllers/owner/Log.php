<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Log extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'owner_model', 'emailtemplate_model', 'sms_model','frontauth_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }

  public function index(){
    $data['error'] = '';
    $data['activeMenu'] = 'Log';
    $data['activeSubMenu'] = 'Log';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $data['ManagerList'] = $this->owner_model->GetManagerList();
    $data['LogType'] = $this->owner_model->GetLogType();
    $HotelList = $this->owner_model->GetOwnerVendorList();    
    $data['HotelList'] = $HotelList;
    //echo '<pre>';print_r($data['HotelList']);die();
    $this->layouts->set_title('Log List');
    $this->layouts->owner_view('owner/log/index', array(), $data);
  }
  function Pagination(){
    $Search['hotel_name']     = $_GET['hotel_name'] ?? '';
    $Search['manager_id']     = $_GET['manager_id'] ?? 'All';
    $Search['log_type']       = $_GET['log_type'] ?? 'All';
    $Search['vendor_id']       = $_GET['vendor_id'] ?? 'All';
    $Search['page']           = $_GET['page'] ?? 1;
    $Search['numofrecords']   = $_GET['numofrecords'] ?? 100;
    //$Search['cur_page']       = $Search['page'];
    $Limitpage                = $Search['page']-1;
    $Search['start']          = $Limitpage * $Search['numofrecords'];
    
    $Search['action'] = 'count';
    $TotalData = $this->PaginationData($Search);
    $data['PAGINATION'] = Pagination($Search['numofrecords'],$TotalData, $Search['page']);
    $Search['action'] = 'data';
    $data['ALLDATA'] = $this->PaginationData($Search);
    //echo '<pre>';print_r($data);die;
    $this->load->view('owner/log/Pagination', $data);
  }
  function PaginationData($Search){
    $vendor_id = $this->owner_model->GetAllHotelList();
    $this->db->select('log.*,vendor.vendor_business_name,log_type.log_type as log_name,manager.manager_name');
    $this->db->from('log');
    $this->db->join('vendor', 'vendor.vendor_id=log.vendor_id', 'LEFT');
    $this->db->join('log_type', 'log_type.id=log.log_type', 'LEFT');
    $this->db->join('manager', 'manager.id=log.manager_id', 'LEFT');
    if($Search['hotel_name']!=''){ $this->db->where("vendor.vendor_business_name LIKE '%" . $Search['hotel_name'] . "%'"); }
    if($Search['log_type']!='All'){ $this->db->where("log.log_type",$Search['log_type']); }
    if($Search['vendor_id']!='All'){ $this->db->where("log.vendor_id",$Search['vendor_id']); }
    if($Search['manager_id']!='All'){ $this->db->where("log.manager_id",$Search['manager_id']); }
    $this->db->where_in("log.vendor_id",$vendor_id); 
    $this->db->order_by('log.id DESC');
    if ($Search['action']=='data'){ $this->db->limit($Search['numofrecords'], $Search['start']); }
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($Search['action'] == 'data'){
      if ($query->num_rows() > 0){
        return $query->result_array();
      }else{
        return false;
      }
    }elseif ($Search['action'] == 'count'){
      return $query->num_rows();
    }
  }

  public function logdetails(){
    $html = '';
    if ($this->input->post('viewid')){
      $viewId = $this->input->post('viewid');
      $viewData = $this->common_model->getDataByParticularField('log', 'id', $viewId);
      //echo "<pre>"; print_r($viewData); exit;
      $date = '2024-05-11';
      $addDate = date('Y-m-d',strtotime($viewData['add_date']));
      $data['date'] = $date;
      $data['addDate'] = $addDate;
       $preiousDataa = json_decode($viewData['previous_data'], true);
       //echo count($preiousDataa); exit;
      $data['ct'] = count($preiousDataa);
      if(($viewData['log_type'] == 1 || $viewData['log_type'] == 10 || $viewData['log_type'] == 11 || $viewData['log_type'] == 17)  && $addDate > '2024-05-10' &&  $data['ct'] > 0){
          
          $otsQuery = "SELECT ots_id,ots_name  FROM " . getTablePrefix() . "ots_master ORDER BY id DESC";
            $ots = $this->common_model->getDataByQuery('multiple', $otsQuery);
            foreach ($ots as $key => $val) {
                $otsList[$val['ots_id']] = $val['ots_name'];
            }
          $preiousData = json_decode($viewData['previous_data'], true);
          $updatedData = json_decode($viewData['response'], true);
          //echo "<pre>"; print_r($preiousData); exit;
          $data['updatedData'] = $updatedData;
          $data['preiousData'] = $preiousData;
          $data['otsList'] = $otsList;
          $data['log_type'] = $viewData['log_type'];
          $this->load->view('owner/log/LogDetails',$data);
      }
      else{
        $log_arr = json_decode($viewData['response']);
        foreach ($log_arr as $key => $value) {
          if($key == 'Check In Date' || $key == 'Check Out Date' || $key == 'Check-out Date'){
              $value = date('d-m-Y h:i A', strtotime($value));
          }
          echo '<strong>'.$key.'</strong> :- '.$value.'<br/>';
        }
      }
      
    }
    //echo $html;die();
  }
}