<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Collectionreport extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'emailtemplate_model', 'sms_model', 'owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }
  public function index(){
    $data['error']        =     '';
    $data['activeMenu']   =     'CollectionReports';
    $data['activeSubMenu']=     'CollectionReports';
  
   if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $HotelList = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $HotelList = $this->owner_model->GetSubOwnerVendorList();
    }   

    $Search['VendorArr']    = $_GET['VendorArr'] ?? $HotelList[0]['vendor_id'];
    $data['VendorArr']      = $_GET['VendorArr'] ?? $HotelList[0]['vendor_id'];
    $data['VendorArrData']  = explode(',', $Search['VendorArr']) ;
    $data['HotelList'] = $HotelList;
    //End

    //echo '<pre>';print_r($data);echo '</pre>';die();

    $this->layouts->set_title('Collection report');
    $this->layouts->owner_view('owner/collectionreport/index', array(), $data);
  }
  public function downloadcollectiondata(){
    try {
        require_once APPPATH . 'third_party/classes/PHPExcel.php';
        $objPHPExcel = new PHPExcel();
        $Search['fromDate'] = $_GET['fromDate'];
        $Search['toDate'] = $_GET['toDate'];
        $Search['businessType'] = $_GET['businessType'];
        $Search['VendorArr'] = $_GET['VendorID'];
        $Search['reffer_mode'] = $_GET['reffer_mode'];
        $Search['direct_mode'] = $_GET['direct_mode'];
        $Search['ots_id'] = $_GET['ots_id'];
        $Search['choose_plan'] = $_GET['choose_plan'];
        $Search['bill_generated'] = $_GET['bill_generated'];
        $Search['amount_mode'] = $_GET['amount_mode'];
        $range = $_GET['range'];
        if($range == 'today'){
            $dates = date('Y-m-d');
            $dates2 = date('Y-m-d');
            $Search['toDate']       = $dates;
            $Search['fromDate']     = $dates2;
        }
        elseif($range == 'yesterday'){
            $dates = date('Y-m-d',strtotime("-1 days"));
            //$dates2 = date('Y-m-d');
            $Search['toDate']       = $dates;
            $Search['fromDate']     = $dates;
        }
        elseif($range == 'week'){
            $start = (date('D') != 'Mon') ? date('Y-m-d', strtotime('last Monday')) : date('Y-m-d');
            $finish = (date('D') != 'Sun') ? date('Y-m-d', strtotime('next Sunday')) : date('Y-m-d');
            $Search['toDate']       = $finish;
            $Search['fromDate']     = $start;
        }
        elseif($range == 'last_month'){
            $start = date("Y-m-d", strtotime("first day of previous month"));
            $finish = date("Y-m-d", strtotime("last day of previous month"));
            $Search['toDate']       = $finish;
            $Search['fromDate']     = $start;
        }
        elseif($range == 'till_now'){
            $start = date("Y-m-01");
            $finish = date("Y-m-d");
            $Search['toDate']       = $finish;
            $Search['fromDate']     = $start;
        }
        
      $billbookdata = $this->owner_model->getAllGuestDataForCollectionReport($Search);
      
      if ($billbookdata != "") :
        $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")->setLastModifiedBy("Maarten Balliauw")->setTitle("Office 2007 XLSX Test Document")->setSubject("Office 2007 XLSX Test Document")->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")->setKeywords("office 2007 openxml php")->setCategory("Test result file");
        $objPHPExcel->setActiveSheetIndex(0);
        $objPHPExcel->getActiveSheet()->setCellValue('A2', "Guest Name")
            ->setCellValue('B2', "Entry Number")
            ->setCellValue('C2', "Room Number")
            ->setCellValue('D2', "OTA")
            ->setCellValue('E2', "No. Of Persons")
            ->setCellValue('F2', "Check in date and time")
            ->setCellValue('G2', "Check Out date and time")
            ->setCellValue('H2', "Company GSTIN")
            ->setCellValue('I2', "Company Name")
            ->setCellValue('J2', "Rent")
            ->setCellValue('K2', "Payment Details for offline")
            ->setCellValue('L2', "Payment Details for Online")
            ->setCellValue('M2', "Payment Details for Prepaid")
            ->setCellValue('N2', "Payment Details for BTC")
            ->setCellValue('O2', "Order Date");
        $objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("A")->setWidth('15');
        $objPHPExcel->getActiveSheet()->getColumnDimension("B")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("C")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("D")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("E")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("F")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("G")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("H")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("I")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("J")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("K")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("L")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("M")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("N")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("O")->setWidth('30');

        $objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('B2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('C2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('E2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('F2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('G2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('H2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('I2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('J2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('K2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('L2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('M2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('N2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('O2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1, 1);
        $i = 2;
        $totOffline =  $totOnline = $totPrepaid = $totBtc = 0;
        
        foreach ($billbookdata as $billbookdatainfo) {
            //echo "<pre>"; print_r($billbookdatainfo); exit;
            if($billbookdatainfo['amount_mode'] == 'offline'){
                $totOffline = $totOffline + $billbookdatainfo['payment_paid'];
            }
            if($billbookdatainfo['amount_mode'] == 'online'){
                $totOnline = $totOnline + $billbookdatainfo['payment_paid'];
            }
            if($billbookdatainfo['amount_mode'] == 'prepaid'){
                $totPrepaid = $totPrepaid + $billbookdatainfo['payment_paid'];
            }
            if($billbookdatainfo['amount_mode'] == 'BTC'){
                $totBtc = $totBtc + $billbookdatainfo['payment_paid'];
            }               
                $j = $i + 1;
                //$objPHPExcel->getActiveSheet()->setCellValue('A'.$j, $i);
                $objPHPExcel->getActiveSheet()->setCellValue('A' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['customer_name'])));
                $objPHPExcel->getActiveSheet()->setCellValue('B' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['entry_number'])));
                $objPHPExcel->getActiveSheet()->setCellValue('C' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['room_no'])));
                $objPHPExcel->getActiveSheet()->setCellValue('D' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['ots_name'])));
                $objPHPExcel->getActiveSheet()->setCellValue('E' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['number_of_person'])));
                $objPHPExcel->getActiveSheet()->setCellValue('E' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['number_of_person'])));
                $objPHPExcel->getActiveSheet()->setCellValue('F' . $j, htmlspecialchars_decode(date('d M Y H:i:s', strtotime($billbookdatainfo['check_in_datetime']))));
                $objPHPExcel->getActiveSheet()->setCellValue('G' . $j, htmlspecialchars_decode(!empty($billbookdatainfo['check_out_datetime']) ? date('d M Y H:i:s', strtotime($billbookdatainfo['check_out_datetime'])) : ''));
                $objPHPExcel->getActiveSheet()->setCellValue('H' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['gst_number'])));
                $objPHPExcel->getActiveSheet()->setCellValue('I' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['company_name'])));
                $objPHPExcel->getActiveSheet()->setCellValue('J' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['roomrent'])));

                $objPHPExcel->getActiveSheet()->setCellValue('K'.$j, htmlspecialchars_decode(stripslashes($billbookdatainfo['amount_mode'] == 'offline' ? $billbookdatainfo['payment_paid'] :0)));
                $objPHPExcel->getActiveSheet()->setCellValue('L' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['amount_mode'] == 'online' ? $billbookdatainfo['payment_paid'] :0))); 
                $objPHPExcel->getActiveSheet()->setCellValue('M' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['amount_mode'] == 'prepaid' ? $billbookdatainfo['payment_paid'] :0))); 
                $objPHPExcel->getActiveSheet()->setCellValue('N' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['amount_mode'] == 'BTC' ? $billbookdatainfo['payment_paid'] :0))); 
                $objPHPExcel->getActiveSheet()->setCellValue('O' . $j, htmlspecialchars_decode(!empty($billbookdatainfo['order_date']) ? date('d M Y H:i:s', strtotime($billbookdatainfo['order_date'])) : ''));   
                $objPHPExcel->setActiveSheetIndex(0);
                $i++;
            }    
        
            $j++;
            $objPHPExcel->getActiveSheet()->getStyle('K' . $j)->getFont()->setBold(true)
                                ->setName('Verdana')
                                ->setSize(10)
                                ->getColor()->setRGB('6F6F6F');
            $objPHPExcel->getActiveSheet()->getStyle('L' . $j)->getFont()->setBold(true)
                                ->setName('Verdana')
                                ->setSize(10)
                                ->getColor()->setRGB('6F6F6F');
            $objPHPExcel->getActiveSheet()->getStyle('M' . $j)->getFont()->setBold(true)
                                ->setName('Verdana')
                                ->setSize(10)
                                ->getColor()->setRGB('6F6F6F');
            $objPHPExcel->getActiveSheet()->getStyle('N' . $j)->getFont()->setBold(true)
                                ->setName('Verdana')
                                ->setSize(10)
                                ->getColor()->setRGB('6F6F6F');
            $objPHPExcel->getActiveSheet()->setCellValue('K' . $j, htmlspecialchars_decode(stripslashes("Total Offline - ".$totOffline)));    
            $objPHPExcel->getActiveSheet()->setCellValue('L' . $j, htmlspecialchars_decode(stripslashes("Total Online - ".$totOnline)));    
            $objPHPExcel->getActiveSheet()->setCellValue('M' . $j, htmlspecialchars_decode(stripslashes("Total Prepaid - ".$totPrepaid)));    
            $objPHPExcel->getActiveSheet()->setCellValue('N' . $j, htmlspecialchars_decode(stripslashes("Total BTC - ".$totBtc)));    
        $curfilename = 'bill_book_report.xls';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . basename($curfilename) . '"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel5");
        ob_end_clean();
        $objWriter->save('php://output');
        exit;
      else :
        redirect($_SERVER['HTTP_REFERER']);
        exit;
      endif;
    } catch (Throwable $th) {
      echo "<pre>";
      echo ($th);
      echo "</pre>";
      die;
    }
    }
    
     

}
