<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Businessreport extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'emailtemplate_model', 'sms_model', 'owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }
  public function index(){
    $data['error']        =     '';
    $data['activeMenu']   =     'BusinessReports';
    $data['activeSubMenu']=     'BusinessReports';
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $HotelList = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $HotelList = $this->owner_model->GetSubOwnerVendorList();
    } 

    $Search['toDate']       = date('Y-m-d');
    $Search['fromDate']     = date('Y-m-d');
    $Search['VendorArr']    = $_GET['VendorArr'] ?? $HotelList[0]['vendor_id'];
    $Search['VendorArrComp']    = $_GET['VendorArrComp'];
    $data['VendorArrComp']      = $_GET['VendorArrComp'];
    $data['VendorArr']      = $_GET['VendorArr'] ?? $HotelList[0]['vendor_id'];
    $data['VendorArrData']  = explode(',', $Search['VendorArr']) ;
    $range = $_GET['range'];
    $data['submit'] = $_GET['submit']; 
    //echo "<pre>"; print_r($_GET); exit;
    $data['range'] = $range;
    if($range == 'Select Range'){
       $data['toDate']   = date('Y-m-d');
       $data['fromDate'] = date('Y-m-d');
       $Search['toDate']       = $data['toDate'];
       $Search['fromDate']     = $data['fromDate'];         
    }
    if (($this->input->get('toDate') <> '') && ($this->input->get('fromDate') <> "")){ 
      $data['toDate']   = date('Y-m-d', strtotime($this->input->get('toDate')));
      $data['fromDate'] = date('Y-m-d', strtotime($this->input->get('fromDate')));
      $Search['toDate']       = $data['toDate'];
      $Search['fromDate']     = $data['fromDate'];
    }
    if($range == 'today'){
        $dates = date('Y-m-d');
        $dates2 = date('Y-m-d');
        $Search['fromDate']       = $dates2;
        $Search['toDate']     = $dates;
    }
    if($range == 'yesterday'){
        $dates = date('Y-m-d',strtotime("-1 days"));
        $dates2 = date('Y-m-d');
        $Search['fromDate']       = $dates;
        $Search['toDate']     = $dates;
    }
    if($range == 'week'){
        $start = (date('D') != 'Mon') ? date('Y-m-d', strtotime('last Monday')) : date('Y-m-d');
        $finish = (date('D') != 'Sun') ? date('Y-m-d', strtotime('next Sunday')) : date('Y-m-d');
        $Search['fromDate']       = $finish;
        $Search['toDate']     = $start;
    }
    if($range == 'last_month'){
        $start = date("Y-m-d", strtotime("first day of previous month"));
        $finish = date("Y-m-d", strtotime("last day of previous month"));
        $Search['fromDate']       = $finish;
        $Search['toDate']     = $start;
    }
    if($range == 'till_now'){
        $start = date("Y-m-01");
        $finish = date("Y-m-d");
        $Search['fromDate']       = $finish;
        $Search['toDate']     = $start;
    } 
       // echo "<pre>"; print_r($data); exit;
    $data['totalSale']                      =  $this->getTotalSaleByManagerId($Search);
    $data['directBookingMode']              =  $this->getTotalSaleByOnlineDirectModeWise($Search,'offline');
    $data['onlineBookingMode']              =  $this->getTotalSaleByOnlineDirectModeWise($Search,'online');
    $data['onlinePrepaidBookingMode']       =  $this->getTotalSaleByDirectCommissionMode($Search,'online','prepaid');
    $data['totalCashPayment']               =  $this->getTotalPaymentsReceivedByPaymentMode($Search,'offline');
    $data['totalOnlinePayment']             =  $this->getTotalPaymentsReceivedByPaymentMode($Search,'online');
    $data['totalOnlinePrepaid']             =  $this->getTotalPaymentsReceivedByPaymentMode($Search,'prepaid');
    $data['totalOnlineBtc']             =  $this->getTotalPaymentsReceivedByPaymentMode($Search,'BTC');
    $data['totalExpence']                   =  $this->getTotalPaymentsExpences($Search);
    $data['ownerWallet']                    =  $this->getTotalOwnersWallet($Search);
    $data['avgRoomRents']                    =  $this->getTotalAverageRoomRent($Search);
    //$data['foodAndOtherServices']           =  $this->getTotalTotalFoodAndOtherServices($Search);
    $data['occupencyRoom']                  =  $this->getOccupencyRoom($Search);
    $data['totalRoom']                      =  $this->getTotalRoom($Search);
    $data['totalCheckIn']                   =  $this->getCheckIn($Search);
    $data['totalCheckout']                  =  $this->getCheckOut($Search);
    $data['RoomOnline']                     =  $this->getRoomfrombase($Search,'online');
    $data['RoomDirect']                     =  $this->getRoomfrombase($Search,'offline');
    $data['RoomCommissioned']               =  $this->getRoomCommissioned($Search,'offline', 'commission');
    
    $data['RoomWithoutCommission']          =  $this->getRoomCommissioned($Search,'offline', 'non_commission');
    if(!empty($data['avgRoomRents']) && !empty($data['totalCheckIn'])){
        
        $data['avgRoomRent'] = ($data['avgRoomRents']['totalRoomRent'] / $data['totalCheckIn']['totalCheckin']);
    }
    if (!empty($data['occupencyRoom']) && !empty($data['totalRoom'])) {
        $data['occupancyPercentage']            = ($data['occupencyRoom'] / $data['totalRoom']) * 100 ?? 0;
    }
    $data['totalOtaSale']           =  $this->getTotalOtaSale($Search);

    $shortField = 'hs.service_name ASC, hs.service_id ASC';
    $HWhereCon['where'] = "";
    $tblName = 'hotel_services as hs';
    $data['ExpenditureData'] = $this->selectHotelServiceData($Search);

    //Compare Data

    if(!empty($data['VendorArrComp'])){
        $Search['VendorArr'] = $Search['VendorArrComp'];
        //echo $Search['VendorArr']; exit;
        $data['totalSaleComp']                      =  $this->getTotalSaleByManagerId($Search);
        $data['directBookingModeComp']              =  $this->getTotalSaleByOnlineDirectModeWise($Search,'offline');
        $data['onlineBookingModeComp']              =  $this->getTotalSaleByOnlineDirectModeWise($Search,'online');
        $data['onlinePrepaidBookingModeComp']       =  $this->getTotalSaleByDirectCommissionMode($Search,'online','prepaid');
        $data['totalCashPaymentComp']               =  $this->getTotalPaymentsReceivedByPaymentMode($Search,'offline');
        $data['totalOnlinePaymentComp']             =  $this->getTotalPaymentsReceivedByPaymentMode($Search,'online');
        $data['totalOnlinePrepaidComp']             =  $this->getTotalPaymentsReceivedByPaymentMode($Search,'prepaid');
        $data['totalOnlineBtcComp']             =  $this->getTotalPaymentsReceivedByPaymentMode($Search,'BTC');
        $data['totalExpenceComp']                   =  $this->getTotalPaymentsExpences($Search);

        $data['ownerWalletComp']                    =  $this->getTotalOwnersWallet($Search);
        $data['avgRoomRentsComp']                    =  $this->getTotalAverageRoomRent($Search);
        //$data['foodAndOtherServices']           =  $this->getTotalTotalFoodAndOtherServices($Search);
        $data['occupencyRoomComp']                  =  $this->getOccupencyRoom($Search);
        $data['totalRoomComp']                      =  $this->getTotalRoom($Search);
        $data['totalCheckInComp']                   =  $this->getCheckIn($Search);
        $data['totalCheckoutComp']                  =  $this->getCheckOut($Search);
        $data['RoomOnlineComp']                     =  $this->getRoomfrombase($Search,'online');
        $data['RoomDirectComp']                     =  $this->getRoomfrombase($Search,'offline');
        $data['RoomCommissionedComp']               =  $this->getRoomCommissioned($Search,'offline', 'commission');
        
        $data['RoomWithoutCommissionComp']          =  $this->getRoomCommissioned($Search,'offline', 'non_commission');
        if(!empty($data['avgRoomRentsComp']) && !empty($data['totalCheckInComp'])){
             
            $data['avgRoomRentComp'] = ($data['avgRoomRentsComp']['totalRoomRent'] / $data['totalCheckInComp']['totalCheckin']);
        }
        if (!empty($data['occupencyRoomComp']) && !empty($data['totalRoomComp'])) {
            $data['occupancyPercentageComp']            = ($data['occupencyRoomComp'] / $data['totalRoomComp']) * 100 ?? 0;
        }
        $data['totalOtaSaleComp']           =  $this->getTotalOtaSale($Search);

        $shortField = 'hs.service_name ASC, hs.service_id ASC';
        $HWhereCon['where'] = "";
        $tblName = 'hotel_services as hs';
        $data['ExpenditureDataComp'] = $this->selectHotelServiceData($Search);
        
    }
    $data['HotelList'] = $HotelList;
    //End
    $this->layouts->set_title('Manage Business report');
    $this->layouts->owner_view('owner/businessreport/index', array(), $data);
  }
  function getTotalSaleByManagerId($Search){
    $LoginVenderId = sessionData('MHM_OWNER_ID');
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('SUM(csd.payment_paid) as totalSale,csd.page_source');
    $this->db->from('customer_summary_details as csd');
    //$whereCon['like'] = "csd.creation_date BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'";
    $this->db->where("DATE_FORMAT(csd.creation_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'");  
    $this->db->where("csd.hotel_manager_id",$hotel_manager_id); 
    $this->db->where("csd.page_source='add_an_advance'");
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($query->num_rows() > 0) :
      return $query->row_array();
    else :
      return false;
    endif;
  }
  function getTotalSaleByOnlineDirectModeWise($Search,$modeType){
    $LoginVenderId = sessionData('MHM_OWNER_ID');
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('SUM(csb.commission_amount) as totalDirectCommision');
    $this->db->from('customer_summary_book as csb');
    if ($Search['toDate']!=''){
      $this->db->where("DATE_FORMAT(csb.creation_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'");
    } 
    $this->db->where("csb.hotel_manager_id",$hotel_manager_id); 
    $this->db->where("csb.reffer_mode", $modeType);
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
        return $query->row_array();
    else :
        return false;
    endif;
  }
  function getTotalSaleByDirectCommissionMode($Search,$modeType,$directType){
    $LoginVenderId = sessionData('MHM_OWNER_ID');
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('SUM(csb.prepaid_amount) as prepaidCommision,SUM(csb.commission_amount) as totalCommision');
    $this->db->from('customer_summary_book as csb');
    if ($Search['toDate']!=''){
      $this->db->where("DATE_FORMAT(csb.creation_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'");
    } 
    $this->db->where("csb.reffer_mode", $modeType);
    if ($modeType == 'offline'){
      $this->db->where("csb.direct_mode", $directType);
    }else{
      $this->db->where("csb.online_mode", $directType);
    }
    $this->db->where("csb.hotel_manager_id",$hotel_manager_id); 
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
        return $query->row_array();
    else :
        return false;
    endif;
  }
  function getTotalPaymentsReceivedByPaymentMode($Search,$paymentType){
    $LoginVenderId = sessionData('MHM_OWNER_ID');
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('SUM(csd.payment_paid) as totalAmount');
    $this->db->from('customer_summary_details as csd');
    if ($Search['toDate']!=''){
      $this->db->where("DATE_FORMAT(csd.order_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'"); 
    } 
    $this->db->where("csd.hotel_manager_id",$hotel_manager_id); 
    $this->db->where("csd.amount_mode", $paymentType);
    $this->db->where("csd.daybook_mode='In'");
    $query = $this->db->get();
    //echo $this->db->last_query();die;
    if ($query->num_rows() > 0) :
        return $query->row_array();
    else :
        return false;
    endif;
  }
  function getTotalPaymentsExpences($Search){
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('*');
    $this->db->from('customer_summary_details as csd');
    if ($Search['toDate']!=''){
      $this->db->where("DATE_FORMAT(csd.creation_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'"); 
    } 
    $this->db->where("csd.hotel_manager_id",$hotel_manager_id); 
    $this->db->where("csd.daybook_mode = 'Out'");
    $query = $this->db->get();
    //echo $this->db->last_query();die;
    if ($query->num_rows() > 0) :
        return $query->result_array();
    else :
        return false;
    endif;
  }
  function getTotalOwnersWallet($Search){
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('SUM(csd.amount_out) as ownerWallet');
    $this->db->from('customer_summary_details as csd');
    if ($Search['toDate']!=''){
      $this->db->where("DATE_FORMAT(csd.creation_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'"); 
    } 
    $this->db->where("csd.hotel_manager_id",$hotel_manager_id); 
    $this->db->where('csd.owners_wallet="Y"');
    $this->db->where("csd.daybook_mode = 'Out'");
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
      return $query->row_array();
    else :
      return false;
    endif;
  }
  function getTotalAverageRoomRent($Search){
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('SUM(csd.amount) as totalRoomRent');
    $this->db->from('customer_summary_book as csd');
    if ($Search['toDate']!=''){
      $this->db->where("DATE_FORMAT(csd.check_in_datetime,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'"); 
    } 
    $this->db->where("csd.hotel_manager_id",$hotel_manager_id); 
    //$this->db->where("csd.page_source='extend_stay'");
    //$this->db->where('room_rent_status', 'Y');
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
      return $query->row_array();
    else :
      return false;
    endif;
  }
  function getTotalTotalFoodAndOtherServices($Search){
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('SUM(csd.advance_paid) as totalRoomRent');
    $this->db->from('customer_summary_details as csd');
    if ($Search['toDate']!=''){
      $this->db->where("DATE_FORMAT(csd.creation_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'"); 
    } 
    $this->db->where("csd.hotel_manager_id",$hotel_manager_id); 
    $this->db->where("csd.page_source='add_a_service'");
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
      return $query->row_array();
    else :
      return false;
    endif;
  }
  function getOccupencyRoom($Search){
    $hotel_manager_id = $Search['VendorArr'];

    $this->db->select('rm.id');
        $this->db->from('room_number as rm');
        $this->db->where("rm.hotel_manager_id",$hotel_manager_id);
        $this->db->group_start(); //this will start grouping
        $this->db->where('rm.status',1);
        $this->db->where('rm.room_no_use =', 'N');
        $this->db->or_where('rm.room_no_use =', "D");
        $this->db->group_end();
		$query = $this->db->get();
        //echo $this->db->last_query(); die;
        return $query->num_rows();
    //$this->db->select('csb.assign_room_number as occupencyPercentage');
    //$this->db->from('customer_summary_book as csb');
    // if ($Search['toDate']!=''){
    //   $this->db->where("DATE_FORMAT(csb.creation_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'"); 
    // } 
    //$this->db->where("csb.hotel_manager_id",$hotel_manager_id); 
    //$this->db->group_by('csb.assign_room_number');
    //$query = $this->db->get();
    //echo $this->db->last_query(); die;
    //return $query->num_rows();
  }
  function getTotalRoom($Search){
   
    $hotel_manager_id = $Search['VendorArr'];
    
    $this->db->select('room_no');
    $this->db->from('room_number');
    $this->db->where('status', 'Y');
    $this->db->where("hotel_manager_id",$hotel_manager_id); 
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    return $query->num_rows();
  }
  function getRoomfrombase($Search,$type){
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('COUNT(csb.assign_room_number) as roomCount');
    $this->db->from('customer_summary_book as csb');
    if ($Search['toDate']!=''){
      $this->db->where("DATE_FORMAT(csb.creation_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'"); 
    } 
    $this->db->where("csb.hotel_manager_id",$hotel_manager_id); 
    $this->db->where('csb.reffer_mode', $type);
    //$this->db->group_by('csb.assign_room_number');
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    return $query->row_array();
  }
  function getRoomCommissioned($Search, $type, $subType){
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('COUNT(csb.assign_room_number) as roomCountdata');
    $this->db->from('customer_summary_book as csb');
    if ($Search['toDate']!=''){
      $this->db->where("DATE_FORMAT(csb.creation_date,'%Y-%m-%d') BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "'"); 
    } 
    $this->db->where("csb.hotel_manager_id",$hotel_manager_id); 
    $this->db->where('csb.reffer_mode', $type);
    $this->db->where('csb.direct_mode', $subType);
    //$this->db->group_by('csb.assign_room_number');
    $query = $this->db->get();
    return $query->row_array();
  }
  function getTotalOtaSale($Search){
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('om.*');
    $this->db->from('ots_master as om');
    $this->db->where("om.hotel_manager_id",$hotel_manager_id); 
    $query = $this->db->get();
    //echo $this->db->last_query();die;
    if ($query->num_rows() > 0) :
      return $query->result_array();
    else :
      return false;
    endif;
  } 
  function selectHotelServiceData($Search){
    $hotel_manager_id = $Search['VendorArr'];
    $this->db->select('hs.*');
    $this->db->from('hotel_services as hs');
    $this->db->order_by('hs.service_name ASC, hs.service_id ASC');
    $this->db->where("hs.hotel_manager_id",$hotel_manager_id);
    $query = $this->db->get();
    if ($query->num_rows() > 0) :
      return $query->result_array();
    else :
      return false;
    endif;
  }
    function getCheckIn($Search){
        $id = 'is null';
        $hotel_manager_id = $Search['VendorArr'];
        $BookQuery = "SELECT COUNT(`csb`.`id`) as totalCheckin FROM ".getTablePrefix()."customer_summary_book as `csb` WHERE `csb`.`hotel_manager_id` = '".$hotel_manager_id."' AND DATE(csb.check_in_datetime) BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "' ORDER BY `csb`.`check_in_datetime` DESC";
        //echo $BookQuery; exit;
            $Result = $this->common_model->getDataByQuery('single', $BookQuery);       
        return $Result;
    }
    function getCheckOut($Search){

        $hotel_manager_id = $Search['VendorArr'];

        $BookQuery = "SELECT COUNT(`csb`.`id`) as totalCheckout FROM ".getTablePrefix()."customer_summary_book as `csb` WHERE `csb`.`hotel_manager_id` = '".$hotel_manager_id."' AND DATE(csb.check_out_datetime) BETWEEN '" . $Search['toDate'] . "' AND '" . $Search['fromDate'] . "' AND `csb`.`check_in_datetime` IS NOT NULL  ORDER BY `csb`.`check_in_datetime` DESC";
            $Result = $this->common_model->getDataByQuery('single', $BookQuery);       
        return $Result;
        
    }

}
