<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Billbookdata extends CI_Controller{

  public function __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'emailtemplate_model', 'sms_model','owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','general','owner');
    $this->ownerauth_model->authCheck();
  }
  public function index(){
    $data['error'] = '';
    $data['activeMenu'] = 'BillBook';
    $data['activeSubMenu'] = 'BillBook';
    if(!empty($this->session->userdata('MHM_IS_OWNER'))){
        $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    }
    else{
        $data['HotelList'] = $this->owner_model->GetSubOwnerVendorList();
    }
    $this->layouts->set_title('Manage Bill Book Summary');
    $this->layouts->owner_view('owner/billbook/index', array(), $data);
  }
  
  function BillBookPagination(){
    $Search['m_name']         = $_GET['m_name'] ?? '';
    $Search['c_name']         = $_GET['c_name'] ?? '';
    $Search['entry_no']       = $_GET['entry_no'] ?? '';
    $Search['check_in']       = $_GET['check_in'] ?? '';
    $Search['check_out']      = $_GET['check_out'] ?? '';
    $Search['mobile']         = $_GET['mobile'] ?? '';
    $Search['VendorArr']      = $_GET['VendorArr'] ?? '';
    $Search['room_no']        = $_GET['room_no'] ?? '';
    $Search['user_status']    = $_GET['user_status'] ?? 'All';
    $Search['page']           = $_GET['page'] ?? 1;
    $Search['numofrecords']   = $_GET['numofrecords'] ?? 100;
    $Search['cur_page']       = $Search['page'];
    $Limitpage                = $Search['page']-1;
    $Search['start']          = $Limitpage * $Search['numofrecords'];

    $Search['action'] = 'count';
    $TotalData = $this->BillBookPaginationData($Search);
    $data['PAGINATION'] = Pagination($Search['numofrecords'],$TotalData, $Search['page']);
    $data['noOfContent'] = 'Showing ' . $Search['page'] . '-' . $Search['numofrecords'] . ' of ' . $TotalData . ' items';
    $Search['action'] = 'data';
    $data['ALLDATA'] = $this->BillBookPaginationData($Search);
    $data['VendorID'] = $Search['VendorArr'];

    $this->load->view('owner/billbook/Pagination', $data);
  }
  function BillBookPaginationData($Search){
    //$this->db->select('csb.*,rn.room_no');
    $this->db->select('csb.*');
    $this->db->from('customer_summary_book as csb');
    //$this->db->join('room_number as rn', 'csb.assign_room_number = rn.room_id', 'LEFT');
    if($Search['m_name']!=''){ $this->db->where("csb.hotel_manager_name LIKE '%" . $Search['m_name'] . "%'"); }
    if($Search['c_name']!=''){ $this->db->where("csb.customer_name LIKE '%" . $Search['c_name'] . "%'"); }
    if($Search['entry_no']!=''){ $this->db->where("csb.entry_number LIKE '%" . $Search['entry_no'] . "%'"); }
    if($Search['check_in']!=''){ $this->db->where("csb.check_in_datetime LIKE '%" . $Search['check_in'] . "%'"); }
    if($Search['check_out']!=''){ $this->db->where("csb.check_out_datetime LIKE '%" . $Search['check_out'] . "%'"); }
    if($Search['mobile']!=''){ $this->db->where("csb.customer_mobile_number LIKE '%" . $Search['mobile'] . "%'"); }
    if($Search['room_no']!=''){ 
      $RoomQuery = "SELECT room_id FROM " . getTablePrefix() . "room_number WHERE room_no = '" . $Search['room_no'] . "' AND hotel_manager_id='".$Search['VendorArr']."' ";
      $Room = $this->common_model->getDataByQuery('single', $RoomQuery);
      //echo $Room['room_id'];echo '<br/>';
      if($Room['room_id']!=''){
        $this->db->where("csb.assign_room_number",$Room['room_id']); 
      }
    }
    if($Search['user_status']!='All'){ $this->db->where("csb.user_status",$Search['user_status']); }
    $this->db->where("csb.hotel_manager_id",$Search['VendorArr']); 
    $this->db->where('csb.check_out_datetime !=', "NULL");
    $this->db->order_by('csb.check_out_datetime DESC');
    if ($Search['action']=='data'){$this->db->limit($Search['numofrecords'], $Search['start']); }
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($Search['action'] == 'data'){
      if ($query->num_rows() > 0){
        return $query->result_array();
      }else{
        return false;
      }
    }elseif ($Search['action'] == 'count'){
      return $query->num_rows();
    }
  }
  function setCustomebillbook($customerId){
    try {
      $data['error'] = '';
      $data['activeMenu'] = 'BillBook';
      $data['activeSubMenu'] = 'BillBook';
      $data['customerId'] = $customerId;
      $data['CUSTOMERDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'summary_book_id', $customerId);
      $data['LoginVenderId'] = $data['CUSTOMERDATA']['hotel_manager_id'];
      $data['customerInfo'] = $this->vendor_model->getCustomerInfo($customerId);
      $data['VENDORDATA'] = $this->common_model->getDataByParticularField('vendor', 'vendor_id', $data['LoginVenderId']);
      $data['VENDORDETAIL'] = $this->common_model->getDataByParticularField('vendor_details', 'vendor_id', $data['LoginVenderId']);
      //check bill generate or not
      $data['checkBillGenerate'] = $this->common_model->getDataByParticularField('customer_summary_book', 'summary_book_id', $customerId);
      if ($data['checkBillGenerate']['user_status'] == '2'):
        $summaryQuery = "SELECT csd.id,csd.service_gst,csd.bill_generated_date,csd.bill_item,csd.bill_amount as advance_paid,csd.page_source FROM " .getTablePrefix() . "custom_bill_book as csd WHERE csd.customer_id LIKE '" . $data['customerId'] . "'";
        $data['SUMMARYDETAIL'] = $this->common_model->getDataByQuery('multiple', $summaryQuery);
      elseif ($data['checkBillGenerate']['user_status'] == '1'):
        // remove 'add_a_service' condition ad per the discussion date : 27:01:2023
        $summaryQuery = "SELECT csd.detail_book_id,csd.hotel_manager_name,csd.order_date,csd.bill_item,csd.amount_mode,csd.advance_paid,csd.payment_paid,csd.page_source FROM " . getTablePrefix() . "customer_summary_details as csd WHERE csd.customer_id LIKE '" . $data['customerId'] . "' AND (csd.page_source LIKE '%extend_stay%' OR csd.page_source LIKE '%add_a_service%' OR csd.page_source LIKE '%add_a_services%')";
        //echo '<pre>';print_r($data);die;
        $data['SUMMARYDETAIL'] = $this->common_model->getDataByQuery('multiple', $summaryQuery);
        //echo '<pre>';print_r($data['SUMMARYDETAIL']);die;
      endif;
      //end
      $delQuery = "SELECT room_no FROM " . getTablePrefix() . "room_number WHERE room_id = '" . $data['CUSTOMERDATA']['assign_room_number'] . "' AND hotel_manager_id = '" . $data['LoginVenderId'] . "'";
      $data['ASSIGNROOM'] = $this->common_model->getDataByQuery('single', $delQuery);
      $this->layouts->owner_view('owner/billbook/setcustomeinvoice', array(), $data);
    } catch (\Exception $e) {
      echo "<pre>";
      print_r($e);
      echo "</pre>";
      die;
    }
  }
  function UpdateCustomerData(){
    try {
      $data['customerId'] = $this->input->post('customeID');
      $data['CUSTOMERDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'summary_book_id', $data['customerId']);
      $data['LoginVenderId'] = $data['CUSTOMERDATA']['hotel_manager_id'];

      $data['VENDORDATA'] = $this->common_model->getDataByParticularField('vendor', 'vendor_id', $data['LoginVenderId']);
      $data['VENDORDETAIL'] = $this->common_model->getDataByParticularField('vendor_details', 'vendor_id', $data['LoginVenderId']);      
      //echo '<pre>';print_r($_POST);die;
      if ($this->input->post('SaveChanges')):
        //$this->generatelogs->putLog('VENDOR', logOutPut($_POST));
        //echo '<pre>';print_r($data['VENDORDETAIL']);die;
        $error = 'NO';
        $this->form_validation->set_rules('TotalFilterDefault', 'lang:TotalDetails', 'trim');
        $totaldetails = $this->input->post('TotalFilterDefault');
        if ($totaldetails):
          for ($i = 1; $i <= $totaldetails; $i++):
            if ($i == 1):
              $this->form_validation->set_rules('filter_details_id_' . $i, 'lang:Filter Details', 'trim');
              $this->form_validation->set_rules('bill_item_' . $i, 'lang:bill_item_', 'trim|required');
              $this->form_validation->set_rules('advance_amount_' . $i, 'lang:advance amount', 'trim|required');
            else:
              $this->form_validation->set_rules('filter_details_id_' . $i, 'lang:Filter Details', 'trim');
              $this->form_validation->set_rules('bill_item_' . $i, 'lang:Details', 'trim');
              $this->form_validation->set_rules('advance_amount_' . $i, 'lang:Question Type', 'trim');
            endif;
            $data['filter_details_id_' . $i] = $this->input->post('filter_details_id_' . $i);
            $data['bill_item_' . $i] = $this->input->post('bill_item_' . $i);
            $data['advance_amount_' . $i] = $this->input->post('advance_amount_' . $i);
          endfor;
          $data['TotalFilterDefault'] = $this->input->post('TotalFilterDefault');
        endif;
        if ($this->form_validation->run() && $error == 'NO'):
          $totaldetails = $this->input->post('TotalFilterDefault');
          if ($totaldetails):
            $this->vendor_model->delete_item_data($data['customerId']);
            $AllFilterIds = $this->input->post('AllFilterIds') ? explode('_____', $this->input->post('AllFilterIds')) : array();
            for ($i = 1; $i <= $totaldetails; $i++):
              if ($this->input->post('bill_item_' . $i)):
                $optparams['customer_id'] = $this->input->post('customeID');
                $optparams['bill_number'] = $this->input->post('bill_number');
                $optparams['bill_generated_date'] = $this->input->post('date');
                if ($this->input->post('room_rent_type') == 'gst_include') {
                  $optparams['total_amount'] = $this->input->post('total_amount');
                  $optparams['cgst'] = round($this->input->post('total_amount') / 2);
                  $optparams['sgst'] = round($this->input->post('total_amount') / 2);
                  $optparams['paybal_amount'] = round($this->input->post('paybal_amount'));
                } elseif ($this->input->post('room_rent_type') == 'gst_exclude') {
                  $optparams['total_amount'] = $this->input->post('total_amount');
                  $optparams['cgst'] = $this->input->post('amount2') / 2;
                  $optparams['sgst'] = $this->input->post('amount2') / 2;
                  $optparams['paybal_amount'] = $optparams['total_amount'] + $optparams['cgst'] + $optparams['sgst'];
                } elseif (empty($this->input->post('room_rent_type'))) {
                  $optparams['total_amount'] = $this->input->post('total_amount');
                  $optparams['cgst'] = $this->input->post('amount2') / 2;
                  $optparams['sgst'] = $this->input->post('amount2') / 2;
                  $optparams['paybal_amount'] = $optparams['total_amount'] + $optparams['cgst'] + $optparams['sgst'];
                }
                $optparams['summary_detail_id'] = $this->input->post('filter_details_id_' . $i);
                $optparams['bill_item'] = $this->input->post('bill_item_' . $i);
                $optparams['bill_amount'] = $this->input->post('advance_amount_' . $i);
                $optparams['page_source'] = $this->input->post('page_source_' . $i);
                $optparams['service_gst'] = $this->input->post('service_gst_' . $i);
                $optparams['hotel_manager_id'] = $data['LoginVenderId'];
                if ($this->input->post('bill_item_' . $i) != ''):
                  $optparams['creation_date'] = currentDateTime();
                  $optparams['created_by'] = $data['LoginVenderId'];
                  //echo '<pre>';print_r($optparams);
                  $this->common_model->addData('custom_bill_book', $optparams);
                endif;
                $params['gst_number'] = $this->input->post('gst_number');
                $params['company_name'] = $this->input->post('company_name');
                $params['company_address'] = $this->input->post('company_address');
                $params['user_status'] = 2;
                $this->common_model->editData('customer_summary_book', $params, 'summary_book_id', $data['customerId']);
              endif;
            endfor;
            //die;
            // Update Bill Number Date: 18-01-2023
            $ENTparam['bill_number'] = $this->input->post('bill_number');
            //$ENTparam['other_details'] = addslashes($this->input->post('other_details'));
            $ENTwhere['vendor_id'] = $data['LoginVenderId'];
            $URMparam['update_date'] = currentDateTime();
            $this->common_model->editDataByMultipleCondition('vendor_details', $ENTparam, $ENTwhere);
          endif;
        endif;
      endif;
      $this->session->set_flashdata('alert_success', lang('updatesuccess'));
      redirect('owner/billbookdata/setCustomebillbook/'.$data['customerId']);
    } catch (\Exception $e) {
      echo "<pre>";
      print_r($e);
      echo "</pre>";
      die;
    }
  }
  public function downloadbillbookdata(){
    try {
        require_once APPPATH . 'third_party/classes/PHPExcel.php';
        $objPHPExcel = new PHPExcel();
        $Search['fromDate'] = $_GET['fromDate'];
        $Search['toDate'] = $_GET['toDate'];
        $Search['businessType'] = $_GET['businessType'];
        $Search['VendorArr'] = $_GET['VendorID'];
        $Search['reffer_mode'] = $_GET['reffer_mode'];
        $Search['direct_mode'] = $_GET['direct_mode'];
        $Search['ots_id'] = $_GET['ots_id'];
        $Search['choose_plan'] = $_GET['choose_plan'];
        $Search['bill_generated'] = $_GET['bill_generated'];
        $Search['amount_mode'] = $_GET['amount_mode'];
        $range = $_GET['range'];
        if($range == 'today'){
            $dates = date('Y-m-d');
            $dates2 = date('Y-m-d');
            $Search['toDate']       = $dates;
            $Search['fromDate']     = $dates2;
        }
        elseif($range == 'yesterday'){
            $dates = date('Y-m-d',strtotime("-1 days"));
            //$dates2 = date('Y-m-d');
            $Search['toDate']       = $dates;
            $Search['fromDate']     = $dates;
        }
        elseif($range == 'week'){
            $start = (date('D') != 'Mon') ? date('Y-m-d', strtotime('last Monday')) : date('Y-m-d');
            $finish = (date('D') != 'Sun') ? date('Y-m-d', strtotime('next Sunday')) : date('Y-m-d');
            $Search['toDate']       = $finish;
            $Search['fromDate']     = $start;
        }
        elseif($range == 'last_month'){
            $start = date("Y-m-d", strtotime("first day of previous month"));
            $finish = date("Y-m-d", strtotime("last day of previous month"));
            $Search['toDate']       = $finish;
            $Search['fromDate']     = $start;
        }
        elseif($range == 'till_now'){
            $start = date("Y-m-01");
            $finish = date("Y-m-d");
            $Search['toDate']       = $finish;
            $Search['fromDate']     = $start;
        }
        
      $billbookdata = $this->owner_model->getAllGuestDataForExcelDownloadOwner($Search);
      //echo "<pre>"; print_r($billbookdata); exit;
      if ($billbookdata != "") :
        $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")->setLastModifiedBy("Maarten Balliauw")->setTitle("Office 2007 XLSX Test Document")->setSubject("Office 2007 XLSX Test Document")->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")->setKeywords("office 2007 openxml php")->setCategory("Test result file");
        $objPHPExcel->setActiveSheetIndex(0);
        $objPHPExcel->getActiveSheet()->setCellValue('A2', "Guest Name")
            ->setCellValue('B2', "GRC No.")
            ->setCellValue('C2', "Room Number")
            ->setCellValue('D2', "Bill Number")
            ->setCellValue('E2', "OTA")
            ->setCellValue('F2', "No. Of Persons")
            ->setCellValue('G2', "No. Of Days")
            ->setCellValue('H2', "Check in date and time")
            ->setCellValue('I2', "Check Out date and time")
            ->setCellValue('J2', "Company GSTIN")
            ->setCellValue('K2', "Company Name")
            ->setCellValue('L2', "Rent")
            ->setCellValue('M2', "Total Rent")
            ->setCellValue('N2', "CGST")
            ->setCellValue('O2', "SGST")
            ->setCellValue('P2', "Grand Total (Room Rent)")
            ->setCellValue('Q2', "Payment Details for offline")
            ->setCellValue('R2', "Payment Details for Online")
            ->setCellValue('S2', "Payment Details for Prepaid")
            ->setCellValue('T2', "Payment Details for BTC")
            ->setCellValue('U2', "Total Food Bill")
            ->setCellValue('V2', "CGST")
            ->setCellValue('W2', "SGST")
            ->setCellValue('X2', "Grand Total Food Bill")
            ->setCellValue('Y2', "BLANK")
            ->setCellValue('Z2', "Grand Total Paybal");
        $objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("A")->setWidth('15');
        $objPHPExcel->getActiveSheet()->getColumnDimension("B")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("C")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("D")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("E")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("F")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("G")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("H")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("I")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("J")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("K")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("L")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("M")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("N")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("O")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("P")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("Q")->setWidth('90');
        $objPHPExcel->getActiveSheet()->getColumnDimension("R")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("S")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("T")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("U")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("V")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("W")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("X")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("Y")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getColumnDimension("Z")->setWidth('30');
        $objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('B2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('C2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('E2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('F2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('G2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('H2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('I2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('J2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('K2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('L2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('M2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('N2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('O2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('P2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('Q2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('R2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('S2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('T2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('U2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('V2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('W2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('X2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('Y2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getStyle('Z2')->applyFromArray(cellAlignment());
        $objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1, 1);
        $i = 2;
        $totOffline =  $totOnline = $totPrepaid = $totBtc = 0;
        foreach ($billbookdata as $billbookdatainfo) {
          $amountOffline = $amountOnline = $amountPrepaid = $amountBtc = 0;
          $foodBillData = $this->common_model->getFoodBillTotalAmount($billbookdatainfo['customer_id']);
          //echo "<pre>"; print_r($foodBillData);die;
            if($Search['amount_mode'] =='All'){
                $summaryQuery2 = "SELECT bill_item,amount_mode,payment_paid,page_source FROM ".getTablePrefix()."customer_summary_details as csd WHERE customer_id='".$billbookdatainfo['summary_book_id']."' 
                ";
            }
            else{
                if($Search['amount_mode']=='CashOnline'){
                    $summaryQuery2 = "SELECT bill_item,amount_mode,payment_paid,page_source FROM ".getTablePrefix()."customer_summary_details as csd WHERE 
                    customer_id='".$billbookdatainfo['summary_book_id']."''
                     AND (amount_mode ='online' OR amount_mode ='offline')  ";
                }
                else{
                    $summaryQuery2 = "SELECT bill_item,amount_mode,payment_paid,page_source FROM ".getTablePrefix()."customer_summary_details as csd WHERE
                     customer_id='".$billbookdatainfo['summary_book_id']."' AND amount_mode ='".$Search['amount_mode']."'
                     ";
                }
                
            }
            //echo $summaryQuery2; exit;
            $summaryQuery = "SELECT bill_item,amount_mode,payment_paid,page_source FROM ".getTablePrefix()."customer_summary_details as csd WHERE 
            customer_id='".$billbookdatainfo['summary_book_id']."' 
            ";
            $SUMMARYDETAIL = $this->common_model->getDataByQuery('multiple', $summaryQuery);
            $SUMMARYDETAIL2 = $this->common_model->getDataByQuery('multiple', $summaryQuery2);
            if((!empty($SUMMARYDETAIL) && $Search['amount_mode'] =='All') || ($Search['amount_mode'] !='All' && $SUMMARYDETAIL2)){
                $productname='';    
                $CheckData = 0;  
                $amoun = $tOffline =  $amountOnline = $amountPrepaid = $amountBtc = 0;
                foreach ($SUMMARYDETAIL2 as $row) {
                    if($Search['amount_mode'] =='All'){

                        if($row['amount_mode'] == 'offline'){
                            $amountOffline = $amountOffline + $row['payment_paid'];
                        }
                        if ($row['amount_mode'] == 'online') {
                            $amountOnline = $amountOnline + $row['payment_paid'];
                        }
                        if ($row['amount_mode'] == 'prepaid') {
                            $amountPrepaid = $amountPrepaid + $row['payment_paid'];
                        }
                        if ($row['amount_mode'] == 'BTC') {
                            $amountBtc = $amountBtc + $row['payment_paid'];
                        }
                    }
                    elseif($Search['amount_mode']=='CashOnline'){

                        if($row['amount_mode'] == 'offline'){
                            $amountOffline = $amountOffline + $row['payment_paid'];
                        }
                        if ($row['amount_mode'] == 'online') {
                            $amountOnline = $amountOnline + $row['payment_paid'];
                        }
                    }
                    else{
                        if($row['amount_mode'] == 'offline'){
                            $amountOffline = $amountOffline + $row['payment_paid'];
                        }
                        if($row['amount_mode'] == 'online'){
                            $amountOnline = $amountOnline + $row['payment_paid'];
                        }
                        if($row['amount_mode'] == 'prepaid'){
                            $amountPrepaid = $amountPrepaid + $row['payment_paid'];
                        }
                        if($row['amount_mode'] == 'BTC'){
                            $amountBtc = $amountBtc + $row['payment_paid'];
                        }
                    }
                }
                $totOffline = $totOffline + $amountOffline;
                $totOnline = $totOnline + $amountOnline;
                $totPrepaid = $totPrepaid + $amountPrepaid;
                $totBtc = $totBtc + $amountBtc;
                if ($billbookdatainfo['gstType']  == "gst_include") {
                    $totalPaybalRoomAmount  = $billbookdatainfo['totalRoomRent'];
                    $totalGstAmount  = round($billbookdatainfo['totalRoomRent'] / 1.12);
                    $totalAmnt  = round($totalGstAmount * 12) / 100;
                    $TTGst  = $PaybalAmountRoom - $totalAmnt;
                    $cgst  = $totalAmnt / 2;
                    $sgst  = $totalAmnt / 2;
                    $totalAmount  = $totalGstAmount;
                } elseif ($billbookdatainfo['gstType']  == "gst_exclude") {
                    $totalAmount  = round($billbookdatainfo['totalRoomRent'] * 12) / 100;
                    $cgst  = $totalAmount / 2;
                    $sgst  = $totalAmount / 2;
                    $totalPaybalRoomAmount  = $billbookdatainfo['totalRoomRent'] + $totalAmount;
                } elseif (empty($billbookdatainfo['gstType'])) {
                    $totalAmount  = round($billbookdatainfo['totalRoomRent'] * 12) / 100;
                    $cgst  = $totalAmount / 2;
                    $sgst  = $totalAmount / 2;
                    $totalPaybalRoomAmount  = $billbookdatainfo['totalRoomRent'] + $totalAmount;
                }
                // Food Bill Start
                if ($billbookdatainfo['gstType']  == "gst_include") {
                    $totalFoodAmount  = round($foodBillData['totalfoodbill'] * 5) / 100;
                    $fcgst  = $totalFoodAmount / 2;
                    $fsgst  = $totalFoodAmount / 2;
                    $totalPaybalFoodAmount  = $foodBillData['totalfoodbill'] + $totalFoodAmount;
                } elseif ($billbookdatainfo['gstType']  == "gst_exclude") {
                    $totalFoodAmount  = round($foodBillData['totalfoodbill'] * 5) / 100;
                    $fcgst  = $totalFoodAmount / 2;
                    $fsgst  = $totalFoodAmount / 2;
                    $totalPaybalFoodAmount  = $foodBillData['totalfoodbill'] + $totalFoodAmount;
                } elseif (empty($billbookdatainfo['gstType'])) {
                    $totalFoodAmount  = round($foodBillData['totalfoodbill'] * 5) / 100;
                    $fcgst  = $totalFoodAmount / 2;
                    $fsgst  = $totalFoodAmount / 2;
                    $totalPaybalFoodAmount  = $foodBillData['totalfoodbill'] + $totalFoodAmount;
                }
                //Grand Total Both
                $GrandTotalFoodAndRoom  = $totalPaybalRoomAmount + $totalPaybalFoodAmount;
                // End

                $j = $i + 1;
                //$objPHPExcel->getActiveSheet()->setCellValue('A'.$j, $i);
                $objPHPExcel->getActiveSheet()->setCellValue('A' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['customer_name'])));
                $objPHPExcel->getActiveSheet()->setCellValue('B' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['entry_number'])));
                $objPHPExcel->getActiveSheet()->setCellValue('C' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['room_no'])));
                $objPHPExcel->getActiveSheet()->setCellValue('D' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['bill_number'])));
                $objPHPExcel->getActiveSheet()->setCellValue('E' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['ots_name'])));
                $objPHPExcel->getActiveSheet()->setCellValue('F' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['number_of_person'])));
                $objPHPExcel->getActiveSheet()->setCellValue('G' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['totalDays'])));
                $objPHPExcel->getActiveSheet()->setCellValue('H' . $j, htmlspecialchars_decode(date('d M Y H:i:s', strtotime($billbookdatainfo['check_in_datetime']))));
                $objPHPExcel->getActiveSheet()->setCellValue('I' . $j, htmlspecialchars_decode(date('d M Y H:i:s', strtotime($billbookdatainfo['check_out_datetime']))));
                $objPHPExcel->getActiveSheet()->setCellValue('J' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['gst_number'])));
                $objPHPExcel->getActiveSheet()->setCellValue('K' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['company_name'])));
                $objPHPExcel->getActiveSheet()->setCellValue('L' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['roomrent'])));
                $objPHPExcel->getActiveSheet()->setCellValue('M' . $j, htmlspecialchars_decode(stripslashes($billbookdatainfo['totalRoomRent'])));
                $objPHPExcel->getActiveSheet()->setCellValue('N' . $j, htmlspecialchars_decode(stripslashes($cgst)));
                $objPHPExcel->getActiveSheet()->setCellValue('O' . $j, htmlspecialchars_decode(stripslashes($sgst)));
                if ($billbookdatainfo['gstType']  == 'gst_include') {
                $objPHPExcel->getActiveSheet()->setCellValue('P' . $j, htmlspecialchars_decode(stripslashes($totalPaybalRoomAmount)));
                } elseif ($billbookdatainfo['gstType']  == 'gst_exclude') {
                $objPHPExcel->getActiveSheet()->setCellValue('P' . $j, htmlspecialchars_decode(stripslashes($totalPaybalRoomAmount)));
                } elseif (empty($billbookdatainfo['gstType'])) {
                $objPHPExcel->getActiveSheet()->setCellValue('P' . $j, htmlspecialchars_decode(stripslashes($totalPaybalRoomAmount))); 
                }

                $objPHPExcel->getActiveSheet()->setCellValue('Q'.$j, htmlspecialchars_decode(stripslashes($amountOffline)));
                $objPHPExcel->getActiveSheet()->setCellValue('R' . $j, htmlspecialchars_decode(stripslashes($amountOnline))); 
                $objPHPExcel->getActiveSheet()->setCellValue('S' . $j, htmlspecialchars_decode(stripslashes($amountPrepaid))); 
                $objPHPExcel->getActiveSheet()->setCellValue('T' . $j, htmlspecialchars_decode(stripslashes($amountBtc))); 
                //Food Bill Start
                $objPHPExcel->getActiveSheet()->setCellValue('U' . $j, htmlspecialchars_decode(stripslashes($foodBillData['totalfoodbill'])));
                $objPHPExcel->getActiveSheet()->setCellValue('V' . $j, htmlspecialchars_decode(stripslashes($fcgst)));
                $objPHPExcel->getActiveSheet()->setCellValue('W' . $j, htmlspecialchars_decode(stripslashes($fsgst)));     
                $objPHPExcel->getActiveSheet()->setCellValue('X' . $j, htmlspecialchars_decode(stripslashes($totalPaybalFoodAmount)));
                //End Food Bill Start                  
                $objPHPExcel->getActiveSheet()->setCellValue('Y' . $j, htmlspecialchars_decode('')); /*Blank*/
                $objPHPExcel->getActiveSheet()->setCellValue('Z' . $j, htmlspecialchars_decode(stripslashes($GrandTotalFoodAndRoom)));    
                $objPHPExcel->setActiveSheetIndex(0);
                $i++;
            }    
        }
            $j++;
            $objPHPExcel->getActiveSheet()->getStyle('Q' . $j)->getFont()->setBold(true)
                                ->setName('Verdana')
                                ->setSize(10)
                                ->getColor()->setRGB('6F6F6F');
            $objPHPExcel->getActiveSheet()->getStyle('R' . $j)->getFont()->setBold(true)
                                ->setName('Verdana')
                                ->setSize(10)
                                ->getColor()->setRGB('6F6F6F');
            $objPHPExcel->getActiveSheet()->getStyle('S' . $j)->getFont()->setBold(true)
                                ->setName('Verdana')
                                ->setSize(10)
                                ->getColor()->setRGB('6F6F6F');
            $objPHPExcel->getActiveSheet()->getStyle('T' . $j)->getFont()->setBold(true)
                                ->setName('Verdana')
                                ->setSize(10)
                                ->getColor()->setRGB('6F6F6F');
            $objPHPExcel->getActiveSheet()->setCellValue('Q' . $j, htmlspecialchars_decode(stripslashes("Total Offline - ".$totOffline)));    
            $objPHPExcel->getActiveSheet()->setCellValue('R' . $j, htmlspecialchars_decode(stripslashes("Total Online - ".$totOnline)));    
            $objPHPExcel->getActiveSheet()->setCellValue('S' . $j, htmlspecialchars_decode(stripslashes("Total Prepaid - ".$totPrepaid)));    
            $objPHPExcel->getActiveSheet()->setCellValue('T' . $j, htmlspecialchars_decode(stripslashes("Total BTC - ".$totBtc)));    
        $curfilename = 'bill_book_report.xls';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . basename($curfilename) . '"');
        header('Cache-Control: max-age=0');
        $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel5");
        ob_end_clean();
        $objWriter->save('php://output');
        exit;
      else :
        redirect($_SERVER['HTTP_REFERER']);
        exit;
      endif;
    } catch (Throwable $th) {
      echo "<pre>";
      echo ($th);
      echo "</pre>";
      die;
    }
  }  

  public function AddServices(){
    $entry_number = $this->input->post('add_entry_number');
    $query = "SELECT id FROM " . getTablePrefix() . "customer_summary_book WHERE hotel_manager_id='".sessionData('MHM_VENDOR_ID')."' and entry_number = '" . $entry_number . "'";
    $count = $this->common_model->getDataByQuery('count', $query);
    if($count>0){
      $param['hotel_manager_name'] = '';
      $param['quantity'] = '';
      $param['order_date'] = currentDateTime();
      $param['amount_mode'] = "offline";
      $param['service_id'] = '';
      $param['advance_paid'] = $this->input->post('total_amt');
      $param['service_gst'] = $this->input->post('service_gst');
      $param['entry_number'] = $entry_number;
      $param['payment_paid'] = 0;
      $param['bill_item'] = $this->input->post('bill_items');
      $param['hotel_manager_id'] = sessionData('MHM_VENDOR_ID');
      $param['customer_id'] = addslashes($this->input->post('Customer_ID'));
      $param['daybook_mode'] = "In";
      $param['page_source'] = "add_a_services";
      $param['creation_date'] = currentDateTime();
      $param['created_by'] = $this->session->userdata('MHM_ADMIN_ID');
      
      //echo '<pre>';print_r($param);die;
      //echo '<pre>';print_r($this->input->post());die;
      
      $lastInsertId = $this->common_model->addData('customer_summary_details', $param);
      $Uparam['encrypt_id'] = ashishEncript($lastInsertId);
      $Uparam['detail_book_id'] = generateUniqueId($lastInsertId);
      $Uwhere['id'] = $lastInsertId;
      $this->common_model->editDataByMultipleCondition('customer_summary_details', $Uparam, $Uwhere);
      //echo '<pre>';print_r($lastInsertId);die;


      $CURRENTENTRYNUMBER = $this->common_model->getDataByParticularField('vendor_details', 'vendor_id', sessionData('MHM_VENDOR_ID'));
      $billNumber = $CURRENTENTRYNUMBER['bill_number'] + 1;
      $optparams['customer_id'] = addslashes($this->input->post('Customer_ID'));
      $optparams['summary_detail_id'] = $Uparam['detail_book_id'];
      $optparams['bill_item'] = $param['bill_item'];
      $optparams['bill_amount'] = $param['advance_paid'];
      $optparams['service_gst'] = $param['service_gst'];
      $optparams['hotel_manager_id'] = sessionData('MHM_VENDOR_ID');
      $optparams['creation_date'] = currentDateTime();
      $optparams['page_source'] = 'add_a_services';
      $optparams['created_by'] = sessionData('MHM_VENDOR_ID');
      $optparams['bill_number'] = $billNumber;
      //echo '<pre>';print_r($optparams);
      $this->common_model->addData('custom_bill_book', $optparams);

      $response['status'] = 1;
      echo json_encode($response);
      exit;
    }else{
      $response['status'] = 2;
      $response['msg'] = 'Please enter valid number of group.';
      echo json_encode($response);
      exit;
    }
  }  
  public function GetServicesBookingId($entry_number){
    $BookQuery = "SELECT summary_book_id FROM " . getTablePrefix() . "customer_summary_book WHERE hotel_manager_id='".sessionData('MHM_VENDOR_ID')."' and entry_number='".$entry_number."' ";
    $GetBookArr = $this->common_model->getDataByQuery('multiple', $BookQuery);
    $GetBookIDArr = [];
    foreach ($GetBookArr as $row) {
      $GetBookIDArr[] = $row['summary_book_id'];
    }
    return $GetBookIDArr;
  }
  public function GetServices($entry_number){
    $GetBookIDArr = $this->GetServicesBookingId($entry_number);
    $GetBookID = implode(',', $GetBookIDArr);
    $ServiceArr = [];
    $CustomerList = '<option value="">Select Customer</option>';
    if($GetBookID){ 
      $ServiceQuery = "SELECT id,bill_item,bill_amount,service_gst FROM " . getTablePrefix() . "custom_bill_book WHERE customer_id IN (".$GetBookID.")  and page_source='add_a_services' ORDER BY id DESC";
      $ServiceArr = $this->common_model->getDataByQuery('multiple', $ServiceQuery);

      $BookQuery = "SELECT summary_book_id,customer_name,assign_room_number FROM " . getTablePrefix() . "customer_summary_book WHERE hotel_manager_id='".sessionData('MHM_VENDOR_ID')."' and entry_number='".$entry_number."' ";
      $GetBookArr = $this->common_model->getDataByQuery('multiple', $BookQuery);
      foreach ($GetBookArr as $row) {

        $delQuery = "SELECT room_no FROM " . getTablePrefix() . "room_number WHERE room_id = '" . $row['assign_room_number'] . "' ";
        $Room = $this->common_model->getDataByQuery('single', $delQuery);

        $CustomerList.='<option value="'.$row['summary_book_id'].'">'.$row['customer_name'].' ('.$Room['room_no'].')</option>';
      }
      $response['status'] = 1;
    }
    $msg = '';
    foreach ($ServiceArr as $service) {
      $msg.= '<div class="col-md-12 col-sm-12 col-xs-12 form-space">
              <div class="col-md-1 col-sm-1 col-xs-1">
                <div class="form-group" style="margin-top:28px;">
                  <input type="checkbox" name="service_check['.$service['id'].']" id="service_check" value="'.$service['id'].'">
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group">
                  <label class="fancy-checkbox form-headings">Bill Item</label>
                  <input type="text" name="bill_items['.$service['id'].']" id="bill_items" value="'.$service['bill_item'].'" class="form-control required" placeholder="Bill Item">
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group">
                  <label class="fancy-checkbox form-headings">Amount</label>
                  <input type="text" name="total_amt['.$service['id'].']" id="total_amt" value="'.$service['bill_amount'].'" class="form-control required" placeholder="Amount (exclusive of GST)">
                </div>
              </div>
              <div class="col-md-3 col-sm-3 col-xs-3">
                  <div class="form-group">
                    <label class="fancy-checkbox form-headings">GST</label>
                    <input type="text" name="service_gst['.$service['id'].']" id="service_gst" value="'.$service['service_gst'].'" class="form-control" placeholder="GST PERCENTAGE">
                  </div>
              </div>
            </div>';
    }
    $msg.='<div class="col-md-12 col-sm-12 col-xs-12 form-space"><div id="AddNewServiceDiv"><a href="javascript:void(0)" onclick="NewServices()">Add Other Services</a></div></div>';
    $response['msg'] = $msg;
    $response['customer_id'] = $GetBookID;
    $response['CustomerList'] = $CustomerList;
    echo json_encode($response);
    exit;
  }

  public function AddAGuest(){
    $data['LoginVenderId'] = sessionData('MHM_VENDOR_ID');
    $CURRENTENTRYNUMBER = $this->common_model->getDataByParticularField('vendor_details', 'vendor_id', sessionData('MHM_VENDOR_ID'));
    $entry_number = $CURRENTENTRYNUMBER['entry_number'] + 1;
    
    $entry_number = addslashes($this->input->post('entry_number'));

    $ENTparam['entry_number'] = $entry_number;
    $ENTwhere['vendor_id'] = sessionData('MHM_VENDOR_ID');
    $URMparam['update_date'] = currentDateTime();
    $this->common_model->editDataByMultipleCondition('vendor_details', $ENTparam, $ENTwhere);

    $param['hotel_manager_name'] = addslashes($this->input->post('manager_name'));
    $param['customer_name'] = addslashes($this->input->post('customer_name'));
    $param['customer_email'] = addslashes($this->input->post('customer_email'));
    $param['customer_mobile_number'] = addslashes($this->input->post('customer_mobile_number'));
    $param['check_in_datetime'] = addslashes(date('Y-m-d').'T'.date('H:i'));
    $param['assign_room_number'] = addslashes($this->input->post('assign_room_number'));
    $param['address'] = '';
    $param['remarks'] = '';
    $param['number_of_person'] = addslashes($this->input->post('number_of_person'));
    $param['reffer_mode'] = '';
    $param['direct_mode'] = '';
    $param['online_mode'] = '';
    $param['ots_id'] = '';
    $param['commission_amount'] = '';
    //$param['amount_mode'] = $this->input->post('amount_mode');
    $param['prepaid_amount'] = '';
    $param['entry_number'] = $entry_number;
    $param['remarks'] = '';
    $param['room_rent_type'] = '';
    $param['amount'] = addslashes($this->input->post('amount'));
    $param['gst_number'] = '';
    $param['company_name'] = '';
    $param['company_slug'] = '';
    $param['company_address'] = '';
    if ($this->input->post('CurrentDataID') == '') :
      $roomQuery = "SELECT room_no_use FROM " . getTablePrefix() . "room_number WHERE room_id = '" . $param['assign_room_number'] . "' AND hotel_manager_id = '" . $data['LoginVenderId'] . "'";
      $checkRoomAvailablity = $this->common_model->getDataByQuery('single', $roomQuery);
      if ($checkRoomAvailablity['room_no_use'] == 'N') :
        $param['creation_date'] = currentDateTime();
        $param['hotel_manager_id'] = $this->session->userdata('MHM_VENDOR_ID');
        $param['created_by'] = $this->session->userdata('MHM_VENDOR_ID');
        $param['status'] = 'Y';
        $this->generatelogs->putLog('VENDOR', logOutPut($param));
        $vendorId = $this->common_model->addData('customer_summary_book', $param);
        $Uparam['encrypt_id'] = ashishEncript($vendorId);
        $Uparam['summary_book_id'] = generateUniqueId($vendorId);
        $Uwhere['id'] = $vendorId;
        $customerId = $Uparam['summary_book_id'];
        $this->common_model->editDataByMultipleCondition('customer_summary_book', $Uparam, $Uwhere);

        /*Send Whatsapp Msg*/
        $this->common_model->CheckInMsg($Uparam['encrypt_id']);
        /*Send Whatsapp Msg*/

        //Automatic company name entry in master table if company not exist in master table
        // Date : 09-02-2023
        $companyQuery = "SELECT company_id FROM " . getTablePrefix() . "company_info WHERE company_name = '" . $param['company_name'] . "' AND hotel_manager_id = '" . $data['LoginVenderId'] . "'";
        $checkCompanyName = $this->common_model->getDataByQuery('single', $companyQuery);
        if ($checkCompanyName == '' && $this->input->post('gst_number') != '') {
          $CPparam['hotel_manager_id'] = addslashes($this->session->userdata('MHM_VENDOR_ID'));
          $CPparam['company_name'] = addslashes($this->input->post('company_name'));
          $CPparam['company_slug'] = strtolower(url_title(trim($this->input->post('company_name'))));
          $CPparam['company_gst'] = addslashes($this->input->post('gst_number'));
          $CPparam['company_address'] = addslashes($this->input->post('company_address'));
          $CPparam['creation_date'] = currentDateTime();
          $CPparam['created_by'] = $this->session->userdata('MHM_VENDOR_ID');
          $CPparam['status'] = 'Y';
          $CPlastInsertId = $this->common_model->addData('company_info', $CPparam);
          $UCPparam['encrypt_id'] = ashishEncript($CPlastInsertId);
          $UCPparam['company_id'] = generateUniqueId($CPlastInsertId);
          $UCPwhere['id'] = $CPlastInsertId;
          $this->common_model->editDataByMultipleCondition('company_info', $UCPparam, $UCPwhere);
        }
        //end
        // Check Room Number use or nor
        $RMparam['room_no_use'] = 'Y';
        $RMwhere['room_id'] = $this->input->post('assign_room_number');
        $RMparam['update_date'] = currentDateTime();
        $this->common_model->editDataByMultipleCondition('room_number', $RMparam, $RMwhere);
        //Extend Stay Automatic : 16-01-2023
        $ESparam['hotel_manager_name'] = addslashes($this->input->post('manager_name'));
        $ESparam['amount_mode'] = "offline";
        $ESparam['order_date'] = currentDateTime();
        $ESparam['advance_paid'] = addslashes($this->input->post('amount'));
        $ESparam['payment_paid'] = 0;
        //$ESparam['bill_item'] = "Room Rent (" . date('d/m/Y') . ")";
        $ESparam['bill_item'] = "Room Rent (" . date('d/m/Y', strtotime($param['check_in_datetime'])) . ")";
        $ESparam['room_rent_status'] = addslashes($this->input->post('room_rent_status'));
        $ESparam['hotel_manager_id'] = sessionData('MHM_VENDOR_ID');
        $ESparam['customer_id'] = $customerId;
        $ESparam['daybook_mode'] = "In";
        $ESparam['page_source'] = "extend_stay";
        $ESparam['creation_date'] = currentDateTime();
        $ESparam['created_by'] = $this->session->userdata('MHM_ADMIN_ID');
        $ESlastInsertId = $this->common_model->addData('customer_summary_details', $ESparam);
        $this->generatelogs->putLog('VENDOR', logOutPut($ESparam));
        $ESUparam['encrypt_id'] = ashishEncript($ESlastInsertId);
        $ESUparam['detail_book_id'] = generateUniqueId($ESlastInsertId);
        $ESUwhere['id'] = $ESlastInsertId;
        $this->common_model->editDataByMultipleCondition('customer_summary_details', $ESUparam, $ESUwhere);
        // END
        //Add an advance date : 09-02-2023
        if (!empty($this->input->post('amount_mode')) && !empty($this->input->post('prepaid_amount'))) :
          $AADparam['hotel_manager_name'] = addslashes($this->input->post('manager_name'));
          $AADparam['order_date'] = currentDateTime();
          $AADparam['amount_mode'] = addslashes($this->input->post('amount_mode'));
          $AADparam['advance_paid'] = 0;
          $AADparam['payment_paid'] = addslashes($this->input->post('prepaid_amount'));
          $AADparam['bill_item'] = "Advance Paid";
          $AADparam['room_rent_status'] = '';
          $AADparam['hotel_manager_id'] = sessionData('MHM_VENDOR_ID');
          $AADparam['customer_id'] = $customerId;
          $AADparam['daybook_mode'] = "In";
          $AADparam['page_source'] = "add_an_advance";
          $AADparam['creation_date'] = currentDateTime();
          $AADparam['created_by'] = $this->session->userdata('MHM_ADMIN_ID');
          $addAdvanceInsertId = $this->common_model->addData('customer_summary_details', $AADparam);
          $UAADparam['encrypt_id'] = ashishEncript($addAdvanceInsertId);
          $UAADparam['detail_book_id'] = generateUniqueId($addAdvanceInsertId);
          $UAADwhere['id'] = $addAdvanceInsertId;
          $this->common_model->editDataByMultipleCondition('customer_summary_details', $UAADparam, $UAADwhere);
        endif;
        //End
        // Update Bill Number Date: 18-01-2023
        $ENTparam['entry_number'] = $entry_number;
        $ENTwhere['vendor_id'] = sessionData('MHM_VENDOR_ID');
        $URMparam['update_date'] = currentDateTime();
        $this->common_model->editDataByMultipleCondition('vendor_details', $ENTparam, $ENTwhere);
        $this->session->set_flashdata('alert_success', lang('addsuccess'));
      else :
        $this->session->set_flashdata('alert_success', lang('alreadyAssign'));
      endif;
    else :
    $vendorId = $this->input->post('CurrentDataID');
    $customerId = $vendorId;
    if ($this->input->post('assign_room_number') != "") :
      //When hotel owner want to change room .  Date : 24-09-2022
      if ($data['EDITDATA']['assign_room_number'] != $this->input->post('assign_room_number')) :
        $URMAparam['room_no_use'] = 'N';
        $URMAparam['update_date'] = currentDateTime();
        $URMAwhere['room_id'] = $data['EDITDATA']['assign_room_number'];
        $this->common_model->editDataByMultipleCondition('room_number', $URMAparam, $URMAwhere);
      endif;
      // END
      // Check Room Number use or nor
      if ($this->input->post('CurrentDataID') != '') :
        $URMparam['room_no_use'] = 'Y';
        $URMparam['update_date'] = currentDateTime();
        $URMwhere['room_id'] = $this->input->post('assign_room_number');
        $this->common_model->editDataByMultipleCondition('room_number', $URMparam, $URMwhere);
      endif;
    endif;
    // END
    $param['update_date'] = currentDateTime();
    $param['updated_by'] = $this->session->userdata('MHM_VENDOR_ID');
    $this->common_model->editData('customer_summary_book', $param, 'summary_book_id', $vendorId);
    $this->session->set_flashdata('alert_success', lang('updatesuccess'));
    endif;
    $this->session->set_flashdata('alert_success', lang('addsuccess'));
    //echo '<pre>';print_r($param);die();
    redirect($this->session->userdata('MHM_VENDOR_CURRENT_PATH') . 'dashboard');
  }
  public function todayreport(){
    $this->session->unset_userdata('MHM_VENDOR_OWNER_PASSCODE');
    $this->vendorauth_model->authCheck();
    $LoginVenderId = sessionData('MHM_VENDOR_ID');
    $date = date('Y-m-d');
    $catstr = [];
    $datastr = [];
    $total = 0;
    for ($i=0; $i < 10; $i++) { 
      $BackDate = date("Y-m-d", strtotime("-".$i." day"));
      $dayWisePrepaidSales  = $this->vendor_model->getDayWiseTotalSales("prepaid", $BackDate);
      $dayWiseOnlineSales  = $this->vendor_model->getDayWiseTotalSales("online", $BackDate);
      $dayWiseOfflineSales  = $this->vendor_model->getDayWiseTotalSales("offline", $BackDate);    
      $subtotal = $dayWisePrepaidSales['totalAmount'] + $dayWiseOnlineSales['totalAmount'] + $dayWiseOfflineSales['totalAmount'];
      $catstr[]   = "'".date('d M',strtotime($BackDate))."'";
      $datastr[]  = $subtotal;
      $total += $subtotal;
    }

    $data['catstr'] = implode(',',$catstr);
    $data['datastr'] = implode(',',$datastr);
    $data['total'] = number_format($total,2);

    /*Total Sales*/
    $dayWisePrepaidSales  = $this->vendor_model->getDayWiseTotalSales("prepaid", $date);
    $dayWiseOnlineSales  = $this->vendor_model->getDayWiseTotalSales("online", $date);
    $dayWiseOfflineSales  = $this->vendor_model->getDayWiseTotalSales("offline", $date);
    $data['TotalSale'] = $dayWisePrepaidSales['totalAmount'] + $dayWiseOnlineSales['totalAmount'] + $dayWiseOfflineSales['totalAmount'];
    /*Total Sales*/

    /*Total Expenses*/
    $whereCon['where'] = "hdbo.hotel_manager_id='".$LoginVenderId."' AND hdbo.order_date like '%" . date('Y-m-d') . "%'  AND hdbo.daybook_mode = 'Out'";
    $tblName = 'customer_summary_details as hdbo';
    $ExpensesArr = $this->vendor_model->selectDayBookOutManagerData('data', $tblName, $whereCon,'hdbo.detail_book_id ASC', 0, 0);
    $TotalExpenses = 0;
    foreach ($ExpensesArr as $row) {
      $TotalExpenses+= $row['amount_out'];
    }
    $data['TotalExpenses'] = $TotalExpenses;
    /*Total Expenses*/

    $tblName = 'customer_summary_book as csb';
    $whereCon['where'] = "csb.hotel_manager_id = '" . $LoginVenderId . "'";
    $whereCon['like'] = "(csb.check_in_datetime LIKE '%" . $date . "%')";
    $data['TotalCheckIn'] = $this->vendor_model->selectCustomerSummaryBookDataCount('count', $tblName, $whereCon, $shortField, '0', '0');


    $tblName = 'customer_summary_book as csb';
    $whereCon['where'] = "csb.hotel_manager_id = '" . $LoginVenderId . "'";
    $whereCon['like'] = "(csb.check_out_datetime LIKE '%" . $date . "%')";
    $data['TotalCheckOut'] = $this->vendor_model->selectCustomerSummaryBookDataCount('count', $tblName, $whereCon, $shortField, '0', '0');
    
    $data['TotalWhatsapp'] = $this->common_model->CoutnTotalWhatsapp();

    $kycQuery = "SELECT room_id,room_no,room_no_use,encrypt_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id=".$LoginVenderId." AND room_no_use='Y' ";
    $availableRooms = $this->common_model->getDataByQuery('multiple', $kycQuery);

    $i = 0;
    foreach ($availableRooms as $Arooms) {
      $BookQuery = "SELECT `csb`.*, `rn`.`room_no`, `rn`.`room_no_use`, `rn`.`room_id` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`assign_room_number` = '".$Arooms['room_id']."' AND `csb`.`hotel_manager_id` = '".$LoginVenderId."' AND `csb`.`check_out_datetime` IS NULL AND `rn`.`room_no_use` = 'Y' ORDER BY `csb`.`check_in_datetime` DESC";
      $Result = $this->common_model->getDataByQuery('single', $BookQuery);
      $check_in_datetime = date('Y-m-d',strtotime($Result['check_in_datetime']));
      if($check_in_datetime!=date('Y-m-d')){
        $i++;
      }
    }

    $data['TotalValidCheckout'] = $i;

    $data['error'] = '';
    $data['activeMenu'] = 'Dashboard';
    //$data['adminMssageData'] = $this->vendor_model->getAdminMessage($date);
    //$data['reminderData'] = $this->vendor_model->getReminderData($date);
    //$data['vacentRoom'] = $this->vendor_model->getVacantRoomInfo();
    //$data['occupaieRoom'] = $this->vendor_model->getRoomInfo($type = "Y");

    $this->layouts->set_title('Dashboard');
    $this->layouts->vendor_view('vendor/TodayReport', array(), $data);
  }
  public function SaveBillBookPopUp(){

    $customerId = $this->input->post('summary_book_id');
    $amount = $this->input->post('amount');

    $data['CUSTOMERDATA'] = $this->common_model->getDataByParticularField('customer_summary_book', 'summary_book_id', $customerId);

    //check bill generate or not
    $summaryQuery = "SELECT csd.id,csd.service_gst,csd.bill_generated_date,csd.bill_item,csd.bill_amount as advance_paid,csd.page_source FROM " .getTablePrefix() . "custom_bill_book as csd WHERE csd.customer_id='" . $customerId . "' and ='extend_stay' ";
    $data['SUMMARYDETAIL'] = $this->common_model->getDataByQuery('multiple', $summaryQuery);
    //end

    $params['gst_number'] = $amount;
    $params['company_name'] = $this->input->post('company_name');
    $params['company_address'] = $this->input->post('company_address');
    $params['user_status'] = 2;
    $this->common_model->editData('customer_summary_book', $params, 'summary_book_id', $data['customerId']);
  }
  public function GetOTSData(){
    $VendorID = $this->input->GET('VendorID');
    $html = '<option value="">Select Booking Platform</option>';
    $this->db->select('ots_id,ots_name');
    $this->db->from('ots_master');
    $this->db->where("hotel_manager_id",$VendorID);
    $this->db->where("status = 'Y'");
    $this->db->order_by("ots_id ASC");
    $query = $this->db->get();
    //print_r($this->db->last_query()); 
    if ($query->num_rows() > 0) :
      $data = $query->result_array();
      foreach ($data as $info) :
        $html .= '<option value="' . $info['ots_id'] . '" >' . $info['ots_name'] . '</option>';
      endforeach;
    endif;
    echo $html;
  }

  public function savecompanymaster(){

        if ($this->input->post('SaveChanges')) :
            $error = 'NO';
            $data['formError'] = 'Yes';
            if ($this->input->post('CurrentDataID') == '') :
                $this->form_validation->set_rules('company_gst', 'company_gst', 'required|callback_check_company_gst');
            else :
                $this->form_validation->set_rules('company_gst', 'company_gst', 'required');
            endif;
            $this->form_validation->set_rules('company_name', 'company_name', 'trim');
            $this->form_validation->set_rules('company_address', 'company_address', 'trim');

            if ($error == 'NO') :
              //echo "<pre>"; print_r($this->form_validation->run()); exit;
                $data['formError'] = 'No';
                $param['hotel_manager_id'] = addslashes($this->input->post('hotel_manager_id'));
                $param['company_name'] = addslashes($this->input->post('company_name'));
                $param['company_slug'] = strtolower(url_title(trim($this->input->post('company_name'))));
                $param['company_gst'] = addslashes($this->input->post('company_gst'));
                $param['company_address'] = addslashes($this->input->post('company_address'));

                if ($this->input->post('CurrentDataID') == '') :
                    $param['creation_date'] = currentDateTime();
                    $param['created_by'] = $this->session->userdata('MHM_ADMIN_ID');
                    $param['status'] = 'Y';
                    $currentDataID = $this->common_model->addData('company_info', $param);
                    $Uparam['encrypt_id'] = ashishEncript($currentDataID);
                    $Uparam['company_id'] = generateUniqueId($currentDataID);
                    $Uwhere['id'] = $currentDataID;
                    $this->common_model->editDataByMultipleCondition('company_info', $Uparam, $Uwhere);
                    $this->session->set_flashdata('alert_success', lang('addsuccess'));
                else :
                    $currentDataID = $this->input->post('CurrentDataID');
                    $param['update_date'] = currentDateTime();
                    $param['updated_by'] = $this->session->userdata('MHM_ADMIN_ID');
                    $this->common_model->editData('company_info', $param, 'company_id', $currentDataID);
                    $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                endif;

                $query = "SELECT company_gst, company_name, company_address FROM " . getTablePrefix() . "company_info WHERE id = '" . $currentDataID . "' AND hotel_manager_id = '" . $this->input->post('hotel_manager_id') . "'";
                $data['company'] = $this->common_model->getDataByQuery('single', $query);

            endif;
        endif;

        //add the header here
        header('Content-Type: application/json');
        echo json_encode($data);
    } // END OF FUNCTION

    /***********************************************************************
     ** Function name : GetDetailsByCompanyName
     ** Developed By :  Abhay Singh
     ** Purpose  : This function used for Get Details By Company Name by ajax.
     ** Date : 26 March 2024
     ************************************************************************/
    public function GetDetailsByCompanyName()
    {
        $companyName = $this->input->post('companyName');
        $hotel_manager_id = $this->input->post('hotel_manager_id');
        if ($companyName) :
            $delQuery = "SELECT company_name,company_address FROM " . getTablePrefix() . "company_info
            WHERE company_gst = '" . $companyName . "' AND hotel_manager_id = '" . $hotel_manager_id . "'";
            $COMPANYDETAILS = $this->common_model->getDataByQuery('single', $delQuery);
            //return $COMPANYDETAILS;
            echo json_encode($COMPANYDETAILS);
            exit;
        endif;
    }
    public function send(){
        $this->load->library('phpmailer_lib');
            $mail = $this->phpmailer_lib->load();
            $mail->SMTPDebug = 1;   
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'admin@minihotelman.com';
            $mail->Password = 'Dhangurutegbahadurji';
            $mail->SMTPSecure = 'tls';
            $mail->Port = '587';
            $mail->setFrom('singhabhay396@gmail.com','Abhay');
            $mail->addReplyTo('singhabhay396@gmail.com','Abhay');
            $mail->addAddress('singhabhay396@gmail.com');
            $mail->Subject = 'Test Email';
            $mail->isHTML(true);
            $mailContent = "New email received!";
            $mail->Body = $mailContent;
            if(!$mail->send()){
                echo "Not Send";
                echo 'Mail Error: '. $mail->ErrorInfo;
            }
            else{
                echo "success";
            }
        exit;
    }
}
