<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Reports extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'emailtemplate_model', 'sms_model', 'owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }
  public function index(){
    $data['error']        =     '';
    $data['activeMenu']   =     'TodayReports';
    $data['activeSubMenu']=     'TodayReports';
  
    $HotelList = $this->owner_model->GetOwnerVendorList();    
    $data['HotelList'] = $HotelList;
    //End

    //echo '<pre>';print_r($data);echo '</pre>';die();

    $this->layouts->set_title('Today report');
    $this->layouts->owner_view('owner/reports/index', array(), $data);
  }
  public function downloadreport(){

    $date = $_GET['download_date'] ?? date('Y-m-d');
    $LoginVenderId = $_GET['VendorID'] ?? 0;
    //$LoginVenderId = $date['LoginVenderId'];
    $tblName = 'customer_summary_book as csb';
    $whereCon['where'] = "csb.hotel_manager_id = '" . $LoginVenderId . "'";
    $whereCon['like'] = "(csb.check_in_datetime LIKE '%" . $date . "%')";
    $data['GetCheckInArr'] = $this->vendor_model->selectCustomerSummaryBookDataCount('data', $tblName, $whereCon, $shortField, '0', '0');
    $tblName = 'customer_summary_book as csb';
    $whereCon['where'] = "csb.hotel_manager_id = '" . $LoginVenderId . "'";
    $whereCon['like'] = "(csb.check_out_datetime LIKE '%" . $date . "%')";
    $data['GetCheckOutArr'] = $this->vendor_model->selectCustomerSummaryBookDataCount('data', $tblName, $whereCon, $shortField, '0', '0');
    $vQuery = "SELECT vendor_business_name FROM ".getTablePrefix()."vendor WHERE vendor_id=".$LoginVenderId."";
    $data['VendoerName'] = $this->common_model->getDataByQuery('single', $vQuery);

    $kycQuery = "SELECT room_id,room_no,room_no_use,encrypt_id FROM ".getTablePrefix()."room_number WHERE hotel_manager_id=".$LoginVenderId." AND room_no_use='Y' ";
    $data['AvailableRoomsArr'] = $this->common_model->getDataByQuery('multiple', $kycQuery);
    
    $whereCon['like'] = '';
    $whereCon['where'] = "csd.hotel_manager_id = '".$LoginVenderId."' AND csd.order_date LIKE  '%".$date. "%'  AND csd.daybook_mode = 'In' AND csd.advance_paid != '' AND csd.page_source ='add_an_advance'";
    $shortField   = 'csb.summary_book_id DESC';
    $tblName      = 'customer_summary_details as csd';
    $data['DayBookIn'] = $this->vendor_model->selectCustomerSummaryDayBookData('data', $tblName, $whereCon, $shortField, 5000, 0);
    //echo '<pre>';print_r($data['DayBookIn']);echo '</pre>';exit();
    $data['dayWisePrepaidSales']  = $this->vendor_model->getDayWiseTotalSales("prepaid", $date,$LoginVenderId);
    $data['dayWiseOnlineSales']  = $this->vendor_model->getDayWiseTotalSales("online", $date,$LoginVenderId);
    $data['dayWiseOfflineSales']  = $this->vendor_model->getDayWiseTotalSales("offline", $date,$LoginVenderId);
    $data['dayWiseB2CSales']  = $this->vendor_model->getDayWiseTotalSales("BTC", $date,$LoginVenderId);

    $whereCon['like'] = '';
    $whereCon['where'] = "hdbo.hotel_manager_id = '".$LoginVenderId."' AND hdbo.order_date like  '%" . $date . "%'  AND hdbo.daybook_mode='Out'";
    $tblName = 'customer_summary_details as hdbo';
    $shortField = 'hdbo.detail_book_id ASC';
    $data['DayBookOut'] = $this->vendor_model->selectDayBookOutManagerData('data', $tblName, $whereCon, $shortField, 5000, 0);
    
    $ResQuery = "SELECT * FROM ".getTablePrefix()."calendar_reservations WHERE hotel_manager_id='".$LoginVenderId."' AND (add_date LIKE '%".$date."%') order by id desc";
    $data['ResData'] = $this->common_model->getDataByQuery('multiple', $ResQuery);
    //$data['Date'] = date('d M Y h:i A');
    $data['Date'] = $date;
    $data['LoginVenderId'] = $LoginVenderId;
    
    $this->layouts->set_title('Today report');
    $this->layouts->owner_view('owner/reports/downloadreport', array(), $data, 'onlyview');
    //echo '<pre>';print_r($data);exit();
    //$this->layouts->vendor_view('vendor/billbook/downloadbillinvoice', array(), $data, 'onlyview');
  } 

}
