<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Kot extends CI_Controller{

  public function __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'emailtemplate_model', 'sms_model','owner_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','general','owner');
    $this->ownerauth_model->authCheck();
  }
  public function index(){
    $data['error'] = '';
    $data['activeMenu'] = 'KOT';
    $data['activeSubMenu'] = 'KOT';
    $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    $data['RestaurantList'] = $this->owner_model->GetOwnerRestaurantList('All');
    $this->layouts->set_title('Manage KOT');
    $this->layouts->owner_view('owner/kot/index', array(), $data);
  }
  
  function KotPagination(){
    $Search['r_name']         = $_GET['r_name'] ?? '';
    $Search['tbl_no']         = $_GET['tbl_no'] ?? '';
    $Search['kot_no']         = $_GET['kot_no'] ?? '';
    $Search['k_date']         = $_GET['k_date'] ?? '';
    $Search['VendorArr']      = $_GET['VendorArr'] ?? 'All';
    $Search['page']           = $_GET['page'] ?? 1;
    $Search['numofrecords']   = $_GET['numofrecords'] ?? 100;
    $Search['cur_page']       = $Search['page'];
    $Limitpage                = $Search['page']-1;
    $Search['start']          = $Limitpage * $Search['numofrecords'];
    $Search['action'] = 'count';
    $TotalData = $this->KOTPaginationData($Search);
    $data['PAGINATION'] = Pagination($Search['numofrecords'],$TotalData, $Search['page']);
    $Search['action'] = 'data';
    $data['ALLDATA'] = $this->KOTPaginationData($Search);
    //print_r($data['ALLDATA']);die();
    $data['VendorID'] = $Search['VendorArr'];
    $this->load->view('owner/kot/Pagination', $data);
  }
  function KOTPaginationData($Search){
    $hotel_manager_id = $this->owner_model->GetAllHotelList();
    $this->db->select('kot.*,rest.rest_name,vendor.vendor_business_name');
    $this->db->from('restaurant_kot as kot');
    $this->db->join('restaurant as rest', 'rest.id = kot.restaurant_id', 'LEFT');
    $this->db->join('vendor as vendor', 'vendor.vendor_id = kot.hotel_manager_id', 'LEFT');

    if($Search['r_name']!=''){ $this->db->where("rest.rest_name LIKE '%" . $Search['r_name'] . "%'"); }
    if($Search['kot_no']!=''){ $this->db->where("kot.kot_no LIKE '%" . $Search['kot_no'] . "%'"); }
    if($Search['tbl_no']!=''){ $this->db->where("kot.table_name LIKE '%" . $Search['tbl_no'] . "%'"); }
    if($Search['k_date']!=''){ $this->db->where("kot.add_date LIKE '%" . $Search['k_date'] . "%'"); }
    
    if($Search['VendorArr']=='All'){
      $this->db->where_in("kot.hotel_manager_id",$hotel_manager_id); 
    }else{
      $this->db->where("kot.hotel_manager_id",$Search['VendorArr']); 
    }
    $this->db->group_by('kot.kot_no');
    $this->db->order_by('kot.id DESC');
    if ($Search['action']=='data'){$this->db->limit($Search['numofrecords'], $Search['start']); }
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($Search['action'] == 'data'){
      if ($query->num_rows() > 0){
        return $query->result_array();
      }else{
        return false;
      }
    }elseif ($Search['action'] == 'count'){
      return $query->num_rows();
    }
  }

  public function downloadkotdata(){
    try {
      require_once APPPATH . 'third_party/classes/PHPExcel.php';
      $objPHPExcel = new PHPExcel();
      $Search['range'] = $_GET['range'];
      $Search['fromDate'] = $_GET['fromDate'];
      $Search['toDate'] = $_GET['toDate'];
      $Search['amount_mode'] = $_GET['amount_mode'];
      $Search['type'] = $_GET['type'];
      $Search['VendorID'] = $_GET['VendorID'] ?? 'All';

      $range = $_GET['range'];
      if($range == 'today'){
        $dates = date('Y-m-d');
        $dates2 = date('Y-m-d');
        $Search['toDate']       = $dates;
        $Search['fromDate']     = $dates2;
      }elseif($range == 'yesterday'){
        $dates = date('Y-m-d',strtotime("-1 days"));
        //$dates2 = date('Y-m-d');
        $Search['toDate']       = $dates;
        $Search['fromDate']     = $dates;
      }elseif($range == 'week'){
        $start = (date('D') != 'Mon') ? date('Y-m-d', strtotime('last Monday')) : date('Y-m-d');
        $finish = (date('D') != 'Sun') ? date('Y-m-d', strtotime('next Sunday')) : date('Y-m-d');
        $Search['toDate']       = $finish;
        $Search['fromDate']     = $start;
      }elseif($range == 'last_month'){
        $start = date("Y-m-d", strtotime("first day of previous month"));
        $finish = date("Y-m-d", strtotime("last day of previous month"));
        $Search['toDate']       = $finish;
        $Search['fromDate']     = $start;
      }elseif($range == 'till_now'){
        $start = date("Y-m-01");
        $finish = date("Y-m-d");
        $Search['toDate']       = $finish;
        $Search['fromDate']     = $start;
      } 
      $RoomData = [];
      $TableData = [];
      //if($Search['type']=='Both'){
        $RoomData = $this->RoomData($Search);
        $TableData = $this->TableData($Search);
      //}
      
      $objPHPExcel->getProperties()->setCreator("Maarten Balliauw")->setLastModifiedBy("Maarten Balliauw")->setTitle("Office 2007 XLSX Test Document")->setSubject("Office 2007 XLSX Test Document")->setDescription("Test document for Office 2007 XLSX, generated using PHP classes.")->setKeywords("office 2007 openxml php")->setCategory("Test result file");
      $objPHPExcel->setActiveSheetIndex(0);
      $objPHPExcel->getActiveSheet()->setCellValue('A2', "KOT number")
            ->setCellValue('B2', "Room/Table")
            ->setCellValue('C2', "Name of customer")
            ->setCellValue('D2', "Bill items")
            ->setCellValue('E2', "Total price")
            ->setCellValue('F2', "CGST")
            ->setCellValue('G2', "SGST")
            ->setCellValue('H2', "Grand Total")
            ->setCellValue('I2', "Cash")
            ->setCellValue('J2', "Online")
            ->setCellValue('K2', "Discount");
      $objPHPExcel->getActiveSheet()->getRowDimension('2')->setRowHeight('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("A")->setWidth('15');
      $objPHPExcel->getActiveSheet()->getColumnDimension("B")->setWidth('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("C")->setWidth('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("D")->setWidth('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("E")->setWidth('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("F")->setWidth('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("G")->setWidth('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("H")->setWidth('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("I")->setWidth('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("J")->setWidth('30');
      $objPHPExcel->getActiveSheet()->getColumnDimension("K")->setWidth('30');
      
      $objPHPExcel->getActiveSheet()->getStyle('A2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('B2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('C2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('D2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('E2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('F2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('G2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('H2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('I2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('J2')->applyFromArray(cellAlignment());
      $objPHPExcel->getActiveSheet()->getStyle('K2')->applyFromArray(cellAlignment());
      
      $i = 2;
      $FinelTotalPrice = 0;
      $FinelTotalCGST = 0;
      $FinelTotalSGST = 0;
      $FinelGrandTotal = 0;
      $FinelTotalCash = 0;
      $FinelTotalOnline = 0;
      $FinelTotalDiscount = 0;
      
      if($RoomData){
        foreach ($RoomData as $row){
          $productname='';    
          $CheckData = 0;    
          $j = $i + 1;

          $ItemData = $this->common_model->GetSaleCustomerItemData($row['kot_number'],$row['hotel_manager_id']);
          $BillItem = '';
          foreach ($ItemData as $Item) {
            $BillItem.= $Item['bill_item']." (".$Item['quantity'].")"."\n";          
          }
          $Total = $row['total_amt'];
          $totalAmnt  = round($Total * 5) / 100;
          $TotalAmt  = $Total - $totalAmnt;
          $cgst  = $totalAmnt / 2;
          $sgst  = $totalAmnt / 2;

          $GrandTotal = $Total + $cgst + $sgst;

          $FinelTotalPrice+= $row['total_amt'];
          $FinelTotalCGST+= $cgst;
          $FinelTotalSGST+= $sgst;
          $FinelGrandTotal+= $GrandTotal;
          $FinelTotalCash+= $row['cash_paid'];
          $FinelTotalOnline+= $row['online_paid'];
          $FinelTotalDiscount+= $row['discount'];


          $objPHPExcel->getActiveSheet()->setCellValue('A' . $j, $row['kot_number']);
          $objPHPExcel->getActiveSheet()->setCellValue('B' . $j, $row['room_no']);
          $objPHPExcel->getActiveSheet()->setCellValue('C' . $j, $row['customer_name']);
          $objPHPExcel->getActiveSheet()->setCellValue('D' . $j, $BillItem);
          $objPHPExcel->getActiveSheet()->setCellValue('E' . $j, $row['total_amt']); 
          $objPHPExcel->getActiveSheet()->setCellValue('F' . $j, $cgst); 
          $objPHPExcel->getActiveSheet()->setCellValue('G' . $j, $sgst); 
          $objPHPExcel->getActiveSheet()->setCellValue('H' . $j, $GrandTotal); 
          $objPHPExcel->getActiveSheet()->setCellValue('I' . $j, $row['cash_paid']); 
          $objPHPExcel->getActiveSheet()->setCellValue('J' . $j, $row['online_paid']); 
          $objPHPExcel->getActiveSheet()->setCellValue('K' . $j, $row['discount']); 
          $objPHPExcel->setActiveSheetIndex(0);
          $i++;
        }

      }

      if($TableData){
        foreach ($TableData as $row){
          $productname='';    
          $CheckData = 0;    
          $j = $i + 1;

          $ItemData = $this->common_model->GetSaleTableItemData($row['kot_no'],$row['hotel_manager_id']);
          $BillItem = '';
          foreach ($ItemData as $Item) {
            $BillItem.= $Item['menu_name']." (".$Item['qty'].")"."\n";          
          }

          $Total = $row['total_amt'];
          $totalAmnt  = round($Total * 5) / 100;
          $TotalAmt  = $Total - $totalAmnt;
          $cgst  = $totalAmnt / 2;
          $sgst  = $totalAmnt / 2;

          $GrandTotal = $Total + $cgst + $sgst;

          $FinelTotalPrice+= $row['total_amt'];
          $FinelTotalCGST+= $cgst;
          $FinelTotalSGST+= $sgst;
          $FinelGrandTotal+= $GrandTotal;
          $FinelTotalCash+= $row['cash_paid'];
          $FinelTotalOnline+= $row['online_paid'];
          $FinelTotalDiscount+= $row['discount'];

          $objPHPExcel->getActiveSheet()->setCellValue('A' . $j, $row['kot_no']);
          $objPHPExcel->getActiveSheet()->setCellValue('B' . $j, $row['table_name']);
          $objPHPExcel->getActiveSheet()->setCellValue('C' . $j, '');
          $objPHPExcel->getActiveSheet()->setCellValue('D' . $j, $BillItem);
          $objPHPExcel->getActiveSheet()->setCellValue('E' . $j, $row['total_amt']); 
          $objPHPExcel->getActiveSheet()->setCellValue('F' . $j, $cgst); 
          $objPHPExcel->getActiveSheet()->setCellValue('G' . $j, $sgst); 
          $objPHPExcel->getActiveSheet()->setCellValue('H' . $j, $GrandTotal); 
          $objPHPExcel->getActiveSheet()->setCellValue('I' . $j, $row['cash_paid']); 
          $objPHPExcel->getActiveSheet()->setCellValue('J' . $j, $row['online_paid']); 
          $objPHPExcel->getActiveSheet()->setCellValue('K' . $j, $row['discount']); 
          $objPHPExcel->setActiveSheetIndex(0);
          $i++;
        }
      }

      $f = $i + 1;

      $styleArray = array('font' => array('bold' => true));

      $objPHPExcel->getActiveSheet()->setCellValue('A' . $f, '');
      $objPHPExcel->getActiveSheet()->setCellValue('B' . $f, '');
      $objPHPExcel->getActiveSheet()->setCellValue('C' . $f, '');
      $objPHPExcel->getActiveSheet()->setCellValue('D' . $f, 'Total');
      $objPHPExcel->getActiveSheet()->setCellValue('E' . $f, $FinelTotalPrice); 
      $objPHPExcel->getActiveSheet()->setCellValue('F' . $f, $FinelTotalCGST); 
      $objPHPExcel->getActiveSheet()->setCellValue('G' . $f, $FinelTotalSGST); 
      $objPHPExcel->getActiveSheet()->setCellValue('H' . $f, $FinelGrandTotal); 
      $objPHPExcel->getActiveSheet()->setCellValue('I' . $f, $FinelTotalCash); 
      $objPHPExcel->getActiveSheet()->setCellValue('J' . $f, $FinelTotalOnline); 
      $objPHPExcel->getActiveSheet()->setCellValue('K' . $f, $FinelTotalDiscount); 


      $objPHPExcel->getActiveSheet()->setCellValue('A' . $f, '');
      $objPHPExcel->getActiveSheet()->setCellValue('B' . $f, '');
      $objPHPExcel->getActiveSheet()->setCellValue('C' . $f, '');
      $objPHPExcel->getActiveSheet()->setCellValue('D' . $f, 'Total');
      $objPHPExcel->getActiveSheet()->setCellValue('E' . $f, $FinelTotalPrice); 
      $objPHPExcel->getActiveSheet()->setCellValue('F' . $f, $FinelTotalCGST); 
      $objPHPExcel->getActiveSheet()->setCellValue('G' . $f, $FinelTotalSGST); 
      $objPHPExcel->getActiveSheet()->setCellValue('H' . $f, $FinelGrandTotal); 
      $objPHPExcel->getActiveSheet()->setCellValue('I' . $f, $FinelTotalCash); 
      $objPHPExcel->getActiveSheet()->setCellValue('J' . $f, $FinelTotalOnline); 
      $objPHPExcel->getActiveSheet()->setCellValue('K' . $f, $FinelTotalDiscount); 
      $objPHPExcel->setActiveSheetIndex(0);

      $objPHPExcel->getActiveSheet()->setTitle('KOT Report');
      $objPHPExcel->getDefaultStyle()->getAlignment()->setWrapText(true);
      $objPHPExcel->getActiveSheet()
        ->getStyle($objPHPExcel->getActiveSheet()->calculateWorksheetDimension())
        ->getAlignment()
        ->setVertical(PHPExcel_Style_Alignment::VERTICAL_TOP);
      $lastrow = $objPHPExcel->getActiveSheet()->getHighestRow();

      $objPHPExcel->getActiveSheet()
        ->getStyle('A1:A' . $lastrow)
        ->getAlignment()
        ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

      $curfilename = 'kot_report.xls';
      header('Content-Type: application/vnd.ms-excel');
      header('Content-Disposition: attachment;filename="' . $curfilename . '"');
      header('Cache-Control: max-age=0');
      header('Cache-Control: max-age=1');
      header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
      header('Last-Modified: ' . gmdate('D, d M Y H:i:s') . ' GMT');
      header('Cache-Control: cache, must-revalidate');
      header('Pragma: public');
      $objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, "Excel5");
      ob_end_clean();
      $objWriter->save('php://output');
      exit;
      
    } catch (Throwable $th) {
      echo "<pre>";
      echo ($th);
      echo "</pre>";
      die;
    }
  }  
  public function RoomData($Search){
    if($Search['VendorID']=='All'){
      $hotel_manager_id = $this->owner_model->GetAllHotelList();
    }else{
      $hotel_manager_id = [$Search['VendorID']];
    }
    $toDate = date('Y-m-d', strtotime($Search['toDate']));
    $fromDate = date('Y-m-d', strtotime($Search['fromDate']));
    $this->db->select('cbb.kot_number,cbb.cash_paid,cbb.online_paid,cbb.discount,cbb.total_amt,cbb.amount_mode,cbb.creation_date,rn.room_no,csb.customer_name,csb.hotel_manager_id');
    //$this->db->select('cbb.*,csb.assign_room_number');
    $this->db->from('customer_summary_details as cbb');
    $this->db->join('customer_summary_book as csb', 'csb.summary_book_id = cbb.customer_id', 'left');
    $this->db->join('room_number as rn', 'csb.assign_room_number = rn.room_id', 'left');
    $this->db->where_in("cbb.hotel_manager_id",$hotel_manager_id); 
    if ($fromDate != '1970-01-01' && $toDate != '1970-01-01') {
      //$this->db->where("DATE(csb.creation_date) BETWEEN '$fromDate' AND '$toDate'");
    }
    $this->db->where("cbb.settle_type",'Settle_on_the_spot'); 
    $this->db->group_by('cbb.kot_number');
    $this->db->order_by('cbb.id DESC');
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    return $RoomResultArr = $query->result_array();
  }
  public function TableData($Search){
    if($Search['VendorID']=='All'){
      $hotel_manager_id = $this->owner_model->GetAllHotelList();
    }else{
      $hotel_manager_id = [$Search['VendorID']];
    }
    $toDate = date('Y-m-d', strtotime($Search['toDate']));
    $fromDate = date('Y-m-d', strtotime($Search['fromDate']));
    $this->db->select('kot.*');
    $this->db->from('restaurant_kot as kot');
    $this->db->where_in("kot.hotel_manager_id",$hotel_manager_id); 
    if ($fromDate != '1970-01-01' && $toDate != '1970-01-01') {
      //$this->db->where("DATE(kot.add_date) BETWEEN '$fromDate' AND '$toDate'");
    }
    $this->db->group_by('kot.kot_no');
    $this->db->order_by('kot.id DESC');
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    return $query->result_array();
  }
}
