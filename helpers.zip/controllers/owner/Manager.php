<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Manager extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'owner_model', 'emailtemplate_model', 'sms_model','frontauth_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('vendor','owner');
    $this->ownerauth_model->authCheck();
  }

  public function index(){
    $data['error'] = '';
    $data['activeMenu'] = 'Manager';
    $data['activeSubMenu'] = 'Manager';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $data['HotelList'] = $this->owner_model->GetOwnerVendorList();
    $this->layouts->set_title('Manager List');
    $this->layouts->owner_view('owner/manager/index', array(), $data);
  }
  function ManagerPagination(){
    $Search['hotel_name']     = $_GET['hotel_name'] ?? '';
    $Search['vendor_id']      = $_GET['vendor_id'] ?? 'All';
    $Search['m_name']         = $_GET['m_name'] ?? '';
    $Search['email']          = $_GET['email'] ?? '';
    $Search['mobile']         = $_GET['mobile'] ?? '';
    $Search['status']         = $_GET['status'] ?? 'All';
    $Search['page']           = $_GET['page'] ?? 1;
    $Search['numofrecords']   = $_GET['numofrecords'] ?? 100;
    //$Search['cur_page']       = $Search['page'];
    $Limitpage                = $Search['page']-1;
    $Search['start']          = $Limitpage * $Search['numofrecords'];
    
    $Search['action'] = 'count';
    $TotalData = $this->ManagerPaginationData($Search);
    $data['PAGINATION'] = Pagination($Search['numofrecords'],$TotalData, $Search['page']);
    $Search['action'] = 'data';
    $data['ALLDATA'] = $this->ManagerPaginationData($Search);
    //echo '<pre>';print_r($data);die;
    $this->load->view('owner/manager/Pagination', $data);
  }
  function ManagerPaginationData($Search){
    $vendor_id = $this->owner_model->GetAllHotelList();
    $this->db->select('m.*,vendor.vendor_business_name');
    $this->db->from('manager as m');
    $this->db->join('vendor', 'vendor.vendor_id=m.vendor_id', 'LEFT');
    if($Search['hotel_name']!=''){ $this->db->where("vendor.vendor_business_name LIKE '%" . $Search['hotel_name'] . "%'"); }
    if($Search['m_name']!=''){ $this->db->where("m.manager_name LIKE '%" . $Search['m_name'] . "%'"); }
    if($Search['email']!=''){ $this->db->where("m.email LIKE '%" . $Search['email'] . "%'"); }
    if($Search['mobile']!=''){ $this->db->where("m.mobile LIKE '%" . $Search['mobile'] . "%'"); }
    if($Search['status']!='All'){ $this->db->where("m.status",$Search['status']); }
    if($Search['vendor_id']!='All'){ 
      $this->db->where("m.vendor_id",$Search['vendor_id']); 
    }else{
      $this->db->where_in("m.vendor_id",$vendor_id); 
    }

    $this->db->order_by('m.id DESC');
    if ($Search['action']=='data'){ $this->db->limit($Search['numofrecords'], $Search['start']); }
    $query = $this->db->get();
    //echo $this->db->last_query(); die;
    if ($Search['action'] == 'data'){
      if ($query->num_rows() > 0){
        return $query->result_array();
      }else{
        return false;
      }
    }elseif ($Search['action'] == 'count'){
      return $query->num_rows();
    }
  }

  public function addeditdata($editId = ''){
    $data['error'] = '';
    $data['activeMenu'] = 'Manager';
    $data['activeSubMenu'] = 'Manager';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $data['custId'] = $editId;
    $data['HotelList'] = $this->owner_model->GetOwnerVendorList();

    if($editId){
      $data['EDITDATA']   = $this->common_model->getDataByParticularField('manager', 'id', $editId);
    }

    if ($this->input->post('SaveChanges')) :
      $error          = 'NO';
      $this->form_validation->set_rules('vendor_id', 'Hotel name', 'trim');
      $this->form_validation->set_rules('manager_name', 'Name', 'trim|required');
      $this->form_validation->set_rules('manager_email', 'E-Mail', 'trim|required|valid_email|is_unique[manager.manager_email]');
      $this->form_validation->set_rules('manager_mobile', 'Phone', 'trim|required|min_length[10]|max_length[15]');
      $vendoremail    = str_replace(' ', '', $this->input->post('manager_email'));
      if ($this->input->post('manager_email') && !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
        if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
          $error            = 'YES';
          $data['mobileerror']    =   'Please eneter correct email id.';
        endif;
      endif;
      if ($this->input->post('new_password') != '') :
        $this->form_validation->set_rules('new_password', 'New password', 'trim|required|min_length[6]|max_length[25]');
        $this->form_validation->set_rules('conf_password', 'Confirm password', 'trim|required|min_length[6]|matches[new_password]');
      endif;


      //if ($this->form_validation->run() && $error == 'NO'):  
      //echo '<pre>';print_r($_POST);die();

        $param['vendor_id']      =   addslashes($this->input->post('vendor_id'));
        $param['manager_name']     =   addslashes($this->input->post('manager_name'));
        $param['manager_email']  =   addslashes($this->input->post('manager_email'));
        $param['manager_mobile']      =   addslashes($this->input->post('manager_mobile'));
        if ($this->input->post('new_password')) :
          $NewPassword        = $this->input->post('new_password');
          $param['manager_password'] =   $this->ownerauth_model->encriptPassword($NewPassword);
        endif;      
        if ($this->input->post('CurrentDataID') == '') :
          $param['creation_date']   = currentDateTime();
          $param['status']      = 'A';
               
          $lastInsertId       = $this->common_model->addData('manager', $param);
          $this->session->set_flashdata('alert_success', lang('addsuccess'));
        else :
          $Id         = $this->input->post('CurrentDataID');
          $this->common_model->editData('manager', $param, 'id', $Id);
          $this->session->set_flashdata('alert_success', lang('updatesuccess'));
        endif;
        redirect('owner/manager');
      //endif;
    endif;
    $this->layouts->set_title('Edit Manager Details');
    $this->layouts->owner_view('owner/manager/addedit', array(), $data);
  }
  function changestatus($changeStatusId = '', $statusType = ''){
    $param['status']    = $statusType;
    $this->common_model->editData('manager', $param, 'id', $changeStatusId);
    $this->session->set_flashdata('alert_success', lang('statussuccess'));
    redirect('owner/manager');
  }
}