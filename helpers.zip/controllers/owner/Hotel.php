<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Hotel extends CI_Controller
{
  public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('ownerauth_model', 'vendor_model', 'owner_model', 'emailtemplate_model', 'sms_model','frontauth_model'));
    $this->lang->load('statictext', 'owner');
    $this->load->helper('admin','general');
    $this->ownerauth_model->authCheck();
  }

  public function index(){
    $data['error'] = '';
    $data['activeMenu'] = 'Hotel';
    $data['activeSubMenu'] = 'Hotel';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');

    $tblName = 'vendor as ven';
    $whereCon['where'] =   "";
    $shortField =   'ven.vendor_id DESC';
    $grField  =   'ven.vendor_id';
    $data['ALLDATA'] = $this->owner_model->selectSelletData('data', $tblName, $whereCon, $shortField, 100, 0,$grField);
 
    $data['OwnerData']   = $this->common_model->getDataByParticularField('vendor', 'vendor_id', sessionData('MHM_OWNER_ID'));

    $TemplateQuery = "SELECT * FROM " . getTablePrefix() . "whatsapp_template WHERE status = '1' ";
    $data['TemplateArr'] = $this->common_model->getDataByQuery('multiple', $TemplateQuery);

    //echo '<pre>';print_r($data['ALLDATA']);die();
    $this->layouts->set_title('Hotel List');
    $this->layouts->owner_view('owner/hotel/index', array(), $data);
  }
  public function addeditdataOld($editId = ''){
    $data['error'] = '';
    $data['activeMenu'] = 'Hotel';
    $data['activeSubMenu'] = 'Hotel';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $data['custId'] = $editId;

    if($editId){
      $data['EDITDATA']   = $this->common_model->getDataByParticularField('vendor', 'vendor_id', $editId);
    }

    if ($this->input->post('SaveChanges')) :
      $error          = 'NO';
      $this->form_validation->set_rules('vendor_business_name', 'Business name', 'trim');
      $this->form_validation->set_rules('vendor_title', 'Title', 'trim|required');
      $this->form_validation->set_rules('vendor_name', 'Name', 'trim');
      $this->form_validation->set_rules('vendor_email', 'E-Mail', 'trim|required|valid_email|is_unique[vendor.vendor_email]');
      $this->form_validation->set_rules('admin_mobile_number', 'Phone', 'trim|required|min_length[10]|max_length[15]');
      $vendoremail    = str_replace(' ', '', $this->input->post('vendor_email'));
      if ($this->input->post('vendor_email') && !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
        if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
          $error            = 'YES';
          $data['mobileerror']    =   'Please eneter correct email id.';
        endif;
      endif;
      $this->form_validation->set_rules('vendor_image', 'Image', 'trim');
      if ($this->input->post('new_password') != '') :
        $this->form_validation->set_rules('new_password', 'New password', 'trim|required|min_length[6]|max_length[25]');
        $this->form_validation->set_rules('conf_password', 'Confirm password', 'trim|required|min_length[6]|matches[new_password]');
      endif;

      $this->form_validation->set_rules('vendor_address', 'Address', 'trim');
      $this->form_validation->set_rules('vendor_city', 'City', 'trim');
      $this->form_validation->set_rules('vendor_pincode', 'Pincode', 'trim');
      $this->form_validation->set_rules('vendor_nationality', 'Nationality', 'trim');
      $this->form_validation->set_rules('vendor_pan', 'Pan no', 'trim');
      $this->form_validation->set_rules('uploadimage0', 'Pan image', 'trim');
      $this->form_validation->set_rules('vendor_gst', 'GST no', 'trim');
      $this->form_validation->set_rules('uploadimage1', 'GST image', 'trim');
      $this->form_validation->set_rules('vendor_address_proof', 'Address proof type', 'trim');
      $this->form_validation->set_rules('uploadimage2', 'Address proof image', 'trim');

      $this->form_validation->set_rules('vendor_kyc_status', 'KYC verify', 'trim');

      if ($this->form_validation->run() && $error == 'NO'):  

        $param['vendor_title']      =   addslashes($this->input->post('vendor_title'));
        $param['vendor_name']     =   addslashes($this->input->post('vendor_name'));
        $param['vendor_business_name']  =   addslashes($this->input->post('vendor_business_name'));
        $param['vendor_email']      =   addslashes($this->input->post('vendor_email'));
        $param['vendor_phone']      =   addslashes($this->input->post('admin_mobile_number'));
        $param['whatsapp_checkin']    =   addslashes($this->input->post('whatsapp_checkin'));
        $param['feedback_link']     =   addslashes($this->input->post('feedback_link'));
        $param['whatsapp_checkout']   =   addslashes($this->input->post('whatsapp_checkout'));
        $param['whatsapp_bulk']     =   addslashes($this->input->post('whatsapp_bulk'));
        $param['parent_id']     =   sessionData('MHM_OWNER_ID');

        if ($this->input->post('new_password')) :
          $NewPassword        = $this->input->post('new_password');
          $param['vendor_password'] =   $this->ownerauth_model->encriptPassword($NewPassword);
        endif;

        if ($this->input->post('vendor_passcode')) :
          $vendor_passcode        = $this->input->post('vendor_passcode');
          $param['vendor_passcode'] =   $this->ownerauth_model->encriptPassword($vendor_passcode);
        endif;    
        
        $param['vendor_image']      =   addslashes($this->input->post('vendor_image'));
        $SDparam['vendor_address']    =   addslashes($this->input->post('vendor_address'));
        $SDparam['vendor_city']     =   addslashes($this->input->post('vendor_city'));
        $SDparam['vendor_pincode']    =   addslashes($this->input->post('vendor_pincode'));
        $SDparam['vendor_nationality']  =   addslashes($this->input->post('vendor_nationality'));
        $SDparam['vendor_pan']      =   addslashes($this->input->post('vendor_pan'));
        $SDparam['vendor_pan_attach'] =   addslashes($this->input->post('uploadimage0'));
        $SDparam['vendor_gst']      =   addslashes($this->input->post('gst_number'));
        $SDparam['vendor_gst_attach'] =   addslashes($this->input->post('uploadimage1'));
        $SDparam['vendor_address_proof'] =  addslashes($this->input->post('vendor_address_proof'));
        $SDparam['vendor_address_proof_attach'] =   addslashes($this->input->post('uploadimage2'));
        $SDparam['vendor_kyc_status'] =   $this->input->post('vendor_kyc_status');
        
        if ($this->input->post('CurrentDataID') == '') :
          $param['creation_date']   = currentDateTime();
          $param['created_by']    = $this->session->userdata('MHM_OWNER_ID');
          $param['vendor_type']   = 'Verified';
          $param['status']      = 'A';
          $lastInsertId       = $this->common_model->addData('vendor', $param);
          $Uparam['encrypt_id']   = ashishDecript($lastInsertId);
          $Uparam['vendor_id']    = generateUniqueId($lastInsertId);
          $Uparam['vendor_slug']    = strtolower(url_title(trim($this->input->post('vendor_business_name')))) . $lastInsertId;
          $Uwhere['id']       = $lastInsertId;
          $this->common_model->editDataByMultipleCondition('vendor', $Uparam, $Uwhere);
          $vendorId         = $Uparam['vendor_id'];
          if ($vendorId) :
            $SDparam['vendor_id']   = $vendorId;
            $SDparam['creation_date'] = currentDateTime();
            $SDparam['created_by']    = $this->session->userdata('MHM_OWNER_ID');
            $SDlastInsertId       = $this->common_model->addData('vendor_details', $SDparam);
            $SDUparam['encrypt_id']   = ashishDecript($SDlastInsertId);
            $SDUparam['vendor_detail_id'] = generateUniqueId($SDlastInsertId);
            $SDUwhere['id']       = $SDlastInsertId;
            $this->common_model->editDataByMultipleCondition('vendor_details', $SDUparam, $SDUwhere);
          endif;
          $this->session->set_flashdata('alert_success', lang('addsuccess'));
        else :
          $vendorId         = $this->input->post('CurrentDataID');
          $param['update_date']   = currentDateTime();
          $param['vendor_type']   = 'Verified';
          $param['updated_by']    = $this->session->userdata('MHM_OWNER_ID');
          $this->common_model->editData('vendor', $param, 'vendor_id', $vendorId);
            // START SENDING CRED
                if($data['KYCDATA']['vendor_kyc_status'] != 'Y'):
                    //$this->emailtemplate_model->UserRegistrationMailToUser($vendorId, $vendorPassword, $vendorPasscode);
                    //$this->emailtemplate_model->UserRegistrationMailToAdmin($vendorId);
                endif;
            // end of red
          if ($vendorId) :
            $SDparam['update_date'] = currentDateTime();
            $SDparam['updated_by']  = $this->session->userdata('MHM_OWNER_ID');
            $this->common_model->editData('vendor_details', $SDparam, 'vendor_id', $vendorId);
          endif;
          $this->session->set_flashdata('alert_success', lang('updatesuccess'));
        endif;
        redirect('owner/hotel');
      endif;
    endif;

    $this->layouts->set_title('Edit Hotel Details');
    $this->layouts->owner_view('owner/hotel/addeditOld', array(), $data);
  }
  public function addeditdata($editId = ''){
    $data['error'] = '';
    $data['activeMenu'] = 'Hotel';
    $data['activeSubMenu'] = 'Hotel';
    $data['LoginVenderId'] = sessionData('MHM_OWNER_ID');
    $data['custId'] = $editId;

    if($editId){
      $data['EDITDATA']   = $this->common_model->getDataByParticularField('vendor', 'vendor_id', $editId);
      $kycQuery = "SELECT * FROM " . getTablePrefix() . "vendor_details WHERE vendor_id = '" . $editId . "'";
      $data['KYCDATA'] = $this->common_model->getDataByQuery('single', $kycQuery);
    }

    if ($this->input->post('SaveChanges')) :
      $error          = 'NO';
      $this->form_validation->set_rules('vendor_business_name', 'Business name', 'trim');
      $this->form_validation->set_rules('vendor_title', 'Title', 'trim|required');
      $this->form_validation->set_rules('vendor_name', 'Name', 'trim');
      $this->form_validation->set_rules('vendor_email', 'E-Mail', 'trim|required|valid_email|is_unique[vendor.vendor_email]');
      $this->form_validation->set_rules('admin_mobile_number', 'Phone', 'trim|required|min_length[10]|max_length[15]');
      $vendoremail    = str_replace(' ', '', $this->input->post('vendor_email'));
      if ($this->input->post('vendor_email') && !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
        if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
          $error            = 'YES';
          $data['mobileerror']    =   'Please eneter correct email id.';
        endif;
      endif;
      $this->form_validation->set_rules('vendor_image', 'Image', 'trim');
      $this->form_validation->set_rules('vendor_address', 'Address', 'trim');
      $this->form_validation->set_rules('vendor_city', 'City', 'trim');
      $this->form_validation->set_rules('vendor_pincode', 'Pincode', 'trim');
      $this->form_validation->set_rules('vendor_nationality', 'Nationality', 'trim');
      $this->form_validation->set_rules('vendor_pan', 'Pan no', 'trim');
      $this->form_validation->set_rules('uploadimage0', 'Pan image', 'trim');
      $this->form_validation->set_rules('gst_number', 'GST no', 'trim');
      $this->form_validation->set_rules('uploadimage1', 'GST image', 'trim');
      $this->form_validation->set_rules('vendor_address_proof', 'Address proof type', 'trim');
      $this->form_validation->set_rules('uploadimage2', 'Address proof image', 'trim');

      $this->form_validation->set_rules('vendor_kyc_status', 'KYC verify', 'trim');

      if ($this->form_validation->run() && $error == 'NO'):  

        $param['vendor_title']      =   addslashes($this->input->post('vendor_title'));
        $param['vendor_name']     =   addslashes($this->input->post('vendor_name'));
        $param['vendor_business_name']  =   addslashes($this->input->post('vendor_business_name'));
        $param['vendor_email']      =   addslashes($this->input->post('vendor_email'));
        $param['vendor_phone']      =   addslashes($this->input->post('admin_mobile_number'));
        $param['owner_secoundry_contact_number'] = addslashes($this->input->post('owner_secoundry_contact_number'));
        $param['first_manager_contact_number'] = addslashes($this->input->post('manager_contact_number_first'));
        $param['secound_manager_contact_number'] = addslashes($this->input->post('manager_contact_number_secound'));
        $param['booking_mode'] = addslashes($this->input->post('booking_mode')); 
        $param['transaction_id'] = addslashes($this->input->post('transaction_id')); 
        $param['id_proof'] = addslashes($this->input->post('id_proof')); 
          
        if ($this->input->post('vendor_passcode')) :
          $vendor_passcode        = $this->input->post('vendor_passcode');
          $param['vendor_passcode'] =   $this->ownerauth_model->encriptPassword($vendor_passcode);
        endif;    
        
        $param['vendor_image']      =   addslashes($this->input->post('vendor_image'));
        
        $SDparam['bill_number'] = addslashes($this->input->post('bill_number'));
        $SDparam['entry_number'] = addslashes($this->input->post('entry_number'));
        $SDparam['website_url'] = addslashes($this->input->post('website'));
        $SDparam['managed_by'] = addslashes($this->input->post('managed_by'));
        $SDparam['other_details'] = addslashes($this->input->post('other_details'));
        $SDparam['vendor_gst']      =   addslashes($this->input->post('gst_number'));
        $SDparam['you_are'] = addslashes($this->input->post('you_are'));
        $SDparam['vendor_address']    =   addslashes($this->input->post('vendor_address'));
        if ($this->input->post('CurrentDataID') == '') :

          $param['parent_id']     =   sessionData('MHM_OWNER_ID');
          $NewPassword        = 'admin123';
          $param['vendor_password'] =   $this->ownerauth_model->encriptPassword($NewPassword);

          $param['creation_date']   = currentDateTime();
          $param['created_by']    = $this->session->userdata('MHM_OWNER_ID');
          $param['vendor_type']   = 'Verified';
          $param['status']      = 'A';
          $lastInsertId       = $this->common_model->addData('vendor', $param);
          $Uparam['encrypt_id']   = ashishDecript($lastInsertId);
          $Uparam['vendor_id']    = generateUniqueId($lastInsertId);
          $Uparam['vendor_slug']    = strtolower(url_title(trim($this->input->post('vendor_business_name')))) . $lastInsertId;
          $Uwhere['id']       = $lastInsertId;
          $this->common_model->editDataByMultipleCondition('vendor', $Uparam, $Uwhere);
          $vendorId         = $Uparam['vendor_id'];
          if ($vendorId) :
            $SDparam['vendor_id']   = $vendorId;
            $SDparam['creation_date'] = currentDateTime();
            $SDparam['created_by']    = $this->session->userdata('MHM_OWNER_ID');
            $SDlastInsertId       = $this->common_model->addData('vendor_details', $SDparam);
            $SDUparam['encrypt_id']   = ashishDecript($SDlastInsertId);
            $SDUparam['vendor_detail_id'] = generateUniqueId($SDlastInsertId);
            $SDUwhere['id']       = $SDlastInsertId;
            $this->common_model->editDataByMultipleCondition('vendor_details', $SDUparam, $SDUwhere);
          endif;
          $this->session->set_flashdata('alert_success', lang('addsuccess'));
        else :
          $vendorId         = $this->input->post('CurrentDataID');
          $param['update_date']   = currentDateTime();
          $param['vendor_type']   = 'Verified';
          $param['updated_by']    = $this->session->userdata('MHM_OWNER_ID');
          $this->common_model->editData('vendor', $param, 'vendor_id', $vendorId);
            // START SENDING CRED
                if($data['KYCDATA']['vendor_kyc_status'] != 'Y'):
                    //$this->emailtemplate_model->UserRegistrationMailToUser($vendorId, $vendorPassword, $vendorPasscode);
                    //$this->emailtemplate_model->UserRegistrationMailToAdmin($vendorId);
                endif;
            // end of red
          if ($vendorId) :
            $SDparam['update_date'] = currentDateTime();
            $SDparam['updated_by']  = $this->session->userdata('MHM_OWNER_ID');
            $this->common_model->editData('vendor_details', $SDparam, 'vendor_id', $vendorId);
          endif;
          $this->session->set_flashdata('alert_success', lang('updatesuccess'));
        endif;
        redirect('owner/hotel');
      endif;
    endif;

    $this->layouts->set_title('Edit Hotel Details');
    $this->layouts->owner_view('owner/hotel/addedit', array(), $data);
  }
  function firstImageUpload(){
    if ($this->input->post('imageData')) :
      $imageData        =   $this->input->post('imageData');
      $imageName        =   time() . '.png';
      $imageFolder      = '';
      $imageType        = 'vendorImage';
      $this->load->library("upload_crop_img");
      $returnFileName   = $this->upload_crop_img->_upload_canvas_image($imageData, $imageName, $imageType, $imageFolder);
      if ($returnFileName) :
        echo $returnFileName;
        die;
      else :
        echo 'UPLODEERROR';
        die;
      endif;
    else :
      echo 'UPLODEERROR';
      die;
    endif;
  } // END OF FUNCTION
  function firstImageDelete(){
    $imageName  = $this->input->post('imageName');
    if ($imageName) :
      $this->load->library("upload_crop_img");
      $return = $this->upload_crop_img->_delete_image($imageName);
    endif;
    echo '1';
    die;
  } // END OF FUNCTION

  function UplodeImage(){
    $file_name          =   $_FILES['uploadfile']['name'];
    if ($file_name) :
      $tmp_name       =   $_FILES['uploadfile']['tmp_name'];
      $imageInformation     =   getimagesize($_FILES['uploadfile']['tmp_name']);
      if ($imageInformation[0] <= 800 && $imageInformation[1] <= 800) :
        $this->load->library("upload_crop_img");
        $return_file_name = $this->upload_crop_img->_upload_image($file_name, $tmp_name, 'vendorProofImage');
        echo $return_file_name;
        die;
      else :
        echo 'ERROR_____Image Must Be Max Width:800px And Height:800px.';
        die;
      endif;
    else :
      echo 'UPLODEERROR';
      die;
    endif;
  }
  function DeleteImage(){
    $imagename  = $this->input->post('imagename');
    if ($imagename) :
      $this->load->library("upload_crop_img");
      $return = $this->upload_crop_img->_delete_image($imagename);
    endif;
    echo '1';
    die;
  }
  function changestatus($changeStatusId = '', $statusType = ''){
    $param['status']    = $statusType;
    $this->common_model->editData('vendor', $param, 'vendor_id', $changeStatusId);
    $this->session->set_flashdata('alert_success', lang('statussuccess'));
    redirect('owner/hotel');
  }
}