<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Adminmessages extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        error_reporting(E_ALL ^ E_NOTICE);
        $this->load->model(array('adminauth_model', 'admin_model', 'emailtemplate_model', 'sms_model'));
        $this->lang->load('statictext', 'admin');
        $this->load->helper('admin');
    }
    /* * *********************************************************************
     * * Function name : Chat SMS
     * * Developed By : Ashish Umrao
     * * Purpose  : This function used for Chat SMS
     * * Date : 07  MAY 2022
     * * **********************************************************************/
    public function index()
    {
        $this->adminauth_model->authCheck('admin', 'view_data');
        $data['error'] = '';
        $data['activeMenu'] = 'adminmessages';
        $data['activeSubMenu'] = 'adminmessages';

        if ($this->input->get('searchValue')):
            $sValue = $this->input->get('searchValue');
            $whereCon['like'] = "(adm.title LIKE '%" . $sValue . "%')";
            $data['searchValue'] = $sValue;
        else:
            $whereCon['like'] = "";
            $data['searchValue'] = '';
        endif;
        $whereCon['where'] = "";

        $shortField = 'adm.creation_date DESC';

        $baseUrl = $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index';
        $this->session->set_userdata('chatAdminData', currentFullUrl());
        $qStringdata = explode('?', currentFullUrl());
        $suffix = $qStringdata[1] ? '?' . $qStringdata[1] : '';
        $tblName = 'admin_individual_chat as adm';
        $con = '';
        $totalRows = $this->admin_model->selectAdminMessageData('count', $tblName, $whereCon, $shortField, '0', '0');

        if ($this->input->get('showLength') == 'All'):
            $perPage = $totalRows;
            $data['perpage'] = $this->input->get('showLength');
        elseif ($this->input->get('showLength')):
            $perPage = $this->input->get('showLength');
            $data['perpage'] = $this->input->get('showLength');
        else:
            $perPage = SHOW_NO_OF_DATA;
            $data['perpage'] = SHOW_NO_OF_DATA;
        endif;
        $uriSegment = getUrlSegment();
        $data['PAGINATION'] = adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

        if ($this->uri->segment(getUrlSegment())):
            $page = $this->uri->segment(getUrlSegment());
        else:
            $page = 0;
        endif;

        $data['forAction'] = $baseUrl;
        if ($totalRows):
            $first = ($page) + 1;
            $data['first'] = $first;
            $last = (($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
            $data['noOfContent'] = 'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
        else:
            $data['first'] = 1;
            $data['noOfContent'] = '';
        endif;

         // update view reminder flag status
		 $where                     =     "admin_id = '" . sessionData('MHM_ADMIN_ID') . "' AND creation_date LIKE  '%" . date('Y-m-d') . "%'";
		 $param['msg_flag_admin']        =    0;
		 $param['updated_by']        =    $this->session->userdata('MHM_ADMIN_ID');
		 $this->common_model->editDataByMultipleCondition('admin_individual_chat', $param, $where);
		 //END
        $data['ALLDATA'] = $this->admin_model->selectAdminMessageData('data', $tblName, $whereCon, $shortField, $perPage, $page);

        //////////////////        ADD EDIT SECTION   START     ////////////////
        $data['formError'] = 'No';
        $data['editid'] = '';
        $data['editlink'] = $qStringdata[1] ? $baseUrl . '?' . $qStringdata[1] . '&editid=' : $baseUrl . '?editid=';
        if (strpos($data['editlink'], 'showLength')):
            $showlinkdata = explode('&editid=', $data['editlink']);
            if ($page > 0):
                $newlinkdata = explode('?', $showlinkdata[0]);
                $data['cancellink'] = $newlinkdata[0] . '/' . $page . '?' . $newlinkdata[1];
            else:
                $data['cancellink'] = $showlinkdata[0];
            endif;
        else:
            $showlinkdata = explode('?editid=', $data['editlink']);
            if ($page > 0):
                $data['cancellink'] = $showlinkdata[0] . '/' . $page;
            else:
                $data['cancellink'] = $showlinkdata[0];
            endif;
        endif;
        if ($this->input->post('SaveChanges')):

            $error = 'NO';
            $data['formError'] = 'Yes';
            $this->form_validation->set_rules('message', 'message', 'trim|required');

            if ($this->form_validation->run() && $error == 'NO'):

                $data['formError'] = 'No';
                $vendorID = $this->input->post('vendor_id');
                foreach ($vendorID as $vID) {
                    $param['message'] = addslashes($this->input->post('message'));
                    $param['admin_id'] = $this->session->userdata('MHM_ADMIN_ID');
                    $param['hotel_manager_id'] = $vID;
                    $param['creation_date'] = currentDateTime();
                    $param['created_by'] = $this->session->userdata('MHM_ADMIN_ID');
                    $param['status'] = 'Y';
                    $param['message_type'] = 'sent';
                    $param['msg_flag']                  =    1;
                    $alastInsertId = $this->common_model->addData('admin_individual_chat', $param);
                    $Uparam['encrypt_id'] = ashishEncript($alastInsertId);
                    $Uparam['message_id'] = generateUniqueId($alastInsertId);
                    $Uwhere['id'] = $alastInsertId;
                    $this->common_model->editDataByMultipleCondition('admin_individual_chat', $Uparam, $Uwhere);
                    $this->session->set_flashdata('alert_success', lang('addsuccess'));
                }
                redirect($data['cancellink']);
            endif;
        endif;
        //////////////////        ADD EDIT SECTION   END     ////////////////
        $this->layouts->set_title('Manage Chat Section');
        $this->layouts->admin_view('admin/adminchat/index', array(), $data);
    } // END OF FUNCTION

    /***********************************************************************
     ** Function name : changeStatus
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for change status
     ** Date : 07  MAY 2022
     ************************************************************************/
    public function changeStatus($changeStatusId = '', $statusType = '')
    {
        $this->adminauth_model->authCheck('admin', 'view_data');
        $param['status'] = $statusType;
        $this->common_model->editData('admin_individual_chat', $param, 'service_id', $changeStatusId);
        $this->session->set_flashdata('alert_success', lang('statussuccess'));
        redirect(correctLink('chatAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
    }

    /***********************************************************************
     ** Function name : deleteData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for delete data
     ** Date : 07  MAY 2022
     ************************************************************************/
    public function deleteData($deleteId = '')
    {
        $this->adminauth_model->authCheck('admin', 'view_data');
        $this->common_model->deleteParticularData('admin_individual_chat', 'service_id', $deleteId);
        $this->session->set_flashdata('alert_success', lang('deletesuccess'));
        redirect(correctLink('chatAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
    }
}
