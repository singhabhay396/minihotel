<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Adminhotelowner extends CI_Controller
{
	public function  __construct()
	{
		parent::__construct();
		error_reporting(E_ALL ^ E_NOTICE);
		$this->load->model(array('adminauth_model', 'admin_model', 'emailtemplate_model', 'sms_model','frontauth_model','owner_model'));
		$this->lang->load('statictext', 'admin');
		$this->load->helper('admin','general');
	}

	/* * *********************************************************************
	 * * Function name : Hotel Owner
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for vendor
	 * * Date : 08 April 2022
	 * * **********************************************************************/
	public function index()
	{
		$this->adminauth_model->authCheck('admin', 'view_data');
		$this->adminauth_model->getPermissionType($data);
		$data['error'] 						= 	'';
		$data['activeMenu'] 				= 	'adminhotelowner';
		$data['activeSubMenu'] 				= 	'adminhotelowner';

		if ($this->input->get('searchValue')) :
			$sValue							=	$this->input->get('searchValue');
			$whereCon['like']		 		= 	"(ven.vendor_title LIKE '%" . $sValue . "%'
			                   					  OR ven.vendor_name LIKE '%" . $sValue . "%'
												  OR ven.vendor_business_name LIKE '%" . $sValue . "%'
												  OR ven.vendor_phone LIKE '%" . $sValue . "%'
												  OR ven.vendor_email LIKE '%" . $sValue . "%'
												  OR vende.vendor_address LIKE '%" . $sValue . "%'
												  OR vende.vendor_nationality LIKE '%" . $sValue . "%'
												  OR vende.vendor_pan LIKE '%" . $sValue . "%'
												  OR vende.vendor_gst LIKE '%" . $sValue . "%'
												  OR vende.vendor_address_proof LIKE '%" . $sValue . "%'
												  OR vende.vendor_kyc_status LIKE '%" . $sValue . "%')";
			$data['searchValue'] 			= 	$sValue;
		else :
			$whereCon['like']		 		= 	"";
			$data['searchValue'] 			= 	'';
		endif;

		// $whereCon['where']		 			= 	"ven.vendor_type = 'Verified'";
		$shortField 						= 	'ven.vendor_id DESC';
        $grField 						= 	'ven.vendor_id';
		$baseUrl 							= 	$this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index';
		$this->session->set_userdata('vendorAdminData', currentFullUrl());
		$qStringdata						=	explode('?', currentFullUrl());
		$suffix								= 	$qStringdata[1] ? '?' . $qStringdata[1] : '';
		$tblName 							= 	'vendor as ven';
		$con 								= 	'';
		$totalRows 							= 	$this->admin_model->selectSelletData('count', $tblName, $whereCon, $shortField, '0', '0',$grField,1);

		if ($this->input->get('showLength') == 'All') :
			$perPage	 					= 	$totalRows;
			$data['perpage'] 				= 	$this->input->get('showLength');
		elseif ($this->input->get('showLength')) :
			$perPage	 					= 	$this->input->get('showLength');
			$data['perpage'] 				= 	$this->input->get('showLength');
		else :
			$perPage	 					= 	SHOW_NO_OF_DATA;
			$data['perpage'] 				= 	SHOW_NO_OF_DATA;
		endif;
		$uriSegment 						= 	getUrlSegment();
		$data['PAGINATION']					=	adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

		if ($this->uri->segment(getUrlSegment())) :
			$page = $this->uri->segment(getUrlSegment());
		else :
			$page = 0;
		endif;

		$data['forAction'] 					= 	$baseUrl;
		if ($totalRows) :
			$first							=	($page) + 1;
			$data['first']					=	$first;
			$last							=	(($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
			$data['noOfContent']			=	'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
		else :
			$data['first']					=	1;
			$data['noOfContent']			=	'';
		endif;

		$data['ALLDATA'] 					= 	$this->admin_model->selectSelletData('data', $tblName, $whereCon, $shortField, $perPage, $page,$grField,1);
		$this->layouts->set_title('Manage Seller Details');
		$this->layouts->admin_view('admin/vendor/index', array(), $data);
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : addeditdata
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for add edit data
	 * * Date : 11 APRIL 2022
	 * * **********************************************************************/
	public function addeditdata($editId = '')
	{
		$data['error'] 				= 	'';
		$data['activeMenu'] 		= 	'adminhotelowner';
		$data['activeSubMenu'] 		= 	'adminhotelowner';

		if ($editId) :
			$this->adminauth_model->authCheck('admin', 'edit_data');
			$data['EDITDATA']		=	$this->common_model->getDataByParticularField('vendor', 'vendor_id', $editId);
      $vendorPassword = 	$this->adminauth_model->decryptsPassword($data['EDITDATA']['vendor_password']);
      $vendorList = 	$this->owner_model->GetOwnerVendorList($editId);
      $data['vendorList'] = $vendorList;
      if($data['EDITDATA']['vendor_passcode']){
      	$VendorPassCode = $data['EDITDATA']['vendor_passcode'];
      }else{
      	$VendorPassCode = 'qMkDUqAxYsRPXHz/UUHW1OL+dY1MLlW47XO8mygMC/9xYkt0WUo1emllcEFaUldmbHBJbWhyL1N0OUZvUEE9PQ==';
      }
      $vendorPasscode = $this->adminauth_model->decryptsPassword($VendorPassCode);
      //echo '<pre>';print_r($data);die();	
			$kycQuery				=	"SELECT * FROM " . getTablePrefix() . "vendor_details
										 WHERE vendor_id = '" . $editId . "'";
			$data['KYCDATA']		=	$this->common_model->getDataByQuery('single', $kycQuery);
		else :
			$this->adminauth_model->authCheck('admin', 'add_data');
		endif;

		if ($this->input->post('SaveChanges')) :
			
			$error					=	'NO';
			$this->form_validation->set_rules('vendor_business_name', 'Business name', 'trim');
			$this->form_validation->set_rules('vendor_title', 'Title', 'trim|required');
			$this->form_validation->set_rules('vendor_name', 'Name', 'trim');
			//$this->form_validation->set_rules('vendor_email', 'E-Mail', 'trim|required|valid_email|is_unique[vendor.vendor_email]');
			$this->form_validation->set_rules('admin_mobile_number', 'Phone', 'trim|required|min_length[10]|max_length[15]');
			$vendoremail		=	str_replace(' ', '', $this->input->post('vendor_email'));
			if ($this->input->post('vendor_email') && !preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
				if (!preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $vendoremail)) :
					$error						=	'YES';
					$data['mobileerror'] 		= 	'Please eneter correct email id.';
				endif;
			endif;
			$this->form_validation->set_rules('vendor_image', 'Image', 'trim');
			if ($this->input->post('new_password') != '') :
				$this->form_validation->set_rules('new_password', 'New password', 'trim|required|min_length[6]|max_length[25]');
				$this->form_validation->set_rules('conf_password', 'Confirm password', 'trim|required|min_length[6]|matches[new_password]');
			endif;

			$this->form_validation->set_rules('vendor_address', 'Address', 'trim');
			$this->form_validation->set_rules('vendor_city', 'City', 'trim');
			$this->form_validation->set_rules('vendor_pincode', 'Pincode', 'trim');
			$this->form_validation->set_rules('vendor_nationality', 'Nationality', 'trim');
			$this->form_validation->set_rules('vendor_pan', 'Pan no', 'trim');
			$this->form_validation->set_rules('uploadimage0', 'Pan image', 'trim');
			$this->form_validation->set_rules('vendor_gst', 'GST no', 'trim');
			$this->form_validation->set_rules('uploadimage1', 'GST image', 'trim');
			$this->form_validation->set_rules('vendor_address_proof', 'Address proof type', 'trim');
			$this->form_validation->set_rules('uploadimage2', 'Address proof image', 'trim');

			$this->form_validation->set_rules('vendor_kyc_status', 'KYC verify', 'trim');

			if ($this->form_validation->run() && $error == 'NO'):  
           
              
				$param['vendor_title']			= 	addslashes($this->input->post('vendor_title'));
				$param['vendor_name']			= 	addslashes($this->input->post('vendor_name'));
				$param['vendor_business_name']	= 	addslashes($this->input->post('vendor_business_name'));
				$param['vendor_email']			= 	addslashes($this->input->post('vendor_email'));
				$param['vendor_phone']			= 	addslashes($this->input->post('admin_mobile_number'));
				$param['whatsapp_checkin']		= 	addslashes($this->input->post('whatsapp_checkin'));
				$param['feedback_link']			= 	addslashes($this->input->post('feedback_link'));
				$param['contact_owner']			= 	addslashes($this->input->post('contact_owner'));
				$param['whatsapp_checkout']		= 	addslashes($this->input->post('whatsapp_checkout'));
				$param['whatsapp_bulk']			= 	addslashes($this->input->post('whatsapp_bulk'));

				if ($this->input->post('new_password')) :
					$NewPassword				=	$this->input->post('new_password');
					$param['vendor_password']	= 	$this->adminauth_model->encriptPassword($NewPassword);
				endif;

                if ($this->input->post('vendor_passcode')) :
					$vendor_passcode				=	$this->input->post('vendor_passcode');
					$param['vendor_passcode']	= 	$this->adminauth_model->encriptPassword($vendor_passcode);
				endif;    


			    //$vendorPassword = generateRandomString(6, 'nl');
                //$vendorPasscode = generateRandomString(6, 'nl');
                //$param['vendor_passcode'] = $this->frontauth_model->encriptPassword($vendorPasscode);
                //$param['vendor_password'] = $this->frontauth_model->encriptPassword($vendorPassword);
				$param['vendor_image']			= 	addslashes($this->input->post('vendor_image'));
				$SDparam['vendor_address']		= 	addslashes($this->input->post('vendor_address'));
				$SDparam['vendor_city']			= 	addslashes($this->input->post('vendor_city'));
				$SDparam['vendor_pincode']		= 	addslashes($this->input->post('vendor_pincode'));
				$SDparam['vendor_nationality']	= 	addslashes($this->input->post('vendor_nationality'));
				$SDparam['vendor_pan']			= 	addslashes($this->input->post('vendor_pan'));
				$SDparam['vendor_pan_attach']	= 	addslashes($this->input->post('uploadimage0'));
				$SDparam['vendor_gst']			= 	addslashes($this->input->post('vendor_gst'));
				$SDparam['vendor_gst_attach']	= 	addslashes($this->input->post('uploadimage1'));
				$SDparam['vendor_address_proof'] = 	addslashes($this->input->post('vendor_address_proof'));
				$SDparam['vendor_address_proof_attach'] = 	addslashes($this->input->post('uploadimage2'));
				$SDparam['vendor_kyc_status']	= 	$this->input->post('vendor_kyc_status');
				$SDparam['no_of_restaurant']	= 	$this->input->post('no_of_restaurant'); 

				if ($this->input->post('CurrentDataID') == '') :
					$param['creation_date']		=	currentDateTime();
					$param['created_by']		=	$this->session->userdata('MHM_ADMIN_ID');
					$param['vendor_type']		=	'Verified';
					$param['status']			=	'A';
					$lastInsertId				=	$this->common_model->addData('vendor', $param);
					$Uparam['encrypt_id']		=	ashishDecript($lastInsertId);
					$Uparam['vendor_id']		=	generateUniqueId($lastInsertId);
					$Uparam['vendor_slug']		=	strtolower(url_title(trim($this->input->post('vendor_business_name')))) . $lastInsertId;
					$Uwhere['id']				=	$lastInsertId;
					$this->common_model->editDataByMultipleCondition('vendor', $Uparam, $Uwhere);
					$vendorId					=	$Uparam['vendor_id'];
					if ($vendorId) :
						$SDparam['vendor_id']		=	$vendorId;
						$SDparam['creation_date']	=	currentDateTime();
						$SDparam['created_by']		=	$this->session->userdata('MHM_ADMIN_ID');
						$SDlastInsertId				=	$this->common_model->addData('vendor_details', $SDparam);
						$SDUparam['encrypt_id']		=	ashishDecript($SDlastInsertId);
						$SDUparam['vendor_detail_id'] =	generateUniqueId($SDlastInsertId);
						$SDUwhere['id']				=	$SDlastInsertId;
						$this->common_model->editDataByMultipleCondition('vendor_details', $SDUparam, $SDUwhere);
					endif;
					$this->session->set_flashdata('alert_success', lang('addsuccess'));
				else :
					$vendorId					=	$this->input->post('CurrentDataID');
					$param['update_date']		=	currentDateTime();
					$param['vendor_type']		=	'Verified';
					$param['updated_by']		=	$this->session->userdata('MHM_ADMIN_ID');
					$this->common_model->editData('vendor', $param, 'vendor_id', $vendorId);
						// START SENDING CRED
      					if($data['KYCDATA']['vendor_kyc_status'] != 'Y'):
						$this->emailtemplate_model->UserRegistrationMailToUser($vendorId, $vendorPassword, $vendorPasscode);
                		$this->emailtemplate_model->UserRegistrationMailToAdmin($vendorId);
      					endif;
						// end of red
					if ($vendorId) :
						$SDparam['update_date']	=	currentDateTime();
						$SDparam['updated_by']	=	$this->session->userdata('MHM_ADMIN_ID');
						$this->common_model->editData('vendor_details', $SDparam, 'vendor_id', $vendorId);
					endif;
					if(!empty($this->input->post('vendor_ids'))){
						$vendorList = $this->input->post('vendor_ids');
						$isRestaurant =  $this->input->post('is_restaurant');
						$isTable = $this->input->post('is_table');
						$ids = $this->input->post('ids');
						//echo "<pre>"; print_r($_POST); exit;
						foreach ($vendorList as $key => $value) {

							if(isset($ids[$value]) && !empty($ids[$value])){
								$RSparam['vendor_id']		=	$value;
								$RSparam['owner_id']		=	$editId;
								$RSparam['is_restaurant']		= isset($isRestaurant[$value]) && $isRestaurant[$value] == 'on' ? 1:0;
								$RSparam['is_table']			=	isset($isTable[$value]) && $isTable[$value] == 'on' ? 1:0;
								$RSparam['update_date']	=	currentDateTime();
								$this->common_model->editData('restaurant_setting', $RSparam, 'id',$ids[$value]);
							}
							else{
								$RSparam['owner_id']		=	$editId;
								$paramV['vendor_id']		=	$value;
								$paramV['is_restaurant']		= isset($isRestaurant[$value]) && $isRestaurant[$value] == 'on' ? 1:0;
								$paramV['is_table']			=	isset($isTable[$value]) && $isTable[$value] == 'on' ? 1:0;
								$paramV['create_date']		=	currentDateTime();
								$lastInsertIdV				=	$this->common_model->addData('restaurant_setting', $paramV);
							}
							
						}

					}
					$this->session->set_flashdata('alert_success', lang('updatesuccess'));
				endif;
				redirect(correctLink('vendorAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
			endif;
		endif;

		$this->layouts->set_title('Edit Seller Details');
		$this->layouts->admin_view('admin/vendor/addeditdata', array(), $data);
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : firstImageUpload
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for first Image Upload
	 ** Date : 11 APRIL 2022
	 ************************************************************************/
	function firstImageUpload()
	{
		if ($this->input->post('imageData')) :
			$imageData				= 	$this->input->post('imageData');
			$imageName				= 	time() . '.png';
			$imageFolder			=	'';

			$imageType				=	'vendorImage';

			$this->load->library("upload_crop_img");
			$returnFileName		=	$this->upload_crop_img->_upload_canvas_image($imageData, $imageName, $imageType, $imageFolder);
			if ($returnFileName) :
				echo $returnFileName;
				die;
			else :
				echo 'UPLODEERROR';
				die;
			endif;
		else :
			echo 'UPLODEERROR';
			die;
		endif;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : firstImageDelete
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for first Image Delete
	 ** Date : 11 APRIL 2022
	 ************************************************************************/
	function firstImageDelete()
	{
		$imageName	=	$this->input->post('imageName');
		if ($imageName) :
			$this->load->library("upload_crop_img");
			$return	=	$this->upload_crop_img->_delete_image($imageName);
		endif;
		echo '1';
		die;
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : UplodeImage
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used uplode image
	 ** Date : 11 APRIL 2022
	 ************************************************************************/
	function UplodeImage()
	{
		$file_name					= 	$_FILES['uploadfile']['name'];
		if ($file_name) :
			$tmp_name				= 	$_FILES['uploadfile']['tmp_name'];
			$imageInformation 		= 	getimagesize($_FILES['uploadfile']['tmp_name']);
			if ($imageInformation[0] <= 800 && $imageInformation[1] <= 800) :
				$this->load->library("upload_crop_img");
				$return_file_name	=	$this->upload_crop_img->_upload_image($file_name, $tmp_name, 'vendorProofImage');
				echo $return_file_name;
				die;
			else :
				echo 'ERROR_____Image Must Be Max Width:800px And Height:800px.';
				die;
			endif;
		else :
			echo 'UPLODEERROR';
			die;
		endif;
	}

	/***********************************************************************
	 ** Function name : DeleteImage
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for delete image by ajax.
	 ** Date : 11 APRIL 2022
	 ************************************************************************/
	function DeleteImage()
	{
		$imagename	=	$this->input->post('imagename');
		if ($imagename) :
			$this->load->library("upload_crop_img");
			$return	=	$this->upload_crop_img->_delete_image($imagename);
		endif;
		echo '1';
		die;
	}

	/***********************************************************************
	 ** Function name : changestatus
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for change status
	 ** Date : 11 APRIL 2022
	 ************************************************************************/
	function changestatus($changeStatusId = '', $statusType = '')
	{
		$this->adminauth_model->authCheck('admin', 'edit_data');

		$param['status']		=	$statusType;
		$this->common_model->editData('vendor', $param, 'vendor_id', $changeStatusId);

		$this->session->set_flashdata('alert_success', lang('statussuccess'));

		redirect(correctLink('vendorAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
	}

  /***********************************************************************
	 ** Function name : deleteData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for delete data
	 ** Date : 14 MAY 2022
	 ************************************************************************/
	function deleteData($deleteId = '')
	{
		$this->adminauth_model->authCheck('admin', 'edit_data');

		$this->common_model->deleteParticularVenodrData('vendor', 'vendor_id', $deleteId);

		$this->session->set_flashdata('alert_success', lang('deletesuccess'));

		redirect(correctLink('vendorAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
	}
  
	/***********************************************************************
	 ** Function name : get_view_data
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for get view data.
	 ** Date : 11 APRIL 2022
	 ************************************************************************/
	function get_view_data()
	{
		$html					=	'';
		if ($this->input->post('viewid')) :
			$viewId					=	$this->input->post('viewid');
			$viewData				=	$this->common_model->getDataByParticularField('vendor', 'vendor_id', $viewId);
			if ($viewData <> "") :
				if ($viewData['vendor_image']) :
					$vendorimg  	=	'<img src="' . $viewData['vendor_image'] . '" alt="Vendor image" width="100">';
				else :
					$vendorimg  	=	'';
				endif;
				$kycData			=	$this->common_model->getDataByParticularField('vendor_details', 'vendor_id', $viewId);
				if ($kycData['vendor_pan_attach']) :
					$vendorpanimg  	=	'<img src="' . $kycData['vendor_pan_attach'] . '" alt="Pan image" width="100">';
				else :
					$vendorpanimg  	=	'';
				endif;
				if ($kycData['vendor_gst_attach']) :
					$vendorgstimg  	=	'<img src="' . $kycData['vendor_gst_attach'] . '" alt="GST image" width="100">';
				else :
					$vendorgstimg  	=	'';
				endif;
				if ($kycData['vendor_address_proof_attach']) :
					$vendoraddimg  	=	'<img src="' . $kycData['vendor_address_proof_attach'] . '" alt="Address proof image" width="100">';
				else :
					$vendoraddimg  	=	'';
				endif;
				$html			.=	'<table class="table border-none">
									  <tbody>
										<tr>
										  <td>';
				$html			.=	'<table class="table border-none">
									  <thead>
										<tr>
										  <th align="left" colspan="2"><strong>Personal details</strong></th>
										</tr>
									  </thead>
									  <tbody><tr>
									  <td align="left" width="30%"><strong>Business Name</strong></td>
									  <td align="left" width="70%">' . stripslashes($viewData['vendor_business_name']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Title</strong></td>
									  <td align="left" width="70%">' . stripslashes($viewData['vendor_title']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Name</strong></td>
									  <td align="left" width="70%">' . stripslashes($viewData['vendor_name']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Email</strong></td>
									  <td align="left" width="70%">' . stripslashes($viewData['vendor_email']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Owner Mobile Number 1</strong></td>
									  <td align="left" width="70%">' . stripslashes($viewData['vendor_phone']) . '</td>
									</tr>
                                    <tr>
									  <td align="left" width="30%"><strong>Owner Mobile Number 2</strong></td>
									  <td align="left" width="70%">' . stripslashes($viewData['owner_secoundry_contact_number']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Image</strong></td>
									  <td align="left" width="70%">' . $vendorimg . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Referral Code</strong></td>
									  <td align="left" width="70%">' . stripslashes($viewData['referral_code']) . '</td>
									</tr>
                                    <tr>
									  <td align="left" width="30%"><strong>Manager Mobile Number 1</strong></td>
									  <td align="left" width="70%">' . stripslashes($viewData['first_manager_contact_number']) . '</td>
									</tr>
                                    <tr>
									  <td align="left" width="30%"><strong>Manager Mobile Number 2</strong></td>
									  <td align="left" width="70%">' . stripslashes($viewData['secound_manager_contact_number']) . '</td>
									</tr>
                                    <tr>
									  <td align="left" width="30%"><strong>You Are</strong></td>
									  <td align="left" width="70%">' . stripslashes($kycData['you_are']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Status</strong></td>
									  <td align="left" width="70%">' . showStatus($viewData['status']) . '</td>
									</tr>
									</tbody>
										</table></td>
									</tr>';
				$html			.=	'<tr>
										  <td>
										<table class="table border-none">
									  <thead>
										<tr>
										  <th align="left" colspan="2"><strong>KYC details</strong></th>
										</tr>
									  </thead>
									  <tbody><tr>
									  <td align="left" width="30%"><strong>Address</strong></td>
									  <td align="left" width="70%">' . stripslashes($kycData['vendor_address']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>City</strong></td>
									  <td align="left" width="70%">' . stripslashes($kycData['vendor_city']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Pincode</strong></td>
									  <td align="left" width="70%">' . stripslashes($kycData['vendor_pincode']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Nationality</strong></td>
									  <td align="left" width="70%">' . stripslashes($kycData['vendor_nationality']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Pan No</strong></td>
									  <td align="left" width="70%">' . stripslashes($kycData['vendor_pan']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Pan Image</strong></td>
									  <td align="left" width="70%">' . $vendorpanimg . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>GST No</strong></td>
									  <td align="left" width="70%">' . stripslashes($kycData['vendor_gst']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>GST Image</strong></td>
									  <td align="left" width="70%">' . $vendorgstimg . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Address Proof</strong></td>
									  <td align="left" width="70%">' . stripslashes($kycData['vendor_address_proof']) . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>Address Proof Image</strong></td>
									  <td align="left" width="70%">' . $vendoraddimg . '</td>
									</tr>
									<tr>
									  <td align="left" width="30%"><strong>KYC Verify</strong></td>
									  <td align="left" width="70%">' . showKYCStatus($kycData['vendor_kyc_status']) . '</td>
									</tr>
									</tbody>
										</table></td>
									</tr>';
				$html			.=	'</td>
										</tr></tbody>
									</table>';
			endif;
		endif;
		echo $html;
		die;
	}


	
}