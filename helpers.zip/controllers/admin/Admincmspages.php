<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admincmspages extends CI_Controller {

	public function  __construct()
	{
		parent:: __construct();
		error_reporting(E_ALL ^ E_NOTICE);
		$this->load->model(array('adminauth_model','admin_model','emailtemplate_model','sms_model'));
		$this->lang->load('statictext', 'admin');
		$this->load->helper('admin');
	}

	/* * *********************************************************************
	 * * Function name : cms pages
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for cms pages
	 * * Date : 09   MAY 2022
	 * * **********************************************************************/
	public function index()
	{
		$this->adminauth_model->authCheck('admin','view_data');
		$data['error'] 						= 	'';
		$this->adminauth_model->getPermissionType($data);
		$data['activeMenu'] 				= 	'adminhomebanner';
		$data['activeSubMenu'] 				= 	'admincmspages';

		if($this->input->get('searchValue')):
			$sValue							=	$this->input->get('searchValue');
			$whereCon['like']		 		= 	"(cms.title LIKE '%".$sValue."%'
			                   					  OR cms.alias_name LIKE '%".$sValue."%'
												  OR cms.seo_title LIKE '%".$sValue."%'
												  OR cms.seo_keyword LIKE '%".$sValue."%'
												  OR cms.seo_description LIKE '%".$sValue."%')";
			$data['searchValue'] 			= 	$sValue;
		else:
			$whereCon['like']		 		= 	"";
			$data['searchValue'] 			= 	'';
		endif;

		$whereCon['where']		 			= 	"status='Y'";
		$shortField 						= 	'cms.title ASC';

		$baseUrl 							= 	$this->session->userdata('MHM_ADMIN_CURRENT_PATH').$this->router->fetch_class().'/index';
		$this->session->set_userdata('cmspagesAdminData',currentFullUrl());
		$qStringdata						=	explode('?',currentFullUrl());
		$suffix								= 	$qStringdata[1]?'?'.$qStringdata[1]:'';
		$tblName 							= 	'cms as cms';
		$con 								= 	'';
		$totalRows 							= 	$this->admin_model->selectCmsPagesData('count',$tblName,$whereCon,$shortField,'0','0');

		if($this->input->get('showLength') == 'All'):
			$perPage	 							= 	$totalRows;
			$data['perpage'] 				= 	$this->input->get('showLength');
		elseif($this->input->get('showLength')):
			$perPage	 							= 	$this->input->get('showLength');
			$data['perpage'] 				= 	$this->input->get('showLength');
		else:
			$perPage	 							= 	SHOW_NO_OF_DATA;
			$data['perpage'] 				= 	SHOW_NO_OF_DATA;
		endif;
		$uriSegment 							= 	getUrlSegment();
	    $data['PAGINATION']					=	adminPagination($baseUrl,$suffix,$totalRows,$perPage,$uriSegment);

       if ($this->uri->segment(getUrlSegment())):
           $page = $this->uri->segment(getUrlSegment());
       else:
           $page = 0;
       endif;

		$data['forAction'] 					= 	$baseUrl;
		if($totalRows):
			$first							=	($page)+1;
			$data['first']					=	$first;
			$last							=	(($page)+$data['perpage'])>$totalRows?$totalRows:(($page)+$data['perpage']);
			$data['noOfContent']			=	'Showing '.$first.'-'.$last.' of '.$totalRows.' items';
		else:
			$data['first']					=	1;
			$data['noOfContent']			=	'';
		endif;

		$data['ALLDATA'] 					= 	$this->admin_model->selectCmsPagesData('data',$tblName,$whereCon,$shortField,$perPage,$page);

		$this->layouts->set_title('Manage CMS Pages Details');
		$this->layouts->admin_view('admin/cmspages/index',array(),$data);
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : addeditdata
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for add edit data
	 * * Date : 09   MAY 2022
	 * * **********************************************************************/
	public function addeditdata($editId='')
	{
		$data['error'] 				= 	'';
		$data['activeMenu'] 		= 	'adminhomebanner';
		$data['activeSubMenu'] 		= 	'admincmspages';

		if($editId):
			$this->adminauth_model->authCheck('admin','edit_data');
			$data['EDITDATA']		=	$this->common_model->getDataByParticularField('cms','cms_id',$editId);
		else:
			$this->adminauth_model->authCheck('admin','add_data');
		endif;

		if($this->input->post('SaveChanges')):
			$error					=	'NO';
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			//$this->form_validation->set_rules('alias_name', 'Alias Name', 'trim|required');
			$this->form_validation->set_rules('content', 'Description', 'trim|required');

			$this->form_validation->set_rules('seo_title', 'SEO Title', 'trim');
			$this->form_validation->set_rules('seo_keyword', 'SEO Keyword', 'trim');
			$this->form_validation->set_rules('seo_description', 'SEO Description', 'trim');

			if($this->form_validation->run() && $error == 'NO'):

				$param['title']					= 	addslashes($this->input->post('title'));
				//$param['alias_name']			= 	url_title($this->input->post('alias_name'));
				$param['content']				= 	addslashes($this->input->post('content'));

				$SDparam['seo_title']			= 	addslashes($this->input->post('seo_title'));
				$SDparam['seo_keyword']			= 	addslashes($this->input->post('seo_keyword'));
				$SDparam['seo_description']		= 	addslashes($this->input->post('seo_description'));

				if($this->input->post('CurrentDataID') ==''):
					$param['creation_date']		=	currentDateTime();
					$param['created_by']		=	$this->session->userdata('MHM_ADMIN_ID');
					$param['status']			=	'Y';
					$lastInsertId				=	$this->common_model->addData('cms',$param);

					$Uparam['encrypt_id']		=	ashishEncript($lastInsertId);
					$Uparam['cms_id']			=	generateUniqueId($lastInsertId);
					$Uwhere['id']				=	$lastInsertId;
					$this->common_model->editDataByMultipleCondition('cms',$Uparam,$Uwhere);

					$this->session->set_flashdata('alert_success',lang('addsuccess'));
				else:
					$cmsId						=	$this->input->post('CurrentDataID');
					$param['update_date']		=	currentDateTime();
					$param['updated_by']		=	$this->session->userdata('MHM_ADMIN_ID');
					$this->common_model->editData('cms',$param,'cms_id',$cmsId);

					$this->session->set_flashdata('alert_success',lang('updatesuccess'));
				endif;

				redirect(correctLink('cmspagesAdminData',$this->session->userdata('MHM_ADMIN_CURRENT_PATH').$this->router->fetch_class().'/index'));
			endif;
		endif;

		$this->layouts->set_title('Edit CMS Pages Details');
		$this->layouts->admin_view('admin/cmspages/addeditdata',array(),$data);
	}	// END OF FUNCTION
}
