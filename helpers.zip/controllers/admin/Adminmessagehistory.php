<?php defined('BASEPATH') or exit('No direct script access allowed');
class Adminmessagehistory extends CI_Controller
{
    public function  __construct()
    {
        parent::__construct();
        error_reporting(E_ALL ^ E_NOTICE);
        $this->load->model(array('adminauth_model', 'admin_model', 'emailtemplate_model', 'sms_model'));
        $this->lang->load('statictext', 'admin');
        $this->load->helper('admin');
    }
    /* * *********************************************************************
	 * * Function name : Index
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for Calendar Reminder
	 * * Date : 26 APRIL 2022
	 * * **********************************************************************/
    public function index()
    {
        $this->adminauth_model->authCheck('admin', 'view_data');
        $this->adminauth_model->getPermissionType($data);
        $data['error']                         =     '';
        $data['activeMenu']                 =     'adminmessagehistory';
        $data['activeSubMenu']                 =     'adminmessagehistory';

        if ($this->input->get('searchValue')) :
            $sValue                            =    $this->input->get('searchValue');
            $whereCon['like']                 =     "(ven.vendor_business_name LIKE '%" . $sValue . "%')";
            $data['searchValue']             =     $sValue;
        else :
            $whereCon['like']                 =     "";
            $data['searchValue']             =     '';
        endif;

        $whereCon['where']                     =     "ven.status='A'";
        $shortField                         =     'ven.creation_date DESC';
        $grField 						= 	'ven.vendor_id';

        $baseUrl                             =     $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index';
        $this->session->set_userdata('messageHistory', currentFullUrl());
        $qStringdata                        =    explode('?', currentFullUrl());
        $suffix                                =     $qStringdata[1] ? '?' . $qStringdata[1] : '';
        $tblName                             =     'vendor as ven';
        $con                                 =     '';
        $totalRows                             =     $this->admin_model->selectSelletData('count', $tblName, $whereCon, $shortField, '0', '0',$grField);

        if ($this->input->get('showLength') == 'All') :
            $perPage                         =     $totalRows;
            $data['perpage']                 =     $this->input->get('showLength');
        elseif ($this->input->get('showLength')) :
            $perPage                         =     $this->input->get('showLength');
            $data['perpage']                 =     $this->input->get('showLength');
        else :
            $perPage                         =     SHOW_NO_OF_DATA;
            $data['perpage']                 =     SHOW_NO_OF_DATA;
        endif;
        $uriSegment                         =     getUrlSegment();
      
        $data['PAGINATION']                    =    adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

        if ($this->uri->segment(getUrlSegment())) :
            $page = $this->uri->segment(getUrlSegment());
        else :
            $page = 0;
        endif;

        $data['forAction']                     =     $baseUrl;
        if ($totalRows) :
            $first                            =    ($page) + 1;
            $data['first']                    =    $first;
            $last                            =    (($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
            $data['noOfContent']            =    'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
        else :
            $data['first']                    =    1;
            $data['noOfContent']            =    '';
        endif;
        $data['ALLDATA']                     =     $this->admin_model->selectSelletData('data', $tblName, $whereCon, $shortField, $perPage, $page,$grField);
       
        $this->layouts->set_title('Manage Message History');
        $this->layouts->admin_view('admin/messagehistory/index', array(), $data);
    }
  
   /* * *********************************************************************
	 * * Function name : messagehistory
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for message history
	 * * Date : 24 November 2022
	 * * **********************************************************************/
    public function messagehistory($editId = '')
    {
        $this->adminauth_model->authCheck('admin', 'view_data');
        $this->adminauth_model->getPermissionType($data);
        $data['error']                         =     '';
        $data['activeMenu']                 =     'adminmessagehistory';
        $data['activeSubMenu']                 =     'adminmessagehistory';

        if ($this->input->get('searchValue')) :
            $sValue                            =    $this->input->get('searchValue');
            $whereCon['like']                 =     "(cr.guest_name LIKE '%" . $sValue . "%'
            											OR cr.guest_mobile_number LIKE '%" . $sValue . "%'
												  		OR cr.booking_id LIKE '%" . $sValue . "%'
                                                    )";
            $data['searchValue']             =     $sValue;
        else :
            $whereCon['like']                 =     "";
            $data['searchValue']             =     '';
        endif;

        $whereCon['where']                     =     "";
        $shortField                         =     'cr.guest_name DESC';

        $baseUrl                             =     $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/messagehistory/'.$editId;
        $this->session->set_userdata('messageHistory', currentFullUrl());
        $qStringdata                        =    explode('?', currentFullUrl());
        $suffix                                =     $qStringdata[1] ? '?' . $qStringdata[1] : '';
        $tblName                             =     'calendar_reservation as cr';
        $con                                 =     '';
        $totalRows                             =     $this->admin_model->selectmessagehistory('count', $tblName, $whereCon, $shortField, '0', '0',$editId);
        if ($this->input->get('showLength') == 'All') :
            $perPage                         =     $totalRows;
            $data['perpage']                 =     $this->input->get('showLength');
        elseif ($this->input->get('showLength')) :
            $perPage                         =     $this->input->get('showLength');
            $data['perpage']                 =     $this->input->get('showLength');
        else :
            $perPage                         =     SHOW_NO_OF_DATA;
            $data['perpage']                 =     SHOW_NO_OF_DATA;
        endif;
        $uriSegment                         =     6;
      	//echo $uriSegment; die;
        $data['PAGINATION']                    =    adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

        if ($this->uri->segment(6)) :
            $page = $this->uri->segment(6);
        else :
            $page = 0;
        endif;

        $data['forAction']                     =     $baseUrl;
        if ($totalRows) :
            $first                            =    ($page) + 1;
            $data['first']                    =    $first;
            $last                            =    (($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
            $data['noOfContent']            =    'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
        else :
            $data['first']                    =    1;
            $data['noOfContent']            =    '';
        endif;
        $data['ALLDATAHISTORY']                     =     $this->admin_model->selectmessagehistory('data', $tblName, $whereCon, $shortField, $perPage, $page,$editId);
        //echo "<pre>"; print_r($data['ALLDATAHISTORY']); die;
        $this->layouts->set_title('Manage Message History');
        $this->layouts->admin_view('admin/messagehistory/messagehistory', array(), $data);
    }
}