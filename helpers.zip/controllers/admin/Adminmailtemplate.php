<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Adminmailtemplate extends CI_Controller {

	public function  __construct()  
	{ 
		parent:: __construct();
		error_reporting(E_ALL ^ E_NOTICE);  
		$this->load->model(array('adminauth_model','admin_model','emailtemplate_model','sms_model'));
		$this->lang->load('statictext', 'admin');
		$this->load->helper('admin');
	} 
	
	/* * *********************************************************************
	 * * Function name : mail template
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for mail template
	 * * Date : 03 NOVEMBER 2018
	 * * **********************************************************************/
	public function index()
	{	
		$this->adminauth_model->authCheck('admin','view_data');
		$data['error'] 						= 	'';
		$this->adminauth_model->getPermissionType($data); 
		$data['activeMenu'] 				= 	'adminmailtemplate';
		$data['activeSubMenu'] 				= 	'';
		
		if($this->input->get('searchValue')):
			$sValue							=	$this->input->get('searchValue');
			$whereCon['like']		 		= 	"(emlt.mailtype LIKE '%".$sValue."%'
		  										  OR emlt.subject LIKE '%".$sValue."%')";
			$data['searchValue'] 			= 	$sValue;
		else:
			$whereCon['like']		 		= 	"";
			$data['searchValue'] 			= 	'';
		endif;
		
		$whereCon['where']		 			= 	"";		
		$shortField 						= 	'emlt.id ASC';
		
		$baseUrl 							= 	$this->session->userdata('MHM_ADMIN_CURRENT_PATH').$this->router->fetch_class().'/index';
		$this->session->set_userdata('mailtemplateAdminData',currentFullUrl());
		$qStringdata						=	explode('?',currentFullUrl());
		$suffix								= 	$qStringdata[1]?'?'.$qStringdata[1]:'';
		$tblName 							= 	'email_template as emlt';
		$con 								= 	'';
		$totalRows 							= 	$this->admin_model->selectMailTemplateData('count',$tblName,$whereCon,$shortField,'0','0');
		
		if($this->input->get('showLength') == 'All'):
			$perPage	 					= 	$totalRows;
			$data['perpage'] 				= 	$this->input->get('showLength');  
		elseif($this->input->get('showLength')):
			$perPage	 					= 	$this->input->get('showLength'); 
			$data['perpage'] 				= 	$this->input->get('showLength'); 
		else:
			$perPage	 					= 	SHOW_NO_OF_DATA;
			$data['perpage'] 				= 	SHOW_NO_OF_DATA; 
		endif;
		$uriSegment 						= 	getUrlSegment();
	    $data['PAGINATION']					=	adminPagination($baseUrl,$suffix,$totalRows,$perPage,$uriSegment);

       if ($this->uri->segment(getUrlSegment())):
           $page = $this->uri->segment(getUrlSegment());
       else:
           $page = 0;
       endif;
		
		$data['forAction'] 					= 	$baseUrl; 
		if($totalRows):
			$first							=	($page)+1;
			$data['first']					=	$first;
			$last							=	(($page)+$data['perpage'])>$totalRows?$totalRows:(($page)+$data['perpage']);
			$data['noOfContent']			=	'Showing '.$first.'-'.$last.' of '.$totalRows.' items';
		else:
			$data['first']					=	1;
			$data['noOfContent']			=	'';
		endif;
		
		$data['ALLDATA'] 					= 	$this->admin_model->selectMailTemplateData('data',$tblName,$whereCon,$shortField,$perPage,$page); 
		
		$this->layouts->set_title('Manage Mail Template Details');
		$this->layouts->admin_view('admin/mailtemplate/index',array(),$data);
	}	// END OF FUNCTION
	
	/* * *********************************************************************
	 * * Function name : addeditdata
	 * * Developed By : Ashish UMrao
	 * * Purpose  : This function used for add edit data
	 * * Date : 03 NOVEMBER 2018
	 * * **********************************************************************/
	public function addeditdata($editId='')
	{		
		$data['error'] 				= 	'';
		$data['activeMenu'] 		= 	'adminmailtemplate';
		$data['activeSubMenu'] 		= 	'';
		
		if($editId):
			$this->adminauth_model->authCheck('admin','edit_data');
			$data['EDITDATA']		=	$this->common_model->getDataByParticularField('email_template','id',$editId);
		else:
			$this->adminauth_model->authCheck('admin','add_data');
		endif;
		
		if($this->input->post('SaveChanges')):
			$error					=	'NO';
			$this->form_validation->set_rules('subject', 'Subject', 'trim|required');
			$this->form_validation->set_rules('mail_header', 'Mail Header', 'trim|required');
			$this->form_validation->set_rules('mail_body', 'Mail Body', 'trim|required');
			$this->form_validation->set_rules('mail_footer', 'Mail Footer', 'trim|required');
			
			if($this->form_validation->run() && $error == 'NO'):  
			
				$param['subject']				= 	addslashes($this->input->post('subject'));
				$param['mail_header']			= 	addslashes($this->input->post('mail_header'));
				$param['mail_body']				= 	addslashes($this->input->post('mail_body'));
				$param['mail_footer']			= 	addslashes($this->input->post('mail_footer'));

				if($this->input->post('CurrentDataID') ==''):

					$this->common_model->addData('email_template',$param);

					$this->session->set_flashdata('alert_success',lang('addsuccess'));
				else:  
					$mailTemId					=	$this->input->post('CurrentDataID');
					$this->common_model->editData('email_template',$param,'id',$mailTemId);

					$this->session->set_flashdata('alert_success',lang('updatesuccess')); 
				endif;
				
				redirect(correctLink('mailtemplateAdminData',$this->session->userdata('MHM_ADMIN_CURRENT_PATH').$this->router->fetch_class().'/index'));
			endif;
		endif;
		
		$this->layouts->set_title('Edit Mail Template Details');
		$this->layouts->admin_view('admin/mailtemplate/addeditdata',array(),$data);
	}	// END OF FUNCTION
}
