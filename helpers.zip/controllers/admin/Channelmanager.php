<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Channelmanager extends CI_Controller
{
	public function  __construct(){
    parent::__construct();
    error_reporting(E_ALL ^ E_NOTICE);
    $this->load->model(array('adminauth_model','admin_model', 'chat_model'));
	  $this->lang->load('statictext', 'admin');
    $this->load->helper('vendor');
  }
	public function index(){
    $this->adminauth_model->authCheck('admin', 'view_data');
		$data['error'] 						= 	'';
		$data['activeMenu'] 				= 	'adminmessages';
		$data['activeSubMenu'] 				= 	'adminmessages';
		$this->layouts->set_title('Manage Channel Manager Section');
		$this->layouts->admin_view('admin/chatroom/index',);
	}
	public function whatsapp(){
    $this->adminauth_model->authCheck('admin', 'view_data');
    $whereCon['like']   = "";
    $shortField         = 'ven.vendor_id DESC';
    $tblName            = 'vendor as ven';
    $grField            =   'ven.vendor_id';
    $data['AllVendor']    = $this->admin_model->selectSelletData('data', $tblName, $whereCon, $shortField, '0', '0',$grField);
    //print_r($data['AllVendor']);
    $data['error']            =   '';
    $data['activeMenu']         =   'WhatsApp';
    $data['activeSubMenu']        =   'WhatsApp';
    $this->layouts->set_title('Manage WhatsApp');
    $this->layouts->admin_view('admin/whatsapp/index', array(), $data);
  } // END OF FUNCTION
  public function whatsapplisting(){
    $years = $this->input->get('years');
    $months = $this->input->get('months');
    $vendor_id = $this->input->get('vendor_id') ?? 'All';
    $msg_type = $this->input->get('msg_type') ?? 'All';
    $status = $this->input->get('status') ?? 'All';
    $page           = $this->input->get('page') ?? 1;
    $numofrecords   = 20;
    $cur_page       = $page;
    $Limitpage      = $page-1;
    $start          = $Limitpage * $numofrecords;
    $date = $years.'-'.$months;
    $whereCon['like'] = "(add_date LIKE '%" . $date . "%')";
    $whereCon['where'] = "";
    $tblName = 'customer_whatsapp';
    $shortField = 'add_date';
    $Count = $this->common_model->selectwhatsapplisting('count', $tblName, $whereCon, $shortField, '0', '0', $vendor_id,$msg_type,$status);
    $ALLDATA = $this->common_model->selectwhatsapplisting('data', $tblName, $whereCon, $shortField, $numofrecords, $Limitpage, $vendor_id,$msg_type,$status);
    //echo '<pre>';print_r($ALLDATA);die;
    $Pagination   = Pagination($numofrecords, $Count, $page); 
    $i = 1;
    foreach ($ALLDATA as $ALLDATAINFO) : ?>
      <tr class="<?php if ($i % 2 == 0) : echo 'odd'; else : echo 'even'; endif; ?> gradeX">
        <td><?= $i++ ?></td>
        <td><?= ($ALLDATAINFO['business_name']) ?></td>
        <td><?= ($ALLDATAINFO['msg_type']) ?></td>
        <td><?= ($ALLDATAINFO['customer_mobile']) ?></td>
        <td><?= ($ALLDATAINFO['customer_name']) ?></td>
        <td><?= html_entity_decode($ALLDATAINFO['msg']) ?></td>
        <td>
          <?php 
          if($ALLDATAINFO['status']==1){
            echo '<span class="status-success">Send</span>';
          }else{
            echo '<span class="status-danger">Failed</span>';
          }
          ?>
        </td>
        <td><?= date('d-m-Y H:i:s', strtotime($ALLDATAINFO['add_date'])) ?></td>
      </tr>
    <?php 
    endforeach;
    ?>
    <tr><td colspan="10"><?=$Pagination?></td></tr>
    <?php
  }
  public function DownloadWhatsappData(){
    $years = $this->input->get('years');
    $months = $this->input->get('months');
    $vendor_id = $this->input->get('vendor_id') ?? 'All';
    $msg_type = $this->input->get('msg_type') ?? 'All';
    $status = $this->input->get('status') ?? 'All';
    $date = $years.'-'.$months;

    $whereCon['like'] = "(add_date LIKE '%" . $date . "%')";
    $whereCon['where'] = "";
    $tblName = 'customer_whatsapp';
    $shortField = 'add_date';

    $ALLDATA = $this->common_model->selectwhatsapplisting('data', $tblName, $whereCon, $shortField, 10000, 0, $vendor_id,$msg_type,$status);
    $fileName = 'WhatsAppMsg.csv';
    $delimiter = ","; 
    $f = fopen('php://memory', 'w'); 
    $fields = ['Sr.No.','Business Name','Msg Type','Mobile','Customer Name','Message','Date','Status'];
    fputcsv($f, $fields, $delimiter);
    foreach ($ALLDATA as $key=>$rows) {
      $row['Sr.No.']                = $key+1;
      $row['Name']                = $rows['business_name'];
      $row['Msg Type']                = $rows['msg_type'];
      $row['Mobile']        = $rows['customer_mobile'];
      $row['Customer Name']        = $rows['customer_name'];
      $row['Message']        = html_entity_decode($rows['msg']);
      $row['Date']            = date('d-m-Y h:i a',strtotime($rows['add_date']));
      $row['Status']          = !empty($rows['status']) ? 'Send':'Faild';
      fputcsv($f, $row, $delimiter);
      //echo '<pre>';print_r($row);
    }
    fseek($f, 0);
    header('Content-Type: text/csv'); 
    header('Content-Disposition: attachment; filename="' . $fileName . '";'); 
    fpassthru($f); 
    exit();
  }
	public function init(){
    $this->chat_model->dispatchActions();
    $this->chat_model->render();
  }
}