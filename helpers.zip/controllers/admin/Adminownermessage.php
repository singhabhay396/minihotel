<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Adminownermessage extends CI_Controller{


public function __construct()
    {
        parent::__construct();
        error_reporting(E_ALL ^ E_NOTICE);
        $this->load->model(array('adminauth_model', 'admin_model', 'emailtemplate_model', 'sms_model','message_model'));
        $this->lang->load('statictext', 'admin');
        $this->load->helper('admin');
         $this->load->helper('owner');
    }

	public function index(){
 $this->adminauth_model->authCheck('admin', 'view_data');
        $this->adminauth_model->getPermissionType($data);
        $data['error']                         =     '';
        $data['activeMenu']                 =     'adminhomebanner';
        $data['activeSubMenu']                 =     'vendorquotes';

        if ($this->input->get('searchValue')) :
            $sValue                            =    $this->input->get('searchValue');
            $whereCon['like']                 =     "(q.message LIKE '%" . $sValue . "%'
                                                 )";
            $data['searchValue']             =     $sValue;
        else :
            $whereCon['like']                 =     "";
            $data['searchValue']             =     '';
        endif;

        $whereCon['where']                     =     "";
        $shortField                         =     'q.id ASC';

        $baseUrl                             =     $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index';
        $this->session->set_userdata('adminVendorQuotes', currentFullUrl());
        $qStringdata                        =    explode('?', currentFullUrl());
        $suffix                                =     $qStringdata[1] ? '?' . $qStringdata[1] : '';
        $tblName                             =     'add_message q';
        $con                                 =     '';
        $totalRows                             =     $this->admin_model->selectQuotesData ('count', $tblName, $whereCon, $shortField, '0', '0');
        if ($this->input->get('showLength') == 'All') :
            $perPage                         =     $totalRows;
            $data['perpage']                 =     $this->input->get('showLength');
        elseif ($this->input->get('showLength')) :
            $perPage                         =     $this->input->get('showLength');
            $data['perpage']                 =     $this->input->get('showLength');
        else :
            $perPage                         =     SHOW_NO_OF_DATA;
            $data['perpage']                 =     SHOW_NO_OF_DATA;
        endif;
        $uriSegment                         =     getUrlSegment();
        $data['PAGINATION']                    =    adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

        if ($this->uri->segment(getUrlSegment())) :
            $page = $this->uri->segment(getUrlSegment());
        else :
            $page = 0;
        endif;

        $data['forAction']                     =     $baseUrl;
        if ($totalRows) :
            $first                            =    ($page) + 1;
            $data['first']                    =    $first;
            $last                            =    (($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
            $data['noOfContent']            =    'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
        else :
            $data['first']                    =    1;
            $data['noOfContent']            =    '';
        endif;
        $data['messagedata']=$this->message_model->getmessagedata1('data', $tblName, $whereCon, $shortField, $perPage, $page);
        
        //$data['ALLDATA']                     =     $this->admin_model->selectQuotesData ('data', $tblName, $whereCon, $shortField, $perPage, $page);

        //////////////////      ADD EDIT SECTION   START    ////////////////
        $data['formError']                    =    'No';
        $data['editid']                        =    '';
        $data['editlink']                    =     $qStringdata[1] ? $baseUrl . '?' . $qStringdata[1] . '&editid=' : $baseUrl . '?editid=';
        if (strpos($data['editlink'], 'showLength')) :
            $showlinkdata                    =    explode('&editid=', $data['editlink']);
            if ($page > 0) :
                $newlinkdata                =    explode('?', $showlinkdata[0]);
                $data['cancellink']            =     $newlinkdata[0] . '/' . $page . '?' . $newlinkdata[1];
            else :
                $data['cancellink']            =     $showlinkdata[0];
            endif;
        else :
            $showlinkdata                    =    explode('?editid=', $data['editlink']);
            if ($page > 0) :
                $data['cancellink']            =     $showlinkdata[0] . '/' . $page;
            else :
                $data['cancellink']            =     $showlinkdata[0];
            endif;
        endif;

        if ($this->input->get('editid')) :
            $data['editid']                    =    $this->input->get('editid');
            $this->adminauth_model->authCheck('admin', 'edit_data');
            $data['EDITDATA']                =    $this->common_model->getDataByParticularField('vendor_quotes', 'quotes_id', $data['editid']);
        endif;

        if ($this->input->post('SaveChanges')) :
            $error                                =    'NO';
            $this->form_validation->set_rules('quotes', 'Name', 'trim|required');
            if ($this->form_validation->run() && $error == 'NO') :

                $param['quotes']                    =     addslashes($this->input->post('quotes'));
                if ($this->input->post('CurrentDataID') == '') :
                    $param['creation_date']        =    currentDateTime();
                    $param['created_by']        =    $this->session->userdata('MHM_ADMIN_ID');
                    $param['status']            =    'Y';
                    $alastInsertId                =    $this->common_model->addData('vendor_quotes', $param);

                    $Uparam['encrypt_id']        =    ashishEncript($alastInsertId);
                    $Uparam['quotes_id']    =    generateUniqueId($alastInsertId);
                    $Uwhere['id']                =    $alastInsertId;
                    $this->common_model->editDataByMultipleCondition('vendor_quotes', $Uparam, $Uwhere);
                    $this->session->set_flashdata('alert_success', lang('addsuccess'));
                else :
                    $prodCateId                    =    $this->input->post('CurrentDataID');
                    $param['update_date']        =    currentDateTime();
                    $param['updated_by']        =    $this->session->userdata('MHM_ADMIN_ID');
                    $this->common_model->editData('vendor_quotes', $param, 'quotes_id', $prodCateId);
                    $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                endif;

                redirect($data['cancellink']);
            endif;
        endif;
        //////////////////      ADD EDIT SECTION   END  ////////////////

        $this->layouts->set_title('Manage Message');
        $this->layouts->admin_view('admin/message_menu/index', array(), $data);   

	}


     public function addmessage(){


         $this->adminauth_model->getPermissionType($data);
        $data['error']                         =     '';
        $data['activeMenu']                 =     'adminhomebanner';
        $data['activeSubMenu']                 =     'vendorquotes';

        if ($this->input->get('searchValue')) :
            $sValue                            =    $this->input->get('searchValue');
            $whereCon['like']                 =     "(q.quotes LIKE '%" . $sValue . "%'
                                                 )";
            $data['searchValue']             =     $sValue;
        else :
            $whereCon['like']                 =     "";
            $data['searchValue']             =     '';
        endif;

        $whereCon['where']                     =     "";
        $shortField                         =     'q.quotes_id ASC';

        $baseUrl                             =     $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index';
        $this->session->set_userdata('adminVendorQuotes', currentFullUrl());
        $qStringdata                        =    explode('?', currentFullUrl());
        $suffix                                =     $qStringdata[1] ? '?' . $qStringdata[1] : '';
        $tblName                             =     'vendor_quotes q';
        $con                                 =     '';
        $totalRows                             =     $this->admin_model->selectQuotesData ('count', $tblName, $whereCon, $shortField, '0', '0');

        if ($this->input->get('showLength') == 'All') :
            $perPage                         =     $totalRows;
            $data['perpage']                 =     $this->input->get('showLength');
        elseif ($this->input->get('showLength')) :
            $perPage                         =     $this->input->get('showLength');
            $data['perpage']                 =     $this->input->get('showLength');
        else :
            $perPage                         =     SHOW_NO_OF_DATA;
            $data['perpage']                 =     SHOW_NO_OF_DATA;
        endif;
        $uriSegment                         =     getUrlSegment();
        $data['PAGINATION']                    =    adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

        if ($this->uri->segment(getUrlSegment())) :
            $page = $this->uri->segment(getUrlSegment());
        else :
            $page = 0;
        endif;

        $data['forAction']                     =     $baseUrl;
        if ($totalRows) :
            $first                            =    ($page) + 1;
            $data['first']                    =    $first;
            $last                            =    (($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
            $data['noOfContent']            =    'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
        else :
            $data['first']                    =    1;
            $data['noOfContent']            =    '';
        endif;

        $data['ALLDATA']                     =     $this->admin_model->selectQuotesData ('data', $tblName, $whereCon, $shortField, $perPage, $page);

        //////////////////      ADD EDIT SECTION   START    ////////////////
        $data['formError']                    =    'No';
        $data['editid']                        =    '';
        $data['editlink']                    =     $qStringdata[1] ? $baseUrl . '?' . $qStringdata[1] . '&editid=' : $baseUrl . '?editid=';
        if (strpos($data['editlink'], 'showLength')) :
            $showlinkdata                    =    explode('&editid=', $data['editlink']);
            if ($page > 0) :
                $newlinkdata                =    explode('?', $showlinkdata[0]);
                $data['cancellink']            =     $newlinkdata[0] . '/' . $page . '?' . $newlinkdata[1];
            else :
                $data['cancellink']            =     $showlinkdata[0];
            endif;
        else :
            $showlinkdata                    =    explode('?editid=', $data['editlink']);
            if ($page > 0) :
                $data['cancellink']            =     $showlinkdata[0] . '/' . $page;
            else :
                $data['cancellink']            =     $showlinkdata[0];
            endif;
        endif;

        if ($this->input->get('editid')) :
            $data['editid']                    =    $this->input->get('editid');
            $this->adminauth_model->authCheck('admin', 'edit_data');
            $data['EDITDATA']                =    $this->common_model->getDataByParticularField('vendor_quotes', 'quotes_id', $data['editid']);
        endif;

        if ($this->input->post('SaveChanges')) :
            $error                                =    'NO';
            $this->form_validation->set_rules('quotes', 'Name', 'trim|required');
            if ($this->form_validation->run() && $error == 'NO') :

                $param['quotes']                    =     addslashes($this->input->post('quotes'));
                if ($this->input->post('CurrentDataID') == '') :
                    $param['creation_date']        =    currentDateTime();
                    $param['created_by']        =    $this->session->userdata('MHM_ADMIN_ID');
                    $param['status']            =    'Y';
                    $alastInsertId                =    $this->common_model->addData('vendor_quotes', $param);

                    $Uparam['encrypt_id']        =    ashishEncript($alastInsertId);
                    $Uparam['quotes_id']    =    generateUniqueId($alastInsertId);
                    $Uwhere['id']                =    $alastInsertId;
                    $this->common_model->editDataByMultipleCondition('vendor_quotes', $Uparam, $Uwhere);
                    $this->session->set_flashdata('alert_success', lang('addsuccess'));
                else :
                    $prodCateId                    =    $this->input->post('CurrentDataID');
                    $param['update_date']        =    currentDateTime();
                    $param['updated_by']        =    $this->session->userdata('MHM_ADMIN_ID');
                    $this->common_model->editData('vendor_quotes', $param, 'quotes_id', $prodCateId);
                    $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                endif;

                redirect($data['cancellink']);
            endif;
        endif;

  $data['ownerdata']=$this->message_model->getownerData('0');
  
        //////////////////      ADD EDIT SECTION   END  ////////////////

        $this->layouts->set_title('Add Message');
        $this->layouts->admin_view('admin/message_menu/add_message', array(), $data);
     }
public function checkbox($id){
    $checkbox=$this->message_model->getcheckboxdata($id);
    foreach($checkbox as $value){
        echo "<input type='checkbox' name='business_id[]' value='".$value['vendor_id']."'>&nbsp;&nbsp;".$value['vendor_business_name']."<br>";
    }
}

public function insertmessage(){
    // Validate input if necessary
    // Example: Check if required fields are not empty
    $businessids = $this->input->post('business_id'); 
    $ids = implode(",", $businessids);
    $data = array(
        'bussines_name' => $this->input->post('bussines_name'),
        'message' => $this->input->post('message'),
        'manager' => $this->input->post('is_manager'),
        'status' => $this->input->post('status'),
        'date' => date('Y-m-d H:i:s'),
        'child_hotels' => $ids,

    );

  
    $this->message_model->addmessage($data);
    
    // Redirect to success page
    $this->session->set_flashdata('alert_success', lang('addsuccess'));

    redirect('admin/adminownermessage/index');}



public function updatemessage(){

    // Validate input if necessary
    // Example: Check if required fields are not empty
    $businessids = $this->input->post('business_id'); 
    $ids = implode(",", $businessids);

    $messageid = $this->input->post('messageid');

    $data = array(
        'bussines_name' => $this->input->post('bussines_name'),
        'message' => $this->input->post('message'),
        'manager' => $this->input->post('is_manager'),
        'status' => $this->input->post('status'),
        'date' => date('Y-m-d H:i:s'),
        'child_hotels' => $ids, 
    );

    // Load the model
    
    // Call the model method to insert data
    $this->message_model->updatemessage($messageid,$data);
    
    // Redirect to success page
    $this->session->set_flashdata('alert_success', lang('updatesuccess'));

    redirect('admin/adminownermessage/index');

}

public function editmessagedata(){
    $this->load->model('message_model');
    $id = $_GET['id'];
    $data['msgdata'] = $this->message_model->editmsgdata($id);
    $data['ownerdata']=$this->message_model->getownerData('0');
    $this->layouts->set_title('Edit Message');
    $this->layouts->admin_view('admin/message_menu/edit_message',array(), $data);

                      }




}

?>