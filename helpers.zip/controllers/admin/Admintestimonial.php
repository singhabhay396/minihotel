<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admintestimonial extends CI_Controller
{

    public function  __construct()
    {
        parent::__construct();
        error_reporting(E_ALL ^ E_NOTICE);
        $this->load->model(array('adminauth_model', 'admin_model', 'emailtemplate_model', 'sms_model'));
        $this->lang->load('statictext', 'admin');
        $this->load->helper('admin');
    }

    /* * *********************************************************************
	 * * Function name : product category
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for product category
	 * * Date : 22 JULY 2022
	 * * **********************************************************************/
    public function index()
    {
        $this->adminauth_model->authCheck('admin', 'view_data');
        $this->adminauth_model->getPermissionType($data);
        $data['error']                         =     '';
        $data['activeMenu']                 =     'adminhomebanner';
        $data['activeSubMenu']                 =     'admintestimonial';

        if ($this->input->get('searchValue')) :
            $sValue                            =    $this->input->get('searchValue');
            $whereCon['like']                 =     "(teti.name LIKE '%" . $sValue . "%'
												  OR teti.designation LIKE '%" . $sValue . "%'
												  OR teti.content LIKE '%" . $sValue . "%')";
            $data['searchValue']             =     $sValue;
        else :
            $whereCon['like']                 =     "";
            $data['searchValue']             =     '';
        endif;

        $whereCon['where']                     =     "";
        $shortField                         =     'teti.name ASC';

        $baseUrl                             =     $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index';
        $this->session->set_userdata('testimonialAdminData', currentFullUrl());
        $qStringdata                        =    explode('?', currentFullUrl());
        $suffix                                =     $qStringdata[1] ? '?' . $qStringdata[1] : '';
        $tblName                             =     'testimonial as teti';
        $con                                 =     '';
        $totalRows                             =     $this->admin_model->selectTestimonialData('count', $tblName, $whereCon, $shortField, '0', '0');

        if ($this->input->get('showLength') == 'All') :
            $perPage                         =     $totalRows;
            $data['perpage']                 =     $this->input->get('showLength');
        elseif ($this->input->get('showLength')) :
            $perPage                         =     $this->input->get('showLength');
            $data['perpage']                 =     $this->input->get('showLength');
        else :
            $perPage                         =     SHOW_NO_OF_DATA;
            $data['perpage']                 =     SHOW_NO_OF_DATA;
        endif;
        $uriSegment                         =     getUrlSegment();
        $data['PAGINATION']                    =    adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

        if ($this->uri->segment(getUrlSegment())) :
            $page = $this->uri->segment(getUrlSegment());
        else :
            $page = 0;
        endif;

        $data['forAction']                     =     $baseUrl;
        if ($totalRows) :
            $first                            =    ($page) + 1;
            $data['first']                    =    $first;
            $last                            =    (($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
            $data['noOfContent']            =    'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
        else :
            $data['first']                    =    1;
            $data['noOfContent']            =    '';
        endif;

        $data['ALLDATA']                     =     $this->admin_model->selectTestimonialData('data', $tblName, $whereCon, $shortField, $perPage, $page);

        //////////////////		ADD EDIT SECTION   START 	////////////////
        $data['formError']                    =    'No';
        $data['editid']                        =    '';
        $data['editlink']                    =     $qStringdata[1] ? $baseUrl . '?' . $qStringdata[1] . '&editid=' : $baseUrl . '?editid=';
        if (strpos($data['editlink'], 'showLength')) :
            $showlinkdata                    =    explode('&editid=', $data['editlink']);
            if ($page > 0) :
                $newlinkdata                =    explode('?', $showlinkdata[0]);
                $data['cancellink']            =     $newlinkdata[0] . '/' . $page . '?' . $newlinkdata[1];
            else :
                $data['cancellink']            =     $showlinkdata[0];
            endif;
        else :
            $showlinkdata                    =    explode('?editid=', $data['editlink']);
            if ($page > 0) :
                $data['cancellink']            =     $showlinkdata[0] . '/' . $page;
            else :
                $data['cancellink']            =     $showlinkdata[0];
            endif;
        endif;

        if ($this->input->get('editid')) :
            $data['editid']                    =    $this->input->get('editid');
            $this->adminauth_model->authCheck('admin', 'edit_data');
            $data['EDITDATA']                =    $this->common_model->getDataByParticularField('testimonial', 'testimonial_id', $data['editid']);
        endif;

        if ($this->input->post('SaveChanges')) :
            $error                                =    'NO';
            $this->form_validation->set_rules('name', 'Name', 'trim|required');
            //$this->form_validation->set_rules('designation', 'Designation', 'trim|required');
            $this->form_validation->set_rules('content', 'Content', 'trim|required');
            $this->form_validation->set_rules('image', 'Image', 'trim|required');

            if ($this->form_validation->run() && $error == 'NO') :

                $param['name']                    =     addslashes($this->input->post('name'));
                //$param['designation']            =     addslashes($this->input->post('designation'));
                $param['content']                =     addslashes($this->input->post('content'));
                $param['image']                    =     addslashes($this->input->post('image'));

                if ($this->input->post('CurrentDataID') == '') :
                    $lastOrder                    =    $this->common_model->getLastOrderByFields('order', 'testimonial', '', '');
                    $param['order']                =    ($lastOrder + 1);
                    $param['creation_date']        =    currentDateTime();
                    $param['created_by']        =    $this->session->userdata('MHM_ADMIN_ID');
                    $param['status']            =    'Y';
                    $alastInsertId                =    $this->common_model->addData('testimonial', $param);

                    $Uparam['encrypt_id']        =    ashishEncript($alastInsertId);
                    $Uparam['testimonial_id']    =    generateUniqueId($alastInsertId);
                    $Uwhere['id']                =    $alastInsertId;
                    $this->common_model->editDataByMultipleCondition('testimonial', $Uparam, $Uwhere);
                    $this->session->set_flashdata('alert_success', lang('addsuccess'));
                else :
                    $prodCateId                    =    $this->input->post('CurrentDataID');
                    $param['update_date']        =    currentDateTime();
                    $param['updated_by']        =    $this->session->userdata('MHM_ADMIN_ID');
                    $this->common_model->editData('testimonial', $param, 'testimonial_id', $prodCateId);
                    $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                endif;

                redirect($data['cancellink']);
            endif;
        endif;
        //////////////////		ADD EDIT SECTION   END 	////////////////

        $this->layouts->set_title('Manage Testimonial Details');
        $this->layouts->admin_view('admin/testimonial/index', array(), $data);
    }    // END OF FUNCTION

    /***********************************************************************
     ** Function name : changeStatus
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for change status
     ** Date : 22 JULY 2022
     ************************************************************************/
    function changeStatus($changeStatusId = '', $statusType = '')
    {
        $this->adminauth_model->authCheck('admin', 'edit_data');

        $param['status']        =    $statusType;
        $this->common_model->editData('testimonial', $param, 'testimonial_id', $changeStatusId);

        $this->session->set_flashdata('alert_success', lang('statussuccess'));

        redirect(correctLink('testimonialAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
    }

    /***********************************************************************
     ** Function name : deleteData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for delete data
     ** Date : 22 JULY 2022
     ************************************************************************/
    function deleteData($deleteId = '')
    {
        $this->adminauth_model->authCheck('admin', 'edit_data');

        $this->common_model->deleteParticularData('testimonial', 'testimonial_id', $deleteId);

        $this->session->set_flashdata('alert_success', lang('deletesuccess'));

        redirect(correctLink('testimonialAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
    }

    /***********************************************************************
     ** Function name : prodAttImageUpload
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for prod Att Image Upload
     ** Date : 22 JULY 2022
     ************************************************************************/
    function prodAttImageUpload()
    {

        if ($this->input->post('imageData')) :
            $imageData                =     $this->input->post('imageData');
            $imageName                =     time() . '.png';
            $imageFolder              =    '';
            $imageType                =    'testimonialImage';
            $this->load->library("upload_crop_img");
            $returnFileName        =    $this->upload_crop_img->_upload_canvas_image($imageData, $imageName, $imageType, $imageFolder);
            if ($returnFileName) :
                echo $returnFileName;
                die;
            else :
                echo 'UPLODEERROR';
                die;
            endif;
        else :
            echo 'UPLODEERROR';
            die;
        endif;
    }    // END OF FUNCTION

    /***********************************************************************
     ** Function name : prodAttImageDelete
     ** Developed By : Ashish UMrao
     ** Purpose  : This function used for prod Att Image Delete
     ** Date : 09 JUNE 2022
     ************************************************************************/
    function prodAttImageDelete()
    {
        $imageName    =    $this->input->post('imageName');
        if ($imageName) :
            $this->load->library("upload_crop_img");
            $return    =    $this->upload_crop_img->_delete_image(trim($imageName));
        endif;
        echo '1';
        die;
    }    // END OF FUNCTION

}
