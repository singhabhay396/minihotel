<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Adminsmallcms extends CI_Controller
{

	public function  __construct()
	{
		parent::__construct();
		error_reporting(E_ALL ^ E_NOTICE);
		$this->load->model(array('adminauth_model', 'admin_model', 'emailtemplate_model', 'sms_model'));
		$this->lang->load('statictext', 'admin');
		$this->load->helper('admin');
	}

	/* * *********************************************************************
	 * * Function name : small cms
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for small cms
	 * * Date : 25 APRIL 2022
	 * * **********************************************************************/
	public function index()
	{
		$this->adminauth_model->authCheck('admin', 'view_data');
		$data['error'] 						= 	'';
		$this->adminauth_model->getPermissionType($data);
		$data['activeMenu'] 				= 	'adminhomebanner';
		$data['activeSubMenu'] 				= 	'adminsmallcms';

		if ($this->input->get('searchValue')) :
			$sValue							=	$this->input->get('searchValue');
			$whereCon['like']		 		= 	"(cms.contact_email LIKE '%" . $sValue . "%'  )";
			$data['searchValue'] 			= 	$sValue;
		else :
			$whereCon['like']		 		= 	"";
			$data['searchValue'] 			= 	'';
		endif;

		$whereCon['where']		 			= 	"";
		$shortField 						= 	'cms.contact_email ASC';

		$baseUrl 							= 	$this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index';
		$this->session->set_userdata('smallcmsAdminData', currentFullUrl());
		$qStringdata						=	explode('?', currentFullUrl());
		$suffix								= 	$qStringdata[1] ? '?' . $qStringdata[1] : '';
		$tblName 							= 	'small_cms as cms';
		$con 								= 	'';
		$totalRows 							= 	$this->admin_model->selectSmallCmsData('count', $tblName, $whereCon, $shortField, '0', '0');

		if ($this->input->get('showLength') == 'All') :
			$perPage	 					= 	$totalRows;
			$data['perpage'] 				= 	$this->input->get('showLength');
		elseif ($this->input->get('showLength')) :
			$perPage	 					= 	$this->input->get('showLength');
			$data['perpage'] 				= 	$this->input->get('showLength');
		else :
			$perPage	 					= 	SHOW_NO_OF_DATA;
			$data['perpage'] 				= 	SHOW_NO_OF_DATA;
		endif;
		$uriSegment 						= 	getUrlSegment();
		$data['PAGINATION']					=	adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

		if ($this->uri->segment(getUrlSegment())) :
			$page = $this->uri->segment(getUrlSegment());
		else :
			$page = 0;
		endif;

		$data['forAction'] 					= 	$baseUrl;
		if ($totalRows) :
			$first							=	($page) + 1;
			$data['first']					=	$first;
			$last							=	(($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
			$data['noOfContent']			=	'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
		else :
			$data['first']					=	1;
			$data['noOfContent']			=	'';
		endif;

		$data['ALLDATA'] 					= 	$this->admin_model->selectSmallCmsData('data', $tblName, $whereCon, $shortField, $perPage, $page);

		$this->layouts->set_title('Manage Small CMS Details');
		$this->layouts->admin_view('admin/smallcms/index', array(), $data);
	}	// END OF FUNCTION

	/* * *********************************************************************
	 * * Function name : addeditdata
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for add edit data
	 * * Date : 25 APRIL 2022
	 * * **********************************************************************/
	public function addeditdata($editId = '')
	{
		$data['error'] 				= 	'';
		$data['activeMenu'] 		= 	'adminhomebanner';
		$data['activeSubMenu'] 		= 	'adminsmallcms';

		if ($editId) :
			$this->adminauth_model->authCheck('admin', 'edit_data');
			$data['EDITDATA']		=	$this->common_model->getDataByParticularField('small_cms', 'small_cms_id', $editId);
		else :
			$this->adminauth_model->authCheck('admin', 'add_data');
		endif;

		if ($this->input->post('SaveChanges')) :
			$error					=	'NO';
			$this->form_validation->set_rules('contact_email', 'Title', 'trim');
			$this->form_validation->set_rules('contact_phone', 'Description', 'trim');
			$this->form_validation->set_rules('contact_address', 'contact address', 'trim');
			$this->form_validation->set_rules('link1', 'link', 'trim');
			$this->form_validation->set_rules('link2', 'link', 'trim');
			$this->form_validation->set_rules('link3', 'link', 'trim');
			$this->form_validation->set_rules('link4', 'link', 'trim');

			if ($this->form_validation->run() && $error == 'NO') :

				$param['contact_email']		= 	addslashes($this->input->post('contact_email'));
				$param['contact_phone']		= 	addslashes($this->input->post('contact_phone'));
				$param['contact_address']	= 	addslashes($this->input->post('contact_address'));
				$param['link1']				= 	addslashes($this->input->post('link1'));
				$param['link2']				= 	addslashes($this->input->post('link2'));
				$param['link3']				= 	addslashes($this->input->post('link3'));
				$param['link4']				= 	addslashes($this->input->post('link4'));

				if ($this->input->post('CurrentDataID') == '') :
					$param['creation_date']		=	currentDateTime();
					$param['created_by']		=	$this->session->userdata('MHM_ADMIN_ID');
					$param['status']			=	'Y';
					$lastInsertId				=	$this->common_model->addData('small_cms', $param);

					$Uparam['encrypt_id']		=	ashishEncript($lastInsertId);
					$Uparam['small_cms_id']		=	generateUniqueId($lastInsertId);
					$Uwhere['id']				=	$lastInsertId;
					$this->common_model->editDataByMultipleCondition('small_cms', $Uparam, $Uwhere);

					$this->session->set_flashdata('alert_success', lang('addsuccess'));
				else :
					$smallCmsId					=	$this->input->post('CurrentDataID');
					$param['update_date']		=	currentDateTime();
					$param['updated_by']		=	$this->session->userdata('MHM_ADMIN_ID');
					$this->common_model->editData('small_cms', $param, 'small_cms_id', $smallCmsId);

					$this->session->set_flashdata('alert_success', lang('updatesuccess'));
				endif;

				redirect(correctLink('smallcmsAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
			endif;
		endif;

		$this->layouts->set_title('Edit Small CMS Details');
		$this->layouts->admin_view('admin/smallcms/addeditdata', array(), $data);
	}	// END OF FUNCTION
}
