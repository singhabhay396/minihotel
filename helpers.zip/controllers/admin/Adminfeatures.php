<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Adminfeatures extends CI_Controller
{

    public function  __construct()
    {
        parent::__construct();
        error_reporting(E_ALL ^ E_NOTICE);
        $this->load->model(array('adminauth_model', 'admin_model', 'emailtemplate_model', 'sms_model'));
        $this->lang->load('statictext', 'admin');
        $this->load->helper('admin');
    }

    /* * *********************************************************************
	 * * Function name : product category
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for product category
	 * * Date : 25 APRIL 2022
	 * * **********************************************************************/
    public function index()
    {
        $this->adminauth_model->authCheck('admin', 'view_data');
        $this->adminauth_model->getPermissionType($data);
        $data['error']                         =     '';
        $data['activeMenu']                 =     'adminhomebanner';
        $data['activeSubMenu']                 =     'adminfeatures';

        if ($this->input->get('searchValue')) :
            $sValue                            =    $this->input->get('searchValue');
            $whereCon['like']                 =     "(hph.title LIKE '%" . $sValue . "%'
												 )";
            $data['searchValue']             =     $sValue;
        else :
            $whereCon['like']                 =     "";
            $data['searchValue']             =     '';
        endif;

        $whereCon['where']                     =     "type='feature'";
        $shortField                         =     'hph.title ASC';

        $baseUrl                             =     $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index';
        $this->session->set_userdata('adminfeaturesAdminData', currentFullUrl());
        $qStringdata                        =    explode('?', currentFullUrl());
        $suffix                                =     $qStringdata[1] ? '?' . $qStringdata[1] : '';
        $tblName                             =     'home_page_heading hph';
        $con                                 =     '';
        $totalRows                             =     $this->admin_model->selectFeaturesData('count', $tblName, $whereCon, $shortField, '0', '0');

        if ($this->input->get('showLength') == 'All') :
            $perPage                         =     $totalRows;
            $data['perpage']                 =     $this->input->get('showLength');
        elseif ($this->input->get('showLength')) :
            $perPage                         =     $this->input->get('showLength');
            $data['perpage']                 =     $this->input->get('showLength');
        else :
            $perPage                         =     SHOW_NO_OF_DATA;
            $data['perpage']                 =     SHOW_NO_OF_DATA;
        endif;
        $uriSegment                         =     getUrlSegment();
        $data['PAGINATION']                    =    adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

        if ($this->uri->segment(getUrlSegment())) :
            $page = $this->uri->segment(getUrlSegment());
        else :
            $page = 0;
        endif;

        $data['forAction']                     =     $baseUrl;
        if ($totalRows) :
            $first                            =    ($page) + 1;
            $data['first']                    =    $first;
            $last                            =    (($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
            $data['noOfContent']            =    'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
        else :
            $data['first']                    =    1;
            $data['noOfContent']            =    '';
        endif;

        $data['ALLDATA']                     =     $this->admin_model->selectFeaturesData('data', $tblName, $whereCon, $shortField, $perPage, $page);

        //////////////////		ADD EDIT SECTION   START 	////////////////
        $data['formError']                    =    'No';
        $data['editid']                        =    '';
        $data['editlink']                    =     $qStringdata[1] ? $baseUrl . '?' . $qStringdata[1] . '&editid=' : $baseUrl . '?editid=';
        if (strpos($data['editlink'], 'showLength')) :
            $showlinkdata                    =    explode('&editid=', $data['editlink']);
            if ($page > 0) :
                $newlinkdata                =    explode('?', $showlinkdata[0]);
                $data['cancellink']            =     $newlinkdata[0] . '/' . $page . '?' . $newlinkdata[1];
            else :
                $data['cancellink']            =     $showlinkdata[0];
            endif;
        else :
            $showlinkdata                    =    explode('?editid=', $data['editlink']);
            if ($page > 0) :
                $data['cancellink']            =     $showlinkdata[0] . '/' . $page;
            else :
                $data['cancellink']            =     $showlinkdata[0];
            endif;
        endif;

        if ($this->input->get('editid')) :
            $data['editid']                    =    $this->input->get('editid');
            $this->adminauth_model->authCheck('admin', 'edit_data');
            $data['EDITDATA']                =    $this->common_model->getDataByParticularField('home_page_heading', 'heading_id', $data['editid']);
        endif;

        if ($this->input->post('SaveChanges')) :
            $error                                =    'NO';
            $this->form_validation->set_rules('title', 'Name', 'trim|required');
            $this->form_validation->set_rules('image', 'Image', 'trim|required');

            if ($this->form_validation->run() && $error == 'NO') :

                $param['title']                    =     addslashes($this->input->post('title'));
                $param['image']                    =     addslashes($this->input->post('image'));
                $param['type']                    =     "feature";

                if ($this->input->post('CurrentDataID') == '') :
                    $param['creation_date']        =    currentDateTime();
                    $param['created_by']        =    $this->session->userdata('MHM_ADMIN_ID');
                    $param['status']            =    'Y';
                    $alastInsertId                =    $this->common_model->addData('home_page_heading', $param);

                    $Uparam['encrypt_id']        =    ashishEncript($alastInsertId);
                    $Uparam['heading_id']    =    generateUniqueId($alastInsertId);
                    $Uwhere['id']                =    $alastInsertId;
                    $this->common_model->editDataByMultipleCondition('home_page_heading', $Uparam, $Uwhere);
                    $this->session->set_flashdata('alert_success', lang('addsuccess'));
                else :
                    $prodCateId                    =    $this->input->post('CurrentDataID');
                    $param['update_date']        =    currentDateTime();
                    $param['updated_by']        =    $this->session->userdata('MHM_ADMIN_ID');
                    $this->common_model->editData('home_page_heading', $param, 'heading_id', $prodCateId);
                    $this->session->set_flashdata('alert_success', lang('updatesuccess'));
                endif;

                redirect($data['cancellink']);
            endif;
        endif;
        //////////////////		ADD EDIT SECTION   END 	////////////////

        $this->layouts->set_title('Manage Admin Features Details');
        $this->layouts->admin_view('admin/adminfeatures/index', array(), $data);
    }    // END OF FUNCTION

    /***********************************************************************
     ** Function name : changeStatus
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for change status
     ** Date : 25 APRIL 2022
     ************************************************************************/
    function changeStatus($changeStatusId = '', $statusType = '')
    {
        $this->adminauth_model->authCheck('admin', 'edit_data');

        $param['status']        =    $statusType;
        $this->common_model->editData('home_page_heading', $param, 'heading_id', $changeStatusId);

        $this->session->set_flashdata('alert_success', lang('statussuccess'));

        redirect(correctLink('adminfeaturesAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
    }

    /***********************************************************************
     ** Function name : deleteData
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for delete data
     ** Date : 25 APRIL 2022
     ************************************************************************/
    function deleteData($deleteId = '')
    {
        $this->adminauth_model->authCheck('admin', 'edit_data');

        $this->common_model->deleteParticularData('home_page_heading', 'heading_id', $deleteId);

        $this->session->set_flashdata('alert_success', lang('deletesuccess'));

        redirect(correctLink('adminfeaturesAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
    }

    /***********************************************************************
     ** Function name : featuAttImageUpload
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for prod Att Image Upload
     ** Date : 25 APRIL 2022
     ************************************************************************/
    function featuAttImageUpload()
    {

        if ($this->input->post('imageData')) :
            $imageData                =     $this->input->post('imageData');
            $imageName                =     time() . '.png';
            $imageFolder              =    '';
            $imageType                =    'featureImage';
            $this->load->library("upload_crop_img");
            $returnFileName        =    $this->upload_crop_img->_upload_canvas_image($imageData, $imageName, $imageType, $imageFolder);
            if ($returnFileName) :
                echo $returnFileName;
                die;
            else :
                echo 'UPLODEERROR';
                die;
            endif;
        else :
            echo 'UPLODEERROR';
            die;
        endif;
    }    // END OF FUNCTION

    /***********************************************************************
     ** Function name : featuAttImageDelete
     ** Developed By : Ashish Umrao
     ** Purpose  : This function used for prod Att Image Delete
     ** Date : 09 JUNE 2022
     ************************************************************************/
    function featuAttImageDelete()
    {
        $imageName    =    $this->input->post('imageName');
        if ($imageName) :
            $this->load->library("upload_crop_img");
            $return    =    $this->upload_crop_img->_delete_image(trim($imageName));
        endif;
        echo '1';
        die;
    }    // END OF FUNCTION

}
