<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Adminhomebanner extends CI_Controller
{
	public function  __construct()
	{
		parent::__construct();
		error_reporting(E_ALL ^ E_NOTICE);
		$this->load->model(array('adminauth_model', 'admin_model', 'emailtemplate_model', 'sms_model'));
		$this->lang->load('statictext', 'admin');
		$this->load->helper('admin');
	}

	/* * *********************************************************************
	 * * Function name : home page banner
	 * * Developed By : Ashish Umrao
	 * * Purpose  : This function used for home page banner
	 * * Date : 25 APRIL 2022
	 * * **********************************************************************/
	public function index()
	{
		$this->adminauth_model->authCheck('admin', 'view_data');
		$data['error'] 						= 	'';
		$this->adminauth_model->getPermissionType($data);
		$data['activeMenu'] 				= 	'adminhomebanner';
		$data['activeSubMenu'] 				= 	'adminhomebanner';

		if ($this->input->get('searchValue')) :
			$sValue							=	$this->input->get('searchValue');
			$whereCon['like']		 		= 	"(hslid.slider_image LIKE '%" . $sValue . "%')";
			$data['searchValue'] 			= 	$sValue;
		else :
			$whereCon['like']		 		= 	"";
			$data['searchValue'] 			= 	'';
		endif;

		$whereCon['where']		 			= 	"";
		$shortField 						= 	'hslid.slider_id ASC';

		$baseUrl 							= 	$this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index';
		$this->session->set_userdata('homebannerAdminData', currentFullUrl());
		$qStringdata						=	explode('?', currentFullUrl());
		$suffix								= 	$qStringdata[1] ? '?' . $qStringdata[1] : '';
		$tblName 							= 	'home_slider as hslid';
		$con 								= 	'';
		$totalRows 							= 	$this->admin_model->selectHomeSliderData('count', $tblName, $whereCon, $shortField, '0', '0');

		if ($this->input->get('showLength') == 'All') :
			$perPage	 					= 	$totalRows;
			$data['perpage'] 				= 	$this->input->get('showLength');
		elseif ($this->input->get('showLength')) :
			$perPage	 					= 	$this->input->get('showLength');
			$data['perpage'] 				= 	$this->input->get('showLength');
		else :
			$perPage	 					= 	SHOW_NO_OF_DATA;
			$data['perpage'] 				= 	SHOW_NO_OF_DATA;
		endif;
		$uriSegment 						= 	getUrlSegment();
		$data['PAGINATION']					=	adminPagination($baseUrl, $suffix, $totalRows, $perPage, $uriSegment);

		if ($this->uri->segment(getUrlSegment())) :
			$page = $this->uri->segment(getUrlSegment());
		else :
			$page = 0;
		endif;

		$data['forAction'] 					= 	$baseUrl;
		if ($totalRows) :
			$first							=	($page) + 1;
			$data['first']					=	$first;
			$last							=	(($page) + $data['perpage']) > $totalRows ? $totalRows : (($page) + $data['perpage']);
			$data['noOfContent']			=	'Showing ' . $first . '-' . $last . ' of ' . $totalRows . ' items';
		else :
			$data['first']					=	1;
			$data['noOfContent']			=	'';
		endif;

		$data['ALLDATA'] 					= 	$this->admin_model->selectHomeSliderData('data', $tblName, $whereCon, $shortField, $perPage, $page);

		//////////////////		ADD EDIT SECTION START 	////////////////
		$data['formError']					=	'No';
		$data['editid']						=	'';
		$data['editlink']					= 	$qStringdata[1] ? $baseUrl . '?' . $qStringdata[1] . '&editid=' : $baseUrl . '?editid=';
		if (strpos($data['editlink'], 'showLength')) :
			$showlinkdata					=	explode('&editid=', $data['editlink']);
			if ($page > 0) :
				$newlinkdata				=	explode('?', $showlinkdata[0]);
				$data['cancellink']			= 	$newlinkdata[0] . '/' . $page . '?' . $newlinkdata[1];
			else :
				$data['cancellink']			= 	$showlinkdata[0];
			endif;
		else :
			$showlinkdata					=	explode('?editid=', $data['editlink']);
			if ($page > 0) :
				$data['cancellink']			= 	$showlinkdata[0] . '/' . $page;
			else :
				$data['cancellink']			= 	$showlinkdata[0];
			endif;
		endif;

		if ($this->input->get('editid')) :
			$data['editid']					=	$this->input->get('editid');
			$this->adminauth_model->authCheck('admin', 'edit_data');
			$data['EDITDATA']				=	$this->common_model->getDataByParticularField('home_slider', 'slider_id', $data['editid']);
		endif;

		if ($this->input->post('SaveChanges')) :
			$error								=	'NO';
			$data['formError']					=	'Yes';
			$this->form_validation->set_rules('title', 'Title', 'trim');
			$this->form_validation->set_rules('sub_title', 'sub title', 'trim');
			$this->form_validation->set_rules('content', 'content', 'trim');
			$this->form_validation->set_rules('slider_image', 'Image', 'callback_image_select_error');

			if ($this->form_validation->run() && $error == 'NO') :

				$imageName	=	$_FILES['slider_image']['name'];
				$tmpName	=	$_FILES['slider_image']['tmp_name'];

				$this->load->library("upload_crop_img");
				$imagePath	=	$this->upload_crop_img->_upload_image($imageName, $tmpName, 'homeBannerImage', sanitizedFilename(trim($imageName)), '');
				if ($imagePath != 'UPLODEERROR') :
					$param['slider_image']			 =	   $imagePath;
					$param['title']                  =     addslashes($this->input->post('title'));
					$param['sub_title']            	 =     addslashes($this->input->post('sub_title'));
					$param['content']                =     addslashes($this->input->post('content'));

					if ($this->input->post('CurrentDataID') == '') :
						$param['creation_date']		=	currentDateTime();
						$param['created_by']		=	$this->session->userdata('MHM_ADMIN_ID');
						$param['status']			=	'Y';
						$alastInsertId				=	$this->common_model->addData('home_slider', $param);

						$Uparam['encrypt_id']		=	ashishEncript($alastInsertId);
						$Uparam['slider_id']		=	generateUniqueId($alastInsertId);
						$Uwhere['id']				=	$alastInsertId;
						$this->common_model->editDataByMultipleCondition('home_slider', $Uparam, $Uwhere);
						$this->session->set_flashdata('alert_success', lang('addsuccess'));
					else :
						$bannerId					=	$this->input->post('CurrentDataID');
						$param['update_date']		=	currentDateTime();
						$param['updated_by']		=	$this->session->userdata('MHM_ADMIN_ID');
						$this->common_model->editData('home_slider', $param, 'slider_id', $bannerId);
						$this->session->set_flashdata('alert_success', lang('updatesuccess'));
					endif;
				endif;

				redirect($data['cancellink']);
			endif;
		endif;
		//////////////////		ADD EDIT SECTION   END 	////////////////

		$this->layouts->set_title('Manage Home Banner Details');
		$this->layouts->admin_view('admin/homebanner/index', array(), $data);
	}	// END OF FUNCTION

	/***********************************************************************
	 ** Function name : image_select_error
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for image validation
	 ** Date : 25 APRIL 2022
	 ************************************************************************/
	function image_select_error()
	{
		$this->form_validation->set_message('image_select_error', 'Please Select Image.');
		if (empty($_FILES['slider_image']['name'])) :
			return false;
		else :
			return true;
		endif;
	}
	/***********************************************************************
	 ** Function name : deleteData
	 ** Developed By : Ashish Umrao
	 ** Purpose  : This function used for delete data
	 ** Date : 14 MAY 2022
	 ************************************************************************/
	function deleteData($deleteId = '')
	{
		$this->adminauth_model->authCheck('admin', 'edit_data');
		$this->common_model->deleteParticularData('home_slider', 'slider_id', $deleteId);
		$this->session->set_flashdata('alert_success', lang('deletesuccess'));
		redirect(correctLink('homebannerAdminData', $this->session->userdata('MHM_ADMIN_CURRENT_PATH') . $this->router->fetch_class() . '/index'));
	}
}
