<?php

/*
	 * show status
	 */
if (!function_exists('showStatus')) {
    function showStatus($text = '')
    {
        $statusArray    =    array(
            'A' => '<span class="status-success">Active</span>',
            'I' => '<span class="status-danger">Inactive</span>',
            'B' => '<span class="status-danger">Block</span>',
            'D' => '<span class="status-danger">Deleted</span>',
            'Y' => '<span class="status-success">Active</span>',
            'N' => '<span class="status-danger">Inactive</span>'
        );
        return $statusArray[$text];
    }
}

/*
	 * show status
	 */
if (!function_exists('showKYCStatus')) {
    function showKYCStatus($text = '')
    {
        $statusArray    =    array(
            'Y' => '<span class="status-success">Verified</span>',
            'N' => '<span class="status-danger">Not Verify</span>'
        );
        return $statusArray[$text];
    }
}
