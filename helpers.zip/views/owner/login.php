<style>
  .slimScrollBar {
    background-color: lime !important;
}
.login-responsive
{
    width: 80px;
    height: 60px;
    text-align: center;
}
</style>
<div class="content">
  <form name="loginform" id="loginform" class="form-auth-small" action="" method="post">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <div class="header">
      <div class="logo text-center">
        <img src="{ASSET_VENDOR_URL}images/logo.png" alt="Klorofil Logo" class="login-responsive logo"></div>
      <p class="lead">Welcome To Owner</p>
      <?php if ($error) : ?><p class="error"><?= $error ?></p><?php endif; ?>
    </div>
    <div class="form-group">
      <label for="userEmail" class="control-label sr-only">Email</label>
      <input type="text" name="userEmail" id="userEmail" class="form-control required" value="<?php if (set_value('userEmail')) : echo set_value('userEmail');
                                                                                              endif; ?>" placeholder="Email" autocomplete="off" />
      <?php if (form_error('userEmail')) : ?>
        <label for="userEmail" generated="true" class="error"><?php echo form_error('userEmail'); ?></label>
      <?php endif;
      if ($mobileerror) :  ?>
        <span for="userEmail" generated="true" class="help-inline"><?php echo $mobileerror; ?></span>
      <?php endif; ?>
    </div>
    <div class="form-group">
      <label for="userPassword" class="control-label sr-only">Password</label>
      <input type="password" name="userPassword" id="userPassword" class="form-control required" value="<?php if (set_value('userPassword')) : echo set_value('userPassword');
                                                                                                        endif; ?>" placeholder="Password" autocomplete="off" />
      <?php if (form_error('userPassword')) : ?>
        <label for="userPassword" generated="true" class="error"><?php echo form_error('userPassword'); ?></label>
      <?php endif; ?>
    </div>
    <input type="hidden" name="loginFormSubmit" id="loginFormSubmit" value="Login">
    <button type="submit" class="btn btn-primary btn-lg btn-block">LOGIN</button>
    <div class="bottom">
      <span class="helper-text"><i class="fa fa-lock"></i> <a href="javascript:void(0);" id="to-recover">Forgot Password?</a></span>
    </div>
  </form>
  <form name="recoverform" id="recoverform" action="" method="post" class="form-auth-small">
    <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
    <div class="header">
      <div class="logo text-center">
        <img src="{ASSET_VENDOR_URL}images/logo.png" alt="Klorofil Logo" class="login-responsive logo">
    </div>
      <p class="lead">Please enter your registered mobile number below and we will send you an OTP to recover your password.</p>
      <?php if ($forgoterror) : ?><p class="error"><?= $forgoterror ?></p><?php endif; ?>
      <?php if ($forgotsuccess) : ?><p class="success"><?= $forgotsuccess ?></p><?php endif; ?>
    </div>
    <div class="form-group">
      <input type="text" name="forgotMobile" id="forgotMobile" class="form-control required" value="<?php if (set_value('forgotMobile') && $forgotsuccess == '') : echo set_value('forgotMobile');
                                                                                                    endif; ?>" placeholder="Mobile Number" autocomplete="off" />
      <?php if (form_error('forgotMobile')) : ?>
        <label for="forgotMobile" generated="true" class="error"><?php echo form_error('forgotMobile'); ?></label>
      <?php endif; ?>
    </div>
    <input type="hidden" name="recoverformSubmit" id="recoverformSubmit" value="Login">
    <button type="submit" class="btn btn-primary btn-lg btn-block">SUBMIT</button>
    <div class="bottom">
      <span class="helper-text"> <a href="javascript:void(0);" id="to-login">&laquo; Back To Login</a></span>
    </div>
  </form>
</div>
<script>
  var forgoterror = 'NO'
  <?php if ($forgoterror) : ?>
    forgoterror = 'YES';
  <?php elseif ($forgotsuccess) : ?>
    forgoterror = 'YES';
  <?php endif; ?>
</script>