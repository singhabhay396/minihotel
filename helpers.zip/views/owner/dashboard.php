<style>
.box_guard text {font-size: 15px!important;}
.box_guard .highcharts-credits {display:none;}
.lds-dual-ring.hidden { 
display: none;
}
.lds-dual-ring {
  display: inline-block;
  width: 80px;
  height: 80px;
}
.lds-dual-ring:after {
  content: " ";
  display: block;
  width: 64px;
  height: 64px;
  margin: 5% auto;
  border-radius: 50%;
  border: 6px solid #fff;
  border-color: #fff transparent #fff transparent;
  animation: lds-dual-ring 1.2s linear infinite;
}
@keyframes lds-dual-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}


.overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    background: rgba(0,0,0,.8);
    z-index: 999;
    opacity: 1;
    transition: all 0.5s;
}
</style>

<div class="main">
  <div class="bready">
    <div class="row">
      <div class="col-md-2">
        <ol class="breadcrumb">
          <li><a href="dashboard" class="active"><i class="lnr lnr-home"></i>Dashboard</a></li>
        </ol>
      </div>
    </div>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline" style="background-color:transparent">
        <div class="panel-heading"></div>
        <div class="panel-body">
          <div class="row box_guard">
            <div class="col-md-4 col-sm-4 col-xs-4">
                <select class="form-control" name="vendor_id" id="vendor_id">
                    <option value="">All</option>
                    <?php 
                        foreach ($hotel_list as $key => $value) { ?>
                        <?php //if($this->session->userdata('MHM_PARENT_OWNER') != $value['vendor_id']){ ?>
                           <option value="<?php echo $value['vendor_id']?>" 
                            <?php if($id == $value['vendor_id']){ echo "selected"; } else{ echo ""; }?>><?php echo $value['vendor_business_name']?></option>
                    <?php  } //}
                    ?>
                    
                </select>
            </div>

            <div class="col-md-8 col-sm-8 col-xs-8">
                  <button style="font-size: 10px;font-weight: bold;" type="button" class="btn btn-primary btn-lg " id="fetchDataBtn">View Detailed Reports</button>
              
            </div>
          </div>
          
          <br>
          <div id="loader" class="lds-dual-ring hidden overlay"></div>
          <div id="dataContainer"></div>
          
          <br>

         <div id="dataContainer2"></div>
      </div>
    </div>
  </div>
</div>

<script>
    getDash();
$(document).ready(function(){
    // Event listener for the button click
    $('#fetchDataBtn').click(function(){
      $("#fetchDataBtn").text('Please wait'); 
        $("#fetchDataBtn").prop('disabled', true);
        $("#dataContainer").prop('disabled', true);
        var id = $("#vendor_id").val();
        $('#loader').removeClass('hidden')
        $.ajax({
            url: "<?php echo base_url('owner/Dashboard/get_ajax_data'); ?>",
            type: "POST",
            data:{id:id},
            dataType: "html",
            success: function(response){ 
              $("#fetchDataBtn").prop('disabled', false);
              $("#dataContainer").prop('disabled', false);
              $('#loader').addClass('hidden')
             $("#fetchDataBtn").text('View Detailed Reports');
              //$this.button('reset');
                //$('.loader').hide();
                if(response){
                    $('#dataContainer').html(response);
                } else {
                    $('#dataContainer').html('Failed to fetch data.');
                }
            },
            error: function(){
                $('#dataContainer').html('Error occurred while fetching data.');
            }
        });
    });
});
function getDash(){
    var id = $("#vendor_id").val();
        $('#loader').removeClass('hidden')
        $.ajax({
            url: "<?php echo base_url('owner/Dashboard/get_ajax_dashboard'); ?>",
            type: "POST",
            data:{id:id},
            dataType: "html",
            success: function(response){ 
              $('#loader').addClass('hidden')
                if(response){
                    $('#dataContainer2').html(response);
                } else {
                    $('#dataContainer2').html('Failed to fetch data.');
                }
            },
            error: function(){
                $('#dataContainer2').html('Error occurred while fetching data.');
            }
        });
}
</script>