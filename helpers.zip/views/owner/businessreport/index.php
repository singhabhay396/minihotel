<style>
.col-md-3.col-sm-3.col-xs-3.srch-left {margin-left: 241px;}
strong {margin: 32px;}

.box_guard text {font-size: 15px!important;}
.box_guard .highcharts-credits {display:none;}

a.btn.btn-default.add_btn_center {float: right;padding: 7px 30px !important;margin-left: 10px;font-size: 16px !important;color: #fff;background-color: #315bc2 !important;}

.highcharts-label text {font-size: 15px!important;}
.highcharts-credits {display: none;}
.highcharts-axis-labels text {font-size: 15px!important;}
</style>
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<script src="{ASSET_VENDOR_URL}js/bootstrap-datepicker.js"></script>

<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{VENDOR_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Business Reports</a></li>
    </ol>
  </div>
    <div class="main-content">
        <div class="container-fluid">
            <div class="panel panel-headline">
                <hr class="differ">
                <div class="row">
                    <form id="Data_Form" name="Data_Form" method="get" action="<?php echo $forAction; ?>" autocomplete="off">
                    
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-4 col-sm-4 col-xs-4">
                                <select class="form-control VendorData" id="VendorArr" name="VendorArr" required placeholder="All">
                                <?php
                                foreach ($HotelList as $hotel) {
                                    $selected = '';
                                    if($hotel['vendor_id']==$VendorArr){
                                        $selected = 'selected';
                                    }
                                        echo '<option '.$selected.' value="'.$hotel['vendor_id'].'">'.$hotel['vendor_business_name'].'</option>';
                                    }
                                ?>
                                </select>
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-4">
                              <select id="range" class="form-control" name="range">
                                <option>Select Range</option>
                                <option value="today" <?php if($range == 'today'){ echo "selected" ;} ?>>Today</option>
                                <option value="yesterday" <?php if($range == 'yesterday'){ echo "selected" ;} ?>>Yesterday</option>
                                <option value="week" <?php if($range == 'week'){ echo "selected"; }?>>This Week</option>
                                <option value="last_month" <?php if($range == 'last_month'){ echo "selected"; } ?>>Last Month</option>
                                <option value="till_now" <?php if($range == 'till_now'){ echo "selected"; } ?>>Month Till Now</option>
                                <option value="custom" <?php if($range == 'custom'){ echo "selected"; } ?>>Custom Range</option>
                              </select>
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-4 customes" <?php if($range == 'custom'){ ?>style="display: block" <?php } else{ ?> style="display: none" <?php } ?>>
                              <input type="date" name="toDate" id="toDate" value="<?php if ($toDate <> "") : echo $toDate;endif; ?>" class="form-control input-smt" placeholder="From Date">
                            </div>
                        </div><br>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            
                            <div class="col-md-4 col-sm-4 col-xs-4 customes" <?php if($range == 'custom'){ ?>style="display: block" <?php } else{ ?> style="display: none" <?php } ?>>
                              <input type="date" name="fromDate" id="fromDate" value="<?php if ($fromDate <> "") : echo $fromDate;endif; ?>" class="form-control input-smt" placeholder="To Date">
                            </div>
                            <div class="col-md-4 col-sm-4 col-xs-4" id="compare_vendor" <?php if(!empty($VendorArrComp)){ ?> style="display: block" <?php } else{ ?> style="display: none" <?php } ?>>
                                <select class="form-control VendorData" id="VendorArrComp" name="VendorArrComp" placeholder="All">
                                    <option value="">Select Hotel</option>
                                <?php
                                foreach ($HotelList as $hotel) {
                                    $selected = '';
                                    if($hotel['vendor_id']==$VendorArrComp){
                                        $selected = 'selected';
                                    }
                                        echo '<option '.$selected.' value="'.$hotel['vendor_id'].'">'.$hotel['vendor_business_name'].'</option>';
                                    }
                                ?>
                                </select>
                            </div>
                        </div>
                        <br>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <a style="margin-left: 11px;margin-top: 10px;" href="<?=base_url('owner/businessreport/index')?>" class="btn btn-default add_btn_center">Reset Filter</a>
                              <button type="submit" value="search" name="submit" class="btn btn-default add_btn" style="margin-left: 11px;margin-top: 10px;">Search</button>
                              <a style="margin-left: 11px;margin-top: 10px;" href="javascript:void(0)" class="btn btn-default add_btn_center" id="compare_id">Compare</a>
                               
                               
                            </div>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                               
                            </div>
                            
                        </div>
                    </form>
                </div>    
                <div class="dash">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div <?php if(!empty($VendorArrComp)){ ?>class="col-md-6 col-sm-6 col-xs-6" <?php } else{ ?>class="col-md-12 col-sm-12 col-xs-12" <?php } ?>>
                                <fieldset>
                                    <legend>Total Sale</legend>
                                    <div id="TotalSales1"></div>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Payment Received</th>
                                                <th>Total Amount</th>
                                            </tr>
                                        </thead>
                                        <body>
                                            
                                            <tr>
                                                <td>Total Payments Received In Cash</td>
                                                <td><?= $totalCashPayment['totalAmount'] ?? 0; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Payments Received Online</td>
                                                <td></i> <?= $totalOnlinePayment['totalAmount'] ?? 0; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Payments Received Prepaid</td>
                                                <td><?= $totalOnlinePrepaid['totalAmount'] ?? 0; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Payments Received BTC</td>
                                                <td><?= $totalOnlineBtc['totalAmount'] ?? 0; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Sale</td>
                                                <td><?= $totalSale['totalSale'] ?? 0; ?></td>
                                            </tr>
                                        </body>
                                    </table>
                                </fieldset>
                                <fieldset>
                                  <!--div id="TotalRooms"></div-->
                                    <div>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th >Total Check Ins</th>
                                                    <th >Total Check Outs</th>
                                                </tr>
                                            </thead> 
                                            <body>
                                                <tr>
                                                    <td><?php echo $totalCheckIn['totalCheckin']; ?></td>
                                                    <td><?php echo $totalCheckout['totalCheckout']; ?></td>
                                                </tr>
                                            </body>   
                                        </table>
                                    </div>
                                </fieldset>
                                <fieldset>
                                  <div id="TotalRooms1"></div>
                                    <div>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th >How Many Rooms Came From Online Platform : <?= $RoomOnline['roomCount'] ?? 0; ?>
                                                    <th>
                                                        How Many Rooms Came From Direct Platform : <?= $RoomDirect['roomCount'] ?? 0; ?>
                                                            
                                                    </th>
                                                </tr>
                                                <tr>
                                                <th></th>
                                                 <th style="font-size: 15px; font-weight: 800; text-align: center;">
                                                    Commissioned : <?= $RoomCommissioned['roomCountdata'] ?? 0; ?>
                                                <br>
                                                    Without Commission : <?= $RoomWithoutCommission['roomCountdata'] ?? 0; ?>
                                                </th>
                                                </tr>
                                            </thead>    
                                        </table>
                                    </div>
                                </fieldset>
                                <fieldset>
                                    <legend>Total OTA Sale</legend>
                                    <div id="OTASale1"></div>
                                    <table class="table table-bordered">
                                    <?php 
                                    if (!empty($totalOtaSale)) : 

                                        foreach ($totalOtaSale as $otaInfo) :
                                          $totalSaleByOts  = $this->owner_model->sumOfTotalSaleByOtsIdReportBusiness($otaInfo['ots_id'], $fromDate, $toDate,$VendorArr,$range); 
                                            
                                          $totalCheckinByOts  = $this->owner_model->getCheckinByOtsIdReportBusiness($otaInfo['ots_id'], $fromDate, $toDate,$VendorArr,$range); 

                                                if(!empty($totalSaleByOts)){ 
                                                 ?>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2" style="font-size: 15px;font-weight: 800;"><?php echo strtoupper($otaInfo['ots_name']) ?> (Total Check Ins:- <?php echo $totalCheckinByOts;?>)</th>
                                                        </tr>
                                                          <tr>
                                                            <th>Amount Mode</th>
                                                            <th>Amount Collected</th>
                                                          </tr>
                                                    </thead>
                                                <?php     $sum =  $totCash = $totOnline = $totPrepaid = $totBtc = $totOther = 0;?>
                                                <?php foreach ($totalSaleByOts as $keys => $sale) { 
                                                    $sum = $sum + $sale['paid_amount'];
                                                    if($sale['amount_mode'] == 'online'){
                                                        $totOnline = $sale['paid_amount'];
                                                    }
                                                    elseif($sale['amount_mode'] == 'offline'){
                                                        $totCash = $sale['paid_amount'];
                                                    }
                                                    elseif($sale['amount_mode'] == 'prepaid'){
                                                        $totPrepaid = $sale['paid_amount'];
                                                    }
                                                    elseif($sale['amount_mode'] == 'BTC'){
                                                        $totBtc = $sale['paid_amount'];
                                                    }
                                                    else{
                                                        $totOther = $sale['paid_amount'];
                                                    }
                                                   
                                                    ?>
                                                        
                                                <?php  }
                                                ?>
                                                <tr>
                                                    <?php if(!empty($totCash)){?>
                                                        <td>Cash</td>
                                                        <td><?php echo $totCash; ?></td>
                                                    <?php } ?>
                                                </tr>
                                                <tr>    
                                                    <?php if(!empty($totOnline)){ ?>
                                                        <td>Online</td>
                                                        <td><?php echo $totOnline; ?></td>
                                                    <?php }?>
                                                </tr>
                                                <tr>    
                                                    <?php if(!empty($totPrepaid)){ ?>
                                                        <td>Prepaid</td>
                                                        <td><?php echo $totPrepaid; ?></td>
                                                    <?php } ?>
                                                </tr>
                                                <tr>     
                                                    <?php if(!empty($totBtc)){ ?>
                                                        <td>BTC</td>
                                                        <td><?php echo $totBtc; ?></td>
                                                    <?php } ?>
                                                </tr>
                                                <tr>     
                                                    <?php if(!empty($totOther)){ ?>
                                                        <td>Other</td>
                                                        <td><?php echo $totOther; ?></td>
                                                    <?php } ?>
                                                </tr>        
                                                <tr>
                                                    <th colspan="2" style="font-size: 15px;font-weight: 800; text-align: center;">Total Sale:- <?php echo $sum; ?></td>
                                                </tr>
                                            <?php } ?>                
                                          <!--strong style="font-size: 30px;">Total Sale from <?php echo strtoupper($otaInfo['ots_name']) ?> : <i class="fa fa-inr"></i> <?= stripslashes($totalSaleByOts['totalAmount'] ?? 'N/A') ?> </strong></br-->
                                        <?php 
                                        endforeach;
                                    endif; 
                                    ?>
                                    </table>
                                </fieldset>        
                                <fieldset>
                                    <div id="TotalExpenceAmt1"></div>
                                    <table class="table table-bordered">
                                    <?php 
                                        if(!empty($totalExpence)){ ?>
                                            <thead>
                                                <tr>
                                                    <th>Name of Expense</th>
                                                    <th>Amount</th>
                                                </tr>
                                             </thead>    
                                            <?php //echo "d"; exit;
                                            $totExpense = 0;
                                            foreach ($ExpenditureData as $Exdata){
                                                $ExpansesArr = '';
                                                $TotalExpanses  = $this->owner_model->getTotalExpensesByOwnerId($Exdata['service_id'],$VendorArr,$fromDate,$toDate,$range);
                                                $ExpansesArr  =ucfirst($Exdata['service_name']);
                                                $TotalExpansesArr  = stripslashes($TotalExpanses['totalExpense'] ?? 0); 
                                                $totExpense = $totExpense + $TotalExpansesArr;
                                                ?>
                                                <?php if(!empty($TotalExpansesArr)){ ?>
                                                    <tr>
                                                        <td><?php echo $ExpansesArr?></td>
                                                        <td><?php echo $TotalExpansesArr?></td>
                                                    </tr>
                                                <?php } ?>    
                                            <?php } ?>
                                            <tr>
                                                <th colspan="2" style="font-size: 15px;font-weight: 800; text-align: center;">Expenses Under All Accounts : <?php echo $totExpense; ?></th>
                                            </tr>
                                    <?php   } ?>
                                    </table>
                                </fieldset>
                                <fieldset>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="font-size: 15px; font-weight: 800; text-align: center;">
                                                    Average Room Rent : <?= round($avgRoomRent, 2) ?>
                                                </th>
                                                <th style="font-size: 15px; font-weight: 800; text-align: center;">
                                                    Occupancy Percentage (Current) : % : <?= round($occupancyPercentage, 2) ?? 0; ?>
                                                </th>
                                            </tr>
                                           
                                        </thead>
                                    </table>
                                </fieldset>
                            </div> 
<!----------------- Compare Data ----------------------->
                                
                            <?php if(!empty($VendorArrComp)){ ?>
                            <div class="col-md-6 col-sm-6 col-xs-6">
                                <fieldset>
                                    <legend>Total Sale</legend>
                                    <div id="TotalSales2"></div>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Payment Received</th>
                                                <th>Total Amount</th>
                                            </tr>
                                        </thead>
                                        <body>
                                            
                                            <tr>
                                                <td>Total Payments Received In Cash</td>
                                                <td><?= $totalCashPaymentComp['totalAmount'] ?? 0; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Payments Received Online</td>
                                                <td></i> <?= $totalOnlinePaymentComp['totalAmount'] ?? 0; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Payments Received Prepaid</td>
                                                <td><?= $totalOnlinePrepaidComp['totalAmount'] ?? 0; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Payments Received BTC</td>
                                                <td><?= $totalOnlineBtcComp['totalAmount'] ?? 0; ?></td>
                                            </tr>
                                            <tr>
                                                <td>Total Sale</td>
                                                <td><?= $totalSaleComp['totalSale'] ?? 0; ?></td>
                                            </tr>
                                        </body>
                                    </table>
                                </fieldset>
                                <fieldset>
                                  <!--div id="TotalRooms"></div-->
                                    <div>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th >Total Check Ins</th>
                                                    <th >Total Check Outs</th>
                                                </tr>
                                            </thead> 
                                            <body>
                                                <tr>
                                                    <td><?php echo $totalCheckInComp['totalCheckin']; ?></td>
                                                    <td><?php echo $totalCheckoutComp['totalCheckout']; ?></td>
                                                </tr>
                                            </body>   
                                        </table>
                                    </div>
                                </fieldset>
                                <fieldset>
                                  <div id="TotalRooms2"></div>
                                    <div>
                                        <table class="table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th >How Many Rooms Came From Online Platform : <?= $RoomOnlineComp['roomCount'] ?? 0; ?>
                                                    <th>
                                                        How Many Rooms Came From Direct Platform : <?= $RoomDirectComp['roomCount'] ?? 0; ?>
                                                            
                                                    </th>
                                                </tr>
                                                <tr>
                                                <th></th>
                                                 <th style="font-size: 15px; font-weight: 800; text-align: center;">
                                                    Commissioned : <?= $RoomCommissionedComp['roomCountdata'] ?? 0; ?>
                                                <br>
                                                    Without Commission : <?= $RoomWithoutCommissionComp['roomCountdata'] ?? 0; ?>
                                                </th>
                                                </tr>
                                            </thead>    
                                        </table>
                                    </div>
                                </fieldset>
                                <fieldset>
                                    <legend>Total OTA Sale</legend>
                                    <div id="OTASale23"></div>
                                    <table class="table table-bordered">
                                    <?php 
                                    if (!empty($totalOtaSaleComp)) : 

                                        foreach ($totalOtaSaleComp as $otaInfo) :
                                          $totalSaleByOts  = $this->owner_model->getTotalSaleByOtsIdReportBusiness($otaInfo['ots_id'], $fromDate, $toDate,$VendorArrComp,$range); 
                                          $totalCheckinByOts  = $this->owner_model->getCheckinByOtsIdReportBusiness($otaInfo['ots_id'], $fromDate, $toDate,$VendorArrComp,$range); 

                                                if(!empty($totalSaleByOts)){ 
                                                 ?>
                                                    <thead>
                                                        <tr>
                                                            <th colspan="2" style="font-size: 15px;font-weight: 800;"><?php echo strtoupper($otaInfo['ots_name']) ?> (Total Check Ins:- <?php echo $totalCheckinByOts;?>)</th>
                                                        </tr>
                                                          <tr>
                                                            <th>Amount Mode</th>
                                                            <th>Amount Collected</th>
                                                          </tr>
                                                    </thead>
                                                <?php     $sum =  $totCash = $totOnline = $totPrepaid = $totBtc = $totOther = 0;?>
                                                <?php foreach ($totalSaleByOts as $keys => $sale) { 
                                                    $sum = $sum + $sale['payment_paid'];
                                                    if($sale['amount_mode'] == 'online'){
                                                        $totOnline = $totOnline + $sale['payment_paid'];
                                                    }
                                                    elseif($sale['amount_mode'] == 'offline'){
                                                        $totCash = $totCash + $sale['payment_paid'];
                                                    }
                                                    elseif($sale['amount_mode'] == 'prepaid'){
                                                        $totPrepaid = $totPrepaid + $sale['payment_paid'];
                                                    }
                                                    elseif($sale['amount_mode'] == 'BTC'){
                                                        $totBtc = $totBtc + $sale['payment_paid'];
                                                    }
                                                    else{
                                                        $totOther = $totOther + $sale['payment_paid'];
                                                    }
                                                    if(!empty($sale['payment_paid'])){
                                                    ?>
                                                        
                                                <?php } }
                                                ?>
                                                <tr>
                                                    <?php if(!empty($totCash)){?>
                                                        <td>Cash</td>
                                                        <td><?php echo $totCash; ?></td>
                                                    <?php } ?>
                                                </tr>
                                                <tr>    
                                                    <?php if(!empty($totOnline)){ ?>
                                                        <td>Online</td>
                                                        <td><?php echo $totOnline; ?></td>
                                                    <?php }?>
                                                </tr>
                                                <tr>    
                                                    <?php if(!empty($totPrepaid)){ ?>
                                                        <td>Prepaid</td>
                                                        <td><?php echo $totPrepaid; ?></td>
                                                    <?php } ?>
                                                </tr>
                                                <tr>     
                                                    <?php if(!empty($totBtc)){ ?>
                                                        <td>BTC</td>
                                                        <td><?php echo $totBtc; ?></td>
                                                    <?php } ?>
                                                </tr>
                                                <tr>     
                                                    <?php if(!empty($totOther)){ ?>
                                                        <td>Other</td>
                                                        <td><?php echo $totOther; ?></td>
                                                    <?php } ?>
                                                </tr>        
                                                <tr>
                                                    <th colspan="2" style="font-size: 15px;font-weight: 800; text-align: center;">Total Sale:- <?php echo $sum; ?></td>
                                                </tr>
                                            <?php } ?>                
                                          <!--strong style="font-size: 30px;">Total Sale from <?php echo strtoupper($otaInfo['ots_name']) ?> : <i class="fa fa-inr"></i> <?= stripslashes($totalSaleByOts['totalAmount'] ?? 'N/A') ?> </strong></br-->
                                        <?php 
                                        endforeach;
                                    endif; 
                                    ?>
                                    </table>
                                </fieldset>        
                                <fieldset>
                                    <div id="TotalExpenceAmt2"></div>
                                    <table class="table table-bordered">
                                    <?php //echo $totalExpenceComp; exit;
                                        if(!empty($totalExpenceComp)){ ?>
                                            <thead>
                                                <tr>
                                                    <th>Name of Expense</th>
                                                    <th>Amount</th>
                                                </tr>
                                             </thead>    
                                            <?php //echo "d"; exit;
                                            $totExpense = 0;
                                            foreach ($ExpenditureDataComp as $Exdata){
                                                $ExpansesArr = '';
                                                $TotalExpanses  = $this->owner_model->getTotalExpensesByOwnerId($Exdata['service_id'],$VendorArrComp,$fromDate,$toDate,$range);
                                                $ExpansesArr  =ucfirst($Exdata['service_name']);
                                                $TotalExpansesArr  = stripslashes($TotalExpanses['totalExpense'] ?? 0); 
                                                $totExpense = $totExpense + $TotalExpansesArr;
                                                ?>
                                                <?php if(!empty($TotalExpansesArr)){ ?>
                                                    <tr>
                                                        <td><?php echo $ExpansesArr?></td>
                                                        <td><?php echo $TotalExpansesArr?></td>
                                                    </tr>
                                                <?php } ?>    
                                            <?php } ?>
                                            <tr>
                                                <th colspan="2" style="font-size: 15px;font-weight: 800; text-align: center;">Expenses Under All Accounts : <?php echo $totExpense; ?></th>
                                            </tr>
                                    <?php   } ?>
                                    </table>
                                </fieldset>
                                <fieldset>
                                    <table class="table table-bordered">
                                        <thead>
                                            <tr>
                                                <th style="font-size: 15px; font-weight: 800; text-align: center;">
                                                    Average Room Rent : <?= round($avgRoomRentComp, 2) ?>
                                                </th>
                                                <th style="font-size: 15px; font-weight: 800; text-align: center;">
                                                    Occupancy Percentage (Current) : % : <?= round($occupancyPercentageComp, 2) ?? 0; ?>
                                                </th>
                                            </tr>
                                           
                                        </thead>
                                    </table>
                                </fieldset>
                            </div>
                            <?php } ?>   
                        </div>    
                    </div> 
                </div>
        </div>
    </div>
  </div>
</div>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/highcharts-more.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script type="text/javascript">
$(document).on('change','#range',function(){
    var id = $("#range").val();
    $("#fromDate").val(' ');
    $("#toDate").val(' ');
    if(id == 'custom'){
        $(".customes").css("display",'block');
    }
    else{
        $(".customes").css("display",'none');
    }
});
$(document).on('click','#compare_id',function(){
    $("#compare_vendor").toggle();
    //$("#compare_vendor").css('display','block');
});
<?php
$TotalSale = $totalSale['totalSale'] ?? 0;
$Cash = $totalCashPayment['totalAmount'] ?? 0;
$Online = $totalOnlinePayment['totalAmount'] ?? 0;
$Prepaid = $totalOnlinePrepaid['totalAmount'] ?? 0;
$CashSales = ($Cash*100)/$TotalSale;
$PrepaidSales = ($Prepaid*100)/$TotalSale;
$OnlineSales = ($Online*100)/$TotalSale;
?>  
Highcharts.chart('TotalSales1', {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: 'pie'
  },
  title: {
    text: 'TOTAL SALE BIFURCATION',
    align: 'center'
  },
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
  },
  accessibility: {
    point: {
      valueSuffix: '%'
    }
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
      }
    }
  },
  series: [{
    name: 'Sales',
    colorByPoint: true,
    data: [{
      name: 'Cash Sale',
      y: <?=$CashSales?>,
      sliced: true,
      selected: true
    }, 
    {
      name: 'Online',
      y: <?=$OnlineSales?>
    },
    {
      name: 'Prepaid',
      y: <?=$PrepaidSales?>
    }]
  }]
});
</script>

<?php
$OTAArr = [];
$OTAmtAArr = [];
foreach ($totalOtaSale as $otaInfo){
  $totalSaleByOts  = $this->owner_model->getTotalSaleByOtsIdReport($otaInfo['ots_id'], $fromDate, $toDate,$VendorArr,$range);
  $OTAArr[]  = "'".strtoupper($otaInfo['ots_name'])."'";
  $OTAmtAArr[]  = stripslashes($totalSaleByOts['totalAmount'] ?? 0);
}
$OTAData = implode(',',$OTAArr);
$OTAAmt = implode(',',$OTAmtAArr);
?>
<script type="text/javascript">
const chart = new Highcharts.Chart({
  chart: {
    renderTo: 'OTASale1',
    type: 'column'
  },
  title: {
    text: 'OTA SALE',
    align: 'center'
  },
  xAxis: {
    categories: [<?=$OTAData?>]
  },
  yAxis: {
    title: {
      enabled: false
    }
  },
  tooltip: {
    headerFormat: '<b>Total Sale from {point.key}</b><br>',
    pointFormat: '₹ {point.y}'
  },
  legend: {
    enabled: false
  },
  plotOptions: {
    column: {depth: 25}
  },
  series: [{
    data: [<?=$OTAAmt?>],
    colorByPoint: true
  }]
});
</script>


<?php
$TotalExpansesArr = [];
$ExpansesArr = [];
foreach ($ExpenditureData as $Exdata){
  $TotalExpanses  = $this->owner_model->getTotalExpensesByOwnerId($Exdata['service_id'],$VendorArr,$fromDate,$toDate,$range);
  $ExpansesArr[]  = '"'.stripslashes($Exdata['service_name']).'"';
  $TotalExpansesArr[]  = stripslashes($TotalExpanses['totalExpense'] ?? 0);
}
$ExpansesData = implode(',',$ExpansesArr);
$TotalExpansesData = implode(',',$TotalExpansesArr);
if(!empty($TotalExpansesData) && $TotalExpansesData > 0){
?>

<script type="text/javascript">
const TotalExpence = new Highcharts.Chart({
  chart: {
    renderTo: 'TotalExpenceAmt1',
    type: 'column'
  },
  title: {
    text: 'EXPENDITURE ACCOUNTS',
    align: 'center'
  },
  xAxis: {
    categories: [<?=$ExpansesData?>]
  },
  yAxis: {
    title: {
      enabled: false
    }
  },
  tooltip: {
    headerFormat: '<b>Total Sale from {point.key}</b><br>',
    pointFormat: '₹ {point.y}'
  },
  legend: {
    enabled: false
  },
  plotOptions: {
    column: {depth: 25}
  },
  series: [{
    data: [<?=$TotalExpansesData?>],
    colorByPoint: true
  }]
});
</script>
<?php } ?>

<?php
$TotalRoomOnline = $RoomOnline['roomCount'] ?? 0;
$TotalRoomDirect = $RoomDirect['roomCount'] ?? 0;
$total = $TotalRoomOnline+$TotalRoomDirect;
$RoomOnlinePre = ($TotalRoomOnline*100)/($total);
$TotalRoomDirectPre = ($TotalRoomDirect*100)/($total);
$OnlineSales = ($Online*100)/$TotalSale;
?>  
<script type="text/javascript">
Highcharts.chart('TotalRooms1', {
  chart: {
    plotBackgroundColor: null,
    plotBorderWidth: null,
    plotShadow: false,
    type: 'pie'
  },
  title: {
    text: 'DIRECT/ONLINE PLATFORM BIFURCATION',
    align: 'center'
  },
  tooltip: {
    pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
  },
  accessibility: {
    point: {
      valueSuffix: '%'
    }
  },
  plotOptions: {
    pie: {
      allowPointSelect: true,
      cursor: 'pointer',
      dataLabels: {
        enabled: true,
        format: '<b>{point.name}</b>: {point.percentage:.1f} %'
      }
    }
  },
  series: [{
    name: 'Rooms',
    colorByPoint: true,
    data: [{
      name: 'Online Platform',
      y: <?php echo !empty($RoomOnlinePre) ? $RoomOnlinePre: 0; ?>,
      sliced: true,
      selected: true
    },
    {
      name: 'Direct Platform',
      y: <?php echo !empty($TotalRoomDirectPre) ? $TotalRoomDirectPre: 0; ?>
    }]
  }]
});
</script>
<!--------Compare Data ------------------>

<?php
if(!empty($VendorArrComp)){
    $TotalSale = $totalSaleComp['totalSale'] ?? 0;
    $Cash = $totalCashPaymentComp['totalAmount'] ?? 0;
    $Online = $totalOnlinePaymentComp['totalAmount'] ?? 0;
    $Prepaid = $totalOnlinePrepaidComp['totalAmount'] ?? 0;
    $CashSales = ($Cash*100)/$TotalSale;
    $PrepaidSales = ($Prepaid*100)/$TotalSale;
    $OnlineSales = ($Online*100)/$TotalSale;
    ?>  
    <script>
   Highcharts.chart('TotalSales2', {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
      },
      title: {
        text: 'TOTAL SALE BIFURCATION',
        align: 'center'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      accessibility: {
        point: {
          valueSuffix: '%'
        }
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: true,
            format: '<b>{point.name}</b>: {point.percentage:.1f} %'
          }
        }
      },
      series: [{
        name: 'Sales',
        colorByPoint: true,
        data: [{
          name: 'Cash Sale',
          y: <?php echo !empty($CashSales) ? $CashSales : 0; ?>,
          sliced: true,
          selected: true
        }, 
        {
          name: 'Online',
          y: <?php echo !empty($OnlineSales) ? $OnlineSales : 0; ?>
        },
        {
          name: 'Prepaid',
          y: <?php echo !empty($PrepaidSales) ? $PrepaidSales : 0; ?>
        }]
      }]
    });
    </script>

    <?php
    $OTAArr = [];
    $OTAmtAArr = [];
    foreach ($totalOtaSaleComp as $otaInfo){
      $totalSaleByOts  = $this->owner_model->getTotalSaleByOtsIdReport($otaInfo['ots_id'], $fromDate, $toDate,$VendorArrComp,$range);
      $OTAArr[]  = "'".strtoupper($otaInfo['ots_name'])."'";
      $OTAmtAArr[]  = stripslashes($totalSaleByOts['totalAmount'] ?? 0);
    }
    $OTAData = implode(',',$OTAArr);
    $OTAAmt = implode(',',$OTAmtAArr);
    ?>
    <script type="text/javascript">

     Highcharts.chart('OTASale23', {
      chart: {
        type: 'column'
      },
      title: {
        text: 'OTA SALE',
        align: 'center'
      },
      xAxis: {
        categories: [<?=$OTAData?>]
      },
      yAxis: {
        title: {
          enabled: false
        }
      },
      tooltip: {
        headerFormat: '<b>Total Sale from {point.key}</b><br>',
        pointFormat: '₹ {point.y}'
      },
      legend: {
        enabled: false
      },
      plotOptions: {
        column: {depth: 25}
      },
      series: [{
        data: [<?=$OTAAmt?>],
        colorByPoint: true
      }]
    });
    </script>

    <?php
    $TotalExpansesArr = [];
    $ExpansesArr = [];
    foreach ($ExpenditureDataComp as $Exdata){
      $TotalExpanses  = $this->owner_model->getTotalExpensesByOwnerId($Exdata['service_id'],$VendorArrComp,$fromDate,$toDate,$range);
      $ExpansesArr[]  = '"'.stripslashes($Exdata['service_name']).'"';
      $TotalExpansesArr[]  = stripslashes($TotalExpanses['totalExpense'] ?? 0);
    }
    $ExpansesData = implode(',',$ExpansesArr);
    $TotalExpansesData = implode(',',$TotalExpansesArr);
    if(!empty($TotalExpansesData) && $TotalExpansesData > 0){
        
    ?>
    <script type="text/javascript">
    Highcharts.chart('TotalExpenceAmt2', {
      chart: {
        renderTo: '',
        type: 'column'
      },
      title: {
        text: 'EXPENDITURE ACCOUNTS',
        align: 'center'
      },
      xAxis: {
        categories: [<?=$ExpansesData?>]
      },
      yAxis: {
        title: {
          enabled: false
        }
      },
      tooltip: {
        headerFormat: '<b>Total Sale from {point.key}</b><br>',
        pointFormat: '₹ {point.y}'
      },
      legend: {
        enabled: false
      },
      plotOptions: {
        column: {depth: 25}
      },
      series: [{
        data: [<?=$TotalExpansesData?>],
        colorByPoint: true
      }]
    });
    </script>
<?php } ?>
    <?php
        $TotalRoomOnline = $RoomOnlineComp['roomCount'] ?? 0;
        $TotalRoomDirect = $RoomDirectComp['roomCount'] ?? 0;
        $total = $TotalRoomOnline+$TotalRoomDirect;
        $RoomOnlinePre = ($TotalRoomOnline*100)/($total);
        $TotalRoomDirectPre = ($TotalRoomDirect*100)/($total);
        $OnlineSales = ($Online*100)/$TotalSale;
    ?>  
    <script type="text/javascript">

    Highcharts.chart('TotalRooms2', {
      chart: {
        plotBackgroundColor: null,
        plotBorderWidth: null,
        plotShadow: false,
        type: 'pie'
      },
      title: {
        text: 'DIRECT/ONLINE PLATFORM BIFURCATION',
        align: 'center'
      },
      tooltip: {
        pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
      },
      accessibility: {
        point: {
          valueSuffix: '%'
        }
      },
      plotOptions: {
        pie: {
          allowPointSelect: true,
          cursor: 'pointer',
          dataLabels: {
            enabled: true,
            format: '<b>{point.name}</b>: {point.percentage:.1f} %'
          }
        }
      },
      series: [{
        name: 'Rooms',
        colorByPoint: true,
        data: [{
          name: 'Online Platform',
          y: <?=$RoomOnlinePre?>,
          sliced: true,
          selected: true
        },
        {
          name: 'Direct Platform',
          y: <?=$TotalRoomDirectPre?>
        }]
      }]
    });
</script>
<?php } ?>