<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?=base_url('owner/restaurant')?>" class=""><i class="lnr lnr-user"></i>Restaurant List</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITDATA ? 'Edit' : 'Add' ?> Restaurant</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Restaurant List</h3>
          <a href="<?=base_url('owner/restaurant')?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>Personal Details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_business_name')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Hotel Name</label>
                      <select class="form-control" required name="vendor_id" id="vendor_id">
                        <option value="" selected>Select</option>
                        <?php
                        foreach ($HotelList as $hotel) {
                          $vendor_id = stripslashes($EDITDATA['hotel_manager_id']);
                          $selected = '';
                          if($vendor_id==$hotel['vendor_id']){
                            $selected = 'selected';
                          }
                          echo '<option value="'.$hotel['vendor_id'].'" '.$selected.'>'.$hotel['vendor_business_name'].'</option>';
                        }
                        ?>
                      </select>
                      <?php if (form_error('vendor_id')) : ?>
                        <span for="vendor_id" generated="true" class="help-inline"><?php echo form_error('vendor_id'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Name of Restaurant <span class="required">*</span></label>
                      <input type="text" name="rest_name" required id="rest_name" value="<?php if (set_value('rest_name')) : echo set_value('rest_name'); else : echo stripslashes($EDITDATA['rest_name']); endif; ?>" class="form-control required" placeholder="Name of Restaurant">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Phone<span class="required">*</span></label>
                      <input type="tel" min="0" name="rest_phone" required id="rest_phone" value="<?php if (set_value('rest_phone')) : echo set_value('rest_phone'); else : echo stripslashes($EDITDATA['rest_phone']); endif; ?>" class="form-control required" placeholder="Phone">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Email<span class="required">*</span></label>
                      <input type="text" name="rest_email" required id="rest_email" value="<?php if (set_value('rest_email')) : echo set_value('rest_email'); else : echo stripslashes($EDITDATA['rest_email']); endif; ?>" class="form-control required" placeholder="Email">
                    </div>
                  </div>
                  <?php if ($EDITDATA <> "") : ?>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">New Password</label>
                        <input type="password" name="new_password" id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password'); endif; ?>" class="form-control" placeholder="New Password">
                        <?php if (form_error('new_password')) : ?>
                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Confirm Password</label>
                        <input type="password" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password'); endif; ?>" class="form-control" placeholder="Confirm Password">
                        <?php if (form_error('conf_password')) : ?>
                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php else : ?>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Password</label>
                        <input type="password" name="new_password" required id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password'); endif; ?>" class="form-control" placeholder="New password">
                        <?php if (form_error('new_password')) : ?>
                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Confirm Password</label>
                        <input type="password" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password'); endif; ?>" class="form-control" required placeholder="Confirm Password">
                        <?php if (form_error('conf_password')) : ?>
                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php endif; ?>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox">FSSAI Number<span class="required">*</span></label>
                      <input type="text" name="fssai_number" id="fssai_number" value="<?php if (set_value('fssai_number')) : echo set_value('fssai_number'); else : echo stripslashes($EDITDATA['fssai_number']); endif; ?>" class="form-control required" placeholder="FSSAI Number">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Image</label>
                      <?php $logo = stripslashes($EDITDATA['logo']);?>
                      <img border="0" alt="" src="{ASSET_ADMIN_URL}images/browse-white.png" id="firstImageUpload" class="img-responsive" style="cursor:pointer;">
                      <input type="etxt" name="logo" id="firstAvtar" value="<?php echo $logo; ?>" class="form-control" style="border:none;width:0px;height:0px;margin-top: -14px;" />
                      <span id="firstAvtarImageDiv" style="margin-top:5px;">
                        <?php if ($logo): ?>
                          <img border="0" alt="" src="<?php echo $logo; ?>" class="img-responsive">&nbsp;
                          <a class="spancross" onclick="firstImageDelete('<?php echo $logo; ?>');" href="javascript:void(0);"> <img border="0" alt="" src="{ASSET_ADMIN_URL}images/cross.png"></a>
                        <?php endif;?>
                      </span>
                    </div>
                  </div>
                </div>
              </fieldset>
              <fieldset>
                <legend>Address Details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Address<span class="required">*</span></label>
                      <input type="text" name="address" id="address" value="<?php if (set_value('address')) : echo set_value('address'); else : echo stripslashes($EDITDATA['address']); endif; ?>" class="form-control required" placeholder="Address">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox">GSTIN<span class="required">*</span></label>
                      <input type="text" name="gstin" id="gstin" value="<?php if (set_value('gstin')) : echo set_value('gstin'); else : echo stripslashes($EDITDATA['gstin']); endif; ?>" class="form-control required" placeholder="GSTIN">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox">KOT Number<span class="required">*</span></label>
                      <input type="tel" min="0" name="kot_number" id="kot_number" value="<?php if (set_value('kot_number')) : echo set_value('kot_number'); else : echo stripslashes($EDITDATA['kot_number']); endif; ?>" class="form-control required" placeholder="KOT Number">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox">Bill Number<span class="required">*</span></label>
                      <input type="tel" min="0" name="bill_number" id="bill_number" value="<?php if (set_value('bill_number')) : echo set_value('bill_number'); else : echo stripslashes($EDITDATA['bill_number']); endif; ?>" class="form-control required" placeholder="Bill Number">
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-6 col-sm-6 col-xs-6">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Extra Remarks</label>
                      <textarea name="remarks" id="remarks" class="form-control" cols="40" rows="5"><?php if (set_value('remarks')) : echo set_value('remarks'); else : echo stripslashes($EDITDATA['remarks']); endif; ?></textarea>
                    </div>
                  </div>
                </div>
              </fieldset>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="<?=base_url('owner/restaurant')?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note :- <strong><span style="color:#FF0000;">*</span> Indicates Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>