<style type="text/css">

.lds-dual-ring.hidden { 
display: none;
}
.lds-dual-ring {
  display: inline-block;
  width: 80px;
  height: 80px;
}
.lds-dual-ring:after {
  content: " ";
  display: block;
  width: 64px;
  height: 64px;
  margin: 5% auto;
  border-radius: 50%;
  border: 6px solid #fff;
  border-color: #fff transparent #fff transparent;
  animation: lds-dual-ring 1.2s linear infinite;
}
@keyframes lds-dual-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}


.overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    background: rgba(0,0,0,.8);
    z-index: 999;
    opacity: 1;
    transition: all 0.5s;
}
</style>
<div id="loader" class="lds-dual-ring hidden overlay"></div>
<div class="row box_guard">
    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" class="view-check-info" data-type="checkin" title="TODAY'S CHECK-INS" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong> <?= $TotalCheckIn ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">TODAY'S CHECK-INS </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" class="view-check-info" data-type="checkout" title="TODAY'S CHECK-OUTS" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong> <?= $TotalCheckOut ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">TODAY'S CHECK-OUTS </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>


    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong> <?php echo round((($fillRoomsCount / $totlaRoomsCount) * 100), 2);  ?>% <br> (<?= $fillRoomsCount ?>/<?= $totlaRoomsCount; ?>)</strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">OCCUPANCY PERCENTAGE (TODAY) </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" data-type="occupied" class="view-check-info" title="Current occupied rooms" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong> <?= $fillRoomsCount ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">OCCUPIED ROOMS </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" data-type="continued" class="view-check-info" title="CONTINUED ROOMS" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong> <?= $TotalValidCheckout ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">CONTINUED ROOMS </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" data-type="sale" class="view-check-info" title="TODAY'S TOTAL SALE" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $totalSales ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;"> TODAY'S TOTAL SALE </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" data-type="expense" class="view-check-info" title="TODAY'S TOTAL EXPENSES" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $TotalExpenses ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">TODAY'S TOTAL EXPENSES </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" data-type="offline" class="view-check-info" title="TOTAL CASH SALE TODAY" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $todayCash ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;"> TOTAL CASH SALE TODAY </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
               <a href="javascript:void(0);" data-type="online" class="view-check-info" title="TOTAL ONLINE SALE TODAY" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $TotalOnline ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;"> TOTAL ONLINE SALE TODAY </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" data-type="prepaid" class="view-check-info" title="TOTAL PREPAID SALE TODAY" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $TotalPrepaid ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">TOTAL PREPAID SALE TODAY</h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" data-type="BTC" class="view-check-info" title="TOTAL BTC SALE TODAY" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong> <i class="fa fa-inr" aria-hidden="true"></i> <?= $TotalBTC ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">TOTAL BTC SALE TODAY</h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0);" data-type="cash_in_hand" class="view-check-info" title="TOTAL CASH IN HAND (TODAY)" data-id="<?= $id ?>" data-width="800">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong> <i class="fa fa-inr" aria-hidden="true"></i> <?= $cashInHand; ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;"> TOTAL CASH IN HAND (TODAY) </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong> <i class="fa fa-inr" aria-hidden="true"></i> <?= $todayCashMonth; ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;"> TOTAL CASH SALE THIS MONTH </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $totalSalesMonthly ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">TOTAL SALE CURRENT MONTH </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>

    <div class="col-md-2 col-sm-3 col-xs-6">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $monthlyExp ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">TOTAL EXPENSES THIS MONTH </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>


    <div class="col-md-2 col-sm-3 col-xs-6" style="display: none;">
        <div class="card card-even">
            <div class="card-content bg-3">
                <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= $TotalSale ?></strong></h5>
                            <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Today Revenue </h4>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>