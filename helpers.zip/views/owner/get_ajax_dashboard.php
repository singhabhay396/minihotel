
<div class="row box_guard">
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= round($TotalSale,2)?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Sale </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?=round($TotalExpenses,2)?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Expenses </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                          <h5 style="text-transform: capitalize;"><strong> <?=$TotalCheckIn?></strong></h5>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Check Ins </h4>
                        </div>
                      </a>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong> <?=$TotalCheckOut?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Check Out </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
            <?php 
            $CheckWhatsApp = $this->common_model->CheckOwnerWhatsApp();
            $WhatsAppCount = 0;
            if($CheckWhatsApp['whatsapp_checkin']==1){
              $WhatsAppCount++;
            }
            if($CheckWhatsApp['whatsapp_checkout']==1){
              $WhatsAppCount++;
            }
            if($CheckWhatsApp['whatsapp_bulk']==1){
              $WhatsAppCount++;
            }
            if($WhatsAppCount > 0){
            ?>  
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong> <?=$TotalWhatsapp?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">No of Msg Sent Total </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
            <?php  
            }
            ?>
            <!--div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong> <?=$TotalValidCheckout?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Rooms Continued </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
          </div-->

          <div class="row">

          <?php

            foreach ($totalVendor as $key => $val) {

            ?>
              <div class="col-md-3 col-sm-3 col-xs-6">
                <div class="card card-even" style="border-radius: 20px; height: auto;">
                  <div class="card-content bg-3"> 
                    <a href="<?=base_url('owner/dashboard/MangerLogin/'.$val['hotel_manager_id'])?>" target="_blank" title="Login">
                      <div class="media  align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                          <h3 style="text-transform: capitalize; color: #fff;"><strong> <?=$val['name']?></strong></h3>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Sale - <i class="fa fa-inr" aria-hidden="true"></i><?=round($val['sales'],2) ?? 0?></h4>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Expenses - <i class="fa fa-inr" aria-hidden="true"></i><?=$val['expance'] ?? 0?></h4>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Ins - <?=$val['in'] ?? 0?></h4>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Outs - <?=$val['out'] ?? 0?></h4>
                        </div>
                      </div>
                    </a> 
                  </div>
                </div>
              </div>
            <?php
            }
            ?>
            <?php

            //foreach ($ALLHotel as $key => $val) {
             
            ?>
              <!--div class="col-md-3 col-sm-3 col-xs-6">
                <div class="card card-even" style="border-radius: 20px; height: auto;">
                  <div class="card-content bg-3"> 
                    <a href="<?=base_url('owner/dashboard/MangerLogin/'.$key)?>" target="_blank" title="Login">
                      <div class="media  align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                          <h3 style="text-transform: capitalize; color: #fff;"><strong> <?=$val?></strong></h3>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Sale - <i class="fa fa-inr" aria-hidden="true"></i><?=round($totalSalesVendor[$key],2) ?? 0?></h4>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Expenses - <i class="fa fa-inr" aria-hidden="true"></i><?=$TotalExpensesVendor[$key] ?? 0?></h4>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Ins - <?=$totalCheckinVendor[$key] ?? 0?></h4>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Outs - <?=$totalCheckOutVendor[$key] ?? 0?></h4>
                        </div>
                      </div>
                    </a> 
                  </div>
                </div>
              </div-->
            <?php
            //}
            ?>

            <?php            
            
            if(!empty($this->session->userdata('MHM_IS_OWNER'))){ ?>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <div class="card card-even" style="border-radius: 20px; height: auto;">
                <div class="card-content bg-3"> 
                  <a href="<?=base_url('owner/dashboard/MangerLogin/'.$MainHotel['vendor_id'])?>" target="_blank" title="Login">
                    <div class="media  align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h3 style="text-transform: capitalize; color: #fff;"><strong> <?=$MainHotel['vendor_business_name']?></strong></h3>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Sale - <i class="fa fa-inr" aria-hidden="true"></i><?=round($totalSalesOwn,2) ?? 0?></h4>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Expenses - <i class="fa fa-inr" aria-hidden="true"></i><?=round($TotalExpensesOwn,2) ?? 0?></h4>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Ins - <?=$totalCheckinOwn ?? 0?></h4>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Outs - <?=$totalChkOutOWN ?? 0?></h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div><?php } ?>
          </div>

        </div>