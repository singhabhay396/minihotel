<?php 
if ($ALLDATA != "") : $i = 1;
  foreach ($ALLDATA as $ALLDATAINFO) :

    $RoomQuery = "SELECT room_no FROM " . getTablePrefix() . "room_number WHERE room_id = '" . $ALLDATAINFO['assign_room_number'] . "'  AND hotel_manager_id = '" . $VendorID . "' ";
    $Room = $this->common_model->getDataByQuery('single', $RoomQuery);
  ?>
    <tr class="<?php if ($i % 2 == 0) : echo 'odd'; else : echo 'even'; endif; ?> gradeX">
      <td><?= $i++ ?></td>
      <td><?= stripslashes($ALLDATAINFO['hotel_manager_name']) ?></td>
      <td> <?= stripslashes($ALLDATAINFO['customer_name']) ?></td>
      <td><?= stripslashes($ALLDATAINFO['customer_mobile_number']) ?></td>
      <td><?= date('d-m-Y h:i A', strtotime($ALLDATAINFO['check_in_datetime'])) ?></td>
      <td><?= date('d-m-Y h:i A', strtotime($ALLDATAINFO['check_out_datetime'])) ?></td>
      <td><?=stripslashes($Room['room_no'])?></td>
      <td><?= stripslashes($ALLDATAINFO['entry_number']) ?></td>
      <?php if ($ALLDATAINFO['user_status'] == 1) :  ?>
        <td style="color:red">No</td>
      <?php elseif ($ALLDATAINFO['user_status'] == 2) :  ?>
        <td style="color:green">Yes</td>
      <?php else :  ?>
        <td style="color:green">N/A</td>
      <?php endif;  ?>                 
      <td class="center">
        <div class="btn-group">
          <button class="btn dropdown-toggle" data-toggle="dropdown">More Options <span class="caret"></span></button>
          <ul class="dropdown-menu">
            <li><a href="<?=base_url('owner/billbookdata/setCustomebillbook/'.$ALLDATAINFO['summary_book_id'])?>"><i class="fa fa-plus"></i>Add New Record</a></li>
            <!-- <li class="divider"></li>
            <li><a href="javascript:void(0)" onclick="EditBillPopUp(<?=$ALLDATAINFO['summary_book_id']?>)"> Edit Shortcut</a></li> -->
            
            <!-- <li class="divider"></li>
            <li><a href="<?=base_url('owner/billbookdata/generateOrderPdf/'.$ALLDATAINFO['summary_book_id'].'/room_rent_with_gst')?>"><i class="fa fa-download"></i>Generate Room Rent Bill(With GST)</a></li>
            <li><a href="<?=base_url('owner/billbookdata/generateOrderPdf/'.$ALLDATAINFO['summary_book_id'].'/room_rent_with_food_gst')?>"><i class="fa fa-download"></i>Generate Room Rent Plus Food Bill(With GST)</a></li>
            <li><a href="<?=base_url('owner/billbookdata/generateOrderPdf/'.$ALLDATAINFO['summary_book_id'].'/room_rent_without_gst')?>"><i class="fa fa-download"></i>Generate Room Rent Bill(Without GST)</a></li>
            <li><a href="<?=base_url('owner/billbookdata/generateOrderPdf/'.$ALLDATAINFO['summary_book_id'].'/room_rent_without_food_gst')?>"><i class="fa fa-download"></i>Generate Room Rent Plus Food Bill(Without GST)</a></li> -->
          </ul>
        </div>
      </td>
    </tr>
    <?php 
  endforeach;
  echo '<tr><td colspan="5" style="text-align:left;">'.$noOfContent.'</td>';
  echo '<td colspan="5" style="text-align:right;">'.$PAGINATION.'</td></tr>';
else : ?>
  <tr>
    <td colspan="10" style="text-align:center;">No Data Available In Table</td>
  </tr>
<?php endif; ?>