<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<script>
  $(function() {
    $("#fromDate").datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      maxDate: 0,
      yearRange: "1960:<?php echo date('Y'); ?>"
    });
  });
  $(function() {
    $("#toDate").datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      maxDate: 0,
      yearRange: "1960:<?php echo date('Y'); ?>"
    });
  });
</script>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-book" aria-hidden="true"></i>Bill Book</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Bill Book</h3>
        </div>
        <hr class="differ">
        <form action="<?=base_url('owner/billbookdata/downloadbillbookdata')?>" method="get" name="DownloadData">
          <div class="panel-body row">
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select class="form-control" onchange="Search()" id="VendorID" name="VendorID" >
                <?php
                foreach ($HotelList as $hotel) {
                  echo '<option value="'.$hotel['vendor_id'].'">'.$hotel['vendor_business_name'].'</option>';
                }
                ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-3">
              <select id="range" class="form-control" name="range">
                <option>Select Range</option>
                <option value="today" <?php if($range == 'today'){ echo "selected" ;} ?>>Today</option>
                <option value="yesterday" <?php if($range == 'yesterday'){ echo "selected" ;} ?>>Yesterday</option>
                <option value="week" <?php if($range == 'week'){ echo "selected"; }?>>This Week</option>
                <option value="last_month" <?php if($range == 'last_month'){ echo "selected"; } ?>>Last Month</option>
                <option value="till_now" <?php if($range == 'till_now'){ echo "selected"; } ?>>Month Till Now</option>
                <option value="custom" <?php if($range == 'custom'){ echo "selected"; } ?>>Custome Range</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2 customes" <?php if($range == 'custom'){ ?>style="display: block" <?php } else{ ?> style="display: none" <?php } ?>">
              <input type="text" name="fromDate" id="fromDate" value="<?php if ($searchDate <> "") : echo date('d-m-Y', strtotime($searchDate)); endif; ?>" class="form-control input-smt" placeholder="From Date">
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2 customes" <?php if($range == 'custom'){ ?>style="display: block" <?php } else{ ?> style="display: none" <?php } ?>>
              <input type="text" name="toDate" id="toDate" value="<?php if ($searchDate <> "") : echo date('d-m-Y', strtotime($searchDate)); endif; ?>" class="form-control input-smt" placeholder="To Date">
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="businessType" id="businessType" class="form-control">
                <option value="All">B2B/B2C</option>
                <option value="B2B">B2B</option>
                <option value="B2C">B2C</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="amount_mode" id="amount_mode" class="form-control">
                <option value="All">All</option>
                <option value="prepaid">Prepaid</option>
                <option value="online">Online</option>
                <option value="offline">Cash</option>
                <option value="BTC">BTC</option>
                <option value="CashOnline">Cash/Online</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="reffer_mode" onchange="RefferMode()" id="reffer_mode" class="form-control">
                <option value="All">Direct/Online</option>
                <option value="online">Online Platform</option>
                <option value="offline">Direct</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2" id="DirectModeDiv">
              <select name="direct_mode" id="direct_mode" class="form-control">
                <option value="All">Commission/No Commission</option>
                <option value="commission">Commission</option>
                <option value="non_commission">No commission</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2" id="OTSIDDiv">
              <select name="ots_id" id="ots_id" class="form-control">
                <option value="">Select Booking Platform</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="choose_plan" id="choose_plan" class="form-control">
                <option value="All">Select Plan</option>
                <option value="EP">EP</option>
                <option value="CP">CP</option>
                <option value="MAP">MAP</option>
                <option value="AP">AP</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="bill_generated" id="bill_generated" class="form-control">
                <option value="All">Bill Generated</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-4">
              <input type="submit" name="DownloadBtn" class="btn btn-primary btn-lg form-btn" value="Download Report">
            </div>
          </div>
        </form>
        <div class="dash">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th width="2%">
                  <select id="numofrecords" onchange="Search()">
                    <option value="10" selected>10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="500">500</option>
                  </select>
                </th>
                <th width="6%">Manager Name</th>
                <th width="10%">Customer Name</th>
                <th width="10%">Mobile Number</th>
                <th width="10%">Check-In Date & Time</th>
                <th width="10%">Check-Out Date & Time</th>
                <th width="5%">Room Number</th>
                <th width="5%">GRC No.</th>
                <th width="5%">Bill Generated</th>
                <th width="10%">More Options</th>
              </tr>
            </thead>
            <thead>
              <tr>
                <th>#</th>
                <th><input type="text" class="form-control" id="m_name" placeholder="Manager Name"></th>
                <th><input type="text" class="form-control" id="c_name" placeholder="Customer Name"></th>
                <th><input type="text" class="form-control" id="mobile" placeholder="Mobile"></th>
                <th><input type="date" class="form-control" id="check_in" placeholder="Check-In Date"></th>
                <th><input type="date" class="form-control" id="check_out" placeholder="Check-Out Date"></th>
                <th><input type="text" class="form-control" id="room_no" placeholder="Room Number"></th>
                <th><input type="text" class="form-control" id="entry_no" placeholder="GRC No."></th>
                <th>
                  <select id="user_status" class="form-control" onchange="Search()">
                    <option value="All" selected >All</option>
                    <option value="2">Yes</option>
                    <option value="1">No</option>
                  </select>
                </th>
                <th colspan="3">
                  <button type="button" onclick="Search()" class="btn btn-primary btn-lg">
                    <i class="fa fa-search"></i>
                  </button>
                </th>
              </tr>
            </thead>
            <tbody id="Result"></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<form action="<?=base_url('owner/billbookdata/SaveBillBookPopUp')?>" method="post" class="modal fade" id="EdotBillPopUpModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align: center;">Please add per day room rent</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" name="ci_csrf_token" value="">
        <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
        <input type="hidden" name="summary_book_id" id="summary_book_id" value="" required>
        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Amount<span class="required">*</span></label>
              <input type="number" name="amount" id="amount" min="1" value="" class="form-control" placeholder="Amount" required>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <span class="btn btn-primary btn-lg btn-block">Note:-
              <strong>
                <span style="color:#FF0000;">*</span> Indicates Required Fields
              </strong>
            </span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" style="padding: 6px 12px;">Close</button>
        <button type="submit" class="btn btn-primary" style="padding: 6px 12px;">Submit</button>
      </div>
    </div>
  </div>
</form>

<script>
  $(document).on('change','#range',function(){
    var id = $("#range").val();
    $("#fromDate").val(' ');
    $("#toDate").val(' ');
    if(id == 'custom'){
        $(".customes").css("display",'block');
    }
    else{
        $(".customes").css("display",'none');
    }
});
RefferMode();
function RefferMode() {
  var reffer_mode = $('#reffer_mode').val();
  if(reffer_mode!='All'){
    if(reffer_mode=='online'){
      $('#OTSIDDiv').show();
      $('#DirectModeDiv').hide();
      GetOTSData();
    }else{
      $('#DirectModeDiv').show();
      $('#OTSIDDiv').hide();
    }
  }else{
    $('#DirectModeDiv').hide();
    $('#OTSIDDiv').hide();
  }
}
function EditBillPopUp(summary_book_id) {
  $('#summary_book_id').val(summary_book_id);
  $('#EdotBillPopUpModal').modal("show");
}
$(function() { 
  loadData(1);
  /*$(".form-control").keypress(function(event) {
    if(event.which == 13){
      event.preventDefault();
      loadData(1);
    }
  });*/
});
function Search(){
  var page = $('#CurrentPage').val();
  loadData(page);
  GetOTSData();
}
function Pagination(page){
  loadData(page);
}
function GetOTSData(){
  $("#ots_id").html('<option value="">Loading..</option>');
  var VendorID  = $('#VendorID').val();
  $.ajax({
    url : "<?=base_url('owner/billbookdata/GetOTSData')?>",
    type: "GET",
    data : {VendorID:VendorID},
    success:function(a){
      $("#ots_id").html(a);
    }
  });
}
function loadData(page){
  $("#Result").html('<tr><td colspan="10"><center>Loading..</center></td></tr>');
  var m_name        = $("#m_name").val();
  var c_name        = $("#c_name").val();
  var mobile        = $("#mobile").val();
  var check_in      = $("#check_in").val();
  var numofrecords  = $("#numofrecords").val();
  var check_out     = $("#check_out").val();
  var room_no       = $("#room_no").val();
  var entry_no      = $('#entry_no').val();
  var VendorArr     = $('#VendorID').val();
  var user_status   = $('#user_status').val();
  $.ajax({
    url : "<?=base_url('owner/billbookdata/BillBookPagination')?>",
    type: "GET",
    data : {user_status:user_status,VendorArr:VendorArr,entry_no:entry_no,m_name:m_name,numofrecords:numofrecords,c_name:c_name,check_in:check_in,mobile:mobile,check_out:check_out,room_no:room_no,page:page},
    success:function(a)
    {
      $("#Result").html(a);
      checkboxcount();
    }
  });
}
</script>