<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-book" aria-hidden="true"></i>Custom Bill Book</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <hr class="differ">
        <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="<?=base_url('owner/billbookdata/UpdateCustomerData')?>" enctype="multipart/form-data">
          <input type="hidden" name="customeID" value="<?= $customerId ?>">
          <fieldset>
            <legend>Guest Details</legend>
            <div class="col-md-12 col-sm-12 col-xs-12 form-space">
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('customer_name')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Guest Name</label>
                  <input type="text" name="customer_name" id="customer_name" value="<?php if (set_value('customer_name')) : echo set_value('customer_name'); else : echo stripslashes($CUSTOMERDATA['customer_name']); endif; ?>" class="form-control required" placeholder="Guest Name" readonly>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('customer_mobile_number')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Phone</label>
                  <input type="text" name="customer_mobile_number" id="customer_mobile_number" value="<?php if (set_value('customer_mobile_number')) : echo set_value('customer_mobile_number'); else : echo stripslashes($CUSTOMERDATA['customer_mobile_number']); endif; ?>" class="form-control required" placeholder="Phone" readonly>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('check_in_datetime')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Check-in Date & Time</label>
                  <input type="datetime-local" name="check_in_datetime" id="check_in_datetime" value="<?php if (set_value('check_in_datetime')) : echo set_value('check_in_datetime'); else : echo stripslashes($CUSTOMERDATA['check_in_datetime']); endif; ?>" class="form-control required" placeholder="Check-in Date Time" readonly>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('check_out_datetime')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Check-out Date Time</label>
                  <input type="datetime-local" name="check_out_datetime" id="check_out_datetime" value="<?php if (set_value('check_out_datetime')) : echo set_value('check_out_datetime'); else : echo stripslashes($CUSTOMERDATA['check_out_datetime']); endif; ?>" class="form-control" placeholder="Check Out Date Time" readonly>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('date')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Date</label>
                  <input type="datetime-local" name="date" id="date" value="<?php if (set_value('date')) : echo set_value('date'); else : echo stripslashes($CUSTOMERDATA['check_out_datetime']); endif; ?>" class="form-control" placeholder="Date" readonly>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('amount')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Room Rent</label>
                  <input type="text" name="amount" id="amount" value="<?php if (set_value('amount')) : echo set_value('amount'); else : echo stripslashes($CUSTOMERDATA['amount']); endif; ?>" class="form-control required numberonly" placeholder="Room Rent" readonly>
                </div>
              </div>
            </div>
            <div class="col-md-12 col-sm-12 col-xs-12 form-space">
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group">
                  <label class="fancy-checkbox form-headings">Room Number</label>
                  <input type="text" name="assign_room_number" id="assign_room_number" value="<?php echo stripslashes($ASSIGNROOM['room_no']); ?>" class="form-control" readonly>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('entry_number')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">GRC No.</label>
                  <input type="text" name="entry_number" id="entry_number" value="<?php if (set_value('entry_number')) : echo set_value('entry_number'); else : echo stripslashes($CUSTOMERDATA['entry_number']); endif; ?>" class="form-control required" placeholder="GRC No." readonly>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('number_of_person')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Number Of Persons</label>
                  <input type="text" name="number_of_person" id="number_of_person" value="<?php if (set_value('number_of_person')) : echo set_value('number_of_person'); else : echo stripslashes($CUSTOMERDATA['number_of_person']); endif; ?>" class="form-control number required" placeholder="Number Of Persons" readonly>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('bill_number')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Bill Number</label>
                  <input type="text" name="bill_number" id="bill_number" value="<?php echo $CUSTOMERDATA['bill_number']; ?>" class="form-control required" placeholder="Bill Number">
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('gst_number')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Select GSTIN</label>
                  <?php if (set_value('gst_number')) : $assignCompanyId = set_value('company_name');
                  elseif ($customerInfo['gst_number']) : $assignCompanyId = stripslashes($customerInfo['gst_number']);
                  else : $assignCompanyId = '';
                  endif; ?>
                  <select name="gst_number" id="gst_number" class="form-control mySelect2" onchange="GetCompany()">
                    
                    <?php echo $this->vendor_model->getAllCompanyByHotelId($assignCompanyId,$CUSTOMERDATA['hotel_manager_id']); ?>
                  </select>
                  <?php if (form_error('gst_number')) : ?>
                    <span for="gst_number" generated="true" class="help-inline"><?php echo form_error('gst_number'); ?></span>
                  <?php endif; ?>
                  <a href="#" class="" data-toggle="modal" data-target="#addGSTNModal">Add New GSTIN</a>
                </div>
                <!--div class="form-group <?php if (form_error('gst_number')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">GST Number</label>
                  <input type="text" name="gst_number" id="gst_number" value="<?php if (set_value('gst_number')) : echo set_value('gst_number'); else : echo stripslashes($CUSTOMERDATA['gst_number']); endif; ?>" class="form-control" placeholder="GST Number">
                  <?php if (form_error('gst_number')) : ?>
                    <span for="gst_number" generated="true" class="help-inline"><?php echo form_error('gst_number'); ?></span>
                  <?php endif; ?>
                </div-->
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('company_name')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Company Name</label>
                  <input type="text" name="company_name" id="company_name" value="<?php if (set_value('company_name')) : echo set_value('company_name'); else : echo stripslashes($CUSTOMERDATA['company_name']); endif; ?>" class="form-control" placeholder="Company Name" readonly>
                  <?php if (form_error('company_name')) : ?>
                    <span for="company_name" generated="true" class="help-inline"><?php echo form_error('company_name'); ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('company_address')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Company Address</label>
                  <input type="text" name="company_address" id="company_address" value="<?php if (set_value('company_address')) : echo set_value('company_address'); else : echo stripslashes($CUSTOMERDATA['company_address']); endif; ?>" class="form-control" placeholder="Company Address" readonly>
                  <?php if (form_error('company_address')) : ?>
                    <span for="company_address" generated="true" class="help-inline"><?php echo form_error('company_address'); ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                <div class="form-group <?php if (form_error('room_rent_type')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">Is Room Rent exclusive of GST or inclusive?</label>
                  <input type="text" name="room_rent_type" id="room_rent_type" value="<?php if (set_value('room_rent_type')) : echo set_value('room_rent_type'); else : echo stripslashes($CUSTOMERDATA['room_rent_type']); endif; ?>" class="form-control" placeholder="Room Rent" readonly>
                </div>
              </div>
            </div>
          </fieldset>
          <fieldset>
            <legend>Summary Data</legend>
            <?php $allfilterids = array();
            if ($TotalFilterDefault) : $TotalFilterDefaultCount = $TotalFilterDefault;
            elseif ($SUMMARYDETAIL != "") : $TotalFilterDefaultCount = count($SUMMARYDETAIL);
            else : $TotalFilterDefaultCount = 1;
            endif; ?>
            <input type="hidden" name="TotalFilterDefault" id="TotalFilterDefault" value="<?php echo $TotalFilterDefaultCount; ?>" />
            <div id="FilterDefault">
              <?php if ($TotalFilterDefault) : $i = 1;
                for ($j = 1; $j <= $TotalFilterDefault; $j++) :
                  if ($i == 1) : $requiredField = 'required';
                    $removeaddbutton = '';
                    $numcount = '<span class="required"> * </span>';
                    $horizontal = '';
                  else : $requiredField = '';
                    $removeaddbutton = '<a href="javascript:void(0);" class="removeMoreFilterDetails pull-right">-Remove this Item</a>';
                    $numcount = $i;
                    $horizontal = '<hr />';
                  endif;
                  $filter_details_id_ = 'filter_details_id_' . $i;
                  $billItem_ = 'billItem_' . $i;
                  $error_details_ = form_error('billItem_' . $i);
                  array_push($allfilterids, $$filter_details_id_);
              ?>
                  <span> <?php echo $horizontal; ?>
                    <input type="hidden" name="filter_details_id_<?php echo $i; ?>" id="filter_details_id_<?php echo $i; ?>" class="form-control" value="<?php echo $$filter_details_id_; ?>" />
                    <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                      <div class="col-md-4 col-sm-4 col-xs-4">
                        <div class="form-group <?php if (form_error('bill_item')) : ?>error<?php endif; ?>">
                          <label class="fancy-checkbox form-headings">Bill Item<span class="required">*</span></label>
                          <input type="text" name="bill_item_<?php echo $i; ?>" id="bill_item_<?php echo $i; ?>" class="form-control required" placeholder="Hotel Service Name">
                          <?php if (form_error('bill_item')) : ?>
                            <p for="bill_item" generated="true" class="error"><?php echo form_error('bill_item'); ?></p>
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-md-4 col-sm-4 col-xs-4">
                        <div class="form-group <?php if (form_error('advance_amount')) : ?>error<?php endif; ?>">
                          <label class="fancy-checkbox form-headings">Amount<span class="required">*</span></label>
                          <input type="text" name="advance_amount_<?php echo $i; ?>" id="advance_amount_<?php echo $i; ?>" value="<?php if (set_value('advance_amount')) : echo set_value('advance_amount'); endif; ?>" class="form-control numberonly" placeholder="Amount">
                          <?php if (form_error('advance_amount')) : ?>
                            <span for="advance_amount" generated="true" class="help-inline"><?php echo form_error('advance_amount'); ?></span>
                          <?php endif;
                          if ($mobileerror) : ?>
                            <span for="advance_amount" generated="true" class="help-inline"><?php echo $mobileerror; ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-md-4 col-sm-4 col-xs-4">
                        <div class="form-group <?php if (form_error('page_source')) : ?>error<?php endif; ?>">
                          <label class="fancy-checkbox form-headings">Select Type Of Billing</label>
                          <select name="page_source_<?php echo $i; ?>" id="page_source_<?php echo $i; ?>" class="form-control">
                            <option value="">Select Type Of Billing</option>
                            <option value="extend_stay">Room Rent Bill</option>
                            <option value="add_a_service">>Food Bill</option>
                            <option value="add_a_services">>Other Services</option>
                          </select>
                          <?php if (form_error('page_source')) : ?>
                            <span for="page_source" generated="true" class="help-inline"><?php echo form_error('page_source'); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                    </div>
                    <div class="form-group"> <?php echo $removeaddbutton; ?> </div>
                  </span>
                <?php $i++;
                endfor;
              elseif ($SUMMARYDETAIL != "") : $i = 1;
                foreach ($SUMMARYDETAIL as $SUMMARYDETAILDATAINFO) :
                  //echo "<pre>"; print_r($SUMMARYDETAILDATAINFO['page_source']);echo "</pre>";die;
                  if ($i == 1) : $requiredField = 'required';
                    $removeaddbutton = '';
                    $numcount = '<span class="required"> * </span>';
                    $horizontal = '';
                  else : $requiredField = '';
                    $removeaddbutton = '<a href="javascript:void(0);" class="removeMoreFilterDetails pull-right">-Remove this Item</a>';
                    $numcount = $i;
                    $horizontal = '<hr />';
                  endif;
                  $filter_details_id_ = $SUMMARYDETAILDATAINFO['detail_book_id'];
                  $billItem_ = $SUMMARYDETAILDATAINFO['bill_item'];
                  $amount_mode_ = $SUMMARYDETAILDATAINFO['amount_mode'];
                  $amount_ = $SUMMARYDETAILDATAINFO['advance_amount'];
                  if ($checkBillGenerate['user_status'] == '2') :
                    $totalAmount += $SUMMARYDETAILDATAINFO['advance_paid'];
                  elseif ($checkBillGenerate['user_status'] == '1') :
                    $totalAmount += $SUMMARYDETAILDATAINFO['advance_paid'];
                  endif;
                  $error_details_ = '';
                  //print_r($SUMMARYDETAILDATAINFO['advance_paid']);die;
                  array_push($allfilterids, $filter_details_id_);
                ?>
                  <span> <?php echo $horizontal; ?>
                    <input type="hidden" name="filter_details_id_<?php echo $i; ?>" id="filter_details_id_<?php echo $i; ?>" class="form-control" value="<?php echo $filter_details_id_; ?>" />
                    <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                      <div class="col-md-4 col-sm-4 col-xs-4">
                        <div class="form-group <?php if (form_error('bill_item')) : ?>error<?php endif; ?>">
                          <label class="fancy-checkbox form-headings">Bill Item<span class="required">*</span></label>
                          <input type="text" name="bill_item_<?php echo $i; ?>" id="bill_item_<?php echo $i; ?>" value="<?php if (set_value('bill_item')) : echo set_value('bill_item'); else : echo stripslashes($SUMMARYDETAILDATAINFO['bill_item']); endif; ?>" class="form-control required" placeholder="Hotel Service Name">
                          <?php if (form_error('bill_item')) : ?>
                            <p for="bill_item" generated="true" class="error"><?php echo form_error('bill_item'); ?></p>
                          <?php endif; ?>
                        </div>
                      </div>
                      <div class="col-md-4 col-sm-4 col-xs-4">
                        <div class="form-group <?php if (form_error('advance_amount')) : ?>error<?php endif; ?>">
                          <label class="fancy-checkbox form-headings">Amount<span class="required">*</span></label>
                          <input type="text" name="advance_amount_<?php echo $i; ?>" id="advance_amount_<?php echo $i; ?>" value="<?php if (set_value('advance_amount')) : echo set_value('advance_amount'); else : echo stripslashes($SUMMARYDETAILDATAINFO['advance_paid']); endif; ?>" class="form-control numberonly" placeholder="Amount">
                          <?php if (form_error('advance_amount')) : ?>
                            <span for="advance_amount" generated="true" class="help-inline"><?php echo form_error('advance_amount'); ?></span>
                          <?php endif;
                          if ($mobileerror) : ?>
                            <span for="advance_amount" generated="true" class="help-inline"><?php echo $mobileerror; ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <?php
                      if ($SUMMARYDETAILDATAINFO['page_source'] == 'add_a_services'){
                        echo '<div class="col-md-3 col-sm-3 col-xs-3">';
                      }else{
                        echo '<div class="col-md-4 col-sm-4 col-xs-4">';
                      }
                      ?>
                        <div class="form-group <?php if (form_error('page_source')) : ?>error<?php endif; ?>">
                          <label class="fancy-checkbox form-headings">Select Type Of Billing</label>
                          <select name="page_source_<?php echo $i; ?>" id="page_source_<?php echo $i; ?>" class="form-control">
                            <option value="">Select Type Of Billing</option>
                            <option value="extend_stay" <?php if ($SUMMARYDETAILDATAINFO['page_source'] == 'extend_stay') : echo "selected"; endif; ?>>Room Rent Bill</option>
                            <option value="add_a_service" <?php if ($SUMMARYDETAILDATAINFO['page_source'] == 'add_a_service') : echo "selected"; endif; ?>>Food Bill</option>
                            <option value="add_a_services" <?php if ($SUMMARYDETAILDATAINFO['page_source'] == 'add_a_services') : echo "selected"; endif; ?>>Other Services</option>
                          </select>
                          <?php if (form_error('page_source')) : ?>
                            <span for="page_source" generated="true" class="help-inline"><?php echo form_error('page_source'); ?></span>
                          <?php endif; ?>
                        </div>
                      </div>
                      <?php if ($SUMMARYDETAILDATAINFO['page_source'] == 'add_a_services'):?>
                      <div class="col-md-1 col-sm-1 col-xs-1">
                        <div class="form-group">
                          <label class="fancy-checkbox form-headings">GST<span class="required">*</span></label>
                          <input type="text" name="service_gst_<?php echo $i; ?>" id="service_gst_<?php echo $i; ?>" value="<?php if (set_value('service_gst')) : echo set_value('service_gst'); else : echo stripslashes($SUMMARYDETAILDATAINFO['service_gst']); endif; ?>" class="form-control" placeholder="GST">
                        </div>
                      </div>
                      <?php endif; ?>
                    </div>
                    <br />
                    <div class="form-group"> <?php echo $removeaddbutton; ?> </div>
                  </span>
                <?php $i++;
                endforeach;
              else : ?>
                <span>
                  <input type="hidden" name="filter_details_id_1" id="filter_details_id_1" class="form-control" value="" />
                  <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('bill_item')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Bill Item<span class="required">*</span></label>
                        <input type="text" name="bill_item_1" id="bill_item_1" class="form-control required" placeholder="Bill Item">
                        <?php if (form_error('bill_item')) : ?>
                          <p for="bill_item" generated="true" class="error"><?php echo form_error('bill_item'); ?></p>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('advance_amount')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Amount<span class="required">*</span></label>
                        <input type="text" name="advance_amount_1" id="advance_amount_1" class="form-control required numberonly" placeholder="Amount">
                        <?php if (form_error('advance_amount')) : ?>
                          <span for="advance_amount" generated="true" class="help-inline"><?php echo form_error('advance_amount'); ?></span>
                        <?php endif;
                        if ($mobileerror) : ?>
                          <span for="advance_amount" generated="true" class="help-inline"><?php //echo $mobileerror; ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('page_source')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Select Type Of Billing</label>
                        <select name="page_source_<?php echo $i; ?>" id="page_source_<?php echo $i; ?>" class="form-control">
                          <option value="">Select Type Of Billing</option>
                          <option value="extend_stay">Room Rent Bill</option>
                          <option value="add_a_service">Food Bill</option>
                          <option value="add_a_services">Other Services</option>
                        </select>
                        <?php if (form_error('page_source')) : ?>
                          <span for="page_source" generated="true" class="help-inline"><?php echo form_error('page_source'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  </div>
                </span>
              <?php endif; ?>
            </div>
            <br />
            <div class="form-group"> <a href="javascript:void(0);" class="addMoreFilterDetails pull-right">+ Add another Item</a>
              <input type="hidden" name="AllFilterIds" id="AllFilterIds" value="<?php echo implode('_____', $allfilterids); ?>" />
            </div>
          </fieldset>
          <fieldset>
            <legend>Total Payable Amount</legend>
            <div class="col-md-12 col-sm-12 col-xs-12 form-space">
              <input type="hidden" name="amount2" id="amount2" value="">
              <?php
              //echo "<pre>"; print_r ($CUSTOMERDATA['room_rent_type']); die;
              if ($CUSTOMERDATA['room_rent_type']  != 'gst_include') :   ?>
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="form-group <?php if (form_error('total_amount')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Total Amount<span class="required">*</span></label>
                    <input type="text" name="total_amount" id="total_amount" value="<?= $totalAmount ?>" class="form-control numberonly required" placeholder="Total Amount">
                    <?php if (form_error('total_amount')) : ?>
                      <p for="total_amount" generated="true" class="error"><?php echo form_error('total_amount'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
              <?php else : ?>
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="form-group <?php if (form_error('total_amount')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Total Amount<span class="required">*</span></label>
                    <input type="text" name="total_amount" id="total_amount_gst" value="" class="form-control numberonly required" placeholder="Total Amount">
                    <?php if (form_error('total_amount')) : ?>
                      <p for="total_amount" generated="true" class="error"><?php echo form_error('total_amount'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endif; ?>
              <div class="col-md-4 col-sm-12 col-xs-12">
                <div class="form-group <?php if (form_error('gst')) : ?>error<?php endif; ?>">
                  <label class="fancy-checkbox form-headings">GST</label>
                  <select name="gst" id="gst" class="form-control">
                    <option value="">Select Mode</option>
                    <option value="0">0</option>
                    <option value="12" selected>12</option>
                  </select>
                  <?php if (form_error('gst')) : ?>
                    <span for="gst" generated="true" class="help-inline"><?php echo form_error('gst'); ?></span>
                  <?php endif; ?>
                </div>
              </div>
              <?php if ($CUSTOMERDATA['room_rent_type']  == 'gst_include') : ?>
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="form-group <?php if (form_error('paybal_amount')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Grand Total Payable Amount<span class="required">*</span></label>
                    <input type="text" name="paybal_amount" id="paybal_amount_gst" value="<?= $totalAmount ?>" class="form-control numberonly required" placeholder="Grand Total Payable Amount">
                    <?php if (form_error('paybal_amount')) : ?>
                      <p for="paybal_amount" generated="true" class="error"><?php echo form_error('paybal_amount'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
              <?php else : ?>
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="form-group <?php if (form_error('paybal_amount')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Grand Total Payable Amount<span class="required">*</span></label>
                    <input type="text" name="paybal_amount" id="paybal_amount" value="" class="form-control numberonly required" placeholder="Grand Total Payable Amount">
                    <?php if (form_error('paybal_amount')) : ?>
                      <p for="paybal_amount" generated="true" class="error"><?php echo form_error('paybal_amount'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
              <?php endif; ?>
            </div>
          </fieldset>
          <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
          <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
          <a href="<?php echo correctLink('billBookData', '{VENDOR_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
          <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
              :- <strong><span style="color:#FF0000;">*</span> Indicates
                Required Fields</strong> </span>
          </span>
        </form>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<form action="<?=base_url('owner/billbookdata/savecompanymaster')?>" class="modal fade" id="addGSTNModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel" style="text-align: center;">Add New GSTIN</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
        <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group <?php if (form_error('company_gst')) : ?>error<?php endif; ?>">
              <label class="fancy-checkbox form-headings">Company GSTIN<span class="required">*</span></label>
              <input type="text" name="company_gst" id="company_gst" value="<?= set_value('company_gst') ? set_value('company_gst') : "" ?>" class="form-control required" placeholder="Company GSTIN">
              <?php if (form_error('company_gst')) : ?>
                <p for="company_gst" generated="true" class="error"><?php echo form_error('company_gst'); ?></p>
              <?php endif; ?>
            </div>
          </div>
          <input type="hidden" name="hotel_manager_id" id="hotel_manager_id" value="<?php echo $CUSTOMERDATA['hotel_manager_id']; ?>">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group <?php if (form_error('company_name')) : ?>error<?php endif; ?>">
              <label class="fancy-checkbox form-headings">Company Name</label>
              <input type="text" name="company_name" id="company_name" value="<?= set_value('company_name') ? set_value('company_name') : "" ?>" class="form-control" placeholder="Company Name">
              <?php if (form_error('company_name')) : ?>
                <p for="company_name" generated="true" class="error"><?php echo form_error('company_name'); ?></p>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group <?php if (form_error('company_address')) : ?>error<?php endif; ?>">
              <label class="fancy-checkbox form-headings">Company Address</label>
              <input type="text" name="company_address" id="company_address" value="<?= set_value('company_address') ? set_value('company_address') : "" ?>" class="form-control" placeholder="Company Address">
              <?php if (form_error('company_address')) : ?>
                <p for="company_address" generated="true" class="error"><?php echo form_error('company_address'); ?></p>
              <?php endif; ?>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <span class="btn btn-primary btn-lg btn-block">Note:-
              <strong>
                <span style="color:#FF0000;">*</span> Indicates Required Fields
              </strong>
            </span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" style="padding: 6px 12px;">Close</button>
        <button type="submit" class="btn btn-primary" style="padding: 6px 12px;">Save changes</button>
      </div>
    </div>
  </div>
</form>
<script>
  $(function() {
    var scntDiv = $('#currentPageForm #FilterDefault');
    var i = $('#currentPageForm #FilterDefault > span').size();
    $(document).on('click', '#currentPageForm .addMoreFilterDetails', function() {
      i++;
      $('<span><hr /><input type="hidden" name="filter_details_id_' + i + '" id="filter_details_id_' + i + '" class="form-control" value="" /><div class="col-md-12 col-sm-12 col-xs-12 form-space"><div class="col-md-4 col-sm-4 col-xs-4"><label>Bill Item' + i + '</label><input type="text" name="bill_item_' + i + '" id="bill_item_' + i + '" class="form-control required" placeholder="Bill Item"></div><div class="col-md-4 col-sm-4 col-xs-4"><label>Amount' + i + '</label><input type="text" name="advance_amount_' + i + '" id="advance_amount_' + i + '" class="form-control required" placeholder="Amount"></div><div class="col-md-4 col-sm-4 col-xs-4"><div class="form-group "><label class="fancy-checkbox form-headings">Select Type Of Billing</label><select name="page_source_' + i + '" id="page_source_' + i + '" class="form-control"><option value="">Select Type Of Billing</option><option value="extend_stay">Room Rent Bill</option><option value="add_a_service">Food Bill</option><option value="add_a_services">Other Services</option></select></div></div></div><br/><div class="form-group"><a href="javascript:void(0);" class="removeMoreFilterDetails pull-right"></br>-Remove Item</a></div></span>').appendTo(scntDiv);
      $('#currentPageForm #TotalFilterDefault').val(i);
      return false;
    });
    $(document).on('click', '#currentPageForm .removeMoreFilterDetails', function() {
      if (i > 1) {
        $(this).parents('span').remove();
        i--;
      }
      return false;
    });
  });
</script>
<script>
  <?php
  if (($CUSTOMERDATA['room_rent_type']  != 'gst_include') or empty($CUSTOMERDATA['room_rent_type'])) : ?>
    $(document).ready(function() {
      $('#gst').change(function(ev) {
        var gst = $("#gst").val();
        var price = $("#total_amount").val();
        var tot_price = (price * gst / 100);
        var reeta = parseInt(price, 10) + parseInt(tot_price, 10);
        var paybalAmount = reeta;
        var divobj = document.getElementById('paybal_amount');
        divobj.value = paybalAmount;
        var amount2 = document.getElementById('amount2');
        amount2.value = tot_price;
      });
    });
    // onload
    $(document).ready(function() {
      //Onload
      var gst = $("#gst").val();
      var price = $("#total_amount").val();
      var tot_price = (price * gst / 100);
      var reeta = parseInt(price, 10) + parseInt(tot_price, 10);
      var paybalAmount = reeta;
      var divobj = document.getElementById('paybal_amount');
      divobj.value = paybalAmount;
      var amount2 = document.getElementById('amount2');
      amount2.value = tot_price;
    });
  <?php endif;
  if ($CUSTOMERDATA['room_rent_type']  == 'gst_include') : ?>
    $(document).ready(function() {
      $('#gst').change(function(ev) {
        var gst = $("#gst").val();
        var price = $("#paybal_amount_gst").val();
        var grossGst = '1.' + gst;
        var totalPrice = (price / grossGst);
        var reeta = parseInt(totalPrice, 10);
        var paybalAmount = reeta;
        var divobj = document.getElementById('total_amount_gst');
        divobj.value = paybalAmount;
        var amount2 = document.getElementById('amount2');
        amount2.value = totalPrice;
      });
    });
    $(document).ready(function() {
      //Onload
      var gst = 12;
      var price = $("#paybal_amount_gst").val();
      var grossGst = '1.' + gst;
      var totalPrice = (price / grossGst);
      var reeta = parseInt(totalPrice, 10);
      var paybalAmount = reeta;
      var divobj = document.getElementById('total_amount_gst');
      divobj.value = paybalAmount;
      var amount2 = document.getElementById('amount2');
      amount2.value = totalPrice;
    });
  <?php endif; ?>
  //////////////////////////////////   Automatic fill GSTIN and address Through Ajax
  function GetCompany() {
    var companyName = $('#gst_number :selected').val();
    var hotel_manager_id = $('#hotel_manager_id').val();
    //alert(companyName);
    if(hotel_manager_id !='' && companyName !=''){
      $.ajax({
        type: 'post',
        url: "<?=base_url('owner/billbookdata/GetDetailsByCompanyName')?>",
        data: {
          companyName: companyName,hotel_manager_id:hotel_manager_id
        },
        success: function(response) {
          var obj = jQuery.parseJSON(response);
          $("#company_name").val(obj.company_name);
          $("#company_address").val(obj.company_address);
        }
      });
    }
    else{
      $("#company_name").val('');
      $("#company_address").val('');
    }
    
  }
  // $('.mySelect2').select2({
  //   selectOnClose: true
  // });
  $('#addGSTNModal').on('submit', function(e) {
    e.preventDefault();
    console.log("submitted");
    $.ajax({
      type: 'POST',
      url: $(this).attr("action"),
      data: $(this).serialize(),
      success: function(response) {
        var obj = response;
        if (obj.formError == 'No') {
          var newOption = new Option(obj.company.company_gst, obj.company.company_gst, true, true);
          $('#gst_number').append(newOption).trigger('change');
          $('#addGSTNModal').modal("hide");
        }
      }
    });
  });
  
</script>