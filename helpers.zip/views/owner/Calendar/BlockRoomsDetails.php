<table class="table table-bordered">
  <tbody>
    <tr>
      <td width="40%"><strong>Check-in Date:-</strong></td>
      <td> <?=$ResData['check_in_date']?></td>
    </tr>
    <tr>
      <td width="40%"><strong>Check-out Date:-</strong></td>
      <td> <?=$ResData['check_out_date']?></td>
    </tr>
    <tr>
      <td width="40%"><strong>Remarks:-</strong></td>
      <td> <?=$ResData['remarks']?></td>
    </tr>
    <tr>
      <td width="40%"><strong>Room No.:-</strong></td>
      <td>
        <?php
        $RoomNo = '';
        if($ResData['parent_id']==0){
          $RoomQuery = "SELECT room.room_no FROM ".getTablePrefix()."calendar_block_room as block join ".getTablePrefix()."room_number as room on room.room_id=block.assign_room_number WHERE block.parent_id=".$ResData['id']." ";
          $RoomData = $this->common_model->getDataByQuery('multiple', $RoomQuery);

          $RQuery = "SELECT room_no FROM ".getTablePrefix()."room_number WHERE room_id='".$ResData['assign_room_number']."' ";
          $RoomDetails = $this->common_model->getDataByQuery('single', $RQuery);
          $RoomNo.= $RoomDetails['room_no'].', ';
          foreach ($RoomData as $rdata) {
            $RoomNo.= $rdata['room_no'].',';
          }
        }else{
          $RoomQuery = "SELECT room.room_no FROM ".getTablePrefix()."calendar_block_room as block join ".getTablePrefix()."room_number as room on room.room_id=block.assign_room_number WHERE block.parent_id=".$ResData['parent_id']." ";
          $RoomData = $this->common_model->getDataByQuery('multiple', $RoomQuery);

          $SRoomQuery = "SELECT room.room_no FROM ".getTablePrefix()."calendar_block_room as block join ".getTablePrefix()."room_number as room on room.room_id=block.assign_room_number WHERE block.id=".$ResData['parent_id']." ";
          $SRoomData = $this->common_model->getDataByQuery('single', $SRoomQuery);
          $RoomNo.= $SRoomData['room_no'].', ';
          foreach ($RoomData as $rdata) {
            $RoomNo.= $rdata['room_no'].',';
          }
        }
        $RoomNo = rtrim($RoomNo,",");
        echo rtrim($RoomNo,", ");
        ?>
      </td>
    </tr>
    <tr>
      <td colspan="2">
        <center>
          <span id="DeleteReservationBtn">
            <input type="button" onclick="DeleteBlockRoomData(<?=$ResData['id']?>)" style="background-color:red;border-color: red;" class="btn btn-primary btn-lg form-btn" value="Delete">
          </span>
        </center>
      </td>
    </tr>
  </tbody>
</table>