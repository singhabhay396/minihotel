<style>
  #calendar { max-width: 1100px; margin: 0 auto;}
  .fc-highlight {background: green !important;}
  /* .fc-event {
    background-color: #9e3aad !important;
  } */
</style>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-calendar"></i>Calendar</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <div class="row">
            <div class="col-md-4 col-sm-6 col-xs-6">
              <form method="get" action="" id="FormSubmit">
                <select class="form-control" onchange="SelectVendor()" name="vendor_id" id="vendor_id">
                  <?php
                  foreach ($HotelList as $hotel) {
                    $selected = '';
                    if($hotel['vendor_id']==$vendor_id){
                      $selected = 'selected';
                    }
                    echo '<option value="'.$hotel['vendor_id'].'" '.$selected.'>'.$hotel['vendor_business_name'].'</option>';
                  }
                  ?>
                </select>
              </form>
            </div>
            <div class="col-md-8 col-sm-6 col-xs-6">
              <input type="button" onclick="ReservationModal()" class="btn btn-primary btn-lg form-btn" value="Reservation">
              <input type="button" onclick="BlockRoomsModal()" style="background-color:red;border-color: red;" class="btn btn-primary btn-lg form-btn" value="Block Rooms">
              <input type="button" onclick="LabelRoomsModal()" class="btn btn-primary btn-lg form-btn" value="Label Rooms">
            </div>
          </div>
        </div>
        <hr class="differ">
        <div id='calendar'></div>
        <hr class="differ">
        <div id='CalendarData'></div>
      </div>
    </div>
  </div>
</div>
<input type="text" id="SelectedDate" value="">
<!-- Add Reservation -->
<form action="<?=base_url('owner/calendar/AddReservation')?>" method="post" class="modal fade" id="ReservationModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align: center;">Add Reservation</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
        <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
        <input type="hidden" name="vendor_id" id="r_vendor_id" value="">
        <input type="hidden" id="edit-count-checked-checkboxes" name="TotalFilterDefault" value="" size="60" maxlength="50" class="required" />
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Name<span class="required">*</span></label>
              <input type="text" name="name" id="name" value="" class="form-control" placeholder="Name" required>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Check-in Date <span class="required">*</span></label>
              <input type="date" name="checkin_date" onchange="GetReservationRoom()" id="checkin_date" class="form-control" min="<?=date('Y-m-d')?>" placeholder="Check-in Date" required>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Check-out Date <span class="required">*</span></label>
              <input type="date" name="checkout_date" onchange="GetReservationRoom()" id="checkout_date" min="<?=date('Y-m-d')?>" class="form-control" placeholder="Check-out Date" required>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Choose mode of payment</label>
              <select name="amount_mode" id="amount_mode" class="form-control">
                <option value="">Select Mode</option>
                <option value="prepaid">Prepaid</option>
                <option value="online">Online (Bank transfer, UPI, Paytm, Gpay, PhonePe)</option>
                <option value="offline">Offline (Cash)</option>
            </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Advance Payment</label>
              <input type="text" name="prepaid_amount" id="prepaid_amount" class="form-control" placeholder="Advance Payment">
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Extra remarks</label>
              <textarea class="form-control" name="extr_remarks"></textarea>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group" id="ReservationRoomDiv"></div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group allSelectedData"></div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <span class="btn btn-primary btn-lg btn-block">Note:-
              <strong>
                <span style="color:#FF0000;">*</span> Indicates Required Fields
              </strong>
            </span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" style="padding: 6px 12px;">Close</button>
        <button type="submit" class="btn btn-primary" style="padding: 6px 12px;">Submit</button>
      </div>
    </div>
  </div>
</form>
<!-- Add Reservation -->

<!-- Block Rooms -->
<form action="<?=base_url('owner/calendar/BlockRoom')?>" method="post" class="modal fade" id="BlockRoomModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align: center;">Block Room</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" name="SaveChanges" value="Submit">
        <input type="hidden" name="vendor_id" id="b_vendor_id" value="">
        <div class="row">
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Check-in Date <span class="required">*</span></label>
              <input type="date" name="block_checkin_date" id="block_checkin_date" onchange="GetBlockRoom()" class="form-control" min="<?=date('Y-m-d')?>" required>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group">
              <label class="fancy-checkbox form-headings">Check-out Date <span class="required">*</span></label>
              <input type="date" name="block_checkout_date" onchange="GetBlockRoom()" id="block_checkout_date" min="<?=date('Y-m-d')?>" class="form-control" placeholder="Check-out Date" required>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Remarks <span class="required">*</span></label>
              <input type="text" name="remarks" class="form-control" required>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group" id="BlockRoomDiv"></div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <span class="btn btn-primary btn-lg btn-block">Note:-
              <strong>
                <span style="color:#FF0000;">*</span> Indicates Required Fields
              </strong>
            </span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" style="padding: 6px 12px;">Close</button>
        <button type="submit" class="btn btn-primary" style="padding: 6px 12px;">Submit</button>
      </div>
    </div>
  </div>
</form>
<!-- Block Rooms -->

<!-- Label Rooms -->
<form action="<?=base_url('owner/calendar/LabelRoom')?>" method="post" class="modal fade" id="LabelRoomModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align: center;">Label Room</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" name="SaveChanges" value="Submit">
        <input type="hidden" name="vendor_id" id="l_vendor_id" value="">
        <div class="row">
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Label <span class="required">*</span></label>
              <input type="text" maxlength="18" name="remarks" class="form-control" required>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Check-in Date <span class="required">*</span></label>
              <input type="date" name="label_checkin_date" id="label_checkin_date" onchange="GetLabelRoom()" class="form-control" min="<?=date('Y-m-d')?>" required>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group">
              <label class="fancy-checkbox form-headings">Check-out Date <span class="required">*</span></label>
              <input type="date" name="label_checkout_date" onchange="GetLabelRoom()" id="label_checkout_date" min="<?=date('Y-m-d')?>" class="form-control" placeholder="Check-out Date" required>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <div class="form-group " id="LabelRoomDiv"></div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <span class="btn btn-primary btn-lg btn-block">Note:-
              <strong>
                <span style="color:#FF0000;">*</span> Indicates Required Fields
              </strong>
            </span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" style="padding: 6px 12px;">Close</button>
        <button type="submit" class="btn btn-primary" style="padding: 6px 12px;">Submit</button>
      </div>
    </div>
  </div>
</form>
<!-- Label Rooms -->

<!-- Details -->
<form action="" method="post" class="modal fade" id="DetailsModal" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align: center;" id="ModalTitle"></h4>
      </div>
      <div class="modal-body" id="DetailsDiv"></div>
    </div>
  </div>
</form>
<!-- Details -->

<script>
  function ReservationDetails(s_date,room_id) {
    $('#ModalTitle').html('Reservation Details');
    $('#DetailsDiv').html('<center>Loading..</center>');
    $('#DetailsModal').modal("show");
    var vendor_id = $('#vendor_id').val();
    $.ajax({
      url : "<?=base_url('owner/calendar/ReservationDetails')?>",
      type: "GET",
      data : {vendor_id:vendor_id,s_date:s_date,room_id:room_id},
      success:function(a){
        $("#DetailsDiv").html(a);
      }
    });
  }
  function BlockRoomsDetails(s_date,room_id) {
    $('#ModalTitle').html('Block Rooms Details');
    $('#DetailsDiv').html('<center>Loading..</center>');
    $('#DetailsModal').modal("show");
    var vendor_id = $('#vendor_id').val();
    $.ajax({
      url : "<?=base_url('owner/calendar/BlockRoomsDetails')?>",
      type: "GET",
      data : {vendor_id:vendor_id,s_date:s_date,room_id:room_id},
      success:function(a){
        $("#DetailsDiv").html(a);
      }
    });
  }
  function LabelRoomsDetails(s_date,room_id) {
    $('#ModalTitle').html('Label Rooms Details');
    $('#DetailsDiv').html('<center>Loading..</center>');
    $('#DetailsModal').modal("show");
    var vendor_id = $('#vendor_id').val();
    $.ajax({
      url : "<?=base_url('owner/calendar/LabelRoomsDetails')?>",
      type: "GET",
      data : {vendor_id:vendor_id,s_date:s_date,room_id:room_id},
      success:function(a){
        $("#DetailsDiv").html(a);
      }
    });
  }

  function SelectVendor() {
    var vendor_id = $('#vendor_id').val();
    $("#FormSubmit").submit();
  }
  function ReservationModal() {
    var vendor_id = $('#vendor_id').val();
    $('#r_vendor_id').val(vendor_id);
    $('#ReservationModal').modal("show");
  }
  function GetReservationRoom(){
    var vendor_id = $('#vendor_id').val();
    var checkin_date = $('#checkin_date').val();
    var checkout_date = $('#checkout_date').val();
    if(checkin_date!='' && checkout_date!=''){
      $("#ReservationRoomDiv").html('<center>Loading..</center>');
      $.ajax({
        url : "<?=base_url('owner/calendar/GetReservationRoom')?>",
        type: "GET",
        data : {vendor_id:vendor_id,checkin_date:checkin_date,checkout_date:checkout_date},
        success:function(a){
          $(".allSelectedData").html("");
          $("#ReservationRoomDiv").html(a);
        }
      });
    }else{
      $("#ReservationRoomDiv").html('');
      $(".allSelectedData").html("");
    }
  }
  function BlockRoomsModal() {
    var vendor_id = $('#vendor_id').val();
    $('#b_vendor_id').val(vendor_id);
    $('#BlockRoomModal').modal("show");
  }
  function GetBlockRoom(){
    var vendor_id = $('#vendor_id').val();
    var checkin_date = $('#block_checkin_date').val();
    var checkout_date = $('#block_checkout_date').val();
    if(checkin_date!='' && checkout_date!=''){
      $("#BlockRoomDiv").html('<center>Loading..</center>');
      $.ajax({
        url : "<?=base_url('owner/calendar/GetBlockRoom')?>",
        type: "GET",
        data : {vendor_id:vendor_id,checkin_date:checkin_date,checkout_date:checkout_date},
        success:function(a){
          $("#BlockRoomDiv").html(a);
        }
      });
    }else{
      $("#BlockRoomDiv").html('');
    }
  }

  function LabelRoomsModal() {
    var vendor_id = $('#vendor_id').val();
    $('#l_vendor_id').val(vendor_id);
    $('#LabelRoomModal').modal("show");
  }
  function GetLabelRoom(){
    var vendor_id = $('#vendor_id').val();
    var checkin_date = $('#label_checkin_date').val();
    var checkout_date = $('#label_checkout_date').val();
    if(checkin_date!='' && checkout_date!=''){
      $("#LabelRoomDiv").html('<center>Loading..</center>');
      $.ajax({
        url : "<?=base_url('owner/calendar/GetLabelRoom')?>",
        type: "GET",
        data : {vendor_id:vendor_id,checkin_date:checkin_date,checkout_date:checkout_date},
        success:function(a){
          $("#LabelRoomDiv").html(a);
        }
      });
    }else{
      $("#LabelRoomDiv").html('');
    }
  }
  function GetCalendarData(SelectData){
    var vendor_id = $('#vendor_id').val();
    $("#CalendarData").html('<center>Loading..</center>');
    $.ajax({
      url : "<?=base_url('owner/calendar/GetCalendarData')?>",
      type: "GET",
      data : {vendor_id:vendor_id,SelectData:SelectData},
      success:function(a){
        $("#CalendarData").html(a);
      }
    });
  }

  function DeleteReservationData(cal_id){
    if(confirm("Are you sure you want to delete this?")){
      $("#DeleteReservationBtn").html('<input type="button" style="background-color:red;border-color: red;" class="btn btn-primary btn-lg form-btn" value="Loading..">');
      $.ajax({
        url : "<?=base_url('owner/calendar/DeleteReservationData')?>",
        type: "GET",
        data : {cal_id:cal_id},
        success:function(a){
          window.location.reload();
        }
      });
    }
  }
  function DeleteBlockRoomData(cal_id){
    if(confirm("Are you sure you want to delete this?")){
      $("#DeleteReservationBtn").html('<input type="button" style="background-color:red;border-color: red;" class="btn btn-primary btn-lg form-btn" value="Loading..">');
      $.ajax({
        url : "<?=base_url('owner/calendar/DeleteBlockRoomData')?>",
        type: "GET",
        data : {cal_id:cal_id},
        success:function(a){
          window.location.reload();
        }
      });
    }
  }
  function DeleteLabelRoomData(cal_id){
    if(confirm("Are you sure you want to delete this?")){
      $("#DeleteReservationBtn").html('<input type="button" style="background-color:red;border-color: red;" class="btn btn-primary btn-lg form-btn" value="Loading..">');
      $.ajax({
        url : "<?=base_url('owner/calendar/DeleteLabelRoomData')?>",
        type: "GET",
        data : {cal_id:cal_id},
        success:function(a){
          window.location.reload();
        }
      });
    }
  }

  document.addEventListener('DOMContentLoaded', function() {
    var calendarEl = document.getElementById('calendar');
    var calendar = new FullCalendar.Calendar(calendarEl, {
      headerToolbar: {
        left: 'prev,next today',
        center: 'title',
        right: 'dayGridMonth,timeGridWeek,timeGridDay,listMonth'
      },
      dateClick: function(info) {
        //alert('clicked ' + info.dateStr);
        $('#SelectedDate').val(info.dateStr);
        GetCalendarData(info.dateStr);
      },
      initialDate: '<?php echo date('Y-m-d') ?>',
      navLinks: true, // can click day/week names to navigate views
      businessHours: false, // display business hours
      editable: false,
      selectable: true,
      eventRender: function(info) {
        var tooltip = new Tooltip(info.el, {
          title: info.event.extendedProps,
          placement: 'top',
          trigger: 'hover',
          container: 'body'
        });
      },
      events: [{
                title: 'Today',
                start: '<?php echo date('Y-m-d'); ?>',
                end: '',
                backgroundColor: 'green'
              },
              <?php foreach ($ALLDATA as $events) {?> 
              {
                title: '<?php echo $events['customer_name']; ?>',
                start: '<?php echo $events['check_in_date']; ?>',
                end: '<?php echo date('Y-m-d',strtotime($events['check_out_date'])); ?>',
                description: 'Lecture',
                backgroundColor: '#743aad'
              },
              <?php } ?>
              <?php foreach ($BlockRoomArr as $broom) {?>
              {
                title: 'Room No. <?php echo $broom['room_no']; ?>',
                start: '<?php echo $broom['check_in_date']; ?>',
                end: '<?php echo date('Y-m-d',strtotime($broom['check_out_date'].'+ 1 days')); ?>',
                description: 'Lecture',
                backgroundColor: '#ff0000'
              },
              <?php } ?>
              <?php foreach ($LabelRoomArr as $broom) {?>
              {
                title: 'Label Room No. <?php echo $broom['room_no']; ?>',
                start: '<?php echo $broom['check_in_date']; ?>',
                end: '<?php echo date('Y-m-d',strtotime($broom['check_out_date'].'+ 1 days')); ?>',
                description: 'Lecture',
                backgroundColor: '#315bc2'
              },
              <?php } ?>
              ]
    });
    calendar.render();
  });
</script>

<script>
  function RCheckboxData(){
    $(".allSelectedData").html("");
    var countCheckedCheckboxes = $("input[name='RSelectedRoom']:checked").length;
    $('#edit-count-checked-checkboxes').val(countCheckedCheckboxes);
    $("input[name='RSelectedRoom']:checked").each(function(i) {
      i++;
      var checked = $(this).val();
      var myArray = checked.split("_");
      var roomId = myArray['0'];
      var roomName = myArray['1'];
      if (i == 2) {
        $(".allSelectedData").append('<hr style="border-top: 1px solid !important;border: dotted;"><div class="row"><div class="col-md-12 col-sm-12 col-xs-12 form-space"><input type="checkbox" id="same" name="same_' + i + '" onchange="sameAddress()"/><label for="same"></label>&nbsp<strong>If same select this box</strong></label> <input type="hidden" name="filter_details_id_' + i + '" id="filter_details_id_' + i + '" class="form-control" value="" /></div><div class="col-md-12 col-sm-12 col-xs-12 form-space"> <div class="col-md-3 col-sm-12 col-xs-12"><div class="form-group"> <label class="fancy-checkbox form-headings">Room No.<span class="required">*</span></label> <input type="hidden" class="form-control" id="select_room_' + i + '" name="select_room_' + i + '" value="' + roomId + '" placeholder="Select Room" readonly><input type="text" class="form-control" id="select_room_name_' + i + '" name="select_room_name_' + i + '" value="' + roomName + '" placeholder="Select Room" readonly></div></div> <div class="col-md-5 col-sm-12 col-xs-12"> <div class="form-group"> <label class="fancy-checkbox form-headings">Number Of Persons ' + i + '<span class="required">*</span></label> <input type="text" name="number_of_person_' + i + '" id="number_of_person_' + i + '" required class="form-control number required" placeholder="Number Of Persons"> </div> </div> <div class="col-md-4 col-sm-12 col-xs-12"> <div class="form-group"> <label class="fancy-checkbox form-headings">Room Rent ' + i + '<span class="required">*</span></label> <input type="text" required name="amount_' + i + '" id="amount_' + i + '" value="" class="form-control required numberonly" placeholder="Room Rent"> </div> </div> </div></div>');
      } else {
        $(".allSelectedData").append('<hr style="border-top: 1px solid !important;border: dotted;"><div class="row"> <input type="hidden" name="filter_details_id_' + i + '" id="filter_details_id_' + i + '" class="form-control" value="" /><div class="col-md-12 col-sm-12 col-xs-12 form-space"> <div class="col-md-3 col-sm-12 col-xs-12"><div class="form-group"> <label class="fancy-checkbox form-headings">Room<span class="required">*</span></label> <input type="hidden" class="form-control" id="select_room_' + i + '" name="select_room_' + i + '" value="' + roomId + '" placeholder="Select Room" readonly><input type="text" class="form-control" id="select_room_name_' + i + '" name="select_room_name_' + i + '" value="' + roomName + '" placeholder="Select Room" readonly></div></div> <div class="col-md-5 col-sm-12 col-xs-12"> <div class="form-group"> <label class="fancy-checkbox form-headings">Number Of Persons ' + i + '<span class="required">*</span></label> <input type="text" name="number_of_person_' + i + '" id="number_of_person_' + i + '" value="" class="form-control number required" placeholder="Number Of Persons" required> </div> </div> <div class="col-md-4 col-sm-12 col-xs-12"> <div class="form-group"> <label class="fancy-checkbox form-headings">Room Rent ' + i + '<span class="required">*</span></label> <input type="text" name="amount_' + i + '" id="amount_' + i + '" value="" class="form-control required numberonly" required placeholder="Room Rent"> </div> </div> </div></div>');
      }
    });  
  }
  function sameAddress() {
    if (document.getElementById("same").checked) {
      document.getElementById("number_of_person_2").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_2").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_3").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_3").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_4").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_4").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_5").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_5").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_6").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_6").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_7").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_7").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_8").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_8").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_9").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_9").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_10").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_10").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_11").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_11").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_12").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_12").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_13").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_14").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_14").value = document.getElementById("number_of_person_1").value;
      document.getElementById("amount_15").value = document.getElementById("amount_1").value;
      document.getElementById("number_of_person_15").value = document.getElementById("number_of_person_1").value;
      docum
    } else {
      document.getElementById("number_of_person_1").value = ""
      document.getElementById("amount_1").value = ""
      document.getElementById("number_of_person_2").value = ""
      document.getElementById("amount_2").value = ""
      document.getElementById("number_of_person_3").value = ""
      document.getElementById("amount_3").value = ""
      document.getElementById("number_of_person_4").value = ""
      document.getElementById("amount_4").value = ""
      document.getElementById("number_of_person_5").value = ""
      document.getElementById("amount_6").value = ""
      document.getElementById("number_of_person_7").value = ""
      document.getElementById("amount_7").value = ""
      document.getElementById("number_of_person_8").value = ""
      document.getElementById("amount_8").value = ""
      document.getElementById("number_of_person_9").value = ""
      document.getElementById("amount_9").value = ""
      document.getElementById("number_of_person_10").value = ""
      document.getElementById("amount_11").value = ""
      document.getElementById("number_of_person_12").value = ""
      document.getElementById("amount_13").value = ""
      document.getElementById("number_of_person_14").value = ""
      document.getElementById("amount_14").value = ""
    }
  }
  // end
</script>