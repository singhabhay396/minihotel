<div class="panel panel-headline">
  <div class="panel-heading row">
    <h3 class="tab panel-title"> Room List</h3>
  </div>
  <div class="dash">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th width="2%">#</th>
          <th width="6%">Room No</th>
          <th width="10%">Reservation</th>
          <th width="5%">Block Room</th>
          <th width="5%">Label Room</th>
        </tr>
      </thead>
      <tbody>
        <?php
        foreach ($hotelRoom as $key => $room) {

          $CatQuery = "SELECT `category_name` FROM ".getTablePrefix()."room_category WHERE id=".$room['category_id']."  ";
          $Cat = $this->common_model->getDataByQuery('single', $CatQuery);
          $CategoryName = '';
          if($Cat){ $CategoryName = '('.$Cat['category_name'].')';}
          
          $ResQuery = "SELECT `id` FROM ".getTablePrefix()."calendar_date WHERE type='Reservation' AND cal_date='".$SelectData."' AND room_id='".$room['room_id']."'  ";
          $ResCount = $this->common_model->getDataByQuery('count', $ResQuery);

          $BlockQuery = "SELECT `id` FROM ".getTablePrefix()."calendar_date WHERE type='BlockRoom' AND cal_date='".$SelectData."' AND room_id='".$room['room_id']."'  ";
          $BlockCount = $this->common_model->getDataByQuery('count', $BlockQuery);

          $LabelQuery = "SELECT `id` FROM ".getTablePrefix()."calendar_date WHERE type='LabelRoom' AND cal_date='".$SelectData."' AND room_id='".$room['room_id']."'  ";
          $LabelCount = $this->common_model->getDataByQuery('count', $LabelQuery);
        ?>
        <div style="display:none;">
            <?php echo $ResQuery; ?>
        </div>
          <tr>
            <td><?=$key+1?></td>
            <td><?=$room['room_no']?> <?=$CategoryName?></td>
            <td>
              <?php if($ResCount>0){ ?>
                <input type="button" onclick="ReservationDetails('<?=$SelectData?>','<?=$room['room_id']?>')" style="background-color:#743aad;border-color: #743aad;" class="btn btn-primary" value="Yes">
              <?php }else{ ?>
                No
              <?php } ?>
            </td>
            <td>
              <?php if($BlockCount>0){ ?>
                <input type="button" onclick="BlockRoomsDetails('<?=$SelectData?>','<?=$room['room_id']?>')" style="background-color:#ff0000;border-color: #ff0000;" class="btn btn-primary" value="Yes">
              <?php }else{ ?>
                No
              <?php } ?>
            </td>
            <td>
              <?php if($LabelCount>0){ ?>
                <input type="button" onclick="LabelRoomsDetails('<?=$SelectData?>','<?=$room['room_id']?>')" style="background-color:#315bc2;border-color: #315bc2;" class="btn btn-primary" value="Yes">
              <?php }else{ ?>
                No
              <?php } ?>
            </td>
          </tr>
        <?php
        }
        ?>
      </tbody>
    </table>      
  </div>
</div>
