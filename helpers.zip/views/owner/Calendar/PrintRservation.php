<body style="width: 900px; margin: auto;" onload="window.print()">
  <div class="main-box" style="text-align: center;">
    <div class="header" style="text-align: center;display: inline-block;margin: auto;padding: 10px 20px;background: #00cfe9;">
      <h2 style="font-size: 60px;margin-bottom: 0px;"><?=$ResData['vendor_business_name']?></h2>
      <h4 style="font-size: 25px;margin-bottom: 5px;margin-top: 5px;"><?=$VendorDetails['vendor_address']?></h4>
      <h4 style="margin-top: 5px;font-size: 25px;"><?=$ResData['first_manager_contact_number']?></h4>
    </div>
  </div>
  <div class="main-box" style="text-align: center; margin-top: 50px; margin-bottom: 50px ">
    <div class="header" style="text-align: center;display: inline-block;margin: auto;padding: 10px 20px;background: #00cfe9;">
      <h4 style="font-size: 25px;margin-bottom: 5px;margin-top: 5px;">YOUR BOOKING IS CONFIRMED!</h4>
      <h4 style="margin-top: 5px;margin-bottom: 0px;font-size: 25px;">THE DETAILS ARE AS FOLLOWS:-</h4>
    </div>
  </div>
  <div style="margin: 50px 0px;">
    <h4 style="font-size: 30px;">Name: <?=$ResData['customer_name']?></h4>
    <h4 style="font-size: 30px;">Booking date: <?=date('d-m-Y',strtotime($ResData['add_date']))?></h4>
    <h4 style="font-size: 30px;">Check in: <?=date('d-m-Y',strtotime($ResData['check_in_date']))?></h4>
    <h4 style="font-size: 30px;">Check out: <?=date('d-m-Y',strtotime($ResData['check_out_date']))?></h4>
    <h4 style="font-size: 30px;">
      Rooms:
      <table class="table table-bordered" style="margin: auto;">
        <tr>
          <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;"><strong>Category</strong></td>
          <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;"><strong>Number of Persons</strong></td>
          <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;"><strong>Room Rent</strong></td>
        </tr>
      <?php
      if($ResData['parent_id']==0){
        $RoomQuery = "SELECT room.category_id,room.room_no,reservation.amount,reservation.number_of_person FROM ".getTablePrefix()."calendar_reservations as reservation join ".getTablePrefix()."room_number as room on room.room_id=reservation.assign_room_number WHERE reservation.parent_id=".$ResData['id']." ";
        $RoomData = $this->common_model->getDataByQuery('multiple', $RoomQuery);

        $RQuery = "SELECT category_id,room_no FROM ".getTablePrefix()."room_number WHERE room_id='".$ResData['assign_room_number']."' ";
        $RoomDetails = $this->common_model->getDataByQuery('single', $RQuery);
        
        $CatName = $this->common_model->GetRoomCategory($RoomDetails['category_id']);
        $RoomNo = $CatName;
        if($CatName==''){
          $RoomNo = $RoomDetails['room_no'];
        }
        ?>
        <tr>
          <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;"><?=$RoomNo?></td>
          <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;"><?=$ResData['number_of_person']?></td>
          <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;"><?=$ResData['amount']?></td>
        </tr>
        <?php
        foreach ($RoomData as $rdata) {
          $CatName = $this->common_model->GetRoomCategory($rdata['category_id']);
          $RoomNo = $CatName;
          if($CatName==''){
            $RoomNo = $rdata['room_no'];
          }
          echo '<tr>
                  <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;">'.$RoomNo.'</td>
                  <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;">'.$rdata['number_of_person'].'</td>
                  <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;">'.$rdata['amount'].'</td>
                </tr>';
        }
      }else{
        $RoomQuery = "SELECT room.category_id,room.room_no,reservation.amount,reservation.number_of_person FROM ".getTablePrefix()."calendar_reservations as reservation join ".getTablePrefix()."room_number as room on room.room_id=reservation.assign_room_number WHERE reservation.parent_id=".$ResData['parent_id']." ";
        $RoomData = $this->common_model->getDataByQuery('multiple', $RoomQuery);

        $SRoomQuery = "SELECT room.category_id,room.room_no,reservation.amount,reservation.number_of_person FROM ".getTablePrefix()."calendar_reservations as reservation join ".getTablePrefix()."room_number as room on room.room_id=reservation.assign_room_number WHERE reservation.id=".$ResData['parent_id']." ";
        $SRoomData = $this->common_model->getDataByQuery('single', $SRoomQuery);

        $CatName = $this->common_model->GetRoomCategory($SRoomData['category_id']);
        $RoomNo = $CatName;
        if($CatName==''){
          $RoomNo = $SRoomData['room_no'];
        }
        ?>
        <tr>
          <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;"><?=$RoomNo?></td>
          <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;"><?=$SRoomData['number_of_person']?></td>
          <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;"><?=$SRoomData['amount']?></td>
        </tr>
        <?php
        foreach ($RoomData as $rdata) {
          $CatName = $this->common_model->GetRoomCategory($rdata['category_id']);
          $RoomNo = $CatName;
          if($CatName==''){
            $RoomNo = $rdata['room_no'];
          }
          echo '<tr>
                  <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;">'.$RoomNo.'</td>
                  <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;">'.$rdata['number_of_person'].'</td>
                  <td style="font-size: 25px;border: 1px solid;padding: 10px 5px;">'.$rdata['amount'].'</td>
                </tr>';
        }
        ?>
      <?php
      }
      ?>
      </table>
    </h4>
    <h4 style="font-size: 30px;">Advance details -</h4>
    <h4 style="font-size: 30px;">
      Payment Mode: 
      <?php
      if($ResData['amount_mode']=='online'){
        echo 'Online (Bank transfer, UPI, Paytm, Gpay, PhonePe)';
      }elseif ($ResData['amount_mode']=='prepaid') {
        echo 'Prepaid';
      }elseif ($ResData['amount_mode']=='offline') {
        echo 'Offline (Cash)';
      }
      ?>
    </h4>
    <h4 style="font-size: 30px;">Payment Amount: <?=$ResData['prepaid_amount']?></h4>
  </div>
  <hr style="height: 3px; background:  #000;">
  <h4 style="font-size: 20px;  text-align: center;">Amount is non-refundable in the event of cancellation of booking.</h4>
  <h4 style="font-size: 30px;  text-align: center;">Thank you for choosing us. We are looking <br>forward to giving you the best experience!</h4>
</body>