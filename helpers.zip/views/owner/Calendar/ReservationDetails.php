<table class="table table-bordered">
  <tbody>
    <tr>
      <td width="40%"><strong>Name:-</strong> </td>
      <td> <?=$ResData['customer_name']?></td>
    </tr>
    <tr>
      <td width="40%"><strong>Check-in Date:-</strong></td>
      <td> <?=$ResData['check_in_date']?></td>
    </tr>
    <tr>
      <td width="40%"><strong>Check-out Date:-</strong></td>
      <td> <?=$ResData['check_out_date']?></td>
    </tr>
    <tr>
      <td width="40%"><strong>Choose mode of payment:-</strong></td>
      <td>
      <?php
      if ($ResData['amount_mode']=='prepaid') {
        echo 'Prepaid';
      }elseif ($ResData['amount_mode']=='online') {
        echo 'Online (Bank transfer, UPI, Paytm, Gpay, PhonePe)';
      }elseif ($ResData['amount_mode']=='offline') {
        echo 'Offline (Cash)';
      }
      ?> 
      </td>
    </tr>
    <tr>
      <td width="40%"><strong>Advance Payment:-</strong></td>
      <td> <?=$ResData['prepaid_amount']?></td>
    </tr>
    <tr>
      <td width="40%"><strong>Extra remarks:-</strong></td>
      <td> <?=$ResData['remarks']?></td>
    </tr>
    <tr>
      <td width="40%"><strong>Room No.:-</strong></td>
      <td>
        <?php
        if($ResData['parent_id']==0){
          $RoomQuery = "SELECT room.room_no,reservation.amount,reservation.number_of_person FROM ".getTablePrefix()."calendar_reservations as reservation join ".getTablePrefix()."room_number as room on room.room_id=reservation.assign_room_number WHERE reservation.parent_id=".$ResData['id']." ";
          $RoomData = $this->common_model->getDataByQuery('multiple', $RoomQuery);

          $RQuery = "SELECT room_no FROM ".getTablePrefix()."room_number WHERE room_id='".$ResData['assign_room_number']."' ";
          $RoomDetails = $this->common_model->getDataByQuery('single', $RQuery);
          ?>
          <table class="table table-bordered">
            <tr>
              <td><strong>Room No</strong></td>
              <td><strong>Number of Persons</strong></td>
              <td><strong>Room Rent</strong></td>
            </tr>
            <tr>
              <td><?=$RoomDetails['room_no']?></td>
              <td><?=$ResData['number_of_person']?></td>
              <td><?=$ResData['amount']?></td>
            </tr>
            <?php
            foreach ($RoomData as $rdata) {
              echo '<tr>
                      <td>'.$rdata['room_no'].'</td>
                      <td>'.$rdata['number_of_person'].'</td>
                      <td>'.$rdata['amount'].'</td>
                    </tr>';
            }
            ?>
          </table>
          <?php
        }else{
          $RoomQuery = "SELECT room.room_no,reservation.amount,reservation.number_of_person FROM ".getTablePrefix()."calendar_reservations as reservation join ".getTablePrefix()."room_number as room on room.room_id=reservation.assign_room_number WHERE reservation.parent_id=".$ResData['parent_id']." ";
          $RoomData = $this->common_model->getDataByQuery('multiple', $RoomQuery);

          $SRoomQuery = "SELECT room.room_no,reservation.amount,reservation.number_of_person FROM ".getTablePrefix()."calendar_reservations as reservation join ".getTablePrefix()."room_number as room on room.room_id=reservation.assign_room_number WHERE reservation.id=".$ResData['parent_id']." ";
          $SRoomData = $this->common_model->getDataByQuery('single', $SRoomQuery);
          ?>
          <table class="table table-bordered">
            <tr>
              <td><strong>Room No</strong></td>
              <td><strong>Number of Persons</strong></td>
              <td><strong>Room Rent</strong></td>
            </tr>
            <tr>
              <td><?=$SRoomData['room_no']?></td>
              <td><?=$SRoomData['number_of_person']?></td>
              <td><?=$SRoomData['amount']?></td>
            </tr>
            <?php
            foreach ($RoomData as $rdata) {
              echo '<tr>
                      <td>'.$rdata['room_no'].'</td>
                      <td>'.$rdata['number_of_person'].'</td>
                      <td>'.$rdata['amount'].'</td>
                    </tr>';
            }
            ?>
          </table>
          <?php
        }
        //print_r($RoomData);
        ?>
      </td>
    </tr>
    <tr>
      <td colspan="2">
        <center>
          <a href="<?=base_url('owner/calendar/PrintRservation/'.base64_encode($ResData['id']))?>" target="_blank">
            <input type="button" class="btn btn-primary btn-lg form-btn" value="Print">
          </a>
          <span id="DeleteReservationBtn">
            <input type="button" onclick="DeleteReservationData(<?=$ResData['id']?>)" style="background-color:red;border-color: red;" class="btn btn-primary btn-lg form-btn" value="Delete">
          </span>
        </center>
      </td>
    </tr>
  </tbody>
</table>