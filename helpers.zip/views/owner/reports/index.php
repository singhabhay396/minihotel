<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<script>
    $(function() {
        $("#toDate").datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            maxDate: 0,
            yearRange: "1960:<?php echo date('Y'); ?>"
        });
    });
</script>
<div class="main">
    <div class="bready">
        <ol class="breadcrumb">
            <li><a href="<?=base_url('owner/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
            <li><a href="javascript:void(0);" class="active"><i class="fa fa-book" aria-hidden="true"></i>Today Report</a></li>
        </ol>
    </div>
    <div class="main-content">
        <div class="container-fluid">
            <div class="panel panel-headline">
                <div class="panel-heading row">
                    <h3 class="tab panel-title">Today Report</h3>
                </div>
                <hr class="differ">
               
                <div class="row">
                    <form action="<?=base_url('owner/reports/downloadreport')?>" method="get" name="searchData" id="searchData" autocomplete="off">
                        <div class="col-md-4 col-sm-4 col-xs-4">
                              <select class="form-control" id="VendorID" name="VendorID" >
                                <?php
                                foreach ($HotelList as $hotel) {
                                  echo '<option value="'.$hotel['vendor_id'].'">'.$hotel['vendor_business_name'].'</option>';
                                }
                                ?>
                              </select>
                            </div>
                        <div class="col-md-4 col-sm-4 col-xs-4">
                            <input type="date" name="download_date" max="<?=date('Y-m-d')?>" value="<?=date('Y-m-d')?>">
                        </div>

                        <div class="col-md-3 col-sm-3 col-xs-3">
                            <!-- <input type="submit" value="submit" class="btn-primary"> -->
                            <button type="submit" class="btn btn-primary btn-lg form-btn">Download Report</button>
                        </div><br><br><br><br><br><br>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
