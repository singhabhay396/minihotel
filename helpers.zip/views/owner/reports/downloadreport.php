<body onload="loadImage()">
  <table cellpadding="0" style="border:0px solid #b32521; background: #f6d0ae21; margin-bottom: 10px;" cellspacing="0" align="center" width="100%">
    <tbody>
      <tr style="background:#fff  ;">
        <td style="text-align: center;padding-top: 5px;">
          <h4 style="margin-top: 0px;font-size:25px;  font-weight: 800; margin:0px;"><?php echo $VendoerName['vendor_business_name']?> </h4>
          <p style="margin: 0px;"><?=$Date?></p>
        </td>
      </tr>
    </tbody>
  </table>
  <table cellpadding="0" cellspacing="0" align="center" width="100%">
    <tbody>
      <tr style="background:#000;">
        <td style="text-align: center; border:1px solid #000;">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;">S.No.</p>
        </td>
        <td style="text-align: center; border:1px solid #000;">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Entry No.</p>
        </td>
        <td style="text-align: center; border:1px solid #000;">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Room No</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Guest Name</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Online/Direct</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">No. Of Person</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Rent</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Check In</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Check Out</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Phone Number</p>
        </td>
      </tr>
      <tr style="background:#000;">
        <td style="text-align: center; border:1px solid #000;" colspan="9">
          <p style="background: #fff;color: #000;padding: 2px;font-size: 22px; font-weight:600; font-family: poppins;margin-bottom: 0px;margin-top: 0px;">Check Ins</p>
        </td>
      </tr>
      <?php
      
      foreach ($GetCheckInArr as $key => $CheckIn) {
        $RoomQuery = "SELECT `room_no` FROM ".getTablePrefix()."room_number WHERE hotel_manager_id=".$LoginVenderId." AND `room_id` = '".$CheckIn['assign_room_number']."' ";
        $Room = $this->common_model->getDataByQuery('single', $RoomQuery);
      ?>
        <tr style="background:#000;">
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;"><?=$key+1?>.</p>
          </td>
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckIn['entry_number']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Room['room_no']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckIn['customer_name']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">
              <?php
              if($CheckIn['reffer_mode']=='online'){
                $OTSQuery = "SELECT `ots_name` FROM ".getTablePrefix()."ots_master WHERE `ots_id` = '".$CheckIn['ots_id']."' ";
                $OTSData = $this->common_model->getDataByQuery('single', $OTSQuery);
                echo 'Online';
                if($OTSData){
                  echo '('.$OTSData['ots_name'].')';
                }
              }elseif($CheckIn['reffer_mode']=='offline') {
                echo 'Direct';
              }else{
                echo 'N/A';
              }
              ?>
            </p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckIn['number_of_person']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckIn['amount']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=date('d-m-Y h:i A',strtotime($CheckIn['check_in_datetime']))?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"> N/A</p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckIn['customer_mobile_number']?></p>
          </td>
        </tr>
      <?php
      }
      //if($Date==date('Y-m-d')){
      ?>
        <tr style="background:#000;">
          <td style="text-align: center; border:1px solid #000;" colspan="10">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 22px; font-weight:600; font-family: poppins;margin-bottom: 0px;margin-top: 0px;">Rooms Continued</p>
          </td>
        </tr>
        <?php
        $c = 1;
        $dateFormate = "Room Rent (".date("d/m/Y",strtotime($Date)).')';

        $customeQuery = "SELECT `id`,`customer_id` from ".getTablePrefix()."customer_summary_details as `csd` WHERE `csd`.`hotel_manager_id` = '".$LoginVenderId."' AND `csd`.page_source ='extend_stay' AND `csd`.bill_item = '".$dateFormate."'";
        $curtomerResult = $this->common_model->getDataByQuery('multiple', $customeQuery); 
        $customeId = [];
        $dateFormate = date("Y-m-d",strtotime($Date));
        if(!empty($curtomerResult)){
          foreach ($curtomerResult as $key => $value) {
              $customeId[] = $value['customer_id'];
            $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`hotel_manager_id` = '".$LoginVenderId."' AND `csb`.`summary_book_id` = '".$value['customer_id']."' AND `csb`.`check_out_datetime` >= '".$dateFormate."' AND `csb`.check_in_datetime < '".$Date."' ORDER BY `csb`.`check_in_datetime` DESC";
            $Result = $this->common_model->getDataByQuery('single', $BookQuery); 
            $check_out_datetime = date('Y-m-d',strtotime($Result['check_out_datetime']));
            if(!empty($Result) && $check_out_datetime == $dateFormate){
        ?>
            <tr style="background:#000;">
              <td style="text-align: center; border:1px solid #000;">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;"><?=$c?>.</p>
              </td>
              <td style="text-align: center; border:1px solid #000;">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['entry_number']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000;">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['room_no']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['customer_name']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">
                  <?php
                  if($Result['reffer_mode']=='online'){
                    $OTSQuery = "SELECT `ots_name` FROM ".getTablePrefix()."ots_master WHERE `ots_id` = '".$Result['ots_id']."' ";
                    $OTSData = $this->common_model->getDataByQuery('single', $OTSQuery);
                    echo 'Online';
                    if($OTSData){
                      echo '('.$OTSData['ots_name'].')';
                    }
                  }elseif($Result['reffer_mode']=='offline') {
                    echo 'Direct';
                  }else{
                    echo 'N/A';
                  }
                  ?>
                </p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['number_of_person']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['amount']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=date('d-m-Y h:i A',strtotime($Result['check_in_datetime']))?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"> 
                  <?php
                  if($Result['check_out_datetime']){
                    echo date('d-m-Y h:i A',strtotime($Result['check_out_datetime']));
                  }else{
                    echo 'N/A';
                  }
                  ?> 
                </p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['customer_mobile_number']?></p>
              </td>
            </tr>
          <?php
            $c++;
          }
            ?>   
        <?php }

        } ?>
    <?php foreach ($AvailableRoomsArr as $key=>$Arooms) {
          $BookQuery = "SELECT `csb`.*, `rn`.`room_no` FROM ".getTablePrefix()."customer_summary_book as `csb` LEFT JOIN ".getTablePrefix()."room_number as `rn` ON `rn`.`room_id`=`csb`.`assign_room_number` WHERE `csb`.`assign_room_number` = '".$Arooms['room_id']."' AND `csb`.`hotel_manager_id` = '".$LoginVenderId."' AND `csb`.check_in_datetime < '".$Date."' AND `csb`.`check_out_datetime` IS NULL AND `csb`.summary_book_id NOT IN('".$customeId."') ORDER BY `csb`.`check_in_datetime` DESC";
          $Result = $this->common_model->getDataByQuery('single', $BookQuery);        
          if(!empty($Result)){
            //echo "<pre>"; print_r($Result); exit;
        ?>
            <tr style="background:#000;">
              <td style="text-align: center; border:1px solid #000;">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;"><?=$c?>.</p>
              </td>
              <td style="text-align: center; border:1px solid #000;">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['entry_number']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000;">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['room_no']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['customer_name']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">
                  <?php
                  if($Result['reffer_mode']=='online'){
                    $OTSQuery = "SELECT `ots_name` FROM ".getTablePrefix()."ots_master WHERE `ots_id` = '".$Result['ots_id']."' ";
                    $OTSData = $this->common_model->getDataByQuery('single', $OTSQuery);
                    echo 'Online';
                    if($OTSData){
                      echo '('.$OTSData['ots_name'].')';
                    }
                  }elseif($Result['reffer_mode']=='offline') {
                    echo 'Direct';
                  }else{
                    echo 'N/A';
                  }
                  ?>
                </p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['number_of_person']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['amount']?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=date('d-m-Y h:i A',strtotime($Result['check_in_datetime']))?></p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"> 
                  <?php
                  if($Result['check_out_datetime']){
                    echo date('d-m-Y h:i A',strtotime($Result['check_out_datetime']));
                  }else{
                    echo 'N/A';
                  }
                  ?> 
                </p>
              </td>
              <td style="text-align: center; border:1px solid #000; ">
                <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Result['customer_mobile_number']?></p>
              </td>
            </tr>
        <?php
          $c++;
         }
        }
      //}  
      ?>
      <tr style="background:#000;">
        <td style="text-align: center; border:1px solid #000;" colspan="10">
          <p style="background: #fff;color: #000;padding: 2px;font-size: 22px; font-weight:600; font-family: poppins;margin-bottom: 0px;margin-top: 0px;">Check Outs</p>
        </td>
      </tr>
      <?php
      //echo '<pre>';print_r($GetCheckOutArr);exit();
      foreach ($GetCheckOutArr as $key => $CheckOut) {
        $RoomQuery = "SELECT `room_no` FROM ".getTablePrefix()."room_number WHERE hotel_manager_id=".$LoginVenderId." AND `room_id` = '".$CheckOut['assign_room_number']."' ";
        $Room = $this->common_model->getDataByQuery('single', $RoomQuery);
      ?>
        <tr style="background:#000;">
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;"><?=$key+1?>.</p>
          </td>
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckOut['entry_number']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$Room['room_no']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckOut['customer_name']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">
              <?php
              if($CheckOut['reffer_mode']=='online'){
                $OTSQuery = "SELECT `ots_name` FROM ".getTablePrefix()."ots_master WHERE `ots_id` = '".$CheckOut['ots_id']."' ";
                $OTSData = $this->common_model->getDataByQuery('single', $OTSQuery);
                echo 'Online';
                if($OTSData){
                  echo '('.$OTSData['ots_name'].')';
                }
              }else{
                echo 'N/A';
              }
              ?>
            </p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckOut['number_of_person']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckOut['amount']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=date('d-m-Y h:i A',strtotime($CheckOut['check_in_datetime']))?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"> 
              <?php
              if($CheckOut['check_out_datetime']){
                echo date('d-m-Y h:i A',strtotime($CheckOut['check_out_datetime']));
              }else{
                echo 'N/A';
              }
              ?> 
            </p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$CheckOut['customer_mobile_number']?></p>
          </td>
        </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
  <br/><br/>
  <table cellpadding="0" style="border:0px solid #b32521; background: #f6d0ae21; margin-bottom: 10px;" cellspacing="0" align="center" width="100%">
    <tbody>
      <tr style="background:#fff  ;">
        <td style="text-align: center;padding-top: 5px;">
          <h4 style="margin-top: 0px;font-size:25px;  font-weight: 800; margin:0px;">DayBook In</h4>
        </td>
      </tr>
    </tbody>
  </table>
  <table cellpadding="0" cellspacing="0" align="center" width="100%">
    <tbody>
      <tr style="background:#000;">
        <td style="text-align: center; border:1px solid #fff;">
          <p style="backgr;ound: #000;color: #fff;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;">
            <strong>Prepaid</strong> : <?=$dayWisePrepaidSales['totalAmount'] ?? '0'; ?>
          </p>
        </td>
        <td style="text-align: center; border:1px solid #fff;">
          <p style="backgr;ound: #000;color: #fff;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;">
            <strong>Online (Bank Transfer/UPI/Card)</strong> : <?= $dayWiseOnlineSales['totalAmount'] ?? '0'; ?>
          </p>
        </td>
        <td style="text-align: center; border:1px solid #fff;">
          <p style="backgr;ound: #000;color: #fff;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;">
            <strong>Cash</strong> : <?= $dayWiseOfflineSales['totalAmount'] ?? '0'; ?>
          </p>
        </td>
      </tr>
    </tbody>
  </table>
  <br/>
  <table cellpadding="0" cellspacing="0" align="center" width="100%">
    <tbody>
      <tr style="background:#000;">
        <td style="text-align: center; border:1px solid #000;">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;">S.No.</p>
        </td>
        <td style="text-align: center; border:1px solid #000;">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Customer Name</p>
        </td>
        <td style="text-align: center; border:1px solid #000;">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Room Number</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Entry Number</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Bill Items</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Payment Mode</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Amount</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Order Date and Time</p>
        </td>
      </tr>
      <?php
      //echo '<pre>';print_r($DayBookIn);echo '</pre>';exit();
      foreach($DayBookIn as $key => $BookIn) {
      ?>
        <tr style="background:#000;">
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;"><?=$key+1?>.</p>
          </td>
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$BookIn['customer_name']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$BookIn['room_no']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$BookIn['entry_number']?></p>
          </td> 
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$BookIn['bill_item']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">
              <?php
              if($ALLDATAINFO['amount_mode'] == "offline"){
                echo 'Cash';
              }else{
                echo $BookIn['amount_mode'];
              }
              ?>
            </p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"> <?=$BookIn['payment_paid']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"> 
              <?=date('d-m-Y h:i A', strtotime($BookIn['order_date']))?>
            </p>
          </td>
        </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
  <br/><br/>
  <table cellpadding="0" style="border:0px solid #b32521; background: #f6d0ae21; margin-bottom: 10px;" cellspacing="0" align="center" width="100%">
    <tbody>
      <tr style="background:#fff  ;">
        <td style="text-align: center;padding-top: 5px;">
          <h4 style="margin-top: 0px;font-size:25px;  font-weight: 800; margin:0px;">DayBook Out</h4>
        </td>
      </tr>
    </tbody>
  </table>
  <table cellpadding="0" cellspacing="0" align="center" width="100%">
    <tbody>
      <tr style="background:#000;">
        <td style="text-align: center; border:1px solid #000;">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;">S.No.</p>
        </td>
        <td style="text-align: center; border:1px solid #000;">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Name of Expense</p>
        </td>
        <td style="text-align: center; border:1px solid #000;">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Amount</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Extra Remarks</p>
        </td>
        <td style="text-align: center; border:1px solid #000; ">
          <p style="background: #000;color: #fff;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;">Date & Time</p>
        </td>
      </tr>
      <?php
      //echo '<pre>';print_r($DayBookOut);exit();
      foreach ($DayBookOut as $key => $BookOut) {
      ?>
        <tr style="background:#000;">
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 14px; font-weight:400; font-family: poppins;margin-bottom: 0px;margin-top: 0px;"><?=$key+1?>.</p>
          </td>
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$BookOut['service_name']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000;">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$BookOut['amount_out']?></p>
          </td>
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"><?=$BookOut['remark']?></p>
          </td> 
          <td style="text-align: center; border:1px solid #000; ">
            <p style="background: #fff;color: #000;padding: 2px;font-size: 15px; font-weight:400; font-family: poppins; margin-bottom: 10px; margin-bottom: 0px;margin-top: 0px;"> <?=date('d-m-Y h:i A',strtotime($BookOut['order_date']))?></p>
          </td>
        </tr>
      <?php
      }
      ?>
    </tbody>
  </table>
<script>
function loadImage() {
  window.print();
}
</script>
</body>