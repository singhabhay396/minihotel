
<div class="dash">
    <table class="table table-bordered">
        <?php if($calltype == 'checkin'){ ?>
             <?php foreach ($otsDetails as $key => $value) { 
                $sumTotal = 0;
                foreach ($value as $keys => $sum) {
                    $sumTotal = $sumTotal + $sum[0]['totalDays'];
                }
                if($sumTotal > 0){
             ?>
            <thead>
                <tr >
                    <th colspan="3"><?php echo $key; ?> - <?php echo $sumTotal; ?></th>
                </tr>
            </thead>
            <thead>
              <tr>
                <th>Customer Name</th>
                <th>Room Rent Per Night</th>
                <th>Hotel Name</th>
              </tr>
            </thead>
            <body>
                <?php 
                    
                if(isset($CheckInDetails[$key]) && !empty($CheckInDetails[$key])){
                    foreach ($CheckInDetails[$key] as $keys => $values) { 
                        foreach ($values as $key => $value) {

                        $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$value['hotel_manager_id']."'";
                        $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery);     
                        ?>
                        <tr>
                        <td><?php echo $value['customer_name']; ?></td>
                        <td><?php echo $value['amount']; ?></td>
                        <td><?php echo $vendorResult['vendor_business_name']; ?></td>
                         </tr>
                    <?php
                    }  }
                } ?>
            </body>
        <?php } ?>
        <?php } 
        if(!empty($CheckInDetailsOffLine) && $OffLineCount > 0){ ?>
            <thead>
                <tr >
                    <th colspan="3">Direct - <?php echo $OffLineCount; ?></th>
                </tr>
            </thead>
            <thead>
              <tr>
                <th>Customer Name</th>
                <th>Room Rent Per Night</th>
                <th>Hotel Name</th>
              </tr>
            </thead>
            <body>
                <?php 
                    foreach ($CheckInDetailsOffLine as $keys => $value) { 
                        $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$value['hotel_manager_id']."'";
                        $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery);     
                        ?>
                        <tr>
                        <td><?php echo $value['customer_name']; ?></td>
                        <td><?php echo $value['amount']; ?></td>
                        <td><?php echo $vendorResult['vendor_business_name']; ?></td>
                         </tr>
                    <?php    
                } ?>
            </body>
            <?php
            } 
        }
        elseif($calltype == 'expense'){ ?>
             <thead>
              <tr>
                <th>Service Name</th>
                <th>Paid Amount</th>
                <th>Hotel Name</th>
              </tr>
            </thead>
            
            <?php foreach($ExpensesArr as $value){  
                $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$value['hotel_manager_id']."'";
                $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery);  
                ?>
                <tr>
                    <td><?php echo $value['service_name']; ?></td>
                    <td><?php echo $value['amount_out']; ?></td>
                    <td><?php echo $vendorResult['vendor_business_name']; ?></td>
                </tr>

            <?php } ?>
        <?php } 
        elseif($calltype == 'sale'){  ?>
             
            
            <?php foreach($SaleDetails as $key => $value){ 
                
                if(!empty($value)){ 
                    $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$key."'";
                    $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery); ?>
                    
                    <thead>
                        <tr>
                            <th><?php echo $vendorResult['vendor_business_name']; ?></th>
                        </tr>
                      <tr>
                        <th>Customer Name</th>
                        <th>Amount Mode</th>
                        <th>Paid Amount</th>
                      </tr>
                    </thead>
                    
                <?php foreach ($value as $keys => $sale) { 
                        $customeQuery = "SELECT `id`,`customer_name` from ".getTablePrefix()."customer_summary_book as `csb` WHERE `csb`.`hotel_manager_id` = '".$key."' AND `csb`.`summary_book_id` = '".$sale['customer_id']."'";
                        $customerResult = $this->common_model->getDataByQuery('single', $customeQuery); 
                    ?>
                        <tr>
                            <td><?php echo $customerResult['customer_name']; ?></td>
                            <td><?php echo $sale['amount_mode'] == 'offline' ? 'Cash' : ucfirst($sale['amount_mode']); ?></td>
                            <td><?php echo $sale['payment_paid']; ?></td>
                        </tr>
                <?php } 
                ?>
                
                <?php } ?>
            <?php } ?>
        <?php } 
        elseif($calltype == 'cash_in_hand'){ ?>
             
        <?php if(!empty($CashDetails)){ ?>
            <thead>
                <tr><th colspan="2" style="text-align: center;">Cash</th></tr>
            </thead>
            <?php foreach($CashDetails as $key => $value){  
                if(!empty($value)){
                $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$key."'";
                $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery);     
                ?>
                <thead>
                    <tr><th><?php echo $vendorResult['vendor_business_name']; ?></th></tr>
                  <tr>
                    <th>Service Name</th>
                    <th>Paid Amount</th>
                  </tr>
                </thead>
                <?php foreach ($value as $keys => $val) {
                    $customeQuery = "SELECT `id`,`customer_name` from ".getTablePrefix()."customer_summary_book as `csb` WHERE `csb`.`hotel_manager_id` = '".$key."' AND `csb`.`summary_book_id` = '".$val['customer_id']."'";
                        $customerResult = $this->common_model->getDataByQuery('single', $customeQuery);
                 ?>
                    <tr>
                        <td><?php echo $customerResult['customer_name']; ?></td>
                        <td><?php echo ucfirst($val['payment_paid']); ?></td>
                    </tr>
                <?php } ?>
                
                
            <?php } ?>
        <?php } ?>
        <?php } ?>
         <?php if(!empty($ExpensesDetails)){ ?>
            <thead>
                <tr><th colspan="2" style="text-align: center;">Expenses</th></tr>
            </thead>
        <?php foreach($ExpensesDetails as $key => $value){  
                if(!empty($value)){
                $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$key."'";
                $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery);     
                ?>
                <thead>
                    <tr><th><?php echo $vendorResult['vendor_business_name']; ?></th></tr>
                  <tr>
                    <th>Service Name</th>
                    <th>Paid Amount</th>
                  </tr>
                </thead>
                <?php foreach ($value as $keys => $val) { ?>
                    <tr>
                        <td><?php echo $val['service_name']; ?></td>
                        <td><?php echo ucfirst($val['amount_out']); ?></td>
                    </tr>
                <?php } ?>
                
                
            <?php } ?>
        <?php } ?>
        <?php } ?>
        <?php }
        elseif($calltype == 'occupied'){ ?>
             <thead>
              <tr>
                <th>Total Occupied Room</th>
                <th>Hotel Name</th>
              </tr>
            </thead>
            
            <?php foreach($OccupiedRoom as $key => $value){  
                $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$key."'";
                $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery);  
                ?>
                <tr>
                    <td><?php echo $value; ?></td>
                    <td><?php echo $vendorResult['vendor_business_name']; ?></td>
                </tr>

            <?php } ?>
        <?php } 
        elseif($calltype == 'continued'){ 
            //echo "<pre>"; print_r($Continued); exit; ?>
            <?php foreach($Continueds as $key => $value){
                if(!empty($value)){
                $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$key."'";
                $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery);  
                ?>
                <thead>
                    <tr><th><?php echo $vendorResult['vendor_business_name']; ?></th></tr>
                  <tr>
                    <th>Entry Number</th>
                    <th>Customer Name</th>
                    <th>Room No.</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <?php foreach($value as $cont){?>
                <tr>
                    <td><?php echo $cont['entry_number']; ?></td>
                    <td><?php echo $cont['customer_name']; ?></td>
                    <td><?php echo $cont['room_no']; ?></td>
                    <td><?php echo $cont['amount']; ?></td>
                    <td></td>
                </tr>

            <?php }  } ?>
        <?php } }
        elseif($calltype == 'checkout'){ ?>
            <?php foreach($GetCheckOutArr as $key => $value){
                if(!empty($value)){
                $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$key."'";
                $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery);  
                ?>
                <thead>
                    <tr><th><?php echo $vendorResult['vendor_business_name']; ?></th></tr>
                  <tr>
                    <th>Entry Number</th>
                    <th>Customer Name</th>
                    <th>Room No.</th>
                  </tr>
                </thead>
                <?php foreach($value as $cont){ 
                        $RoomQuery = "SELECT `room_no` FROM ".getTablePrefix()."room_number WHERE hotel_manager_id=".$key." AND `room_id` = '".$cont['assign_room_number']."' ";
                        $Room = $this->common_model->getDataByQuery('single', $RoomQuery);

                    ?>
                <tr>
                    <td><?php echo $cont['entry_number']; ?></td>
                    <td><?php echo $cont['customer_name']; ?></td>
                    <td><?php echo $Room['room_no']; ?></td>
                    <td></td>
                </tr>

            <?php }  } ?>
        <?php }
        }
        else{ ?>
            
            <?php foreach($TotalSales as $key => $values){
                if(!empty($values)){  
                    $vendorQuery = "SELECT `id`,`vendor_business_name` from ".getTablePrefix()."vendor as `v` WHERE `v`.`vendor_id` = '".$key."'";
                    $vendorResult = $this->common_model->getDataByQuery('single', $vendorQuery); ?>
                    <thead>
                         <tr><th><?php echo $vendorResult['vendor_business_name']; ?></th></tr>
                      <tr>
                        <th>Customer Name</th>
                        <th>Paid Amount</th>
                        <th>Hotel Name</th>
                      </tr>
                    </thead>
                <?php 
                    foreach ($values as $keys => $value) { 
                        $customeQuery = "SELECT `id`,`customer_name` from ".getTablePrefix()."customer_summary_book as `csb` WHERE `csb`.`hotel_manager_id` = '".$key."' AND `csb`.`summary_book_id` = '".$value['customer_id']."'";
                        $customerResult = $this->common_model->getDataByQuery('single', $customeQuery);     
                    ?>
                    <tr>
                        <td><?php echo $customerResult['customer_name']; ?></td>
                        <td><?php echo $value['payment_paid']; ?></td>
                        <td><?php echo $vendorResult['vendor_business_name']; ?></td>
                    </tr>
                <?php }
                ?>
                <?php } ?>
            <?php } ?>
    <?php } ?>    
    </table>
</div>    
