<?php 
if ($ALLDATA != "") : $i = 1;
  foreach ($ALLDATA as $key=>$ALLDATAINFO) :
  ?>
    <tr class="<?php if ($i % 2 == 0) : echo 'odd'; else : echo 'even';endif; ?> gradeX">
      <td><?=$key+1?></td>
      <td><?=$ALLDATAINFO['vendor_business_name']?></td>
      <td><?=$ALLDATAINFO['manager_name']?></td>
      <td><?=$ALLDATAINFO['manager_email']?></td>
      <td><?=$ALLDATAINFO['manager_mobile']?></td>
      <td>
        <?php if ($ALLDATAINFO['status'] == 'A'){ ?>
          <a href="<?=base_url('owner/manager/changestatus/'.$ALLDATAINFO['id'].'/I')?>"> Active</a>
        <?php }else{ ?>
          <a href="<?=base_url('owner/manager/changestatus/'.$ALLDATAINFO['id'].'/A')?>"> Inactive</a>
        <?php } ?> 
      </td>
      <td class="center">
        <a href="<?=base_url('owner/manager/addeditdata/'.$ALLDATAINFO['id'])?>"> Edit</a>
      </td>
    </tr>
    <?php 
  endforeach;
  echo '<tr><td colspan="10" style="text-align:center;">'.$PAGINATION.'</td></tr>';
else : ?>
  <tr>
    <td colspan="10" style="text-align:center;">No Data Available In Table</td>
  </tr>
<?php endif; ?>