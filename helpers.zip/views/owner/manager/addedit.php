<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?=base_url('owner/manager')?>" class=""><i class="lnr lnr-user"></i>Manager List</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITDATA ? 'Edit' : 'Add' ?> Manager</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Manager List</h3>
          <a href="<?=base_url('owner/manager')?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>Personal details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_business_name')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Hotel Name</label>
                      <select class="form-control" required name="vendor_id" id="vendor_id">
                        <option value="" selected>Select</option>
                        <?php
                        foreach ($HotelList as $hotel) {
                          $vendor_id = stripslashes($EDITDATA['vendor_id']);
                          $selected = '';
                          if($vendor_id==$hotel['vendor_id']){
                            $selected = 'selected';
                          }
                          echo '<option value="'.$hotel['vendor_id'].'" '.$selected.'>'.$hotel['vendor_business_name'].'</option>';
                        }
                        ?>
                      </select>
                      <?php if (form_error('vendor_id')) : ?>
                        <span for="vendor_id" generated="true" class="help-inline"><?php echo form_error('vendor_id'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Name</label>
                      <input type="text" name="manager_name" required id="manager_name" value="<?php if (set_value('manager_name')) : echo set_value('manager_name'); else : echo stripslashes($EDITDATA['manager_name']); endif; ?>" class="form-control" placeholder="Name">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Email</label>
                      <input type="text" name="manager_email" required id="manager_email" value="<?php if (set_value('manager_email')) : echo set_value('manager_email'); else : echo stripslashes($EDITDATA['manager_email']); endif; ?>" class="form-control" placeholder="Email">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Mobile</label>
                      <input type="text" name="manager_mobile" required id="manager_mobile" value="<?php if (set_value('manager_mobile')) : echo set_value('manager_mobile'); else : echo stripslashes($EDITDATA['manager_mobile']); endif; ?>" class="form-control" placeholder="Mobile">
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <?php if ($EDITDATA <> "") : ?>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">New Password</label>
                        <input type="password" name="new_password" id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password'); endif; ?>" class="form-control" placeholder="New Password">
                        <?php if (form_error('new_password')) : ?>
                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Confirm Password</label>
                        <input type="password" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password'); endif; ?>" class="form-control" placeholder="Confirm Password">
                        <?php if (form_error('conf_password')) : ?>
                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php else : ?>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Password</label>
                        <input type="password" name="new_password" required id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password'); endif; ?>" class="form-control" placeholder="New password">
                        <?php if (form_error('new_password')) : ?>
                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Confirm Password</label>
                        <input type="password" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password'); endif; ?>" class="form-control" required placeholder="Confirm Password">
                        <?php if (form_error('conf_password')) : ?>
                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php endif; ?>
                </div>
              </fieldset>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="<?=base_url('owner/manager')?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note :- <strong><span style="color:#FF0000;">*</span> Indicates Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>