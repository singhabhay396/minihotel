<style>
  a.btn.btn-default.add_btn_center {float: right;padding: 7px 30px !important;margin-left: 16px;font-size: 16px !important;color: #fff;background-color: #315bc2 !important;}
</style>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Manager List</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Manager List</h3>
          <a href="<?=base_url('owner/manager/addeditdata')?>" class="btn btn-default add_btn_center">Add a Manager</a>
        </div>
        <hr class="differ">
        <div class="row" style="margin-left: 7px !important;">
          <div class="col-md-3 col-sm-3 col-xs-3">
            <select class="form-control" onchange="Search()" name="vendor_id" id="vendor_id">
              <option value="All">All</option>
              <?php
              foreach ($HotelList as $key=>$hotel) {
                echo '<option value="'.$hotel['vendor_id'].'">'.$hotel['vendor_business_name'].'</option>';
              }
              ?>
            </select>
          </div>
        </div>
        <hr class="differ">
        <div class="dash">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th width="2%">
                  <select id="numofrecords" onchange="Search()">
                    <option value="10" selected>10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="500">500</option>
                  </select>
                </th>
                <th width="6%">Hotel</th>
                <th width="10%">Name</th>
                <th width="5%">Email</th>
                <th width="5%">Mobile</th>
                <th width="5%">Status</th>
                <th width="5%">Action</th>
              </tr>
            </thead>
            <thead>
              <tr>
                <th>#</th>
                <th><input type="text" class="form-control" id="hotel_name" placeholder="Hotel Name"></th>
                <th><input type="text" class="form-control" id="m_name" placeholder="Name"></th>
                <th><input type="text" class="form-control" id="email" placeholder="Email"></th>
                <th><input type="text" class="form-control" id="mobile" placeholder="Mobile"></th>
                <th>
                  <select id="status_data" class="form-control" onchange="Search()">
                    <option value="All" selected>All</option>
                    <option value="A">Active</option>
                    <option value="I">De-Active</option>
                  </select>
                </th>
                <th colspan="3">
                  <button type="button" onclick="Search()" class="btn btn-primary btn-lg">
                    <i class="fa fa-search"></i>
                  </button>
                </th>
              </tr>
            </thead>
            <tbody id="Result"></tbody>
          </table>      
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$(function() { 
  loadData(1);
  $(".form-control").keypress(function(event) {
    if(event.which == 13){
      event.preventDefault();
      loadData(1);
    }
  });
});
function Search(){
  loadData(1);
}
function Pagination(page){
  loadData(page);
}
function loadData(page){
  $("#Result").html('<tr><td colspan="10"><center>Loading..</center></td></tr>');
  var hotel_name    = $("#hotel_name").val();
  var vendor_id     = $("#vendor_id").val();
  var m_name        = $("#m_name").val();
  var email         = $("#email").val();
  var mobile        = $("#mobile").val();
  var status        = $("#status_data").val();
  var numofrecords  = $("#numofrecords").val();
  $.ajax({
    url : "<?=base_url('owner/manager/ManagerPagination')?>",
    type: "GET",
    data : {vendor_id:vendor_id,status:status,hotel_name:hotel_name,m_name:m_name,email:email,mobile:mobile,numofrecords:numofrecords,page:page},
    success:function(a){
      $("#Result").html(a);
    }
  });
}  
</script>