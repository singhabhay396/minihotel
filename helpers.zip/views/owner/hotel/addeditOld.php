<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?=base_url('owner/hotel')?>" class=""><i class="lnr lnr-user"></i>Hotel List</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITDATA ? 'Edit' : 'Add' ?> Hotel</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Hotel List</h3>
          <a href="<?=base_url('owner/hotel')?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?= $EDITDATA['encrypt_id'] ?>" />
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['vendor_id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>Personal details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_business_name')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Business Name</label>
                      <input type="text" name="vendor_business_name" id="vendor_business_name" value="<?php if (set_value('vendor_business_name')) : echo set_value('vendor_business_name'); else : echo stripslashes($EDITDATA['vendor_business_name']);endif; ?>" class="form-control" placeholder="Business Name">
                      <?php if (form_error('vendor_business_name')) : ?>
                        <span for="vendor_business_name" generated="true" class="help-inline"><?php echo form_error('vendor_business_name'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_title')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Title</label>
                      <input type="text" name="vendor_title" id="vendor_title" value="<?php if (set_value('vendor_title')) : echo set_value('vendor_title');
                                                                                      else : echo stripslashes($EDITDATA['vendor_title']);

                                                                                      endif; ?>" class="form-control" placeholder="Title">

                      <?php if (form_error('vendor_title')) : ?>

                        <span for="vendor_title" generated="true" class="help-inline"><?php echo form_error('vendor_title'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_name')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Name</label>

                      <input type="text" name="vendor_name" id="vendor_name" value="<?php if (set_value('vendor_name')) : echo set_value('vendor_name');

                                                                                    else : echo stripslashes($EDITDATA['vendor_name']);

                                                                                    endif; ?>" class="form-control" placeholder="Name">

                      <?php if (form_error('vendor_name')) : ?>

                        <span for="vendor_name" generated="true" class="help-inline"><?php echo form_error('vendor_name'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                </div>

                <div class="col-md-12 col-sm-12 col-xs-12 form-space">

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_email')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Email</label>

                      <input type="text" name="vendor_email" id="vendor_email" value="<?php if (set_value('vendor_email')) : echo set_value('vendor_email');

                                                                                      else : echo stripslashes($EDITDATA['vendor_email']);

                                                                                      endif; ?>" class="form-control email" placeholder="Email">

                      <?php if (form_error('vendor_email')) : ?>

                        <span for="vendor_email" generated="true" class="help-inline"><?php echo form_error('vendor_email'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('admin_mobile_number')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Phone</label>

                      <input type="text" name="admin_mobile_number" id="admin_mobile_number" value="<?php if (set_value('admin_mobile_number')) : echo set_value('admin_mobile_number');

                                                                                                    else : echo stripslashes($EDITDATA['vendor_phone']);

                                                                                                    endif; ?>" class="form-control" placeholder="Phone">

                      <?php if (form_error('admin_mobile_number')) : ?>

                        <span for="admin_mobile_number" generated="true" class="help-inline"><?php echo form_error('admin_mobile_number'); ?></span>

                      <?php endif;

                      if ($mobileerror) :  ?>

                        <span for="admin_mobile_number" generated="true" class="help-inline"><?php echo $mobileerror; ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_image')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Image</label>

                      <?php if (set_value('vendor_image')) : $vendorimage = set_value('vendor_image');

                      elseif ($EDITDATA['vendor_image']) : $vendorimage = stripslashes($EDITDATA['vendor_image']);

                      else : $vendorimage = '';

                      endif; ?>

                      <img border="0" alt="" src="{ASSET_ADMIN_URL}images/browse-white.png" id="firstImageUpload" class="img-responsive" style="cursor:pointer;">

                      <input type="etxt" name="vendor_image" id="firstAvtar" value="<?php echo $vendorimage; ?>" class="form-control" style="border:none;width:0px;height:0px;margin-top: -14px;" />

                      <?php if (form_error('vendor_image')) : ?>

                        <span for="vendor_image" generated="true" class="help-inline"><?php echo form_error('vendor_image'); ?></span>

                      <?php endif; ?>

                      <span id="firstAvtarImageDiv" style="margin-top:5px;">

                        <?php if ($vendorimage) : ?>

                          <img border="0" alt="" src="<?php echo $vendorimage; ?>" class="img-responsive">&nbsp;

                          <a class="spancross" onclick="firstImageDelete('<?php echo $vendorimage; ?>');" href="javascript:void(0);"> <img border="0" alt="" src="{ASSET_ADMIN_URL}images/cross.png"></a>

                        <?php endif; ?>

                      </span>

                    </div>

                  </div>

                </div>

                <div class="col-md-12 col-sm-12 col-xs-12 form-space">

                  <?php if ($EDITDATA <> "") : ?>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">New Password</label>

                        <input type="password" name="new_password" id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password');

                                                                                            endif; ?>" class="form-control" placeholder="New Password">

                        <?php if (form_error('new_password')) : ?>

                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">Confirm Password</label>

                        <input type="password" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password');

                                                                                              endif; ?>" class="form-control" placeholder="Confirm Password">

                        <?php if (form_error('conf_password')) : ?>

                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('vendor_passcode')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Pass Code</label>
                        <input type="password" name="vendor_passcode" id="vendor_passcode" value="<?php if (set_value('vendor_passcode')) : echo set_value('conf_password');
                                                                                              endif; ?>" class="form-control" placeholder="Pass Code">
                        <?php if (form_error('vendor_passcode')) : ?>
                          <span for="vendor_passcode" generated="true" class="help-inline"><?php echo form_error('vendor_passcode'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php else : ?>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">Password</label>

                        <input type="password" name="new_password" id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password');

                                                                                            endif; ?>" class="form-control" placeholder="New password">

                        <?php if (form_error('new_password')) : ?>

                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">Confirm Password</label>

                        <input type="password" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password');

                                                                                              endif; ?>" class="form-control" placeholder="Confirm Password">

                        <?php if (form_error('conf_password')) : ?>

                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('vendor_passcode')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Pass Code</label>
                        <input type="password" name="vendor_passcode" id="vendor_passcode" value="<?php if (set_value('vendor_passcode')) : echo set_value('conf_password');
                                                                                              endif; ?>" class="form-control" placeholder="Pass Code">
                        <?php if (form_error('vendor_passcode')) : ?>
                          <span for="vendor_passcode" generated="true" class="help-inline"><?php echo form_error('vendor_passcode'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php endif; ?>

                </div>

              </fieldset>

              <fieldset>

                <legend>KYC details</legend>

                <div class="col-md-12 col-sm-12 col-xs-12 form-space">

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_address')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Address</label>

                      <input type="text" name="vendor_address" id="vendor_address" value="<?php if (set_value('vendor_address')) : echo set_value('vendor_address');

                                                                                          else : echo stripslashes($KYCDATA['vendor_address']);

                                                                                          endif; ?>" class="form-control" placeholder="Address">

                      <?php if (form_error('vendor_address')) : ?>

                        <span for="vendor_address" generated="true" class="help-inline"><?php echo form_error('vendor_address'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_city')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">City</label>

                      <input type="text" name="vendor_city" id="vendor_city" value="<?php if (set_value('vendor_city')) : echo set_value('vendor_city');

                                                                                    else : echo stripslashes($KYCDATA['vendor_city']);

                                                                                    endif; ?>" class="form-control" placeholder="City">

                      <?php if (form_error('vendor_city')) : ?>

                        <span for="vendor_city" generated="true" class="help-inline"><?php echo form_error('vendor_city'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_pincode')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Pincode</label>

                      <input type="text" name="vendor_pincode" id="vendor_pincode" value="<?php if (set_value('vendor_pincode')) : echo set_value('vendor_pincode');

                                                                                          else : echo stripslashes($KYCDATA['vendor_pincode']);

                                                                                          endif; ?>" class="form-control" placeholder="Pincode">

                      <?php if (form_error('vendor_pincode')) : ?>

                        <span for="vendor_pincode" generated="true" class="help-inline"><?php echo form_error('vendor_pincode'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                </div>

                <div class="col-md-12 col-sm-12 col-xs-12 form-space">

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_nationality')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Nationality</label>

                      <input type="text" name="vendor_nationality" id="vendor_nationality" value="<?php if (set_value('vendor_nationality')) : echo set_value('vendor_nationality');

                                                                                                  else : echo stripslashes($KYCDATA['vendor_nationality']);

                                                                                                  endif; ?>" class="form-control" placeholder="Nationality">

                      <?php if (form_error('vendor_nationality')) : ?>

                        <span for="vendor_nationality" generated="true" class="help-inline"><?php echo form_error('vendor_nationality'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_pan')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Pan No</label>

                      <input type="text" name="vendor_pan" id="vendor_pan" value="<?php if (set_value('vendor_pan')) : echo set_value('vendor_pan');

                                                                                  else : echo stripslashes($KYCDATA['vendor_pan']);

                                                                                  endif; ?>" class="form-control" placeholder="Pan No">

                      <?php if (form_error('vendor_pan')) : ?>

                        <span for="vendor_pan" generated="true" class="help-inline"><?php echo form_error('vendor_pan'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_pan_attach')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Pan Image</label>

                      <span style="display:inline-block;" id="uploadIds0"><img class="img-responsive" src="{ASSET_ADMIN_URL}images/browse-white.png" border="0" alt="" /></span>

                      <input type="text" id="uploadimage0" name="uploadimage0" value="<?php if (set_value('uploadimage0')) : echo set_value('uploadimage0');

                                                                                      else : echo stripslashes($KYCDATA['vendor_pan_attach']);

                                                                                      endif; ?>" class="browseimageclass" />

                      <br clear="all">

                      <?php if (form_error('uploadimage0')) : ?>

                        <label for="uploadimage0" generated="true" class="error"><?php echo form_error('uploadimage0'); ?></label>

                      <?php endif; ?>

                      <div id="uploadstatus0" style="color:red;">&nbsp;</div>

                      <span id="uploadphoto0" style="float:left;">

                        <?php if (set_value('uploadimage0')) : ?>

                          <img src="<?php echo stripslashes(set_value('uploadimage0')) ?>" width="100" border="0" alt="" /> <a href="javascript:void(0);" onClick="DeleteImage('<?php echo stripslashes(set_value('uploadimage0')) ?>','0');"> <img src="{ASSET_ADMIN_URL}images/cross.png" border="0" alt="" /> </a>

                        <?php elseif ($KYCDATA['vendor_pan_attach']) : ?>

                          <img src="<?php echo stripslashes($KYCDATA['vendor_pan_attach']) ?>" width="100" border="0" alt="" /> <a href="javascript:void(0);" onClick="DeleteImage('<?php echo stripslashes($KYCDATA['vendor_pan_attach']) ?>','0');"> <img src="{ASSET_ADMIN_URL}images/cross.png" border="0" alt="" /> </a>

                        <?php endif; ?>

                      </span> <br clear="all" />

                    </div>

                  </div>

                </div>

                <div class="col-md-12 col-sm-12 col-xs-12 form-space">

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_gst')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">GST No</label>

                      <input type="text" name="vendor_gst" id="vendor_gst" value="<?php if (set_value('vendor_gst')) : echo set_value('vendor_gst');

                                                                                  else : echo stripslashes($KYCDATA['vendor_gst']);

                                                                                  endif; ?>" class="form-control" placeholder="GST No">

                      <?php if (form_error('vendor_gst')) : ?>

                        <span for="vendor_gst" generated="true" class="help-inline"><?php echo form_error('vendor_gst'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_gst_attach')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">GST Image</label>

                      <span style="display:inline-block;" id="uploadIds1"><img class="img-responsive" src="{ASSET_ADMIN_URL}images/browse-white.png" border="0" alt="" /></span>

                      <input type="text" id="uploadimage1" name="uploadimage1" value="<?php if (set_value('uploadimage1')) : echo set_value('uploadimage1');

                                                                                      else : echo stripslashes($KYCDATA['vendor_gst_attach']);

                                                                                      endif; ?>" class="browseimageclass" />

                      <br clear="all">

                      <?php if (form_error('uploadimage1')) : ?>

                        <label for="uploadimage1" generated="true" class="error"><?php echo form_error('uploadimage1'); ?></label>

                      <?php endif; ?>

                      <div id="uploadstatus1" style="color:red;">&nbsp;</div>

                      <span id="uploadphoto1" style="float:left;">

                        <?php if (set_value('uploadimage1')) : ?>

                          <img src="<?php echo stripslashes(set_value('uploadimage1')) ?>" width="100" border="0" alt="" /> <a href="javascript:void(0);" onClick="DeleteImage('<?php echo stripslashes(set_value('uploadimage1')) ?>','1');"> <img src="{ASSET_ADMIN_URL}images/cross.png" border="0" alt="" /> </a>

                        <?php elseif ($KYCDATA['vendor_gst_attach']) : ?>

                          <img src="<?php echo stripslashes($KYCDATA['vendor_gst_attach']) ?>" width="100" border="0" alt="" /> <a href="javascript:void(0);" onClick="DeleteImage('<?php echo stripslashes($KYCDATA['vendor_gst_attach']) ?>','1');"> <img src="{ASSET_ADMIN_URL}images/cross.png" border="0" alt="" /> </a>

                        <?php endif; ?>

                      </span> <br clear="all" />

                    </div>

                  </div>

                </div>

                <div class="col-md-12 col-sm-12 col-xs-12 form-space">

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_address_proof')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Address Proof Type</label>

                      <input type="text" name="vendor_address_proof" id="vendor_address_proof" value="<?php if (set_value('vendor_address_proof')) : echo set_value('vendor_address_proof');

                                                                                                      else : echo stripslashes($KYCDATA['vendor_address_proof']);

                                                                                                      endif; ?>" class="form-control" placeholder="Address Proof Type">

                      <?php if (form_error('vendor_address_proof')) : ?>

                        <span for="vendor_address_proof" generated="true" class="help-inline"><?php echo form_error('vendor_address_proof'); ?></span>

                      <?php endif; ?>

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">

                    <div class="form-group <?php if (form_error('vendor_address_proof_attach')) : ?>error<?php endif; ?>">

                      <label class="fancy-checkbox form-headings">Address Proof Image</label>

                      <span style="display:inline-block;" id="uploadIds2"><img class="img-responsive" src="{ASSET_ADMIN_URL}images/browse-white.png" border="0" alt="" /></span>

                      <input type="text" id="uploadimage2" name="uploadimage2" value="<?php if (set_value('uploadimage2')) : echo set_value('uploadimage2');

                                                                                      else : echo stripslashes($KYCDATA['vendor_address_proof_attach']);

                                                                                      endif; ?>" class="browseimageclass" />

                      <br clear="all">

                      <?php if (form_error('uploadimage2')) : ?>

                        <label for="uploadimage2" generated="true" class="error"><?php echo form_error('uploadimage2'); ?></label>

                      <?php endif; ?>

                      <div id="uploadstatus2" style="color:red;">&nbsp;</div>

                      <span id="uploadphoto2" style="float:left;">

                        <?php if (set_value('uploadimage2')) : ?>

                          <img src="<?php echo stripslashes(set_value('uploadimage2')) ?>" width="100" border="0" alt="" /> <a href="javascript:void(0);" onClick="DeleteImage('<?php echo stripslashes(set_value('uploadimage2')) ?>','2');"> <img src="{ASSET_ADMIN_URL}images/cross.png" border="0" alt="" /> </a>

                        <?php elseif ($KYCDATA['vendor_address_proof_attach']) : ?>

                          <img src="<?php echo stripslashes($KYCDATA['vendor_address_proof_attach']) ?>" width="100" border="0" alt="" /> <a href="javascript:void(0);" onClick="DeleteImage('<?php echo stripslashes($KYCDATA['vendor_address_proof_attach']) ?>','2');"> <img src="{ASSET_ADMIN_URL}images/cross.png" border="0" alt="" /> </a>

                        <?php endif; ?>

                      </span> <br clear="all" />

                    </div>

                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_kyc_status')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">KYC Verify</label>
                      <?php if (set_value('vendor_kyc_status')) : $kycstatus =  set_value('vendor_kyc_status');
                      elseif ($KYCDATA['vendor_kyc_status']) : $kycstatus =  stripslashes($KYCDATA['vendor_kyc_status']);
                      else : $kycstatus =  'N';
                      endif; ?>
                      <label class="fancy-radio chck-box">
                        <input type="radio" name="vendor_kyc_status" id="vendor_kyc_status1" value="Y" <?php if ($kycstatus == 'Y') : echo 'checked="checked"';
                      endif; ?>>
                        <span><i></i>Yes</span>
                      </label>
                      <label class="fancy-radio chck-box">
                        <input type="radio" name="vendor_kyc_status" id="vendor_kyc_status2" value="N" <?php if ($kycstatus == 'N') : echo 'checked="checked"';
                      endif; ?>>
                      <span><i></i>No</span>
                      </label>
                      <?php if (form_error('vendor_kyc_status')) : ?>
                        <span for="vendor_kyc_status" generated="true" class="help-inline"><?php echo form_error('vendor_kyc_status'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </fieldset>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="<?=base_url('owner/hotel')?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                :- <strong><span style="color:#FF0000;">*</span> Indicates
                    Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  $(function() {
    UploadImage('0');
    UploadImage('1');
    UploadImage('2');
  });
</script>