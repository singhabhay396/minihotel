<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?=base_url('owner/hotel')?>" class=""><i class="lnr lnr-user"></i>Hotel List</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITDATA ? 'Edit' : 'Add' ?> Hotel</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Hotel List</h3>
          <a href="<?=base_url('owner/hotel')?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?= $EDITDATA['encrypt_id'] ?>" />
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['vendor_id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>Personal details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_business_name')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Guest House Name</label>
                      <input type="text" name="vendor_business_name" id="vendor_business_name" value="<?php if (set_value('vendor_business_name')) : echo set_value('vendor_business_name'); else : echo stripslashes($EDITDATA['vendor_business_name']);endif; ?>" class="form-control" placeholder="Business Name">
                      <?php if (form_error('vendor_business_name')) : ?>
                        <span for="vendor_business_name" generated="true" class="help-inline"><?php echo form_error('vendor_business_name'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_title')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Title</label>
                      <input type="text" name="vendor_title" id="vendor_title" value="<?php if (set_value('vendor_title')) : echo set_value('vendor_title'); else : echo stripslashes($EDITDATA['vendor_title']); endif; ?>" class="form-control" placeholder="Title">
                      <?php if (form_error('vendor_title')) : ?>
                        <span for="vendor_title" generated="true" class="help-inline"><?php echo form_error('vendor_title'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_name')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Name</label>
                      <input type="text" name="vendor_name" id="vendor_name" value="<?php if (set_value('vendor_name')) : echo set_value('vendor_name'); else : echo stripslashes($EDITDATA['vendor_name']); endif; ?>" class="form-control" placeholder="Name">
                      <?php if (form_error('vendor_name')) : ?>
                        <span for="vendor_name" generated="true" class="help-inline"><?php echo form_error('vendor_name'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_email')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Email</label>
                      <input type="text" name="vendor_email" id="vendor_email" value="<?php if (set_value('vendor_email')) : echo set_value('vendor_email'); else : echo stripslashes($EDITDATA['vendor_email']); endif; ?>" class="form-control email" placeholder="Email">
                      <?php if (form_error('vendor_email')) : ?>
                        <span for="vendor_email" generated="true" class="help-inline"><?php echo form_error('vendor_email'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('admin_mobile_number')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Phone</label>
                      <input type="text" name="admin_mobile_number" id="admin_mobile_number" value="<?php if (set_value('admin_mobile_number')) : echo set_value('admin_mobile_number'); else : echo stripslashes($EDITDATA['vendor_phone']); endif; ?>" class="form-control" placeholder="Phone">
                      <?php if (form_error('admin_mobile_number')) : ?>
                        <span for="admin_mobile_number" generated="true" class="help-inline"><?php echo form_error('admin_mobile_number'); ?></span>
                      <?php endif;
                      if ($mobileerror) :  ?>
                        <span for="admin_mobile_number" generated="true" class="help-inline"><?php echo $mobileerror; ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_image')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Image</label>
                      <?php if (set_value('vendor_image')) : $vendorimage = set_value('vendor_image');
                      elseif ($EDITDATA['vendor_image']) : $vendorimage = stripslashes($EDITDATA['vendor_image']);
                      else : $vendorimage = '';
                      endif; ?>
                      <img border="0" alt="" src="{ASSET_ADMIN_URL}images/browse-white.png" id="firstImageUpload" class="img-responsive" style="cursor:pointer;">
                      <input type="etxt" name="vendor_image" id="firstAvtar" value="<?php echo $vendorimage; ?>" class="form-control" style="border:none;width:0px;height:0px;margin-top: -14px;" />
                      <?php if (form_error('vendor_image')) : ?>
                        <span for="vendor_image" generated="true" class="help-inline"><?php echo form_error('vendor_image'); ?></span>
                      <?php endif; ?>
                      <span id="firstAvtarImageDiv" style="margin-top:5px;">
                        <?php if ($vendorimage) : ?>
                          <img border="0" alt="" src="<?php echo $vendorimage; ?>" class="img-responsive">&nbsp;
                          <a class="spancross" onclick="firstImageDelete('<?php echo $vendorimage; ?>');" href="javascript:void(0);"> <img border="0" alt="" src="{ASSET_ADMIN_URL}images/cross.png"></a>
                        <?php endif; ?>
                      </span>
                    </div>
                  </div>
                </div>

                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Primary Contact Number (Owner)<span class="required">*</span></label>
                      <input type="text" name="admin_mobile_number" id="admin_mobile_number" value="<?php if (set_value('admin_mobile_number')): echo set_value('admin_mobile_number'); else:echo stripslashes($EDITDATA['vendor_phone']); endif;?>" class="form-control" placeholder="Phone">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Secondary Contact Number (Owner)<span class="required">*</span></label>
                      <input type="text" name="owner_secoundry_contact_number" id="owner_secoundry_contact_number" value="<?php if (set_value('owner_secoundry_contact_number')): echo set_value('owner_secoundry_contact_number');else:echo stripslashes($EDITDATA['owner_secoundry_contact_number']);endif;?>" class="form-control" placeholder="Secondary Contact Number (Owner)">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Reception (Primary)</label>
                      <input type="text" name="manager_contact_number_first" id="manager_contact_number_first" value="<?php if (set_value('manager_contact_number_first')): echo set_value('manager_contact_number_first'); else:echo stripslashes($EDITDATA['first_manager_contact_number']);endif;?>" class="form-control" placeholder="Reception (Primary)">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Reception (Secondary)</label>
                      <input type="text" name="manager_contact_number_secound" id="manager_contact_number_secound" value="<?php if (set_value('manager_contact_number_secound')): echo set_value('manager_contact_number_secound'); else:echo stripslashes($EDITDATA['secound_manager_contact_number']);endif;?>" class="form-control" placeholder="Reception (Secondary)">
                    </div>
                  </div>
                  <?php if ($EDITDATA <> "") : ?>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('vendor_passcode')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Pass Code</label>
                        <input type="password" name="vendor_passcode" id="vendor_passcode" value="<?php if (set_value('vendor_passcode')) : echo set_value('conf_password');endif; ?>" class="form-control" placeholder="Pass Code">
                        <?php if (form_error('vendor_passcode')) : ?>
                          <span for="vendor_passcode" generated="true" class="help-inline"><?php echo form_error('vendor_passcode'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php else : ?>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('vendor_passcode')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Pass Code</label>
                        <input type="password" name="vendor_passcode" id="vendor_passcode" value="<?php if (set_value('vendor_passcode')) : echo set_value('conf_password'); endif; ?>" class="form-control" placeholder="Pass Code">
                        <?php if (form_error('vendor_passcode')) : ?>
                          <span for="vendor_passcode" generated="true" class="help-inline"><?php echo form_error('vendor_passcode'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php endif; ?>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Booking Mode</label>
                      <!---<input type="text" name="booking_mode" id="booking_mode" value="<?php if (set_value('booking_mode')): echo set_value('booking_mode');else:echo stripslashes($EDITDATA['booking_mode']);endif;?>" class="form-control" placeholder="Booking Mode">-->
                      <select class="form-control" name="booking_mode">
                        
                        <option value="1" <?php if(stripslashes($EDITDATA['booking_mode']) == 1) { echo "selected"; } ?>>Mandotory (yes)</option>
                        <option value="0" <?php if(stripslashes($EDITDATA['booking_mode']) == 0) { echo "selected"; } ?>>Mandotory (No)</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Transaction Id</label>
                      <select class="form-control" name="transaction_id">
                        
                        <option value="1" <?php if(stripslashes($EDITDATA['transaction_id']) == 1) { echo "selected"; } ?>>Mandotory (yes)</option>
                        <option value="0" <?php if(stripslashes($EDITDATA['transaction_id']) == 0) { echo "selected"; } ?>>Mandotory (No)</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">ID Proof</label>
                      <select class="form-control" name="id_proof">
                        <option value="1" <?php if(stripslashes($EDITDATA['id_proof']) == 1) { echo "selected"; } ?>>Mandotory (yes)</option>
                        <option value="0" <?php if(stripslashes($EDITDATA['id_proof']) == 0) { echo "selected"; } ?>>Mandotory (No)</option>
                      </select> 
                    </div>
                  </div>
                </div>
              </fieldset>

              <fieldset>
                <legend>Address Details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-8 col-sm-8 col-xs-8">
                    <div class="form-group <?php if (form_error('vendor_address')): ?>error<?php endif;?>">
                      <label class="fancy-checkbox form-headings">Address<span class="required">*</span></label>
                      <input type="text" name="vendor_address" id="vendor_address" value="<?php if (set_value('vendor_address')): echo set_value('vendor_address');else:echo stripslashes($KYCDATA['vendor_address']);endif;?>" class="form-control required" placeholder="Address">
                      <?php if (form_error('vendor_address')): ?>
                        <span for="vendor_address" generated="true" class="help-inline"><?php echo form_error('vendor_address'); ?></span>
                      <?php endif;?>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-3 col-sm-3 col-xs-3">
                    <div class="form-group <?php if (form_error('you_are')): ?>error<?php endif;?>">
                      <label class="fancy-checkbox form-headings">You Are<span class="required">*</span></label>
                      <select name="you_are" id="you_are" class="form-control">
                        <option value="owner" <?php if ($KYCDATA['you_are'] == "owner"): echo "selected"; endif;?>>Owner</option>
                        <option value="lessee" <?php if ($KYCDATA['you_are'] == "lessee"): echo "selected";endif;?>>Lessee</option>
                      </select>
                      <?php if (form_error('you_are')): ?>
                        <span for="you_are" generated="true" class="help-inline"><?php echo form_error('you_are'); ?></span>
                      <?php endif;?>
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-3 col-xs-3">
                    <div class="form-group <?php if (form_error('gst_number')): ?>error<?php endif;?>">
                      <label class="fancy-checkbox form-headings">GST Number<span class="required">*</span></label>
                      <input type="text" name="gst_number" id="gst_number" value="<?php if (set_value('gst_number')): echo set_value('gst_number');else:echo stripslashes($KYCDATA['vendor_gst']);endif;?>" class="form-control" placeholder="GST Number">
                      <?php if (form_error('gst_number')): ?>
                        <span for="gst_number" generated="true" class="help-inline"><?php echo form_error('gst_number'); ?></span>
                      <?php endif;?>
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-3 col-xs-3">
                    <div class="form-group <?php if (form_error('entry_number')): ?>error<?php endif;?>">
                      <label class="fancy-checkbox form-headings">GRC No.<span class="required">*</span></label>
                      <input type="text" name="entry_number" id="entry_number" value="<?php if (set_value('entry_number')): echo set_value('entry_number');else:echo stripslashes($KYCDATA['entry_number']);endif;?>" class="form-control" placeholder="GRC No.">
                      <?php if (form_error('entry_number')): ?>
                        <span for="entry_number" generated="true" class="help-inline"><?php echo form_error('entry_number'); ?></span>
                      <?php endif;?>
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-3 col-xs-3">
                    <div class="form-group <?php if (form_error('bill_number')): ?>error<?php endif;?>">
                      <label class="fancy-checkbox form-headings">Bill Number<span class="required">*</span></label>
                      <input type="text" name="bill_number" id="bill_number" value="<?php if (set_value('bill_number')): echo set_value('bill_number');else:echo stripslashes($KYCDATA['bill_number']);endif;?>" class="form-control" placeholder="Bill Number">
                      <?php if (form_error('bill_number')): ?>
                        <span for="bill_number" generated="true" class="help-inline"><?php echo form_error('bill_number'); ?></span>
                      <?php endif;?>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-8 col-sm-8 col-xs-8">
                    <div class="form-group <?php if (form_error('managed_by')): ?>error<?php endif;?>">
                      <label class="fancy-checkbox form-headings">Managed By</label>
                      <input type="text" name="managed_by" id="managed_by" value="<?php if (set_value('managed_by')): echo set_value('managed_by');else:echo stripslashes($KYCDATA['managed_by']);endif;?>" class="form-control" placeholder="Managed By..">
                      <?php if (form_error('managed_by')): ?>
                        <span for="managed_by" generated="true" class="help-inline"><?php echo form_error('managed_by'); ?></span>
                      <?php endif;?>
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-3 col-xs-3">
                    <div class="form-group <?php if (form_error('website')): ?>error<?php endif;?>">
                      <label class="fancy-checkbox form-headings">Website</label>
                      <input type="text" name="website" id="website" value="<?php if (set_value('website')): echo set_value('website');else:echo stripslashes($KYCDATA['website_url']);endif;?>" class="form-control" placeholder="Website">
                      <?php if (form_error('website')): ?>
                        <span for="website" generated="true" class="help-inline"><?php echo form_error('website'); ?></span>
                      <?php endif;?>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-8 col-sm-8 col-xs-8">
                    <div class="form-group <?php if (form_error('other_details')): ?>error<?php endif;?>">
                      <label class="fancy-checkbox form-headings">Other Details</label>
                      <textarea name="other_details" id="other_details" cols="40" rows="5"><?php if (set_value('other_details')): echo set_value('other_details');else:echo stripslashes($KYCDATA['other_details']);endif;?></textarea>
                      <?php if (form_error('other_details')): ?>
                        <span for="other_details" generated="true" class="help-inline"><?php echo form_error('other_details'); ?></span>
                      <?php endif;?>
                    </div>
                  </div>
                </div>
              </fieldset>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="<?=base_url('owner/hotel')?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                :- <strong><span style="color:#FF0000;">*</span> Indicates
                    Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  $(function() {
    UploadImage('0');
    UploadImage('1');
    UploadImage('2');
  });
</script>