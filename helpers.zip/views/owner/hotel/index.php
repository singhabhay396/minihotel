<?php
$CheckWhatsApp = $this->common_model->CheckVendorWhatsApp();
?>
<style>
  a.btn.btn-default.add_btn_center {float: right;padding: 7px 30px !important;margin-left: 16px;font-size: 16px !important;color: #fff;background-color: #315bc2 !important;}
</style>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Hotel List</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Hotel List</h3>
          <a href="hotel/addeditdata" class="btn btn-default add_btn_center">Add a Hotel</a>
        </div>
        <hr class="differ">
          <div class="dash">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="6%">Sr.No.</th>
                  <th width="19%">Business Name</th>
                  <th width="10%">Name</th>
                  <th width="10%">Email</th>
                  <th width="10%">Phone</th>
                  <th width="10%">Hotel Owner Status</th>
                  <th width="10%">KYC Status</th>
                  <th width="20%">Last Online</th>
                  <th width="10%">--</th>
                </tr>
              </thead>
              <tbody>
                <tr class="even gradeX">
                  <td>1</td> 
                  <td><?= stripslashes($OwnerData['vendor_business_name']) ?></td>
                  <td><?= stripslashes($OwnerData['vendor_name']) ?></td>
                  <td><?= stripslashes($OwnerData['vendor_email']) ?></td>
                  <td><?= stripslashes($OwnerData['vendor_phone']) ?></td>
                  <td><?= showStatus($OwnerData['status']) ?></td>
                  <td><span class="status-success">Verified</span></td>
                  <td><?= YYMMDDtoDDMMYY($OwnerData['vendor_last_login']) ?></td>
                  <td class="center">
                    <div class="btn-group">
                      <button class="btn dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                      <ul class="dropdown-menu">
                        <li><a href="hotel/addeditdata/<?= $OwnerData['vendor_id'] ?>"><i class="fa fa-edit"></i> Edit Details</a></li>
                        <li class="divider"></li>
                        <?php if ($OwnerData['status'] == 'A'){ ?>
                          <li><a href="hotel/changestatus/<?= $OwnerData['vendor_id'] ?>/I"><i class="fa fa-hand-o-down"></i> Inactive</a></li>
                          <li><a href="hotel/changestatus/<?= $OwnerData['vendor_id'] ?>/B"><i class="fa fa-remove"></i> Block</a></li>
                        <?php }else{ ?>
                          <li><a href="hotel/changestatus/<?= $OwnerData['vendor_id'] ?>/A"><i class="fa fa-hand-o-up"></i> Active</a></li>
                        <?php } ?>  
                        <!-- <li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/deleteData/<?= $OwnerData['vendor_id'] ?>" onclick="return confirm('Are You Sure You Want To Delete This?');"><i class="fa fa-trash"></i> Delete</a></li> -->
                      </ul>
                    </div>
                  </td>
                </tr>
                <?php if ($ALLDATA <> "" ) : $i = 2;
                  foreach ($ALLDATA as $ALLDATAINFO) :
                    if($ALLDATAINFO['status']<>'D'):
                      ?>
                      <tr class="<?php if ($i % 2 == 0) : echo 'odd';else : echo 'even';endif; ?> gradeX">
                      <td><?= $i++ ?></td>
                      <td><?= stripslashes($ALLDATAINFO['vendor_business_name']) ?></td>
                      <td><?= stripslashes($ALLDATAINFO['vendor_name']) ?></td>
                      <td><?= stripslashes($ALLDATAINFO['vendor_email']) ?></td>
                      <td><?= stripslashes($ALLDATAINFO['vendor_phone']) ?></td>
                      <td><?= showStatus($ALLDATAINFO['status']) ?></td>
                      <td><?= showKYCStatus($ALLDATAINFO['vendor_kyc_status']) ?></td>
                      <td><?= YYMMDDtoDDMMYY($ALLDATAINFO['vendor_last_login']) ?></td>
                      <td class="center">
                        <div class="btn-group">
                          <button class="btn dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                          <ul class="dropdown-menu">
                            <li><a href="hotel/addeditdata/<?= $ALLDATAINFO['vendor_id'] ?>"><i class="fa fa-edit"></i> Edit Details</a></li>
                            <li class="divider"></li>
                            <?php if ($ALLDATAINFO['status'] == 'A'){ ?>
                              <li><a href="hotel/changestatus/<?= $ALLDATAINFO['vendor_id'] ?>/I"><i class="fa fa-hand-o-down"></i> Inactive</a></li>
                              <li><a href="hotel/changestatus/<?= $ALLDATAINFO['vendor_id'] ?>/B"><i class="fa fa-remove"></i> Block</a></li>
                            <?php }else{ ?>
                              <li><a href="hotel/changestatus/<?= $ALLDATAINFO['vendor_id'] ?>/A"><i class="fa fa-hand-o-up"></i> Active</a></li>
                            <?php } ?>  
                            <!-- <li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/deleteData/<?= $ALLDATAINFO['vendor_id'] ?>" onclick="return confirm('Are You Sure You Want To Delete This?');"><i class="fa fa-trash"></i> Delete</a></li> -->
                          </ul>
                        </div>
                      </td>
                    </tr>
                  <?php 
                endif;
                endforeach;
                else : ?>
                  <tr>
                    <td colspan="10" style="text-align:center;">No Data Available In Table</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
                        <div class="pagi row">
                            <div class="col-md-6 col-sm-6 col-xs-6 pagi-txt"><?php echo $noOfContent; ?></div>
                            <div class="col-md-6 col-sm-6 col-xs-6 pagi-bar">
                                <?= $PAGINATION ?>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
</div>
<script>
    var prevSerchValue = '<?php echo $searchValue; ?>';
    var prevSearchDate = '<?php echo $searchDate; ?>';
</script>