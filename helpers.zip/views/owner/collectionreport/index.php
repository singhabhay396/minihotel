<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<script>
  $(function() {
    $("#fromDate").datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      maxDate: 0,
      yearRange: "1960:<?php echo date('Y'); ?>"
    });
  });
  $(function() {
    $("#toDate").datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      maxDate: 0,
      yearRange: "1960:<?php echo date('Y'); ?>"
    });
  });
</script>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-book" aria-hidden="true"></i>Collection Report</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Download Collection report for multiple days (excel file)</h3>
        </div>
        <hr class="differ">
        <form action="<?=base_url('owner/Collectionreport/downloadcollectiondata')?>" method="get" name="DownloadData">
          <div class="panel-body row">
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select class="form-control" onchange="Search()" id="VendorID" name="VendorID" >
                <?php
                foreach ($HotelList as $hotel) {
                  echo '<option value="'.$hotel['vendor_id'].'">'.$hotel['vendor_business_name'].'</option>';
                }
                ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-3">
              <select id="range" class="form-control" name="range">
                <option>Select Range</option>
                <option value="today" <?php if($range == 'today'){ echo "selected" ;} ?>>Today</option>
                <option value="yesterday" <?php if($range == 'yesterday'){ echo "selected" ;} ?>>Yesterday</option>
                <option value="week" <?php if($range == 'week'){ echo "selected"; }?>>This Week</option>
                <option value="last_month" <?php if($range == 'last_month'){ echo "selected"; } ?>>Last Month</option>
                <option value="till_now" <?php if($range == 'till_now'){ echo "selected"; } ?>>Month Till Now</option>
                <option value="custom" <?php if($range == 'custom'){ echo "selected"; } ?>>Custom Range</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2 customes" <?php if($range == 'custom'){ ?>style="display: block" <?php } else{ ?> style="display: none" <?php } ?>">
              <input type="text" name="fromDate" id="fromDate" value="<?php if ($searchDate <> "") : echo date('d-m-Y', strtotime($searchDate)); endif; ?>" class="form-control input-smt" placeholder="From Date">
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2 customes" <?php if($range == 'custom'){ ?>style="display: block" <?php } else{ ?> style="display: none" <?php } ?>>
              <input type="text" name="toDate" id="toDate" value="<?php if ($searchDate <> "") : echo date('d-m-Y', strtotime($searchDate)); endif; ?>" class="form-control input-smt" placeholder="To Date">
            </div>
            <!--div class="col-md-2 col-sm-2 col-xs-2">
              <select name="businessType" id="businessType" class="form-control">
                <option value="All">B2B/B2C</option>
                <option value="B2B">B2B</option>
                <option value="B2C">B2C</option>
              </select>
            </div-->
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="amount_mode" id="amount_mode" class="form-control">
                <option value="All">All</option>
                <option value="prepaid">Prepaid</option>
                <option value="online">Online</option>
                <option value="offline">Cash</option>
                <option value="BTC">BTC</option>
                <!--option value="CashOnline">Cash/Online</option-->
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="reffer_mode" onchange="RefferMode()" id="reffer_mode" class="form-control">
                <option value="All">Direct/Online</option>
                <option value="online">Online Platform</option>
                <option value="offline">Direct</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2" id="DirectModeDiv">
              <select name="direct_mode" id="direct_mode" class="form-control">
                <option value="All">Commission/No Commission</option>
                <option value="commission">Commission</option>
                <option value="non_commission">No commission</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2" id="OTSIDDiv">
              <select name="ots_id" id="ots_id" class="form-control">
                <option value="">Select Booking Platform</option>
              </select>
            </div>
            <!--div class="col-md-2 col-sm-2 col-xs-2">
              <select name="choose_plan" id="choose_plan" class="form-control">
                <option value="All">Select Plan</option>
                <option value="EP">EP</option>
                <option value="CP">CP</option>
                <option value="MAP">MAP</option>
                <option value="AP">AP</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="bill_generated" id="bill_generated" class="form-control">
                <option value="All">Bill Generated</option>
                <option value="Yes">Yes</option>
                <option value="No">No</option>
              </select>
            </div--->
            <div class="col-md-4 col-sm-4 col-xs-4">
              <input type="submit" name="DownloadBtn" class="btn btn-primary btn-lg form-btn" value="Download Report">
            </div>
          </div>
        </form>
      </div>

    </div>
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Download Collection report for a single day (PDF)</h3>
        </div>
        <hr class="differ">
        <div class="row">
          <form action="<?=base_url('owner/reports/downloadreport')?>" method="get" name="searchData" id="searchData" autocomplete="off">
              <div class="col-md-4 col-sm-4 col-xs-4">
                    <select class="form-control" id="VendorID" name="VendorID" >
                      <?php
                      foreach ($HotelList as $hotel) {
                        echo '<option value="'.$hotel['vendor_id'].'">'.$hotel['vendor_business_name'].'</option>';
                      }
                      ?>
                    </select>
                  </div>
              <div class="col-md-4 col-sm-4 col-xs-4">
                  <input type="date" name="download_date" max="<?=date('Y-m-d')?>" value="<?=date('Y-m-d')?>">
              </div>

              <div class="col-md-3 col-sm-3 col-xs-3">
                  <!-- <input type="submit" value="submit" class="btn-primary"> -->
                  <button type="submit" class="btn btn-primary btn-lg form-btn">Download Report</button>
              </div><br><br><br><br><br><br>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
  $(document).on('change','#range',function(){
    var id = $("#range").val();
    $("#fromDate").val(' ');
    $("#toDate").val(' ');
    if(id == 'custom'){
        $(".customes").css("display",'block');
    }
    else{
        $(".customes").css("display",'none');
    }
});
RefferMode();
function RefferMode() {
  var reffer_mode = $('#reffer_mode').val();
  if(reffer_mode!='All'){
    if(reffer_mode=='online'){
      $('#OTSIDDiv').show();
      $('#DirectModeDiv').hide();
      GetOTSData();
    }else{
      $('#DirectModeDiv').show();
      $('#OTSIDDiv').hide();
    }
  }else{
    $('#DirectModeDiv').hide();
    $('#OTSIDDiv').hide();
  }
}
RefferMode();
function RefferMode() {
  var reffer_mode = $('#reffer_mode').val();
  if(reffer_mode!='All'){
    if(reffer_mode=='online'){
      $('#OTSIDDiv').show();
      $('#DirectModeDiv').hide();
      GetOTSData();
    }else{
      $('#DirectModeDiv').show();
      $('#OTSIDDiv').hide();
    }
  }else{
    $('#DirectModeDiv').hide();
    $('#OTSIDDiv').hide();
  }
}
function EditBillPopUp(summary_book_id) {
  $('#summary_book_id').val(summary_book_id);
  $('#EdotBillPopUpModal').modal("show");
}

function GetOTSData(){
  $("#ots_id").html('<option value="">Loading..</option>');
  var VendorID  = $('#VendorID').val();
  $.ajax({
    url : "<?=base_url('owner/billbookdata/GetOTSData')?>",
    type: "GET",
    data : {VendorID:VendorID},
    success:function(a){
      $("#ots_id").html(a);
    }
  });
}

</script>