<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?=base_url('owner/manager')?>" class=""><i class="lnr lnr-user"></i>Sub Owner List</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITDATAS ? 'Edit' : 'Add' ?> Sub Owner</a></li>
    </ol>
  </div>
  <?php //echo "<pre>"; print_r($form_error); ?>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATAS ? 'Edit' : 'Add' ?> Sub Owner List</h3>
          <a href="<?=base_url('owner/manager')?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATAS['id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>Personal details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Name</label>
                      <input type="text" name="vendor_name" required id="vendor_name" value="<?php if (set_value('vendor_name')) : echo set_value('vendor_name'); else : echo stripslashes($EDITDATAS['vendor_name']); endif; ?>" class="form-control" placeholder="Name">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Email</label>
                      <input type="text" name="vendor_email" autocomplete="vendor_email" required id="vendor_email" value="<?php echo stripslashes($EDITDATAS['vendor_email']) ?>" class="form-control" placeholder="Email">
                      <?php if (form_error('vendor_email')) : ?>
                          <p><?php echo form_error('vendor_email'); ?></p>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Mobile</label>
                      <input type="text" name="sub_owner_num" required id="manager_mobile" value="<?php if (set_value('manager_mobile')) : echo set_value('sub_owner_num'); else : echo stripslashes($EDITDATAS['sub_owner_num']); endif; ?>" class="form-control" placeholder="Mobile">
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <!--div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('vendor_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Password</label>
                        <input type="password" name="vendor_password" required id="new_password" value="<?php if (set_value('vendor_password')) : echo set_value('vendor_password'); endif; ?>" class="form-control" placeholder="password">
                        <?php if (form_error('vendor_password')) : ?>
                          <span for="vendor_password" generated="true" class="help-inline"><?php echo form_error('vendor_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div-->
                  <input type="hidden" name="vendor_title" value="<?php echo $vendorInfo['vendor_title'];?>">
                  <input type="hidden" name="vendor_slug" value="<?php echo $vendorInfo['vendor_slug'];?>">
                  <input type="hidden" name="parent_id" value="<?php echo $vendorInfo['parent_id'];?>">
                  <input type="hidden" name="vendor_business_name" value="<?php echo $vendorInfo['vendor_business_name'];?>">
                  <input type="hidden" name="vendor_phone" value="<?php echo $vendorInfo['vendor_phone'];?>">
                  <input type="hidden" name="owner_secoundry_contact_number" value="<?php echo $vendorInfo['owner_secoundry_contact_number'];?>">
                  <input type="hidden" name="first_manager_contact_number" value="<?php echo $vendorInfo['first_manager_contact_number'];?>">
                  <input type="hidden" name="secound_manager_contact_number" value="<?php echo $vendorInfo['secound_manager_contact_number'];?>">
                  <input type="hidden" name="feedback_link" value="<?php echo $vendorInfo['feedback_link'];?>">
                  <input type="hidden" name="contact_owner" value="<?php echo $vendorInfo['contact_owner'];?>">
                  <input type="hidden" name="vendor_type" value="<?php echo $vendorInfo['vendor_type'];?>">
                  <input type="hidden" name="vendor_email_verify" value="<?php echo $vendorInfo['vendor_email_verify'];?>">
                  <input type="hidden" name="vendor_phone_verify" value="<?php echo $vendorInfo['vendor_phone_verify'];?>">
                  <input type="hidden" name="booking_mode" value="<?php echo $vendorInfo['booking_mode'];?>">
                  <input type="hidden" name="whatsapp_checkin" value="<?php echo $vendorInfo['whatsapp_checkin'];?>">
                  <input type="hidden" name="whatsapp_checkout" value="<?php echo $vendorInfo['whatsapp_checkout'];?>">
                  <input type="hidden" name="whatsapp_bulk" value="<?php echo $vendorInfo['whatsapp_bulk'];?>">
                  <input type="hidden" name="is_owner" value=0>
                  <input type="hidden" name="status" value="<?php echo $vendorInfo['status'];?>">
                  <input type="hidden" name="accept_policy" value="<?php echo $vendorInfo['accept_policy'];?>">
                  <input type="hidden" name="you_are" value="Subowner">
                  <input type="hidden" name="vendor_kyc_status" value="<?php echo $vendorInfo['vendor_kyc_status'];?>">
                  <input type="hidden" name="other_details" value="<?php echo $vendorInfo['other_details'];?>">
                  <input type="hidden" name="vendor_gst" value="<?php echo $vendorInfo['vendor_gst'];?>">
                  <input type="hidden" name="managed_by" value="<?php echo $vendorInfo['managed_by'];?>">
                  <input type="hidden" name="website_url" value="<?php echo $vendorInfo['website_url'];?>">
                  <input type="hidden" name="bill_number" value="<?php echo $vendorInfo['bill_number'];?>">
                  <input type="hidden" name="entry_number" value="<?php echo $vendorInfo['entry_number'];?>">
                  <input type="hidden" name="kot_number" value="<?php echo $vendorInfo['kot_number'];?>">
                  <input type="hidden" name="no_of_restaurant" value="<?php echo $vendorInfo['no_of_restaurant'];?>">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('vendor_business_name')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Hotel Name</label>
                      <select class="form-control" required name="vendor_id[]" id="vendor_id" multiple>
                        <option value="" selected>Select</option>
                        <?php
                        foreach ($HotelList as $hotel) {
                          $vendor_id = stripslashes($EDITDATAS['vendor_id']);
                          $selected = '';
                          //if($LoginVenderId != $hotel['vendor_id']){
                            if($vendor_id==$hotel['vendor_id']){
                              $selected = 'selected';
                            }
                              echo '<option value="'.$hotel['vendor_id'].'" '.$selected.'>'.$hotel['vendor_business_name'].'</option>';
                          //}
                          
                        }
                        ?>
                      </select>
                      <?php if (form_error('vendor_id')) : ?>
                        <span for="vendor_id" generated="true" class="help-inline"><?php echo form_error('vendor_id'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </fieldset>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn" name="currentPageFormSubmit" value="Submit">Submit</button>
              <a href="<?=base_url('owner/subowner')?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note :- <strong><span style="color:#FF0000;">*</span> Indicates Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>