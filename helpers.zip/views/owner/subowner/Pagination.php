<?php 
if ($ALLDATA != "") : $i = 1;
  foreach ($ALLDATA as $key=>$ALLDATAINFO) :
  ?>
    <tr class="<?php if ($i % 2 == 0) : echo 'odd'; else : echo 'even';endif; ?> gradeX">
      <td><?=$key+1?></td>
      <td><?=$ALLDATAINFO['vendor_business_name']?></td>
      <td><?=$ALLDATAINFO['vendor_name']?></td>
      <td><?=$ALLDATAINFO['vendor_email']?></td>
      <td><?=$ALLDATAINFO['sub_owner_num']?></td>
      <td>
        <?php if ($ALLDATAINFO['status'] == 'A'){ ?>
          <a href="<?=base_url('owner/subowner/changestatus/'.$ALLDATAINFO['id'].'/I')?>"> Active</a>
        <?php }else{ ?>
          <a href="<?=base_url('owner/subowner/changestatus/'.$ALLDATAINFO['id'].'/A')?>"> Inactive</a>
        <?php } ?> 
      </td>
      <td class="center">
        <a href="<?=base_url('owner/subowner/addeditdatas/'.$ALLDATAINFO['vendor_id'])?>"> Edit</a>
      </td>
    </tr>
    <?php 
  endforeach;
  echo '<tr><td colspan="10" style="text-align:center;">'.$PAGINATION.'</td></tr>';
else : ?>
  <tr>
    <td colspan="10" style="text-align:center;">No Data Available In Table</td>
  </tr>
<?php endif; ?>