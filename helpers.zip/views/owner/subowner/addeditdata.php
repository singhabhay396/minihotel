<div class="main">

  <div class="bready">

    <ol class="breadcrumb">

      <li><a href="{FULL_SITE_URL}dashboard" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>

      <li><a href="<?php echo correctLink('vendorAdminData', '{FULL_SITE_URL}{CURRENT_CLASS}/index'); ?>" class=""><i class="lnr lnr-user"></i>Hotel Owner</a></li>

      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITDATA ? 'Edit' : 'Add' ?> Hotel Owner</a></li>

    </ol>

  </div>

  <div class="main-content">

    <div class="container-fluid">

      <div class="panel panel-headline inr-form">

        <div class="panel-heading row">

          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Hotel Owner</h3>

          <a href="<?php echo correctLink('vendorAdminData', '{FULL_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-default add_btn">Back</a>

        </div>

        <hr class="differ">

        <div class="panel">

          <div class="panel-body row">

            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">

              <input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?= $EDITDATA['encrypt_id'] ?>" />

              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['vendor_id'] ?>" />

              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

              <fieldset>

                   <input type="hidden" name="vendor_business_name" id="vendor_business_name" value="<?php if (set_value('vendor_business_name')) : echo set_value('vendor_business_name');else : echo stripslashes($EDITDATA['vendor_business_name']);endif; ?>" class="form-control" placeholder="Business Name">
                    <input type="hidden" name="vendor_name" id="vendor_name" value="<?php if (set_value('vendor_name')) : echo set_value('vendor_name');
                        else : echo stripslashes($EDITDATA['vendor_name']);

                          endif; ?>" class="form-control" placeholder="Name">
                  <input type="hidden" name="vendor_email" id="vendor_email" value="<?php if (set_value('vendor_email')) : echo set_value('vendor_email');

                          else : echo stripslashes($EDITDATA['vendor_email']);
                        endif; ?>" class="form-control email" placeholder="Email">

                  <input type="hidden" name="admin_mobile_number" id="admin_mobile_number" value="<?php if (set_value('admin_mobile_number')) : echo set_value('admin_mobile_number');else : echo stripslashes($EDITDATA['vendor_phone']); endif; ?>" class="form-control" placeholder="Phone">
                  <input type="hidden" name="vendor_kyc_status" id="vendor_kyc_status" value="<?php echo stripslashes($EDITDATA['vendor_kyc_status']); ?>">
                  <input type="hidden" name="vendor_gst" id="vendor_gst" value="<?php echo stripslashes($EDITDATA['vendor_gst']); ?>">
                  <input type="hidden" name="no_of_restaurant" id="no_of_restaurant" value="<?php echo stripslashes($EDITDATA['no_of_restaurant']); ?>">
              
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">

                  <?php if ($EDITDATA <> "") : ?>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">New Password</label>

                        <input type="password" name="new_password" id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password');

                                                                                            endif; ?>" class="form-control" placeholder="New Password">

                        <?php if (form_error('new_password')) : ?>

                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">Confirm Password</label>

                        <input type="password" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password');

                                                                                              endif; ?>" class="form-control" placeholder="Confirm Password">

                        <?php if (form_error('conf_password')) : ?>

                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('vendor_passcode')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Pass Code</label>
                        <input type="password" name="vendor_passcode" id="vendor_passcode" value="<?php if (set_value('vendor_passcode')) : echo set_value('conf_password');
                                                                                              endif; ?>" class="form-control" placeholder="Pass Code">
                        <?php if (form_error('vendor_passcode')) : ?>
                          <span for="vendor_passcode" generated="true" class="help-inline"><?php echo form_error('vendor_passcode'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php else : ?>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">Password</label>

                        <input type="password" name="new_password" id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password');

                                                                                            endif; ?>" class="form-control" placeholder="New password">

                        <?php if (form_error('new_password')) : ?>

                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">Confirm Password</label>

                        <input type="password" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password');

                                                                                              endif; ?>" class="form-control" placeholder="Confirm Password">

                        <?php if (form_error('conf_password')) : ?>

                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('vendor_passcode')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Pass Code</label>
                        <input type="password" name="vendor_passcode" id="vendor_passcode" value="<?php if (set_value('vendor_passcode')) : echo set_value('conf_password');
                                                                                              endif; ?>" class="form-control" placeholder="Pass Code">
                        <?php if (form_error('vendor_passcode')) : ?>
                          <span for="vendor_passcode" generated="true" class="help-inline"><?php echo form_error('vendor_passcode'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                  <?php endif; ?>

                </div>

              </fieldset>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="<?php echo correctLink('vendorAdminData', '{FULL_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                :- <strong><span style="color:#FF0000;">*</span> Indicates
                    Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  $(function() {
    UploadImage('0');
    UploadImage('1');
    UploadImage('2');
  });
</script>