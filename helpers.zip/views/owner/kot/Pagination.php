<?php 
if ($ALLDATA != "") : $i = 1;
  foreach ($ALLDATA as $ALLDATAINFO) :
  ?>
    <tr class="gradeX">
      <td><?= $i++ ?></td>
      <td><?= stripslashes($ALLDATAINFO['vendor_business_name']) ?></td>
      <td><?= stripslashes($ALLDATAINFO['rest_name']) ?></td>
      <td><?= stripslashes($ALLDATAINFO['table_name']) ?></td>
      <td><?= stripslashes($ALLDATAINFO['kot_no']) ?></td>
      <td><?= stripslashes($ALLDATAINFO['price']) ?></td>
      <td><?= stripslashes($ALLDATAINFO['add_date']) ?></td>

      <td class="center">
        <div class="btn-group">
          <button class="btn dropdown-toggle" data-toggle="dropdown">More Options <span class="caret"></span></button>
          <ul class="dropdown-menu">
            <li><a href="<?=base_url('owner/billbookdata/setCustomebillbook/'.$ALLDATAINFO['id'])?>"><i class="fa fa-plus"></i>Add New Record</a></li>
          </ul>
        </div>
      </td>
    </tr>
    <?php 
  endforeach;
  echo '<tr><td colspan="10" style="text-align:center;">'.$PAGINATION.'</td></tr>';
else : ?>
  <tr>
    <td colspan="10" style="text-align:center;">No Data Available In Table</td>
  </tr>
<?php endif; ?>