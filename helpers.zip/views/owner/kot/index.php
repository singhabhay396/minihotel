<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<script>
  $(function() {
    $("#fromDate").datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      maxDate: 0,
      yearRange: "1960:<?php echo date('Y'); ?>"
    });
  });
  $(function() {
    $("#toDate").datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      maxDate: 0,
      yearRange: "1960:<?php echo date('Y'); ?>"
    });
  });
</script>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-book" aria-hidden="true"></i>KOT</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">KOT</h3>
        </div>
        <hr class="differ">
        <form action="<?=base_url('owner/kot/downloadkotdata')?>" method="get" name="DownloadData">
          <div class="panel-body row">
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select class="form-control" onchange="Search()" id="VendorID" name="VendorID" >
                <option value="All">All</option>
                <?php
                foreach ($HotelList as $hotel) {
                  echo '<option value="'.$hotel['vendor_id'].'">'.$hotel['vendor_business_name'].'</option>';
                }
                ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-3">
              <select id="range" class="form-control" name="range">
                <option value="today">Today</option>
                <option value="yesterday">Yesterday</option>
                <option value="week">This Week</option>
                <option value="last_month">Last Month</option>
                <option value="till_now">Month Till Now</option>
                <option value="custom">Custom Range</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2 CustomeDate" style="display: none;">
              <input type="text" name="fromDate" id="fromDate" required value="<?=date('d-m-Y')?>" class="form-control input-smt" placeholder="From Date">
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2 CustomeDate" style="display: none">
              <input type="text" name="toDate" id="toDate" required value="<?=date('d-m-Y')?>" class="form-control input-smt" placeholder="To Date">
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="type" id="type" class="form-control">
                <option value="Table">Table</option>
                <option value="Customer">Room</option>
                <option value="Both">Both</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <select name="amount_mode" id="amount_mode" class="form-control">
                <option value="All">All</option>
                <option value="online">Online</option>
                <option value="offline">Cash</option>
              </select>
            </div>
            <div class="col-md-4 col-sm-4 col-xs-4">
              <input type="submit" name="DownloadBtn" class="btn btn-primary btn-lg form-btn" value="Download Report">
            </div>
          </div>
        </form>
        <div class="dash" style="display:none;">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th width="2%">
                  <select id="numofrecords" onchange="Search()">
                    <option value="10" selected>10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="500">500</option>
                  </select>
                </th>
                <th width="15%">Hotel Name</th>
                <th width="10%">Restaurant Name</th>
                <th width="10%">Table No.</th>
                <th width="10%">KOT No.</th>
                <th width="10%">Total Amount</th>
                <th width="10%">Date</th>
                <th width="10%">More Options</th>
              </tr>
            </thead>
            <thead>
              <tr>
                <th>#</th>
                <th></th>
                <th><input type="text" class="form-control" id="r_name" placeholder="Restaurant Name"></th>
                <th><input type="text" class="form-control" id="tbl_no" placeholder="Table No."></th>
                <th><input type="text" class="form-control" id="kot_no" placeholder="KOT No."></th>
                <th></th>
                <th><input type="date" class="form-control" id="k_date" placeholder="Date"></th>
                <th colspan="3">
                  <button type="button" onclick="Search()" class="btn btn-primary btn-lg">
                    <i class="fa fa-search"></i>
                  </button>
                </th>
              </tr>
            </thead>
            <tbody id="Result"></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
$(document).on('change','#range',function(){
  var id = $("#range").val();
  $("#fromDate").val(' ');
  $("#toDate").val(' ');
  if(id == 'custom'){
    $(".CustomeDate").show();
  }else{
    $(".CustomeDate").hide();
  }
});

$(function() { 
  //loadData(1);
  /*$(".form-control").keypress(function(event) {
    if(event.which == 13){
      event.preventDefault();
      loadData(1);
    }
  });*/
});
function Search(){
  var page = $('#CurrentPage').val();
  loadData(page);
}
function Pagination(page){
  loadData(page);
}
function loadData(page){
  $("#Result").html('<tr><td colspan="10"><center>Loading..</center></td></tr>');
  var r_name        = $("#r_name").val();
  var tbl_no        = $("#tbl_no").val();
  var kot_no        = $("#kot_no").val();
  var k_date        = $("#k_date").val();
  var numofrecords  = $("#numofrecords").val();
  var VendorArr     = $('#VendorID').val();
  $.ajax({
    url : "<?=base_url('owner/kot/KotPagination')?>",
    type: "GET",
    data : {k_date:k_date,r_name:r_name,VendorArr:VendorArr,tbl_no:tbl_no,kot_no:kot_no,numofrecords:numofrecords,page:page},
    success:function(a){
      $("#Result").html(a);
      checkboxcount();
    }
  });
}
</script>