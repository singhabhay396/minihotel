<style type="text/css">
  .error-message{
    color: red;
    font-size: 14px;
  }
</style>>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-user"></i>Change Password</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Change Password</h3>
          <a href="<?=base_url('owner/dashboard')?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageFormaa" name="currentPageFormaa" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>Change Password</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">

                  <?php if ($EDITDATA <> "") : ?>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">New Password</label>

                        <input type="password" data-len="#new_password_len" data-validcheck='#new_password' name="new_password" id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password');                      endif; ?>" class="form-control" required placeholder="New Password">
                        <label id="new_password-error" class="error-message" for="new_password" style="display:none; margin-top:0px">New Password is required.</label>
                        <label id="new_password_len-error" class="error-message" for="new_password_len" style="display:none; margin-top:0px">Please Enter At Least 6 Characters.</label>
                        <?php if (form_error('new_password')) : ?>
                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>
                        <?php endif; ?>
                      </div>
                    </div>
                    <div class="col-md-4 col-sm-4 col-xs-4">
                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">
                        <label class="fancy-checkbox form-headings">Confirm Password</label>
                        <input data-conf='#conf_password_con' data-len="#conf_password_len" data-validcheck='#conf_password' type="password" minlength="6" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password');endif; ?>" class="form-control required" placeholder="Confirm Password">
                        <label id="conf_password-error" class="error-message" for="conf_password" style="display:none; margin-top:0px">Confirm Password is required.</label>
                        <label id="conf_password_len-error" class="error-message" for="conf_password_len" style="display:none; margin-top:0px">Please Enter At Least 6 Characters.</label>
                        <label id="conf_password_con-error" class="error-message" for="conf_password_con" style="display:none; margin-top:0px">Please Enter The Same Value Again.</label>
                        <?php if (form_error('conf_password')) : ?>
                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>
                    
                  <?php else : ?>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('new_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">Password</label>

                        <input data-len="#new_password_len" data-validcheck='#new_password' minlength="6" type="password" name="new_password" id="new_password" value="<?php if (set_value('new_password')) : echo set_value('new_password'); endif; ?>" class="form-control" required placeholder="New password">
                        <label id="new_password-error" class="error-message" for="new_password" style="display:none; margin-top:0px">New Password is required.</label>
                        <label id="new_password_len-error" class="error-message" for="new_password_len" style="display:none; margin-top:0px">Please Enter At Least 6 Characters.</label>
                        <?php if (form_error('new_password')) : ?>

                          <span for="new_password" generated="true" class="help-inline"><?php echo form_error('new_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>

                    <div class="col-md-4 col-sm-4 col-xs-4">

                      <div class="form-group <?php if (form_error('conf_password')) : ?>error<?php endif; ?>">

                        <label class="fancy-checkbox form-headings">Confirm Password</label>

                        <input data-conf='#conf_password_con' data-validcheck='#conf_password' data-len="#conf_password_len" minlength="6" type="password" name="conf_password" id="conf_password" value="<?php if (set_value('conf_password')) : echo set_value('conf_password');  endif; ?>" class="form-control" required placeholder="Confirm Password">
                        <label id="conf_password-error" class="error-message" for="conf_password" style="display:none; margin-top:0px">Confirm Password is required.</label>
                        <label id="conf_password_len-error" class="error-message" for="conf_password_len" style="display:none; margin-top:0px">Please Enter At Least 6 Characters.</label>
                        <label id="conf_password_con-error" class="error-message" for="conf_password_con" style="display:none; margin-top:0px">Please Enter The Same Value Again.</label>
                        <?php if (form_error('conf_password')) : ?>

                          <span for="conf_password" generated="true" class="help-inline"><?php echo form_error('conf_password'); ?></span>

                        <?php endif; ?>

                      </div>

                    </div>
                    
                  <?php endif; ?>

                </div>
              </fieldset>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn" id="change_pass">Submit</button>
              <a href="<?=base_url('owner/restaurant')?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note :- <strong><span style="color:#FF0000;">*</span> Indicates Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
  $(document).on('change blur', '[data-validcheck]', function(){
    
    if ($(this).val() != null || $(this).val() != "") {
        $($(this).data('validcheck')+'-error').css('display','none');
    }
    if ($(this).val() == null || $(this).val() == "") {
        $($(this).data('validcheck')+'-error').css('display','block');
    }
    if($(this).val() != "" && $(this).val().length < 6){
      $($(this).data('len')+'-error').css('display','block');
    }
    if($(this).val() != "" && $(this).val().length > 7){
      $($(this).data('len')+'-error').css('display','none');
    }
});
$(document).on('click', '#change_pass', function(e){ 
    $("[data-validcheck]").each(function(i,h) {
        var getid = $(this).data('validcheck');
        var conf_password = $("#conf_password").val();
        var new_password = $("#new_password").val();
        if(conf_password != new_password){
            $('#conf_password_con-error').css('display','block');
            e.preventDefault();
        }
        console.log(getid);        
        if ($(this).val() == null || $(this).val() == "") {
            $(getid+'-error').css('display','block');
            e.preventDefault();
         }
        else{
            return true;
        }
    });
});
</script>>