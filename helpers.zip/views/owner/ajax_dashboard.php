<style>
.box_guard text {font-size: 15px!important;}
.box_guard .highcharts-credits {display:none;}
.lds-dual-ring.hidden { 
display: none;
}
.lds-dual-ring {
  display: inline-block;
  width: 80px;
  height: 80px;
}
.lds-dual-ring:after {
  content: " ";
  display: block;
  width: 64px;
  height: 64px;
  margin: 5% auto;
  border-radius: 50%;
  border: 6px solid #fff;
  border-color: #fff transparent #fff transparent;
  animation: lds-dual-ring 1.2s linear infinite;
}
@keyframes lds-dual-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}


.overlay {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100vh;
    background: rgba(0,0,0,.8);
    z-index: 999;
    opacity: 1;
    transition: all 0.5s;
}
</style>

<div class="main">
  <div class="bready">
    <div class="row">
      <div class="col-md-2">
        <ol class="breadcrumb">
          <li><a href="dashboard" class="active"><i class="lnr lnr-home"></i>Dashboard</a></li>
        </ol>
      </div>
    </div>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline" style="background-color:transparent">
        <div class="panel-heading"></div>
        <div class="panel-body">
          <div class="row box_guard">
            <div class="col-md-4 col-sm-4 col-xs-4">
                <select class="form-control" name="vendor_id" id="vendor_id">
                    <option value="">All</option>
                    <?php 
                        foreach ($hotel_list as $key => $value) { ?>
                        <?php //if($this->session->userdata('MHM_PARENT_OWNER') != $value['vendor_id']){ ?>
                           <option value="<?php echo $value['vendor_id']?>" 
                            <?php if($id == $value['vendor_id']){ echo "selected"; } else{ echo ""; }?>><?php echo $value['vendor_business_name']?></option>
                    <?php  } //}
                    ?>
                    
                </select>
            </div>

            <div class="col-md-8 col-sm-8 col-xs-8">
                  <button style="font-size: 10px;font-weight: bold;" type="button" class="btn btn-primary btn-lg " id="fetchDataBtn">View Detailed Reports</button>
              
            </div>
          </div>
          
          <br>
          <div id="loader" class="lds-dual-ring hidden overlay"></div>
          <div id="dataContainer"></div>
          
          <br>

          <div class="row box_guard">
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?= round($TotalSale,2)?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Sale </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong><i class="fa fa-inr" aria-hidden="true"></i> <?=round($TotalExpenses,2)?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Expenses </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                          <h5 style="text-transform: capitalize;"><strong> <?=$TotalCheckIn?></strong></h5>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Check Ins </h4>
                        </div>
                      </a>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong> <?=$TotalCheckOut?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Check Out </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
            <?php 
            // $CheckWhatsApp = $this->common_model->CheckOwnerWhatsApp();
            // $WhatsAppCount = 0;
            // if($CheckWhatsApp['whatsapp_checkin']==1){
            //   $WhatsAppCount++;
            // }
            // if($CheckWhatsApp['whatsapp_checkout']==1){
            //   $WhatsAppCount++;
            // }
            // if($CheckWhatsApp['whatsapp_bulk']==1){
            //   $WhatsAppCount++;
            // }
            // if($WhatsAppCount > 0){
            ?>  
            <!--div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong> <?=$TotalWhatsapp?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">No of Msg Sent Total </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div-->
            <?php  
            //}
            ?>
            <!--div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> 
                  <a href="javascript:void(0)" title="vacant rooms">
                    <div class="media align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong> <?=$TotalValidCheckout?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Total Rooms Continued </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div>
          </div-->

          <div class="row">
            <?php

            foreach ($ALLHotel as $key => $val) {
             
            ?>
              <div class="col-md-3 col-sm-3 col-xs-6">
                <div class="card card-even" style="border-radius: 20px; height: auto;">
                  <div class="card-content bg-3"> 
                    <a href="<?=base_url('owner/dashboard/MangerLogin/'.$key)?>" target="_blank" title="Login">
                      <div class="media  align-items-stretch">
                        <div class="p-2 bg-gradient-x-primary white media-body">
                          <h3 style="text-transform: capitalize; color: #fff;"><strong> <?=$val?></strong></h3>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Sale - <i class="fa fa-inr" aria-hidden="true"></i><?=round($totalSalesVendor[$key],2) ?? 0?></h4>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Expenses - <i class="fa fa-inr" aria-hidden="true"></i><?=$TotalExpensesVendor[$key] ?? 0?></h4>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Ins - <?=$totalCheckinVendor[$key] ?? 0?></h4>
                          <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Outs - <?=$totalCheckOutVendor[$key] ?? 0?></h4>
                        </div>
                      </div>
                    </a> 
                  </div>
                </div>
              </div>
            <?php
            }
            ?>

            <?php            
            
            if(!empty($this->session->userdata('MHM_IS_OWNER'))){ ?>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <div class="card card-even" style="border-radius: 20px; height: auto;">
                <div class="card-content bg-3"> 
                  <a href="<?=base_url('owner/dashboard/MangerLogin/'.$MainHotel['vendor_id'])?>" target="_blank" title="Login">
                    <div class="media  align-items-stretch">
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h3 style="text-transform: capitalize; color: #fff;"><strong> <?=$MainHotel['vendor_business_name']?></strong></h3>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Sale - <i class="fa fa-inr" aria-hidden="true"></i><?=round($totalSalesOwn['totalAmount'],2) ?? 0?></h4>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Expenses - <i class="fa fa-inr" aria-hidden="true"></i><?=round($TotalExpensesOwn['totalAmount'],2) ?? 0?></h4>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Ins - <?=$totalCheckinOwn['checkinCount'] ?? 0?></h4>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">Check Outs - <?=$totalChkOutOWN['checkOutCount'] ?? 0?></h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div><?php } ?>
          </div>

        </div>
      </div>
    </div>
  </div>
</div>

<script>
var ids = '';
// getdata(ids);
$(document).ready(function(){
    
    // Event listener for the button click
    $('#fetchDataBtn').click(function(){
      $("#fetchDataBtn").text('Please wait'); 
        $("#fetchDataBtn").prop('disabled', true);
        $("#dataContainer").prop('disabled', true);
        var id = $("#vendor_id").val();
        getdata(id);
    });
});
function getdata(id){
    $('#loader').removeClass('hidden')
        $.ajax({
            url: "<?php echo base_url('owner/Dashboard/get_ajax_data'); ?>",
            type: "POST",
            data:{id:id},
            dataType: "html",
            success: function(response){ 
              $("#fetchDataBtn").prop('disabled', false);
              $("#dataContainer").prop('disabled', false);
              $('#loader').addClass('hidden')
             $("#fetchDataBtn").text('View Detailed Reports');
              //$this.button('reset');
                //$('.loader').hide();
                if(response){
                    $('#dataContainer').html(response);
                } else {
                    $('#dataContainer').html('Failed to fetch data.');
                }
            },
            error: function(){
                $('#dataContainer').html('Error occurred while fetching data.');
            }
        });
}
</script>