<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<div class="main">
	<div class="bready">
		<ol class="breadcrumb">
			<li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
			<li><a href="<?=base_url('owner/guestcheckoutlist/index')?>" class=""><i class="lnr lnr-user"></i>Extend Stay</a></li>
			<li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITTASKDATA ? 'Edit' : 'Add' ?>
					Extend Stay</a></li>
		</ol>
	</div>
	<div class="main-content">
		<div class="container-fluid">
			<div class="panel panel-headline inr-form">
				<div class="panel-heading row">
					<h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Extend Stay</h3>
					<a href="<?=base_url('owner/guestcheckoutlist')?>/viewsummarydetails/<?= $custumId ?>" class="btn btn-default add_btn">Back</a>
				</div>
				<hr class="differ">
				<div class="panel">
					<div class="panel-body row">
						<form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="" enctype="multipart/form-data" autocomplete="off">
							<input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?= $EDITTASKDATA['encrypt_id'] ?>" />
							<input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITTASKDATA['detail_book_id'] ?>" />
							<input type="hidden" name="CustomerID" id="CustomerID" value="<?= $custId; ?>" />
							<input type="hidden" name="manager_name" id="manager_name" value="<?= $CUSTDATA['hotel_manager_name'];?>" />
							<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
							<fieldset>
								<legend>Extend Stay</legend>
								<div class="col-md-12 col-sm-12 col-xs-12 form-space">
					   
									<?php if($EDITTASKDATA ==''): ?>
									<div class="col-md-4 col-sm-12 col-xs-12">
										<div class="form-group">
											<label>Date</label>
											<input type="text" class="form-control select_date" name="select_date" value="<?php if (set_value('order_date')) : echo set_value('order_date');
																										   else : echo stripslashes($EDITTASKDATA['check_in_datetime']);  endif; ?>" placeholder="Pick the multiple dates">
										</div>
									</div>
									<?php endif; ?>
									<?php if($EDITTASKDATA !=''): ?>
										  <div class="col-md-3 col-sm-12 col-xs-12">
										<div class="form-group <?php if (form_error('room_rent')) : ?>error<?php endif; ?>">
											<label class="fancy-checkbox form-headings">Room Rent<span class="required">*</span></label>
											<input type="text" name="room_rent" id="room_rent" value="<?php if (set_value('room_rent')) : echo set_value('room_rent');
																										   else : echo stripslashes($EDITTASKDATA['advance_paid']);  endif; ?>" class="form-control required" placeholder="Room Rent">
											<?php if (form_error('room_rent')) : ?>
												<span for="room_rent" generated="true" class="help-inline"><?php echo form_error('room_rent'); ?></span>
											<?php endif; ?>
										</div>
									</div>
									<?php endif; ?>
								</div>
							</fieldset>
							<input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
							<button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
							<a href="<?=base_url('owner/guestcheckoutlist')?>/viewsummarydetails/<?= $custumId ?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
							<span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
									:- <strong><span style="color:#FF0000;">*</span> Indicates
										Required Fields</strong> </span>
							</span>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
	$('.select_date').datepicker({
		multidate: true,
		format: 'dd-mm-yyyy'
	});
</script>