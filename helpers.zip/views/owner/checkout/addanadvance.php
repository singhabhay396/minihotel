<div class="main">
    <div class="bready">
        <ol class="breadcrumb">
            <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
            <li><a href="<?=base_url('owner/guestcheckoutlist/index')?>" class=""><i class="lnr lnr-user"></i>Add An Advance</a></li>
            <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITTASKDATA ? 'Edit' : 'Add' ?>
                    An Advance</a></li>
        </ol>
    </div>
 
    <div class="main-content">
        <div class="container-fluid">
            <div class="panel panel-headline inr-form">
                <div class="panel-heading row">
                    <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> An Advance</h3>
                    <a href="<?=base_url('owner/guestcheckoutlist')?>/viewsummarydetails/<?= $custumId ?>" class="btn btn-default add_btn">Back</a>
                </div>
                <hr class="differ">
                <div class="panel">
                    <div class="panel-body row">
                        <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="" enctype="multipart/form-data" autocomplete="off">
                            <input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?= $EDITTASKDATA['encrypt_id'] ?>" />
                            <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITTASKDATA['detail_book_id'] ?>" />
                            <input type="hidden" name="CustomerID" id="CustomerID" value="<?= $custId ?>" />
                            <input type="hidden" name="manager_name" id="manager_name" value="<?= $CUSTDATA['hotel_manager_name'];?>" />
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                            <fieldset>
                                <legend>Add An Advance</legend>
                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">    
                                  <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                      <label class="fancy-checkbox form-headings">Order Date</label>
                                      <input type="datetime-local" name="order_date" id="order_date" value="" class="form-control" placeholder="Order Date">
                                      
                                    </div>
                                  </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">    
                                  <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                      <label class="fancy-checkbox form-headings">Amount Mode</label>
                                      <select name="amount_mode3" id="amount_mode3" class="form-control">
                                        <option value="offline">Offline (Cash)</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group <?php if (form_error('payment_paid')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Payment Paid</label>
                                      <input type="text" name="payment_paid3" id="payment_paid3" value="" class="form-control numberonly" placeholder="Payment Paid">
                                    </div>
                                  </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">    
                                  <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                      <label class="fancy-checkbox form-headings">Amount Mode</label>
                                      <select name="amount_mode2" id="amount_mode2" class="form-control">
                                        <option value="online">Online (Bank transfer, UPI, Paytm, Gpay, PhonePe)</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group <?php if (form_error('payment_paid')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Payment Paid</label>
                                      <input type="text" name="payment_paid2" id="payment_paid2" value="" class="form-control numberonly" placeholder="Payment Paid">
                                    </div>
                                  </div>
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">    
                                  <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                      <label class="fancy-checkbox form-headings">Amount Mode</label>
                                      <select name="amount_mode1" id="amount_mode1" class="form-control">
                                        <option value="prepaid">Prepaid</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                      <label class="fancy-checkbox form-headings">Payment Paid</label>
                                      <input type="text" name="payment_paid1" id="payment_paid1" value="" class="form-control numberonly" placeholder="Payment Paid">
                                    </div>
                                  </div>
                                </div>

                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">    
                                  <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                      <label class="fancy-checkbox form-headings">Amount Mode</label>
                                      <select name="amount_mode4" id="amount_mode4" class="form-control">
                                        <option value="BTC">Bill To Company (BTC)</option>
                                      </select>
                                    </div>
                                  </div>
                                  <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                      <label class="fancy-checkbox form-headings">Payment Paid</label>
                                      <input type="text" name="payment_paid4" id="payment_paid4" value="" class="form-control numberonly" placeholder="Payment Paid">
                                    </div>
                                  </div>
                                </div>
                                
                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                                </div>
                            </fieldset>
                            <input type="hidden" name="AddNewChanges" id="SaveChanges" value="Submit">
                            <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
                            <a href="<?=base_url('owner/guestcheckoutlist')?>/viewsummarydetails/<?= $custumId ?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
                            <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                                    :- <strong><span style="color:#FF0000;">*</span> Indicates
                                        Required Fields</strong> </span>
                            </span>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>