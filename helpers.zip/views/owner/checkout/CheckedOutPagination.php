<?php 
if ($ALLDATA != "") : $i = 1;
  foreach ($ALLDATA as $ALLDATAINFO) :
  ?>
    <tr class="<?php if ($i % 2 == 0) : echo 'odd'; else : echo 'even';endif; ?> gradeX">
      <td>
        <input type="checkbox" name="id" class="checkSingle" onclick="checkboxcount()" value="<?= $ALLDATAINFO['summary_book_id'] ?>"> 
      </td>
      <td><?= stripslashes($ALLDATAINFO['hotel_manager_name']) ?></td>
      <td><a target="_new" href="/owner/guestcheckoutlist/viewsummarydetails/<?= $ALLDATAINFO['encrypt_id'] ?>"><?= stripslashes($ALLDATAINFO['customer_name']) ?></a></td>
      <td><?= stripslashes($ALLDATAINFO['customer_mobile_number']) ?></td>
      <td><?= date('d-m-Y h:i A', strtotime($ALLDATAINFO['check_in_datetime'])) ?></td>
      <?php if ($ALLDATAINFO['check_out_datetime'] != "") : ?>
        <td><?= date('d-m-Y h:i a', strtotime($ALLDATAINFO['check_out_datetime'])) ?></td>
      <?php else : ?>
        <td>N/A</td>
      <?php endif; ?>
      <td><?= stripslashes($ALLDATAINFO['room_no']) ?></td>
      <td><?= stripslashes($ALLDATAINFO['entry_number']) ?></td>
      <td class="center">
        <div class="btn-group">
          <button class="btn dropdown-toggle" data-toggle="dropdown">More Options <span class="caret"></span></button>
          <ul class="dropdown-menu">
            <li><a href="javascript:void(0);" class="view-details-data" title="Hotel Guest Details" data-id="<?= $ALLDATAINFO['summary_book_id'] ?>" data-width="800"><i class="fa fa-asterisk"></i> View Details</a></li>
            <li><a href="<?=base_url('owner/guestcheckoutlist/editcheckout/'.$ALLDATAINFO['encrypt_id'])?>" ><i class="fa fa-edit"></i> Edit Details</a></li>
          </ul>
        </div>
      </td>
    </tr>
    <?php 
  endforeach;
  echo '<tr><td colspan="5" style="text-align:left;">'.$noOfContent.'</td>';
  echo '<td colspan="5" style="text-align:right;">'.$PAGINATION.'</td></tr>';
else : ?>
  <tr>
    <td colspan="10" style="text-align:center;">No Data Available In Table</td>
  </tr>
<?php endif; ?>