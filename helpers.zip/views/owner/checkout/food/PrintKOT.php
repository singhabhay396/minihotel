<?php
if($print_type=='A4'){
	$width = '595px';
}else{
	$width = '302px';
}
?>
<body onload="loadImage()">
	<style type="text/css">
		@media(max-width:786px) {table {width: 302px !important;}}
	</style>
	<table cellpadding="0" style="border:0px solid #b32521; " cellspacing="0" align="center" width="<?=$width?>">
		<tbody>
			<?php
			if(!empty($VENDORDATA['vendor_image'])){
				echo '<tr style="background:#fff; border-top: 1px solid #000;">
				      	<td style="text-align: center; "><img src="'.$VENDORDATA['vendor_image'].'" style="width: 100px;"></td>
				      </tr>';
			}
			?>
	 		
	    <tr style="background:#fff  ;">
	    	<td style="text-align: center;">
	    		<h2 style="font-size: 31px;font-family: poppins; margin: 0px;"><?=ucfirst($Restaurant['rest_name'])?></h2>
	    		<?php
	    		if($Restaurant['unit_of']){
	    			echo '<p style="margin-top: 0px;">A Unit of '.$Restaurant['unit_of'].'</p>';
	    		}
	    		?>
	    	</td>
	    </tr>
	    <tr style="background:#fff  ;">
	    	<td style="text-align: center;">
	      	<p style="font-size:13px;font-family: poppins;margin-top: 0px">
	      		<?=ucfirst($VENDORDETAIL['vendor_address'])?><br>
	      		Phone - <?=$VENDORDATA['first_manager_contact_number']?>
	      		<?php
	      		if($gst_type=='with_gst'){
		      		if($VENDORDETAIL['vendor_gst']){
		      			echo '<br>GSTIN - '.$VENDORDETAIL['vendor_gst'];
		      		}
	      		}
	      		?>
	      	</p>
	      </td>
	    </tr>
	  </tbody>
	</table>
	<table cellpadding="0" style="border:0px solid #b32521; " cellspacing="0" align="center" width="<?=$width?>">
		<tbody>
	  	<tr style="background:#fff; border-top: 1px solid #000;">
	    	<td style="text-align: left;" colspan="4">
	      	<p style="background: #fff;color: #000;padding: 2px;font-size: 12px;border-bottom: 2px solid #000;border-top: 2px solid #000;font-weight:400;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">NAME - <?=$CUSTDATA['customer_name']?></p>
	      </td>
	    </tr>
	    <tr>
	    	<td colspan="2">
	      	<p style="background: #fff;color: #000;padding: 2px;font-size: 12px;font-weight:400;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">
	      		Date - <?=date('d/m/Y H:i',strtotime($FoodData[0]['creation_date']))?> <br>
	      		KOT No.- <?=$FoodData[0]['kot_number']?> <br/>
	      		Bill No.- <?=$CUSTDATA['bill_number']?> <br/>
	      	</p>
	      </td>
	      <td colspan="2">
	      	<p style="background: #fff;color: #000;padding: 2px;font-size: 12px;font-weight:400;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">In Room Dine in <br>USER.- <?=$FoodData[0]['hotel_manager_name']?></p>
	      </td>
	    </tr>
	    <tr>
	    	<td>
	      	<p style="background: #fff; text-align:center; border:2px solid #000; color: #000;padding: 2px;font-size: 12px;font-weight:500;text-transform:uppercase;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">ITEMS</p>
	      </td>
	      <td>
	      	<p style="background: #fff; text-align:center; border:2px solid #000; color: #000;padding: 2px;font-size: 12px;font-weight:500;text-transform:uppercase;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">QTY</p>
	      </td>
	      <td>
	      	<p style="background: #fff; text-align:center; border:2px solid #000; color: #000;padding: 2px;font-size: 12px;font-weight:500;text-transform:uppercase;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">Price</p>
	      </td>
	      <td>
	      	<p style="background: #fff; text-align:center; border:2px solid #000; color: #000;padding: 2px;font-size: 12px;font-weight:500;text-transform:uppercase;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">Amount</p>
	      </td>
	    </tr>
	    <?php
	    $Total = 0;
	    foreach ($FoodData as $menu) {
	    	$Total += $menu['menu_price']*$menu['quantity'];
	    ?>
	      <tr>
	      	<td>
	        	<p style="background: #fff; text-align:center; border:2px solid #000; color: #000;padding: 2px;font-size: 12px;font-weight:500;text-transform:uppercase;font-family: poppins;margin-bottom: 0px;margin-top: 0px;"><?=$menu['bill_item']?></p>
	        </td>
	        <td>
	        	<p style="background: #fff; text-align:center; border:2px solid #000; color: #000;padding: 2px;font-size: 12px;font-weight:500;text-transform:uppercase;font-family: poppins;margin-bottom: 0px;margin-top: 0px;"><?=$menu['quantity']?></p>
	        </td>
	        <td>
	        	<p style="background: #fff; text-align:center; border:2px solid #000; color: #000;padding: 2px;font-size: 12px;font-weight:500;text-transform:uppercase;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">Rs <?=($menu['menu_price']/$menu['quantity'])?></p>
	        </td>
	        <td>
	        	<p style="background: #fff; text-align:center; border:2px solid #000; color: #000;padding: 2px;font-size: 12px;font-weight:500;text-transform:uppercase;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">Rs <?=$menu['menu_price']*$menu['quantity']?></p>
	        </td>
	      </tr>
	    <?php
			}
			if($gst_type=='with_gst'){
				$totalAmnt  = round($Total * 5) / 100;
	      //$TotalAmt  = $Total - $totalAmnt;
	      $TotalAmt  = $Total;
	      $cgst  = $totalAmnt / 2;
	      $sgst  = $totalAmnt / 2;
	      $GrandTotal  = $Total + $totalAmnt;
			}else{
				$TotalAmt  = $Total;
				$GrandTotal  = $Total;
			}
	    ?>
	  </tbody>
	</table>
	<table cellpadding="0" style="border:0px solid #b32521; " cellspacing="0" align="center" width="<?=$width?>">
		<tbody>
	    <?php
	    if($gst_type=='with_gst'){
	    ?>
	    	<tr style="background:#fff; border-top: 1px solid #000;">
	      	<td style="text-align: right;">
	        	<p style="background: #fff;color: #000;padding: 2px;font-size: 12px;font-weight:400;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">
	        		TOTAL: <?=$TotalAmt?>
	        	</p>
	        </td>
	      </tr>
	      <tr style="background:#fff; border-top: 1px solid #000;">
	      	<td style="text-align: right;">
	        	<p style="background: #fff;color: #000;padding: 2px;font-size: 12px;font-weight:400;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">CGST (2.5%): <?=$cgst?></p>
	        </td>
	      </tr>
	      <tr style="background:#fff; border-top: 1px solid #000;">
	      	<td style="text-align: right;">
	        	<p style="background: #fff;color: #000;padding: 2px;font-size: 12px;font-weight:400;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">SGST (2.5%): <?=$sgst?></p>
	        </td>
	     	</tr>
	   	<?php
	   	}
	   	?>
	    <tr style="background:#fff; border-top: 1px solid #000;">
	    	<td style="text-align: right;">
	      	<p style="background: #fff;color: #000;padding: 2px;font-size: 12px;font-weight:600;font-family: poppins;margin-bottom: 0px;margin-top: 0px; border-bottom: 2px solid;">GRAND TOTAL: <?=$GrandTotal?></p>
	      </td>
	    </tr>
	  </tbody>
	</table>
	<table cellpadding="0" cellspacing="0" align="center" width="302px">
		<tbody>
	  	<?php
			if($Restaurant['fssai_number']){
			?>	
		  	<tr style="background:#fff;  ">
		    	<td style="text-align:center;">
		      	<p style="background: #fff;color: #000;padding: 2px;font-size: 12px;font-weight:400;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">FSSAI NO. - <?=$Restaurant['fssai_number']?></p>
		      </td>
		    </tr>
		    <?php
			}
		    ?>
	   	<tr style="background:#fff; ">
	    	<td style="text-align:center;">
	      	<p style="background: #fff;color: #000;padding: 2px;font-size: 12px;font-weight:400;font-family: poppins;margin-bottom: 0px;margin-top: 0px;">THANK YOU FOR YOUR VISIT</p>
	      </td>
	    </tr>
	  </tbody>
	</table>
</body>
<script>
function loadImage() {
	window.print();
}
</script>