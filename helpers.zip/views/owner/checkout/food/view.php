<style>
a.btn.btn-default.add_btn_center {
  float: right;
  padding: 7px 30px !important;
  /*margin-left: 16px;*/
  font-size: 16px !important;
  color: #fff;
  background-color: #315bc2 !important;
  margin-right: 13px;
}
a.btn.btn-success.add_btn_center {
  float: right;
  padding: 7px 30px !important;
  font-size: 16px !important;
  margin-right: 13px;
}
</style>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?=base_url('owner/guestcheckoutlist/index')?>" class=""><i class="lnr lnr-user"></i>Summary Details</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Food Services Details</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="panel-title tab"> Food Services Details</h3>
        </div>
        <hr class="differ">
        <div class="row">  
          <div class="col-md-7">
            <div class="dash">
              <table class="table table-bordered">
                <thead>
                  <tr>
                    <th width="5%">Sr. No.</th>
                    <th width="10%">Item</th>
                    <th width="10%">QTY</th>
                    <th width="10%">Price</th>
                  </tr>
                </thead>
                <tbody> 
                  <?php
                  foreach ($FoodData as $key=>$row) {
                    ?>
                      <tr>
                        <td><?=$key+1?></td>
                        <td><?=$row['bill_item']?></td>
                        <td><?=$row['quantity']?></td>
                        <td><?=$row['menu_price']?></td>
                      </tr>
                    <?php
                  }
                  ?>
                  <tr>
                    <td colspan="5">
                      <select name="print_type" id="print_type">
                        <option value="A4">A4</option>
                        <option value="POS">POS</option>
                      </select>
                      <select name="gst_type" id="gst_type">
                        <option value="with_gst">With GST</option>
                        <option value="without_gst">Without GST</option>
                      </select>
                      <a href="javascript:void(0)" onclick="PrintKOT()" style="float: none;" class="btn btn-default add_btn">Print</a>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
  function PrintKOT() {
    var baseUrl = "<?php echo base_url('owner/guestcheckoutlist/')?>";
    var print_type = $('#print_type').val();
    var gst_type = $('#gst_type').val();
    var hotel_manager_id = '<?php echo $hotel_manager_id; ?>';
    location.href = baseUrl+"/PrintKOT?kot_number=<?=base64_encode($kot_number)?>&print_type="+print_type+"&gst_type="+gst_type+"&hotel_manager_id="+hotel_manager_id;
  }
</script>