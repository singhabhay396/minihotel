<fieldset>
	<legend>Food Menu</legend>
	<?php
		if($MenuArr){
	    foreach ($MenuArr as $Result) {
	    ?>
	      <div class="col-md-2 col-sm-3 col-xs-6">
	        <div class="card card-even" style="background-color: #0047AB;">
	          <div class="card-content bg-3"> 
	            <a href="javascript:void(0)" onclick="AddToCardMenu('<?=$Result['id']?>')" title="<?=$Result['menu_name']?>">
	              <div class="media align-items-stretch">
	                <div class="p-2 bg-gradient-x-primary white media-body">
	                  <h5 style="text-transform: capitalize;"><strong><?=$Result['menu_name']?></strong></h5>
	                  <h5 style="text-transform: capitalize;"><i class="fa fa-inr"></i><strong><?=$Result['price']?></strong></h5>
	                </div>
	              </div>
	            </a> 
	          </div>
	        </div>
	      </div> 
	    <?php  
	    }
	  }
    ?>
</fieldset>