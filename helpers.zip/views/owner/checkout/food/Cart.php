<fieldset>
	<legend>Food Menu</legend>
	<div class="col-md-12 col-sm-12 col-xs-12">
		<table class="table table-bordered">
			<thead>
        <tr>
          <th width="6%">Item</th>
          <th width="10%">QTY</th>
          <th width="5%">Price</th>
          <th width="5%">Delete</th>
        </tr>
      </thead>
      <tbody>
      	<?php
      	if($MenuArr){
      		$TotalAmount = 0;
      		foreach ($MenuArr as $row) {
      			$TotalAmount+=$row['price']*$row['qty'];
      	?>
	      	<tr>
	      		<td><?=$row['menu_name']?> (<i class="fa fa-inr"></i><?=$row['price']?>)</td>
	      		<td>
	      			<a href="javascript:void(0)" onclick="descreaseqty(<?=$row['id']?>)">
	      				<i class="fa fa-minus text-danger ms-2"></i>
	      			</a>
		          <input type="tel" value="<?=$row['qty']?>" size="4" min="1" max="4" readonly="" id="qty_<?=$row['id']?>">
	      			<a href="javascript:void(0)" onclick="increaseqty(<?=$row['id']?>)">
		          	<i class="fa fa-plus text-success me-2"></i>
		          </a>
	      		</td>
	      		<td><i class="fa fa-inr"></i><?=$row['price']*$row['qty']?></td>
	      		<td><a style="color: red;" href="javascript:void(0)" onclick="DeleteItem(<?=$row['id']?>)"><i class="fa fa-trash"></i></a></td>
	      	</tr>
      	<?php
      		}
      		$GSTAmt  	= round($TotalAmount * 5) / 100;
          $cgst  		= $GSTAmt / 2;
          $sgst  		= $GSTAmt / 2;
      		?>
      			<tr>
      				<td colspan="4">
      					<a href="javascript:void(0)" onClick="AddATableModal('<?=base64_encode($customer_id)?>','<?=$TotalAmount?>','<?=$GSTAmt?>','<?=$cgst?>','<?=$sgst?>')" class="btn btn-default add_btn">Save KOT</a>
      				</td>
      			</tr>
      		<?php
      	}else{
      		?>
      			<tr>
      				<td colspan="4"> <center> <strong style="color:red">No Data Found</strong> </center> </td>
      			</tr>
      		<?php
      	}
      	?>
      </tbody>
		</table>
	</div>
</fieldset>