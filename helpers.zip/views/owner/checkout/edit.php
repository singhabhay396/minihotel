<style>
.toshow {display: none;}
</style>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link href="https://raw.githack.com/ttskch/select2-bootstrap4-theme/master/dist/select2-bootstrap4.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>

<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?=base_url('owner/guestcheckoutlist')?>" class=""><i class="lnr lnr-user"></i>Checked-Out Customers</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i>Edit Summary Book</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab">Edit Summary Book</h3>
          <a href="<?=base_url('owner/guestcheckoutlist')?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="" enctype="multipart/form-data">
              <input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?= $EDITDATA['encrypt_id'] ?>" />
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['summary_book_id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>Guest details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group <?php if (form_error('customer_name')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Guest Name<span class="required">*</span></label>
                      <input type="text" name="customer_name" id="customer_name" value="<?=stripslashes($EDITDATA['customer_name'])?>" class="form-control required" placeholder="Guest Name">
                      <?php if (form_error('customer_name')) : ?>
                        <span for="customer_name" generated="true" class="help-inline"><?php echo form_error('customer_name'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group <?php if (form_error('customer_email')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Email</label>
                      <input type="text" name="customer_email" id="customer_email" value="<?=stripslashes($EDITDATA['customer_email'])?>" class="form-control email" placeholder="Email">
                      <?php if (form_error('customer_email')) : ?>
                        <span for="customer_email" generated="true" class="help-inline"><?php echo form_error('customer_email'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group <?php if (form_error('customer_mobile_number')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Phone<span class="required">*</span></label>
                      <input type="text" name="customer_mobile_number" id="customer_mobile_number" value="<?=stripslashes($EDITDATA['customer_mobile_number'])?>" class="form-control required" placeholder="Phone">
                      <?php if (form_error('customer_mobile_number')) : ?>
                        <span for="customer_mobile_number" generated="true" class="help-inline"><?php echo form_error('customer_mobile_number'); ?></span>
                      <?php endif;
                      if ($mobileerror) : ?>
                        <span for="customer_mobile_number" generated="true" class="help-inline"><?php echo $mobileerror; ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="form-group <?php if (form_error('check_in_datetime')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Check-in Date & Time<span class="required">*</span></label>
                      <input type="datetime-local" name="check_in_datetime" id="check_in_datetime" value="<?=stripslashes($EDITDATA['check_in_datetime'])?>" class="form-control required" placeholder="Check-in Date Time">
                      <?php if (form_error('check_in_datetime')) : ?>
                        <span for="check_in_datetime" generated="true" class="help-inline"><?php echo form_error('check_in_datetime'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="form-group <?php if (form_error('check_out_datetime')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Check-out Date & Time<span class="required">*</span></label>
                      <input type="datetime-local" name="check_out_datetime" id="check_out_datetime" value="<?=stripslashes($EDITDATA['check_out_datetime'])?>" class="form-control required" placeholder="Check-out Date Time">
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Hourly Check Out</label>
                      <select name="hourly_check_out_id" id="hourly_check_out_id" class="form-control">
                        <option value="0">Hourly Check Out</option>
                        <?php
                        foreach ($HourlyCheckOutArr as $HourlyCheckOut){
                          $selected = '';  
                          if ($EDITDATA['hourly_check_out_id'] == $HourlyCheckOut['id']){
                            $selected = 'selected';  
                          }
                          echo '<option value="'.$HourlyCheckOut['id'].'" '.$selected.'>'.$HourlyCheckOut['hourly'].'</option>';
                        }
                        ?>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="form-group <?php if (form_error('amount')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Room Rent<span class="required">*</span></label>
                      <input type="text" name="amount" id="amount" value="<?=stripslashes($EDITDATA['amount'])?>" class="form-control required numberonly" placeholder="Room Rent">
                      <?php if (form_error('amount')) : ?>
                          <span for="amount" generated="true" class="help-inline"><?php echo form_error('amount'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group <?php if (form_error('room_rent_type')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Is Room Rent exclusive of GST or inclusive?</label>
                      <select name="room_rent_type" id="room_rent_type" class="form-control">
                        <option value="">Select Mode</option>
                        <option value="gst_include" <?php if ($EDITDATA['room_rent_type'] == 'gst_include') : echo "selected"; endif; ?>>Inclusive</option>
                        <option value="gst_exclude" <?php if ($EDITDATA['room_rent_type'] == 'gst_exclude') : echo "selected"; endif; ?> selected>Exclusive</option>
                      </select>
                      <?php if (form_error('room_rent_type')) : ?>
                        <span for="room_rent_type" generated="true" class="help-inline"><?php echo form_error('room_rent_type'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Choose Plan</label>
                      <select name="choose_plan" id="choose_plan" class="form-control">
                        <option value="">Select Plan</option>
                        <option value="EP" <?php if ($EDITDATA['choose_plan'] == 'EP') : echo "selected"; endif; ?>>EP</option>
                        <option value="CP" <?php if ($EDITDATA['choose_plan'] == 'CP') : echo "selected"; endif; ?>>CP</option>
                        <option value="MAP" <?php if ($EDITDATA['choose_plan'] == 'MAP') : echo "selected"; endif; ?>>MAP</option>
                        <option value="AP" <?php if ($EDITDATA['choose_plan'] == 'AP') : echo "selected"; endif; ?>>AP</option>
                      </select>
                    </div>
                  </div>
                  <?php 
                  $delQuery = "SELECT room_id,room_no FROM " . getTablePrefix() . "room_number WHERE room_id = '" . $EDITDATA['assign_room_number'] . "' AND hotel_manager_id = '" . $hotel_manager_id . "'";
                  $roomNumber = $this->common_model->getDataByQuery('single', $delQuery);
                  ?>
                  <div class="col-md-3 col-sm-12 col-xs-12">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Selected Room</label>
                      <input type="text" value="<?php echo stripslashes($roomNumber['room_no']); ?>" class="form-control" readonly>
                    </div>
                  </div>
                  <div class="col-md-2 col-sm-12 col-xs-12">
                                  <?php
                                  if ($EDITDATA == '') :
                                      $CURRENTENTRYNUMBER = $this->common_model->getDataByParticularField('vendor_details', 'vendor_id', sessionData('MHM_VENDOR_ID'));
                                      $entryNumber = $CURRENTENTRYNUMBER['entry_number'] + 1;
                                  endif;
                                  ?>
                                  <div class="form-group <?php if (form_error('entry_number')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">GRC No.<span class="required">*</span></label>
                                      <input type="text" name="entry_number" id="entry_number" value="<?php if (!empty($entryNumber)) : echo $entryNumber;  else : echo stripslashes($EDITDATA['entry_number']);                                                                                                      endif; ?>" class="form-control required" placeholder="GRC No.">
                                      <?php if (form_error('entry_number')) : ?>
                                          <span for="entry_number" generated="true" class="help-inline"><?php echo form_error('entry_number'); ?></span>
                                      <?php endif;
                                      if ($entryNumbererror) : ?>
                                          <span for="entry_number" generated="true" class="help-inline"><?php echo $entryNumbererror; ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                              <div class="col-md-2 col-sm-12 col-xs-12">
                                  <div class="form-group <?php if (form_error('number_of_person')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Number Of Persons<span class="required">*</span></label>
                                      <input type="text" name="number_of_person" id="number_of_person" value="<?php if (set_value('number_of_person')) : echo set_value('number_of_person');
                                                                                                              else : echo stripslashes($EDITDATA['number_of_person']);
                                                                                                              endif; ?>" class="form-control number required" placeholder="Number Of Persons">
                                      <?php if (form_error('number_of_person')) : ?>
                                          <span for="number_of_person" generated="true" class="help-inline"><?php echo form_error('number_of_person'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                              <div class="col-md-2 col-sm-12 col-xs-12">
                                <div class="form-group <?php if (form_error('age')) : ?>error<?php endif; ?>">
                                  <label class="fancy-checkbox form-headings">Age</label>
                                  <input type="text" name="age" id="age" value="<?php if (set_value('age')) : echo set_value('age'); else : echo stripslashes($EDITDATA['age']); endif; ?>" class="form-control number" placeholder="Age">
                                </div>
                              </div>
                              
                              <div class="col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group <?php if (form_error('person_address')) : ?>error<?php endif; ?>">
                                  <label class="fancy-checkbox form-headings">Address</label>
                                  <textarea name="person_address" id="person_address" class="form-control"cols="80" rows="3"><?php if (set_value('person_address')) : echo set_value('person_address'); else : echo stripslashes($EDITDATA['person_address']); endif; ?></textarea>
                                </div>
                              </div>
                              <div class="col-md-6 col-sm-12 col-xs-12">
                                <div class="form-group <?php if (form_error('other_person_details')) : ?>error<?php endif; ?>">
                                  <label class="fancy-checkbox form-headings">Other Person Details</label>
                                  <textarea name="other_person_details" id="other_person_details" class="form-control" cols="80" rows="3"><?php if (set_value('other_person_details')) : echo set_value('other_person_details'); else : echo stripslashes($EDITDATA['other_person_details']); endif; ?></textarea>
                                </div>
                              </div>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                              <div class="col-md-4 col-sm-12 col-xs-12">
                                  <div class="form-group <?php if (form_error('reffer_mode')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Booking Mode</label>
                                      <select name="reffer_mode" id="reffer_mode" class="form-control">
                                          <option value="">Select Mode</option>
                                          <option value="online" <?php if ($EDITDATA['reffer_mode'] == 'online') : echo "selected";
                                                                  endif; ?>>Online Platform</option>
                                          <option value="offline" <?php if ($EDITDATA['reffer_mode'] == 'offline') : echo "selected";
                                                                  endif; ?>>Direct</option>
                                      </select>
                                      <?php if (form_error('reffer_mode')) : ?>
                                          <span for="reffer_mode" generated="true" class="help-inline"><?php echo form_error('reffer_mode'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>

                              <div class="col-md-4 col-sm-12 col-xs-12">
                                  <div class="form-group <?php if (form_error('reffer_mode')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Booking ID</label>
                                      <input type="text" name="booking_id" id="booking_id" value="<?php if (set_value('booking_id')) : echo set_value('booking_id'); else : echo stripslashes($EDITDATA['booking_id']); endif; ?>" class="form-control" placeholder="Booking Id">
                                  </div>
                              </div>

                              <div class="col-md-4 col-sm-12 col-xs-12" id="directMode" style="display:none">
                                  <div class="form-group <?php if (form_error('direct_mode')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Direct Mode</label>
                                      <select name="direct_mode" id="direct_mode" class="form-control">
                                          <option value="">Select Mode</option>
                                          <option value="commission" <?php if ($EDITDATA['direct_mode'] == 'commission') : echo "selected";
                                                                      endif; ?>>Commission</option>
                                          <option value="non_commission" <?php if ($EDITDATA['direct_mode'] == 'non_commission') : echo "selected";
                                                                          endif; ?>>No commission</option>
                                      </select>
                                      <?php if (form_error('direct_mode')) : ?>
                                          <span for="direct_mode" generated="true" class="help-inline"><?php echo form_error('direct_mode'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                              <div class="col-md-4 col-sm-12 col-xs-12" id="otsMode" style="display:none">
                                  <div class="form-group <?php if (form_error('ots_id')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Booking Platform</label>
                                      <?php if (set_value('ots_id')) : $assignroomId = set_value('ots_id');
                                      elseif ($EDITDATA['ots_id']) : $assignroomId = stripslashes($EDITDATA['ots_id']);
                                      else : $assignroomId = '';
                                      endif; ?>
                                      <select name="ots_id" id="ots_id" class="form-control">
                                          <?php echo $this->vendor_model->getAllOtsByHotelId($assignroomId); ?>
                                      </select>
                                      <?php if (form_error('ots_id')) : ?>
                                          <span for="ots_id" generated="true" class="help-inline"><?php echo form_error('ots_id'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                              <div class="col-md-4 col-sm-12 col-xs-12" id="howMuchCommision" style="display:none">
                                  <div class="form-group <?php if (form_error('commission_amount')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">How Much Commission</label>
                                      <input type="text" name="commission_amount" id="commission_amount" value="<?php if (set_value('commission_amount')) : echo set_value('commission_amount');
                                                                                                                  else : echo stripslashes($EDITDATA['commission_amount']);
                                                                                                                  endif; ?>" class="form-control" placeholder="How Much Commission">
                                      <?php if (form_error('commission_amount')) : ?>
                                          <span for="commission_amount" generated="true" class="help-inline"><?php echo form_error('commission_amount'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                              <div class="col-md-4 col-sm-12 col-xs-12">
                                  <div class="form-group <?php if (form_error('online_mode')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Payment Details</label>
                                      <select name="amount_mode" id="amount_mode" class="form-control">
                                          <option value="">Select Mode</option>
                                          <option value="prepaid" <?php if ($EDITTASKDATA['amount_mode'] == 'prepaid') : echo "selected";
                                                                  endif; ?>>Prepaid</option>
                                          <option value="online" <?php if ($EDITTASKDATA['amount_mode'] == 'online') : echo "selected";
                                                                  endif; ?>>Online (Bank transfer, UPI, Paytm, Gpay, PhonePe)</option>
                                          <option value="offline" <?php if ($EDITTASKDATA['amount_mode'] == 'offline') : echo "selected";
                                                                  endif; ?>>Offline (Cash)</option>
                                      </select>
                                      <?php if (form_error('online_mode')) : ?>
                                          <span for="online_mode" generated="true" class="help-inline"><?php echo form_error('online_mode'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                              <div class="col-md-4 col-sm-12 col-xs-12">
                                  <div class="form-group <?php if (form_error('prepaid_amount')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">How Much Amount</label>
                                      <input type="text" name="prepaid_amount" id="prepaid_amount" value="<?php if (set_value('prepaid_amount')) : echo set_value('prepaid_amount');
                                                                                                          else : echo stripslashes($EDITDATA['prepaid_amount']);
                                                                                                          endif; ?>" class="form-control" placeholder="How Much Amount">
                                      <?php if (form_error('prepaid_amount')) : ?>
                                          <span for="prepaid_amount" generated="true" class="help-inline"><?php echo form_error('prepaid_amount'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                              <div class="col-md-12 col-sm-12 col-xs-12">
                                  <div class="form-group <?php if (form_error('remarks')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Extra Remarks</label>
                                      <textarea name="remarks" class="form-control" id="remarks" cols="80" rows="3"><?php echo stripslashes($EDITDATA['remarks']);
                                                                                                                      ?></textarea>
                                      <?php if (form_error('remarks')) : ?>
                                          <span for="remarks" generated="true" class="help-inline"><?php echo form_error('remarks'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                              <div class="col-md-3 col-sm-4 col-xs-4">
                                  <div class="form-group <?php if (form_error('gst_number')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Select GSTIN</label>
                                      <?php if (set_value('gst_number')) : $assignCompanyId = set_value('company_name');
                                      elseif ($EDITDATA['gst_number']) : $assignCompanyId = stripslashes($EDITDATA['gst_number']);
                                      else : $assignCompanyId = '';
                                      endif; ?>
                                      <select name="gst_number" id="gst_number" class="form-control mySelect2" onchange="GetCompany()">
                                          <?php echo $this->vendor_model->getAllCompanyByHotelId($assignCompanyId); ?>
                                      </select>
                                      <?php if (form_error('gst_number')) : ?>
                                          <span for="gst_number" generated="true" class="help-inline"><?php echo form_error('gst_number'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                              <div class="col-md-4 col-sm-4 col-xs-4">
                                  <div class="form-group <?php if (form_error('company_name')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Company Name</label>
                                      <input type="text" name="company_name" id="company_name" value="<?php if (set_value('company_name')) : echo set_value('company_name');
                                                                                                      else : echo stripslashes($EDITDATA['company_name']);
                                                                                                      endif; ?>" class="form-control" placeholder="Company Name" readonly>
                                      <?php if (form_error('company_name')) : ?>
                                          <span for="company_name" generated="true" class="help-inline"><?php echo form_error('company_name'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                              <div class="col-md-4 col-sm-4 col-xs-4">
                                  <div class="form-group <?php if (form_error('company_address')) : ?>error<?php endif; ?>">
                                      <label class="fancy-checkbox form-headings">Company Address</label>
                                      <input type="text" name="company_address" id="company_address" value="<?php if (set_value('company_address')) : echo set_value('company_address');
                                                                                                              else : echo stripslashes($EDITDATA['company_address']);
                                                                                                              endif; ?>" class="form-control" placeholder="Company Address" readonly>
                                      <?php if (form_error('company_address')) : ?>
                                          <span for="company_address" generated="true" class="help-inline"><?php echo form_error('company_address'); ?></span>
                                      <?php endif; ?>
                                  </div>
                              </div>
                          </div>
                      </fieldset>
                      <fieldset>
                          <legend>Identity Proof</legend>
                          <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                              <div class="form-group-inner col-lg-4 col-md-4 col-sm-12 col-xs-12 <?php if (form_error('type_of_trans_id')) : ?>error<?php endif; ?>">
                                  <label>Upload Multiple Document <span class="">(In .jpg, .png,.jpeg
                                          etc)</span></label>
                                  <input type="file" name="uploadfile[]" id="uploadfile" multiple="multiple" class="upfile-space" />
                                  <?php if (form_error('uploadfile[]')) : ?>
                                      <label for="uploadfile[]" generated="true" class="error"><?php echo form_error('uploadfile[]'); ?></label>
                                  <?php endif; ?>
                                  <?php if ($DOCUDATA) : $i = 10;
                                      foreach ($DOCUDATA as $CONTENTINFO) :
                                  ?>
                                          <span id="uploadcontent<?php echo $i; ?>">
                                              <img src="<?php echo base_url() . correctImage(stripslashes($CONTENTINFO['doc_url']), 'original') ?>" width="100" border="0" alt="" /> <a href="javascript:void(0);" onClick="DeleteContent('<?php echo stripslashes($CONTENTINFO['doc_url']) ?>','<?php echo $i; ?>');">
                                                  <img src="<?php echo base_url() ?>assets/admin/images/cross.png" border="0" alt="" /> </a>
                                          </span><br />
                                          <a href="<?php echo base_url() . correctImage(stripslashes($CONTENTINFO['doc_url']), 'original') ?>" target="_blank">View File</a>
                                  <?php $i++;
                                      endforeach;
                                  endif; ?>
                              </div>
                          </div>
                      </fieldset>
                      <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
                      <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
                      <a href="<?php echo correctLink('summaryBookVendorData', '{VENDOR_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
                      <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                              :- <strong><span style="color:#FF0000;">*</span> Indicates
                                  Required Fields</strong> </span>
                      </span>
                  </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
  $(function() {
    UploadImage('0');
    UploadImage('1');
    UploadImage('2');
  });
</script>
<!---------------------------->
<script type="text/javascript">
  $('#reffer_mode').on('change', function() {
    var reffer_mode = $(this).val();
    if (reffer_mode == 'offline') {
      $('#currentPageForm #directMode').show();
      $('#currentPageForm #onlineMode').show();
      $('#currentPageForm #howMuchPrepaid').show();
      $('#currentPageForm #otsMode').hide();
    } else if (reffer_mode == 'online') {
      $('#currentPageForm #otsMode').show();
      $('#currentPageForm #onlineMode').show();
      $('#currentPageForm #directMode').hide();
      $('#currentPageForm #howMuchCommision').hide();
    }
  });
  <?php if ($EDITDATA != "" || $_POST) : ?>
    var reffer_mode = '<?php echo $EDITDATA['reffer_mode']; ?>';
    if (reffer_mode == 'offline') {
      $('#currentPageForm #directMode').show();
      $('#currentPageForm #onlineMode').show();
      $('#currentPageForm #howMuchPrepaid').show();
      $('#currentPageForm #otsMode').hide();
    } else if (reffer_mode == 'online') {
      $('#currentPageForm #otsMode').show();
      $('#currentPageForm #onlineMode').show();
      $('#currentPageForm #directMode').hide();
    }
    <?php endif; ?>
    // How Mush Commision in Direct Mode
    $('#direct_mode').on('change', function() {
      var direct_mode = $(this).val();
      if (direct_mode == 'commission') {
        $('#currentPageForm #howMuchCommision').show();
        $('#currentPageForm #howMuchPrepaid').show();
      } else if (direct_mode == 'non_commission') {
        $('#currentPageForm #howMuchCommision').hide();
        $('#currentPageForm #howMuchPrepaid').show();
      }
    });
    <?php if ($EDITDATA != "" || $_POST) : ?>
      var direct_mode = '<?php echo $EDITDATA['direct_mode']; ?>';
      if (direct_mode == 'commission') {
        $('#currentPageForm #howMuchCommision').show();
        $('#currentPageForm #howMuchPrepaid').show();
      } else if (direct_mode == 'non_commission') {
        $('#currentPageForm #howMuchCommision').hide();
        $('#currentPageForm #howMuchPrepaid').show();
      }
    <?php endif; ?>
    // How Mush Commision in Online Mode
    $('#online_mode').on('change', function() {
      var online_mode = $(this).val();
      if (online_mode == 'prepaid') {
        $('#currentPageForm #howMuchPrepaid').show();
        $('#currentPageForm #howMuchCommision').hide();
      } else if (online_mode == 'cash_at_hotel') {
        $('#currentPageForm #howMuchPrepaid').show();
        $('#currentPageForm #howMuchCommision').hide();
      }
    });
    <?php if ($EDITDATA != "" || $_POST) : ?>
      var online_mode = '<?php echo $EDITDATA['online_mode']; ?>';
      if (online_mode == 'prepaid') {
        $('#currentPageForm #howMuchPrepaid').show();
        $('#currentPageForm #howMuchCommision').hide();
      } else if (online_mode == 'cash_at_hotel') {
        $('#currentPageForm #howMuchPrepaid').show();
        $('#currentPageForm #howMuchCommision').hide();
      }
    <?php endif; ?>
    //////////////////////////////////   Content delete Through Ajax
    function DeleteContent(contentname, contentcount) {
      if (confirm("Sure to delete?")) {
        $.ajax({
            type: 'post',
            url: '<?=base_url('owner/guestcheckoutlist/DeleteContent')?>',
            data: {contentname: contentname},
            success: function(response) {
              document.getElementById('uploadcontent' + contentcount).innerHTML = '';
            }
        });
      }
    }
    function GetCompany() {
      var companyName = $('#gst_number :selected').val();
      $.ajax({
        type: 'post',
        url: '<?=base_url('owner/guestcheckoutlist/GetDetailsByCompanyName')?>',
        data: {companyName: companyName},
        success: function(response) {
          var obj = jQuery.parseJSON(response);
          //alert(obj.company_gst);
          $("#company_name").val(obj.company_name);
          $("#company_address").val(obj.company_address);
          //document.getElementById('uploadcontent' + contentcount).innerHTML = '';
        }
      });
    }
    $('.mySelect2').select2({
      selectOnClose: true
    });

    $('#addGSTNModal').on('submit', function(e) {
      e.preventDefault();
      //console.log("submitted");
      $.ajax({
        type: 'POST',
        url: $(this).attr("action"),
        data: $(this).serialize(),
        success: function(response) {
          var obj = response;
          if (obj.formError == 'No') {
            var newOption = new Option(obj.company.company_gst, obj.company.company_gst, true, true);
            $('#gst_number').append(newOption).trigger('change');
            $('#addGSTNModal').modal("hide");
          }
        }
      });
    });
</script>