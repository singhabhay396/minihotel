<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITTASKDATA ? 'Edit' : 'Add' ?> A Service  </h3>
          <a href="<?=base_url('owner/guestcheckoutlist')?>/viewsummarydetails/<?= $custumId ?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="" enctype="multipart/form-data" autocomplete="off">
              <input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?= $EDITTASKDATA['encrypt_id'] ?>" />
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITTASKDATA['detail_book_id'] ?>" />
              <input type="hidden" name="CustomerID" id="CustomerID" value="<?= $custId ?>" />
              <input type="hidden" name="manager_name" id="manager_name" value="<?= $CUSTDATA['hotel_manager_name'];?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>Add A Service</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Bill Items<span class="required">*</span></label>
                      <input type="text" name="bill_items" id="bill_items" value="<?php if (set_value('bill_items')) : echo set_value('bill_items'); else : echo stripslashes($EDITTASKDATA['bill_item']); endif; ?>" class="form-control required" placeholder="Bill Items">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Total Amount<span class="required">*</span></label>
                      <input type="text" name="total_amt" id="total_amt" value="<?php if (set_value('total_amt')) : echo set_value('total_amt'); else : echo stripslashes($EDITTASKDATA['advance_paid']); endif; ?>" class="form-control required" placeholder="Total Amount">
                    </div>
                  </div>
                </div>
              </fieldset>
              
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="<?=base_url('owner/guestcheckoutlist')?>/viewsummarydetails/<?= $custumId ?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                  :- <strong><span style="color:#FF0000;">*</span> Indicates
                    Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  $(function() {
    var scntDiv = $('#currentPageForm #FilterDefault');
    var i = $('#currentPageForm #FilterDefault > span').size();
    $(document).on('click', '#currentPageForm .addMoreFilterDetails', function() {
      i++;
      $('<hr style="border-top: 1px solid !important;border: dotted;"><span><input type="hidden" name="filter_details_id_' + i + '" id="filter_details_id_' + i + '" class="form-control" value="" /><div class="col-md-12 col-sm-12 col-xs-12 form-space"> <div class="col-md-6 col-sm-12 col-xs-12"> <div class="form-group <?php if (form_error('service_id')) : ?>error<?php endif; ?>"> <label class="fancy-checkbox form-headings">Select Item ('+i+')<span class="required">*</span></label> <select name="service_id_'+i+'" id="service_id_'+i+'" class="form-control select2 <?php if ($EDITTASKDATA['service_id'] == '') : echo "required"; endif; ?>"> <?php echo $this->vendor_model->getAllServicesByHotelId($assignroomId); ?> </select> <?php if (form_error('service_id')) : ?> <span for="service_id" generated="true" class="help-inline"><?php echo form_error('service_id'); ?></span> <?php endif; ?> </div> </div> <div class="col-md-4 col-sm-12 col-xs-12"> <div class="form-group <?php if (form_error('quantity')) : ?>error<?php endif; ?>"> <label class="fancy-checkbox form-headings">Quantity ('+i+')<span class="required">*</span></label> <input type="text" name="quantity_'+i+'" id="quantity_'+i+'" value="<?php if (set_value('quantity')) : echo set_value('quantity'); else : echo stripslashes($EDITTASKDATA['quantity']); endif; ?>" class="form-control numberonly required" placeholder="Quantity"> <?php if (form_error('quantity')) : ?> <span for="quantity" generated="true" class="help-inline"><?php echo form_error('quantity'); ?></span> <?php endif; ?> </div> </div> </div><br/><div class="form-group"><a href="javascript:void(0);" class="removeMoreFilterDetails pull-right"></br>-Remove Item</a></div></span>').appendTo(scntDiv);
      $('#currentPageForm #TotalFilterDefault').val(i);
      return false;
    });
    $(document).on('click', '#currentPageForm .removeMoreFilterDetails', function() {
      if (i > 1) {
        $(this).parents('span').remove();
        i--;
      }
      return false;
    });
  });
</script>