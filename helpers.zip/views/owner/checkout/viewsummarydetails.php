<?php
$unbilledRentDays = [];
if ($checkCheckInOut == '') {
    $billedRentDays = [];
    if ($ALLDATA <> "") {
        foreach ($ALLDATA as $d) { 
            if (strpos($d['bill_item'], "Room Rent") !== FALSE) {
                preg_match('#\((.*?)\)#', $d['bill_item'], $match);
                $billedRentDays[] = $match[1];
            }
        }
    }
    $tmpDay = explode("/", min($billedRentDays));
    $startDay = strtotime($tmpDay[2] . "-" . $tmpDay[1] . "-" . $tmpDay[0] . " 13:00:00");
    //echo '<pre>';print_r($startDay);die();

    while ($startDay < strtotime(date("Y-m-d H:i:s"))) { 
        //$hotel_manager_id = sessionData('MHM_VENDOR_ID');
        $customer_id = $CUSTDATA['summary_book_id'];
        $bill_item = "Room Rent (" . date('d/m/Y', $startDay) . ")";
        $result = $this->db->query("SELECT id FROM " . getTablePrefix() . "customer_summary_details_deleted" . " WHERE hotel_manager_id = ? AND customer_id = ? AND bill_item = ? ", array($hotel_manager_id, $customer_id, $bill_item));

        if (!$result->num_rows() && !in_array(date("d/m/Y", $startDay), $billedRentDays)) {
            $unbilledRentDays[date("d-m-Y", $startDay)] = date("d/m/Y", $startDay);
        }
        $startDay = strtotime("+1 day", $startDay);
    }
}

//echo '<pre>';echo count($unbilledRentDays);die();

?>
<style>
    a.btn.btn-default.add_btn_center {
        float: right;
        padding: 7px 30px !important;
        /*margin-left: 16px;*/
        font-size: 16px !important;
        color: #fff;
        background-color: #315bc2 !important;
        margin-right: 13px;
    }

    a.btn.btn-success.add_btn_center {
        float: right;
        padding: 7px 30px !important;
        font-size: 16px !important;
        margin-right: 13px;
    }
</style>
<div class="main">
    <div class="bready">
        <ol class="breadcrumb">
            <li><a href="<?=base_url('owner/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
            <li><a href="<?=base_url('owner/guestcheckoutlist/index')?>" class=""><i class="lnr lnr-user"></i>Summary Details</a></li>
            <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Edit Summary Book Details</a></li>
        </ol>
    </div>
    <div class="main-content">
        <div class="container-fluid">
            <div class="panel panel-headline">
                <div class="panel-heading row">
                    <h3 class="panel-title tab">View Summary Book Details</h3>
                    <a href="<?=base_url('owner/dashboard')?>" class="btn btn-default add_btn">Back</a>
                    <?php //if ($checkCheckInOut == '') : ?>
                    <a href="/owner/guestcheckoutlist/viewsummarydetails/<?= $ALLDATAINFO['encrypt_id'] ?>"><?= stripslashes($ALLDATAINFO['customer_name']) ?></a>
                        <a href="/owner/guestcheckoutlist/addAnAdvance/<?= $editId ?>" class="btn btn-default add_btn_center">Add An Advance</a>
                        <a href="/owner/guestcheckoutlist/booking/<?= $editId ?>" class="btn btn-default add_btn_center">Food Service</a>
                        <!--a href="/owner/guestcheckoutlist/addaservice/<?= $editId ?>" class="btn btn-default add_btn_center">Food Service</a-->
                        <a href="/owner/guestcheckoutlist/extendstay/<?= $editId ?>" class="btn btn-default add_btn_center">Extend Stay</a>
                        <a href="/owner/guestcheckoutlist/addaservices/<?= $editId ?>" class="btn btn-default add_btn_center">Other Services</a>
                    <?php //endif; ?>
                </div>
                <hr class="differ">
                <div class="row">
                  <div class="col-md-6">
                    <div class="panel-heading row">
                      <h3 class="panel-title tab">Room Rent Details</h3>
                    </div>
                    <div class="dash">
                      <table class="table table-bordered">
                        <thead>
                          <tr>
                            <th width="5%">Sr. No.</th>
                            <th width="10%">Bill Items</th>
                            <th width="10%">Total Amount</th>
                            <th width="10%">Date & Time</th>
                            <td width="5%"></td>
                          </tr>
                        </thead>
                        <tbody>
                          <?php 
                          $i=1;
                          foreach ($ALLDATA as $key=>$ALLDATAINFO){
                            if($ALLDATAINFO['page_source']=='extend_stay'){
                          ?>
                              <tr class="gradeX">
                                <td><?=$i?></td>
                                <td style="color:#e74e68"><?= stripslashes($ALLDATAINFO['bill_item'])?></td>
                                <td><?=stripslashes($ALLDATAINFO['advance_paid'])?></td>
                                <td><?=date('d-m-Y h:i A', strtotime($ALLDATAINFO['order_date']))?></td>
                                <td class="center">
                                  <div class="btn-group">
                                    <button class="btn dropdown-toggle" data-toggle="dropdown">More Options <span class="caret"></span></button>
                                    <ul class="dropdown-menu">
                                      <li><a href="/owner/guestcheckoutlist/extendstay/<?= $editId ?>/<?= $ALLDATAINFO['encrypt_id'] ?>"><i class="fa fa-edit"></i> Edit Details</a></li>
                                      <?php if($i>1){ ?>
                                        <li><a href="/owner/guestcheckoutlist/deleteData/<?= $ALLDATAINFO['detail_book_id'] ?>" onclick="return confirm('Are You Sure You Want To Delete This?');"><i class="fa fa-trash"></i> Delete</a></li>
                                      <?php } ?>
                                    </ul>
                                  </div>
                                </td>
                              </tr>
                          <?php
                              $i++;
                            }
                          }
                          ?>    
                        </tbody>
                      </table>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <?php
                    $CountAdvance = 0;
                    foreach ($ALLDATA as $key=>$ALLDATAINFO){
                      if($ALLDATAINFO['page_source']=='add_an_advance'){
                        $CountAdvance++;
                      }
                    }
                    ?>
                    <?php
                    if($CountAdvance>0){
                    ?>
                      <div class="panel-heading row">
                        <h3 class="panel-title tab">Advance Details</h3>
                      </div>
                      <div class="dash">
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                              <th width="5%">Sr. No.</th>
                              <th width="10%">Bill Items</th>
                              <th width="10%">Amount Paid</th>
                              <th width="10%">Payment Mode</th>
                              <th width="10%">Date & Time</th>
                              <td width="2%"></td>
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
                            $i=1;
                            foreach ($ALLDATA as $key=>$ALLDATAINFO){
                              if($ALLDATAINFO['page_source']=='add_an_advance'){
                            ?>
                                <tr class="gradeX">
                                  <td><?=$i?></td>
                                  <td style="color:#e74e68"><?= stripslashes($ALLDATAINFO['bill_item'])?></td>
                                  <td><?=stripslashes($ALLDATAINFO['payment_paid'])?></td>
                                  <td>
                                    <?php 
                                    if ($ALLDATAINFO['amount_mode'] == "prepaid"){
                                      echo 'Prepaid';
                                    }elseif ($ALLDATAINFO['amount_mode']=='offline') {
                                      echo 'Cash';
                                    }elseif ($ALLDATAINFO['amount_mode']=='online') {
                                      echo 'Online';
                                    }elseif ($ALLDATAINFO['amount_mode']=='BTC') {
                                      echo 'BTC';
                                    }
                                    ?>
                                  </td>
                                  <td><?=date('d-m-Y h:i A', strtotime($ALLDATAINFO['order_date']))?></td>
                                  <td class="center">
                                    <div class="btn-group">
                                      <button class="btn dropdown-toggle" data-toggle="dropdown">More Options <span class="caret"></span></button>
                                      <ul class="dropdown-menu">
                                        <li><a href="/owner/guestcheckoutlist/addAnAdvance/<?= $editId ?>/<?= $ALLDATAINFO['encrypt_id'] ?>"><i class="fa fa-edit"></i> Edit Details</a></li>
                                        <li><a href="/owner/guestcheckoutlist/deleteData/<?= $ALLDATAINFO['detail_book_id'] ?>" onclick="return confirm('Are You Sure You Want To Delete This?');"><i class="fa fa-trash"></i> Delete</a></li>
                                      </ul>
                                    </div>
                                  </td>
                                </tr>
                            <?php  
                                $i++;
                              }
                            }
                            ?>
                          </tbody>
                        </table>
                      </div>
                    <?php
                    }
                    ?>  
                  </div>
                  <div class="col-md-6">
                    <?php
                    foreach ($ALLDATA as $key=>$ALLDATAINFO){
                      $totalAmount  +=  (int)$ALLDATAINFO['advance_paid'];
                      $AmountPaid  +=  (int)$ALLDATAINFO['payment_paid'];
                    }
                    
                    if ($checkCheckInOut == '') :
                      $DueAmount   .=   $totalAmount - $AmountPaid;
                      if ($DueAmount > 0) : ?>
                        <a href="/owner/guestcheckoutlist/checkoutdatetime/<?= $editId ?>" class="btn btn-success add_btn_center active" onclick="return confirm('Payment Pending.Do you still want to check-out?');">Check-Out</a>
                      <?php else : ?>
                        <a href="/owner/guestcheckoutlist/checkoutdatetime/<?= $editId ?>" class="btn btn-success add_btn_center active">Check-Out</a>
                      <?php endif;
                      echo '<br/>';
                    endif; ?>
                    <?php $totalDueAmount   .=   $totalAmount - $AmountPaid; ?>
                    <p style="color:darkgreen ; font-size:36px">Total Payment Due = <i class="fa fa-rupee"></i> <?= $totalDueAmount; ?></p>
                  </div>
                </div>
                <div class="row">  
                  <?php
                  $CountFood = 0;
                  foreach ($ALLDATA as $key=>$ALLDATAINFO){
                    if($ALLDATAINFO['page_source']=='add_a_service' || $ALLDATAINFO['page_source']=='add_a_services'){
                      $CountFood++;
                    }
                  }
                  ?>
                  <?php
                  if($CountFood>0){
                  ?>
                    <div class="col-md-6">
                      <div class="panel-heading row">
                        <h3 class="panel-title tab">Food/Other Services</h3>
                      </div>
                      <div class="dash">
                        <table class="table table-bordered">
                          <thead>
                            <tr>
                              <th width="5%">Sr. No.</th>
                              <th width="10%">Bill Items</th>
                              <th width="10%">Total Amount</th>
                              <th width="10%">Date & Time</th>
                              <td width="5%"></td>
                            </tr>
                          </thead>
                          <tbody>
                            <?php 
                            $i=1;
                            //echo "<pre>"; print_r($FoodData); 
                            foreach ($FoodData as $key=>$ALLDATAINFO){
                              if($ALLDATAINFO['page_source']=='add_a_service'){
                                //$serviceNameQuantity  = $this->vendor_model->getAllServicesByHotelIdAndName($ALLDATAINFO['service_id']);
                                $KOTAmt = $this->common_model->GetTotalKOTAmount($ALLDATAINFO['kot_number'],$ALLDATAINFO['hotel_manager_id']);
                                $delQuery = "SELECT check_in_datetime,check_out_datetime FROM " . getTablePrefix() . "customer_summary_book WHERE summary_book_id = '" . $ALLDATAINFO['customer_id'] . "' AND hotel_manager_id= '".$ALLDATAINFO['hotel_manager_id']."' ";
                                $chkOut = $this->common_model->getDataByQuery('single', $delQuery);
                                $SettleText = '';
                                if($ALLDATAINFO['settle_type']=='Settle_on_the_spot'){
                                  $SettleText = '(Settled)';
                                }
                                $TotalAmount = $ALLDATAINFO['total_amt'];
                                $GSTAmt   = round($TotalAmount * 5) / 100;
                                $cgst     = $GSTAmt / 2;
                                $sgst     = $GSTAmt / 2;
                            ?>
                                <tr class="gradeX">
                                  <td><?=$i?></td>
                                  <?php
                                  /*if ($ALLDATAINFO['page_source'] == "add_a_service"){
                                    echo '<td style="color:#0c26df">'.stripslashes($serviceNameQuantity['menu_name']).' ('.$ALLDATAINFO['quantity'].')</td>';
                                  }elseif ($ALLDATAINFO['page_source'] == "add_a_services") {
                                    echo '<td style="color: #315bc2;">'.$ALLDATAINFO['bill_item'].'</td>';
                                  }*/
                                  ?>  
                                  <td>KOT No. <?=$ALLDATAINFO['kot_number']?> <br/><?=$SettleText?></td>
                                  <td><i class="fa fa-inr"></i><?=$KOTAmt?></td>
                                  <td><?=date('d-m-Y h:i A', strtotime($ALLDATAINFO['order_date']))?></td>
                                  <td class="center">
                                    <?php //if($chkOut['check_out_datetime'] == '' && $chkOut['check_in_datetime'] !='') { ?>
                                    <div class="btn-group">
                                      <button class="btn dropdown-toggle" data-toggle="dropdown">More Options <span class="caret"></span></button>
                                      <ul class="dropdown-menu">
                                        <li><a href="javascript:void(0)" onclick="AddATableModal('<?=base64_encode($ALLDATAINFO['kot_number'])?>','<?=$TotalAmount?>','<?=$GSTAmt?>','<?=$cgst?>','<?=$sgst?>')"><i class="fa fa-edit"></i> Edit</a></li>
                                        <li><a href="<?=base_url('owner/guestcheckoutlist')?>/viewkot/<?=base64_encode($ALLDATAINFO['kot_number'])?>/<?=base64_encode($ALLDATAINFO['hotel_manager_id'])?>"><i class="fa fa-eye"></i> View</a></li>
                                        <?php
                                        if($ALLDATAINFO['kot_number']>0){
                                        ?>
                                          <li><a href="<?=base_url('owner/guestcheckoutlist')?>/DeleteKOT/<?=base64_encode($ALLDATAINFO['kot_number'])?>/<?=$editId?>" onclick="return confirm('Are You Sure You Want To Delete This?');"><i class="fa fa-trash"></i> Delete</a></li>
                                        <?php
                                        }
                                        ?>  
                                      </ul>
                                    </div>
                                    <?php //} ?>
                                  </td>
                                </tr>
                            <?php  
                                $i++;
                              }
                            }
                            foreach ($ALLDATA as $key => $ALLDATAINFO) {
                              if($ALLDATAINFO['page_source']=='add_a_services'){
                              ?>
                                <tr class="gradeX">
                                  <td><?=$i?></td>
                                  <td style="color: #315bc2;"><?=$ALLDATAINFO['bill_item']?></td>
                                  <td><i class="fa fa-inr"></i><?=stripslashes($ALLDATAINFO['advance_paid'])?></td>
                                  <td><?=date('d-m-Y h:i A', strtotime($ALLDATAINFO['order_date']))?></td>
                                  <td class="center">
                                    <div class="btn-group">
                                      <button class="btn dropdown-toggle" data-toggle="dropdown">More Options <span class="caret"></span></button>
                                      <ul class="dropdown-menu">
                                        <li><a href="/owner/guestcheckoutlist/addaservices/<?= $editId ?>/<?= $ALLDATAINFO['encrypt_id'] ?>"><i class="fa fa-edit"></i> Edit Details</a></li>
                                        <li><a href="/owner/guestcheckoutlist/deleteData/<?= $ALLDATAINFO['detail_book_id'] ?>" onclick="return confirm('Are You Sure You Want To Delete This?');"><i class="fa fa-trash"></i> Delete</a></li>
                                      </ul>
                                    </div>
                                  </td>
                                </tr>
                            <?php  
                                $i++;
                              }
                            }
                            ?>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  <?php
                  }
                  ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="addRoomRentConfirmation" class="modal" role="dialog">
    <form id="" name="currentPageForm" class="modal-dialog modal-md" method="post" action="<?=base_url('owner/Guestcheckoutlist')?>/extendstay/<?= $editId ?>" enctype="multipart/form-data" autocomplete="off">
        <div class="modal-content">
            <div class="modal-body">
                <input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" />
                <input type="hidden" name="CurrentDataID" id="CurrentDataID" />
                <input type="hidden" name="CustomerID" id="CustomerID" value="<?= $CUSTDATA['summary_book_id']; ?>" />
                <input type="hidden" name="hotel_manager_id" value="<?php echo $ALLDATAINFO['hotel_manager_id']; ?>">
                <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

                <input type="hidden" name="manager_name" value="System">
                <input type="hidden" name="select_date" value="<?= implode(",", array_keys($unbilledRentDays)) ?>">
                <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">

                Room Rent not added for <?= implode(",", $unbilledRentDays) ?>, Want to add now?
            </div>
            <div class="modal-footer">
                <button class="btn btn-primary" id="addRoomRentBtn" type="submit">Yes</button>
                <button data-dismiss="modal" class="btn btn-danger" type="button">No</button>
            </div>
        </div>
    </form>
</div>
<form action="<?=base_url('owner/Guestcheckoutlist/UpdateKOT')?>" method="get" class="modal fade" id="currentPageForm" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align: center;">Settle Table</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
        <input type="hidden" name="kot_number" id="kot_number" value="">
        <input type="hidden" name="TotalAmount" id="TotalAmount" value="">
        <input type="hidden" name="GrandAmount" id="GrandAmount" value="">
        <input type="hidden" name="hotel_manager_id" id="hotel_manager_id" value="<?php echo $ALLDATAINFO['hotel_manager_id']; ?>">
        <input type="hidden" name="GSTAmt" id="GSTAmt" value="">
        <input type="hidden" name="cgst" id="cgst" value="">
        <input type="hidden" name="sgst" id="sgst" value="">
        
        <div class="row" id="PostItToRoom">
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Settle Type</label>
              <select name="settle_type" required id="settle_type" onchange="SettleType()" class="form-control">
                <option value="">Select</option>
                <option value="Post_it_to_room">Post it to room</option>
                <option value="Settle_on_the_spot">Settle on the spot</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">GST Type</label>
              <select name="gst_type" required id="gst_type" onchange="GSTType()" class="form-control">
                <option value="gst_exclusive" selected>GST Exclusive</option>
                <option value="gst_inclusive">GST Inclusive</option>
              </select>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <center style="color: red; font-size: 20px;"><strong>Total Amount :- <i class="fa fa-inr"></i> <span id="TotalAmt"></span></strong></center>
          </div>
        </div>
        <div class="row" id="SettleInSpot" style="display: none;">
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Amount Mode</label>
              <select name="amount_mode1" id="amount_mode1" class="form-control">
                <option value="offline">Offline (Cash)</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Payment Paid </label>
              <input type="text" name="payment_paid1" id="payment_paid1" onkeyup="PaymentPaid()" class="form-control numberonly" placeholder="Payment Paid">
              <a href="javascript:void(0)" onclick="FullPaid(1)">Paid in full</a> 
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Amount Mode </label>
              <select name="amount_mode2" id="amount_mode2" class="form-control">
                <option value="online">Online (Bank transfer, UPI, Paytm, Gpay, PhonePe)</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Payment Paid </label>
              <input type="text" name="payment_paid2" id="payment_paid2" onkeyup="PaymentPaid()" class="form-control numberonly" placeholder="Payment Paid">
              <a href="javascript:void(0)" onclick="FullPaid(2)">Paid in full</a> 
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Discount</label>
              <input type="text" name="discount" id="discount" readonly required class="form-control numberonly" placeholder="Discount">
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <span class="btn btn-primary btn-lg btn-block">Note:-
              <strong>
                <span style="color:#FF0000;">*</span> Indicates Required Fields
              </strong>
            </span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" style="padding: 6px 12px;">Close</button>
        <button type="submit" class="btn btn-primary" style="padding: 6px 12px;">Submit</button>
      </div>
    </div>
  </div>
</form>

<script>
    var prevSerchValue = '<?php echo $searchValue; ?>';
    <?php if (count($unbilledRentDays) > 0) { ?>
        //$("#addRoomRentConfirmation").modal('show');
        $("#addRoomRentBtn").trigger("click");
    <?php } ?>
function SettleType() {
  var type = $('#settle_type').val();
  if(type!=''){
    if(type=='Post_it_to_room'){
      $('#SettleInSpot').hide();
    }else{
      $('#SettleInSpot').show();
    }
  }else{
    $('#SettleInSpot').hide();
  }
}   
function GSTType(){
  var gst_type = $('#gst_type').val();
  var GSTAmt = parseInt($('#GSTAmt').val());
  var TotalAmount = parseInt($('#TotalAmount').val());
  if(gst_type=='gst_exclusive'){
    var GrandAmount = TotalAmount+GSTAmt;
    $('#TotalAmt').html(GrandAmount);
  }else{
    var GrandAmount = TotalAmount;
    $('#TotalAmt').html(TotalAmount);
  }
  $('#GrandAmount').val(GrandAmount);
  $('#payment_paid1').val('');
  $('#payment_paid2').val('');
  $('#discount').val('');
}
function AddATableModal(kot_number,TotalAmount,GSTAmt,cgst,sgst) {
  $('#kot_number').val(kot_number);
  $('#discount').val(TotalAmount);
  $('#TotalAmount').val(TotalAmount);
  $('#GSTAmt').val(GSTAmt);
  $('#cgst').val(cgst);
  $('#sgst').val(sgst);
  GSTType();
  $('#currentPageForm').modal("show");
}
function PaymentPaid(){
  var GrandAmount = $('#GrandAmount').val();
  var amt2 = $('#payment_paid2').val();
  var amt1 = $('#payment_paid1').val();
  if(amt1==''){ var amt1 = 0 }
  if(amt2==''){ var amt2 = 0 }
  var total = parseInt(amt2) + parseInt(amt1);
  var discount = parseInt(GrandAmount) - parseInt(total);
  $('#discount').val(discount);
}
function FullPaid(id){
  var GrandAmount = $('#GrandAmount').val();
  $('#discount').val('0');
  if(id==2){
    $('#payment_paid2').val(GrandAmount);
    $('#payment_paid1').val('');
  }else{
    $('#payment_paid1').val(GrandAmount);
    $('#payment_paid2').val('');
  }
}
</script>