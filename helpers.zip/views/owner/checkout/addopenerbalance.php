<div class="main">
    <div class="bready">
        <ol class="breadcrumb">
            <li><a href="{VENDOR_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
            <li><a href="javascript:void(0);" class="active"><i class="fa fa-hotel"></i>Opener Balance</a></li>
        </ol>
    </div>
    <div class="main-content">
        <div class="container-fluid">
            <div class="panel panel-headline">
                <div class="panel-heading row">
                    <h3 class="tab panel-title">Add Open Balance</h3>
                </div>
               <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
                      <!--div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" style="text-align: center;">Save Opening Balance</h4>
                      </div-->
                        <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                        <div class="row">
                            <div class="col-md-4 col-sm-4 col-xs-4">
                                 <label class="fancy-checkbox form-headings">Vendor<span class="required">*</span></label>
                                <select class="form-control" name="vendor_id" id="vendor_id" required>
                                    <option value="">All</option>
                                    <?php 
                                        foreach ($HotelList as $key => $value) { ?>
                                           <option value="<?php echo $value['vendor_id']?>" 
                                            <?php if($id == $value['vendor_id']){ echo "selected"; } else{ echo ""; }?>><?php echo $value['vendor_business_name']?></option>
                                    <?php  }
                                    ?>
                                    
                                </select>
                            </div>
                          <!--div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="form-group ">
                              <label class="fancy-checkbox form-headings">Total Cash (Old)<span class="required">*</span></label>
                              <input type="text" id="old_total_cash" value="" class="form-control" placeholder="Total Cash" readonly>
                            </div>
                          </div-->
                          <div class="col-md-4 col-sm-4 col-xs-4">
                            <div class="form-group ">
                              <label class="fancy-checkbox form-headings">Total Cash (Update) <span class="required">*</span></label>
                              <input type="number" min="0" name="total_cash" id="total_cash" value="" class="form-control" placeholder="Total Cash" required>
                            </div>
                          </div>
                          <div class="col-md-12 col-sm-12 col-xs-12">
                            <span class="btn btn-primary btn-lg btn-block">Note:-
                              <strong>
                                <span style="color:#FF0000;">*</span> Indicates Required Fields
                              </strong>
                            </span>
                          </div>
                        </div>
                      <div class="modal-footer">
                        <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
                        <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
                      </div>

                </form>
            </div>
        </div>
    </div>
</div>