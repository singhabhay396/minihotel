<div class="main">
    <div class="bready">
        <ol class="breadcrumb">
            <li><a href="<?=base_url('owner/dashboard')?>" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
            <li><a href="<?=base_url('owner/guestcheckoutlist/index')?>" class=""><i class="lnr lnr-user"></i>Add An Advance</a></li>
            <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITTASKDATA ? 'Edit' : 'Add' ?>
                    An Advance</a></li>
        </ol>
    </div>
 
    <div class="main-content">
        <div class="container-fluid">
            <div class="panel panel-headline inr-form">
                <div class="panel-heading row">
                    <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> An Advance</h3>
                    <a href="<?=base_url('owner/guestcheckoutlist')?>/viewsummarydetails/<?= $custumId ?>" class="btn btn-default add_btn">Back</a>
                </div>
                <hr class="differ">
                <div class="panel">
                    <div class="panel-body row">
                        <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="" enctype="multipart/form-data" autocomplete="off">
                            <input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?= $EDITTASKDATA['encrypt_id'] ?>" />
                            <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITTASKDATA['detail_book_id'] ?>" />
                            <input type="hidden" name="CustomerID" id="CustomerID" value="<?= $custId ?>" />
                            <input type="hidden" name="manager_name" id="manager_name" value="<?= $CUSTDATA['hotel_manager_name'];?>" />
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                            <fieldset>
                                <legend>Add An Advance <?php //echo "sssss".$EDITTASKDATA['oreder_date']; print_r($EDITTASKDATA);?></legend>
                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                                    <div class="col-md-4 col-sm-12 col-xs-12">
                                    <div class="form-group">
                                      <label class="fancy-checkbox form-headings">Order Date</label>
                                      <input type="datetime-local" name="order_date" value="<?=stripslashes($EDITTASKDATA['order_date'])?>" id="order_date" value="" class="form-control" placeholder="Order Date">
                                      
                                    </div>
                                  </div>
                                   <div class="col-md-4 col-sm-12 col-xs-12">
                                        <div class="form-group <?php if (form_error('payment_paid')) : ?>error<?php endif; ?>">
                                            <label class="fancy-checkbox form-headings">Payment Paid<span class="required">*</span></label>
                                            <input type="text" name="payment_paid" id="payment_paid" value="<?php if (set_value('payment_paid')) : echo set_value('payment_paid');
                                                                                                            else : echo stripslashes($EDITTASKDATA['payment_paid']); endif; ?>" class="form-control numberonly required" placeholder="Payment Paid">
                                            <?php if (form_error('payment_paid')) : ?>
                                                <span for="payment_paid" generated="true" class="help-inline"><?php echo form_error('payment_paid'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="col-md-4 col-sm-12 col-xs-12">
                                        <div class="form-group <?php if (form_error('amount_mode')) : ?>error<?php endif; ?>">
                                            <label class="fancy-checkbox form-headings">Amount Mode</label>
                                            <select name="amount_mode" id="amount_mode" class="form-control">
                                                <option value="#" disabled>Select Mode</option>
                                                <option value="prepaid" <?php if ($EDITTASKDATA['amount_mode'] == 'prepaid') : echo "selected"; endif; ?>>Prepaid</option>
                                                <option value="online" <?php if ($EDITTASKDATA['amount_mode'] == 'online') : echo "selected"; endif; ?>>Online (Bank transfer, UPI, Paytm, Gpay, PhonePe)</option>
                                                <option value="offline" <?php if ($EDITTASKDATA['amount_mode'] == 'offline') : echo "selected";endif; ?>>Offline (Cash)</option>
                                                <option value="BTC" <?php if ($EDITTASKDATA['amount_mode'] == 'BTC') : echo "selected";endif; ?>>Bill To Company (BTC)</option>
                                            </select>
                                            <?php if (form_error('amount_mode')) : ?>
                                                <span for="amount_mode" generated="true" class="help-inline"><?php echo form_error('amount_mode'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <!--<div class="col-md-4 col-sm-12 col-xs-12">
                                        <div class="form-group <?php if (form_error('order_datetime')) : ?>error<?php endif; ?>">
                                            <label class="fancy-checkbox form-headings">Order Date Time<span class="required">*</span></label>
                                            <input type="datetime-local" name="order_datetime" id="order_datetime" value="<?php if (set_value('order_datetime')) : echo set_value('order_datetime');
                                                    else : echo stripslashes($EDITDATA['hotel_manager_name']); endif; ?>" class="form-control required" placeholder="Check In Date Time">
                                            <?php if (form_error('order_datetime')) : ?>
                                                <span for="order_datetime" generated="true" class="help-inline"><?php echo form_error('order_datetime'); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>-->
                                </div>
                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                                </div>
                            </fieldset>
                            <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
                            <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
                            <a href="<?=base_url('owner/guestcheckoutlist/index')?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
                            <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                                    :- <strong><span style="color:#FF0000;">*</span> Indicates
                                        Required Fields</strong> </span>
                            </span>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>