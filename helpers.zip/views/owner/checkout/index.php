<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/css/select2.min.css" rel="stylesheet" />
<link href="https://raw.githack.com/ttskch/select2-bootstrap4-theme/master/dist/select2-bootstrap4.css" rel="stylesheet">
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.6-rc.0/js/select2.min.js"></script>


<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<script>
$(function() {
  $("#fromDate").datepicker({
    dateFormat: 'dd-mm-yy',
    changeMonth: true,
    changeYear: true,
    maxDate: 0,
    yearRange: "1960:<?php echo date('Y'); ?>"
  });
});
$(function() {
  $("#toDate").datepicker({
    dateFormat: 'dd-mm-yy',
    changeMonth: true,
    changeYear: true,
    maxDate: 0,
    yearRange: "1960:<?php echo date('Y'); ?>"
  });
});
$(function() {
  $("#check_in").datepicker({
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    changeYear: true,
    maxDate: 0,
    yearRange: "1960:<?php echo date('Y'); ?>"
  });
});
$(function() {
  $("#check_out").datepicker({
    dateFormat: 'yy-mm-dd',
    changeMonth: true,
    changeYear: true,
    maxDate: 0,
    yearRange: "1960:<?php echo date('Y'); ?>"
  });
});
</script>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('owner/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Checked-Out Customers</a>
      </li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <hr class="differ">
        <div class="row" style="margin-left: 7px !important;">
          <form action="<?=base_url('owner/guestcheckoutlist/DownloadCheckOutData')?>" method="get" name="searchData" id="searchData" autocomplete="off">
            <div class="col-md-3 col-sm-3 col-xs-3">
              <select class="form-control VendorData" required onchange="Search()" name="VendorArr" id="VendorID">
                <?php
                foreach ($HotelList as $key=>$hotel) {
                  echo '<option value="'.$hotel['vendor_id'].'">'.$hotel['vendor_business_name'].'</option>';
                }
                ?>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <input type="text" name="fromDate" required id="fromDate" value="<?php if ($searchDate <> "") : echo date('d-m-Y', strtotime($searchDate));endif; ?>" class="form-control input-smt" placeholder="From Date">
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <input type="text" name="toDate" id="toDate" required value="<?php if ($searchDate <> "") : echo date('d-m-Y', strtotime($searchDate)); endif; ?>" class="form-control input-smt" placeholder="To Date">
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Download</button>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-3">
              <span id="DeleteBtn"></span>
              <input type="hidden" id="VendorArr" value="">
            </div>
          </form>
        </div>
        <hr class="differ">
        <div class="dash">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th width="2%">
                  <select id="numofrecords" onchange="Search()">
                    <option value="10" <?php if ($perpage == '10') {echo 'selected="selected"';}?>>10</option>
                    <option value="25" <?php if ($perpage == '25') {echo 'selected="selected"';}?>>25</option>
                    <option value="50" <?php if ($perpage == '50') {echo 'selected="selected"';}?>>50</option>
                    <option value="100" <?php if ($perpage == '100') {echo 'selected="selected"';}?>>100</option>
                    <option value="500" <?php if ($perpage == '500') {echo 'selected="selected"';}?>>500</option>
                  </select>
                </th>
                <th width="6%">Manager Name</th>
                <th width="10%">Customer Name</th>
                <th width="5%">Mobile Number</th>
                <th width="10%">Check-In Date & Time</th>
                <th width="10%">Check-Out Date & Time</th>
                <th width="5%">Room Number</th>
                <th width="5%">GRC No.</th>
                <th width="5%">Action</th>
              </tr>
            </thead>
            <thead>
              <tr>
                <th><input type="checkbox" id="checkedAll" /></th>
                <th><input type="text" class="form-control" id="m_name" placeholder="Manager Name"></th>
                <th><input type="text" class="form-control" id="c_name" placeholder="Customer Name"></th>
                <th><input type="text" class="form-control" id="mobile" placeholder="Mobile"></th>
                <th><input type="date" class="form-control" id="check_in" placeholder="Check-In Date"></th>
                <th><input type="date" class="form-control" id="check_out" placeholder="Check-Out Date"></th>
                <th><input type="text" class="form-control" id="room_no" placeholder="Room Number"></th>
                <th><input type="text" class="form-control" id="entry_no" placeholder="GRC No."></th>
                <th colspan="3">
                  <button type="button" onclick="Search()" class="btn btn-primary btn-lg">
                    <i class="fa fa-search"></i>
                  </button>
                </th>
              </tr>
            </thead>
            <tbody id="Result"></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
/*$(function () {
  $('.VendorData').each(function () {
    $(this).select2({
      theme: 'bootstrap4',
      width: 'style',
      placeholder: $(this).attr('placeholder'),
      allowClear: Boolean($(this).data('allow-clear')),
    });
  });
});*/

function checkboxcount(){
  var len = $("input[name='id']:checked").length;
  if(len > 0){
    $('#DeleteBtn').html('<button type="button" onclick="DeleteData()" class="btn btn-primary btn-lg"><i class="fa fa-trash" aria-hidden="true"></i></button>');
  }else{
    $('#DeleteBtn').html('');
  }
}
$(document).ready(function() {
  $("#checkedAll").change(function(){
    if(this.checked){
      $(".checkSingle").each(function(){
        this.checked=true;
      })              
    }else{
      $(".checkSingle").each(function(){
        this.checked=false;
      })              
    }
    checkboxcount();
  });
});
$(function() { 
  loadData(1);
  $(".form-control").keypress(function(event) {
    if(event.which == 13){
      event.preventDefault();
      loadData(1);
    }
  });
});
function Search(){
  var page = $('#CurrentPage').val();
  loadData(page);
}
function Pagination(page){
  loadData(page);
}
/*$('.VendorData').on("select2:select", function (e) {
  //alert($('.VendorData').select2().val());
  $('#VendorArr').val($('.VendorData').select2().val());
});*/
function loadData(page){
  $("#Result").html('<tr><td colspan="10"><center>Loading..</center></td></tr>');
  var m_name        = $("#m_name").val();
  var c_name        = $("#c_name").val();
  var mobile        = $("#mobile").val();
  var check_in      = $("#check_in").val();
  var numofrecords  = $("#numofrecords").val();
  var check_out     = $("#check_out").val();
  var room_no       = $("#room_no").val();
  var entry_no      = $('#entry_no').val();
  var VendorArr     = $('#VendorID').val();
  $.ajax({
    url : "<?=base_url('owner/guestcheckoutlist/CheckedOutPagination')?>",
    type: "GET",
    data : {VendorArr:VendorArr,entry_no:entry_no,m_name:m_name,numofrecords:numofrecords,c_name:c_name,check_in:check_in,mobile:mobile,check_out:check_out,room_no:room_no,page:page},
    success:function(a)
    {
      $("#Result").html(a);
      checkboxcount();
    }
  });
}

function DeleteData(){
  var StatuId = [];
  $.each($("input[name='id']:checked"), function(){
    StatuId.push($(this).val());
  });
  var statuid_arr = StatuId.join();
  if(statuid_arr==''){
    alert('Select data');return false;
  }else{
    $.ajax({
      url : "<?=base_url('owner/guestcheckoutlist/changeStatus')?>",
      type: "POST",
      data : {id:statuid_arr},
      success:function(a)
      {
        loadData(1);
      }
    });
  }
}
</script>