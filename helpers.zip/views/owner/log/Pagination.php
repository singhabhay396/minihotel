<?php 
if ($ALLDATA != "") : $i = 1;
  foreach ($ALLDATA as $key=>$ALLDATAINFO) :
    $manager_name = 'Owner';
    if($ALLDATAINFO['manager_name']){
      $manager_name = $ALLDATAINFO['manager_name'];
    }   
  ?>
    <tr class="<?php if ($i % 2 == 0) : echo 'odd'; else : echo 'even';endif; ?> gradeX">
      <td><?=$key+1?></td>
      <td><?=$ALLDATAINFO['vendor_business_name']?></td>
      <td><?=$manager_name?></td>
      <td><?=$ALLDATAINFO['log_name']?></td>
      <td><?=$ALLDATAINFO['add_date']?></td>
      <td class="center">
        <a href="javascript:void(0);" class="LogViewDetailsData" title="Log Details" data-id="<?=$ALLDATAINFO['id']?>" data-width="800"><i class="fa fa-asterisk"></i> View Details</a>
      </td>
    </tr>
    <?php  
  endforeach;
  echo '<tr><td colspan="10" style="text-align:center;">'.$PAGINATION.'</td></tr>';
else : ?>
  <tr>
    <td colspan="10" style="text-align:center;">No Data Available In Table</td>
  </tr>
<?php endif; ?>