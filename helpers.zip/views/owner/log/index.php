<style>
  a.btn.btn-default.add_btn_center {float: right;padding: 7px 30px !important;margin-left: 16px;font-size: 16px !important;color: #fff;background-color: #315bc2 !important;}
</style>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Log List</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Log List</h3>
        </div>
        <hr class="differ">
        <div class="dash">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th width="2%">
                  <select id="numofrecords" onchange="Search()">
                    <option value="10" selected>10</option>
                    <option value="25">25</option>
                    <option value="50">50</option>
                    <option value="100">100</option>
                    <option value="500">500</option>
                  </select>
                </th>
                <th width="6%">Hotel</th>
                <th width="10%">Edit By</th>
                <th width="5%">Type</th>
                <th width="5%">Date</th>
                <th width="5%">View</th>
              </tr>
            </thead>
            <thead>
              <tr>
                <th>#</th>
                <th>
                  <select id="vendor_id" onchange="Search()" class="form-control">
                    <option value="All">All</option>
                    <?php
                    foreach ($HotelList as $key => $value) {
                      echo '<option value="'.$value['vendor_id'].'">'.$value['vendor_business_name'].'</option>';
                    }
                    ?>
                  </select>
                </th>

                <!--input type="text" class="form-control" id="hotel_name" placeholder="Hotel Name"-->
                <th>
                  <select id="manager_id" onchange="Search()" class="form-control">
                    <option value="All">All</option>
                    <?php
                    foreach ($ManagerList as $key => $value) {
                      echo '<option value="'.$value['id'].'">'.$value['manager_name'].'</option>';
                    }
                    ?>
                  </select>
                </th>
                <th>
                  <select id="log_type" onchange="Search()" class="form-control">
                    <option value="All">All</option>
                    <?php
                    foreach ($LogType as $key => $value) {
                      echo '<option value="'.$value['id'].'">'.$value['log_type'].'</option>';
                    }
                    ?>
                  </select>
                </th>
                <th></th>
                <th colspan="3">
                  <button type="button" onclick="Search()" class="btn btn-primary btn-lg">
                    <i class="fa fa-search"></i>
                  </button>
                </th>
              </tr>
            </thead>
            <tbody id="Result"></tbody>
          </table>      
        </div>
      </div>
    </div>
  </div>
</div>

<div id="LogDetailsModal" class="modal" role="dialog">
  <div class="modal-dialog modal-md">
    <div class="modal-content">
      <div class="modal-header">
        <button data-dismiss="modal" class="close" type="button">x</button>
        <h3>Pop up Header</h3>
      </div>
      <div class="modal-body">
        <p>Loading...</p>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$(function() { 
  loadData(1);
  $(".form-control").keypress(function(event) {
    if(event.which == 13){
      event.preventDefault();
      loadData(1);
    }
  });
});
function Search(){
  loadData(1);
}
function Pagination(page){
  loadData(page);
}
function loadData(page){
  $("#Result").html('<tr><td colspan="10"><center>Loading..</center></td></tr>');
  var hotel_name    = $("#hotel_name").val();
  var vendor_id    = $("#vendor_id").val();
  var manager_id    = $("#manager_id").val();
  var log_type      = $("#log_type").val();
  var numofrecords  = $("#numofrecords").val();
  $.ajax({
    url : "<?=base_url('owner/log/Pagination')?>",
    type: "GET",
    data : {hotel_name:hotel_name,manager_id:manager_id,log_type:log_type,numofrecords:numofrecords,page:page,vendor_id:vendor_id},
    success:function(a){
      $("#Result").html(a);
    }
  });   
}  

$(document).on('click', '.table .LogViewDetailsData', function() {
  var title = $(this).attr('title');
  $("#LogDetailsModal").modal();
  $("#LogDetailsModal .modal-header h3").html(title);
  var viewid = $(this).attr('data-id');
  var modelwidth = $(this).attr('data-width');
  if (modelwidth) {
    $("#LogDetailsModal .modal-dialog").css('width', modelwidth);
  }

  $.ajax({
    type: 'post',
    url: "<?=base_url('owner/log/logdetails')?>",
    data: {
      csrf_api_key: csrf_api_value,
      viewid: viewid
    },
    success: function(response) {
      $("#LogDetailsModal .modal-body").html(response);
    }
  });
});
</script>