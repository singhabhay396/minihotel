
<style type="text/css">
	.chng{
		color: red;
	}
</style>
<?php //echo "<pre>"; print_r($log_type); exit; ?>
<div class="row">
	<div class="col-md-12">
	<?php if(($log_type == 1 || $log_type == 10) && $addDate > '2024-05-10' && $ct > 0){ ?>
		<div class="col-md-6">
			<h2>Updated Data</h2>
			<?php 

			 foreach ($updatedData as $key => $value) {

			 	if($key == 'hotel_manager_name'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Manager Name</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'customer_name'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Customer Name</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'customer_email'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Customer Email</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'customer_mobile_number'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Customer Mobile</strong> :- '.$value.'</div>';
			 	} 
			 	elseif($key == 'person_address'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Address</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'age'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Age</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'id_card'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Id Card</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'check_in_datetime'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>CheckIn Datetime</strong> :- '.date('d-m-Y h:i A', strtotime($value)).'</div>';
			 	}
			 	elseif($key == 'hourly_check_out_id'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Hourly Check Out</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'amount'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Room Rent</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'room_rent_type'){ 
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Is Room Rent exclusive of GST or inclusive</strong> :- ';
			 		if($value == 'gst_exclude'){
			 			echo 'Exclusive </div>';
			 		}
			 		elseif($value == 'gst_include'){
			 			echo 'Inclusive </div>';
			 		}
			 	}
			 	elseif($key == 'choose_plan'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Choose Plan</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'assign_room_number'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			    	if($key == 'assign_room_number'){
				 		$LogRroom = $this->common_model->getDataByParticularField('room_number', 'room_id', $value);
				 		$value = $LogRroom['room_no'];
			 		}
			 		echo '<div class='.$cls.'><strong>Room</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'entry_number'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>GRC No.</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'number_of_person'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Number Of Persons</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'reffer_mode'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Booking Mode</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'ots_id'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Booking Platform</strong> :- '.$otsList[$value].'</div>';
			 	}
			 	elseif($key == 'booking_id'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Booking ID</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'amount_mode'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Payment Details</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'prepaid_amount'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>How Much Amount</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'remarks'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Extra Remarks</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'gst_number'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>GSTIN</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'company_name'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Company Name</strong> :- '.$value.'</div>';
			 	}
			 	elseif($key == 'company_address'){
			 		$cls = '';
			 		if($preiousData[$key] != $value && !empty($preiousData)){
			    		$cls = 'chng';
			    	}
			 		echo '<div class='.$cls.'><strong>Company Address</strong> :- '.$value.'</div>';
			 	}
			    
			 }
		?>
		</div>
		<div class="col-md-6">
			<h2>Previous Data</h2>
			<?php 
			if(!empty($preiousData)){
				$pre = $preiousData;
			}
			else{
				$pre = $updatedData;
			}
			 foreach ($pre as $key => $value) {
			    if($key == 'hotel_manager_name'){

			 		echo '<strong >Manager Name</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'customer_name'){
			 		echo '<strong>Customer Name</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'customer_email'){
			 		echo '<strong>Customer Email</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'customer_mobile_number'){
			 		echo '<strong>Customer Mobile</strong> :- '.$value.'<br/>';
			 	} 
			 	elseif($key == 'person_address'){
			 		echo '<strong>Address</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'age'){
			 		echo '<strong>Age</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'id_card'){
			 		echo '<strong>Id Card</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'check_in_datetime'){
			 		echo '<strong>CheckIn Datetime</strong> :- '.date('d-m-Y h:i A', strtotime($value)).'<br/>';
			 	}
			 	elseif($key == 'hourly_check_out_id'){
			 		echo '<strong>Hourly Check Out</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'amount'){
			 		echo '<strong>Room Rent</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'room_rent_type' && $value != ''){ 
			 		echo '<strong>Is Room Rent exclusive of GST or inclusive</strong> :- ';
			 		if($value == 'gst_exclude'){
			 			echo 'Exclusive <br/>';
			 		}
			 		elseif($value == 'gst_include'){
			 			echo 'Inclusive <br/>';
			 		}
			 	}
			 	elseif($key == 'choose_plan'){
			 		echo '<strong>Choose Plan</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'assign_room_number'){
			 		if($key == 'assign_room_number'){
				 		$LogRroom = $this->common_model->getDataByParticularField('room_number', 'room_id', $value);
				 		$value = $LogRroom['room_no'];
			 		}
			 		echo '<strong>Room</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'entry_number'){
			 		echo '<strong>GRC No.</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'number_of_person'){
			 		echo '<strong>Number Of Persons</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'reffer_mode'){
			 		echo '<strong>Booking Mode</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'ots_id'){

			    	echo '<strong>Booking Platform</strong> :- '.$otsList[$value].'<br/>';
			 		
			 	}
			 	elseif($key == 'booking_id'){
			 		echo '<strong>Booking ID</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'amount_mode'){
			 		echo '<strong>Payment Details</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'prepaid_amount'){
			 		echo '<strong>How Much Amount</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'remarks'){
			 		echo '<strong>Extra Remarks</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'gst_number'){
			 		echo '<strong>GSTIN</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'company_name'){
			 		echo '<strong>Company Name</strong> :- '.$value.'<br/>';
			 	}
			 	elseif($key == 'company_address'){
			 		echo '<strong>Company Address</strong> :- '.$value.'<br/>';
			 	}
			  }
			?>
		</div>
	<?php } 
		if($log_type == 11 || $log_type == 17 || $ct == 0) {  ?>
		<div class="col-md-6">
			<h2>Updated Data</h2>
			<?php 
			foreach ($updatedData as $key => $value) {
		 		$cls = '';
		 		if($preiousData[$key] != $value){
		    		$cls = 'chng';
		    	}
		 		echo '<div class='.$cls.'><strong>'.$key.'</strong> :- '.$value.'</div>';
	 	 	?>
		<?php } ?>	

		</div>
		<div class="col-md-6">
			<h2>Previous Data</h2>
			<?php 
			foreach ($preiousData as $key => $value) {
		 		$cls = '';
		 		if($preiousData[$key] != $value){
		    		$cls = 'chng';
		    	}
		 		echo '<div class='.$cls.'><strong>'.$key.'</strong> :- '.$value.'</div>';
	 	 	?>
		<?php } ?>	

		</div>
	<?php } ?>
	</div>
</div>
