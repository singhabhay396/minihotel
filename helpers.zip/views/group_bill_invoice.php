<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>Invoice</title>
    <style>
      @media(max-width:786px) {
      table {width: 800px !important;}
      }
    </style>
  </head>
  <body>
    <?php
    //echo "<pre>"; print_r($customerInfo); exit;
$class_obj = new numbertowordconvertsconver();

// $CURRENTENTRYNUMBER = $this->common_model->getDataByParticularField('vendor_details', 'vendor_id', sessionData('MHM_VENDOR_ID'));

//                 $billNumber = $CURRENTENTRYNUMBER['bill_number'] + 1;

// if($OrderDate['bill_number'] == ""){

//     $OrderDate['bill_number'] = $billNumber ;

// }
// /*Save Log*/

// $customerId = $this->input->post('customerID');

// $CUSTOMERDATA = $this->common_model->getDataByParticularField('customer_summary_book', 'summary_book_id', $customerId);

// $assign_room_number = $CUSTOMERDATA['assign_room_number'];

// $RoomData = $this->common_model->getDataByParticularField('room_number', 'room_id', $assign_room_number);

// $SaveLog = [];

// $SaveLog['Customer Name'] = $CUSTOMERDATA['customer_name'];

// $SaveLog['Check In Date'] = $CUSTOMERDATA['check_in_datetime'];

// $SaveLog['Check Out Date'] = $CUSTOMERDATA['check_out_datetime'];

// $SaveLog['Bill Number'] = $OrderDate['bill_number'];

// $SaveLog['Entry Number'] = $CUSTOMERDATA['entry_number'];

// $SaveLog['Room Number'] = $RoomData['room_no'];

// if ($clickType == 'room_rent_with_gst') {

//   $this->common_model->SaveVendorLog($SaveLog,13);

// }

// if ($clickType == 'room_rent_with_food_gst') {

//   $this->common_model->SaveVendorLog($SaveLog,14);

// }

// if ($clickType == 'room_rent_without_gst') {

//   $this->common_model->SaveVendorLog($SaveLog,15);

// }

// if ($clickType == 'room_rent_without_food_gst') {

//   $this->common_model->SaveVendorLog($SaveLog,16);

// } ?>
    <table cellpadding="0" style="border:3px solid #bf40bf; padding: 20px;" cellspacing="0" align="center" width="700px">
      <tbody>
        <?php if($VENDORDATA['vendor_image'] != ''){ ?>
        <tr>
          <td style="text-align: center;padding: 10px;margin-bottom: 10px;" colspan="3">
            <img src="<?php echo $VENDORDATA['vendor_image']; ?>" style="width: 120px;margin: auto;margin-bottom: 10px;">
          </td>
        </tr>
    <?php } ?>
        <tr style="background:#fff;">
          <td style="text-align: center;background: #bf40bf;padding: 10px;margin-bottom: 10px;border-radius: 18px;" colspan="3">
            <p style="margin: 5px;box-sizing: border-box;font-family: Sergio Trendy;font-weight: 900;text-transform: uppercase;font-size: 25px;background: #BF40BF;color: #fff;border-radius: 10px;"><b> <?php echo ucfirst($VENDORDATA['vendor_business_name']); ?></b>
            </p>
          </td>
        </tr>
        <?php $ManagedBy = '';

                if($VENDORDETAIL['managed_by']){

                $ManagedBy = "A Unit Of ".ucfirst($VENDORDETAIL['managed_by']);    
                //$baseUrl = root_path();
                $loc = $this->config->item("root_path") . 'assets/vendor/images/location.png';
                $phone = $this->config->item("root_path") . 'assets/vendor/images/phone.png';
                $email = $this->config->item("root_path") . 'assets/vendor/images/email.png';
                $globe = $this->config->item("root_path") . 'assets/vendor/images/globe.png';

                } ?>
        <tr style="background:#fff;">
          <td style="text-align: left;padding: 10px 20px 10px 20px;line-height: 22px;" colspan="2">
            <h4 style=" margin-bottom: 5px;box-sizing: border-box;font-family: Lato, sans-serif;font-weight: 800;color: #BF40BF;font-size: 16px;"><b><?php echo $ManagedBy; ?></b></h4>
            <h4 style="margin: 5px 0px;box-sizing: border-box;font-family: Lato, sans-serif;font-weight: 500;color: #000;font-size: 13px;"><img style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;width: 10px;height: 15px;display: inline-block;vertical-align: middle;" src="/home/admin/domains/dev2.minihotelman.com/public_html/assets/vendor/images/location.png"/> <?php echo ucfirst($VENDORDETAIL['vendor_address']) ?></h4>
            <h4 style="margin: 5px 0px;box-sizing: border-box;font-family: Lato, sans-serif;font-weight: 500;color: #000;font-size: 13px;"><img style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;width: 13px;height: 17px;display: inline-block;vertical-align: middle;" src="/home/admin/domains/dev2.minihotelman.com/public_html/assets/vendor/images/phone.png"/> <?php echo $VENDORDATA['first_manager_contact_number']; ?> &nbsp; 
              <img class="icon_ema" style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;width: 20px;height: 14px;display: inline-block;vertical-align: middle;" src="/home/admin/domains/dev2.minihotelman.com/public_html/assets/vendor/images/email.png"/> <?php echo $VENDORDATA['vendor_email']; ?>                        
            </h4>
            <?php if($VENDORDETAIL['website_url'] !=''){?>
            <h4 style="margin: 5px 0px;box-sizing: border-box;font-family: Lato, sans-serif;font-weight: 500;color: #000;font-size: 13px;"><img style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;width: 19px;height: 19px;display: inline-block;vertical-align: middle;" src="/home/admin/domains/dev2.minihotelman.com/public_html/assets/vendor/images/globe.png"/> <?php echo $VENDORDETAIL['website_url']; ?></h4>
                <?php } ?>
            <?php 
            if (($billType == 'room_rent_with_gst' || $billType == 'room_rent_with_food_gst') && $VENDORDETAIL['vendor_gst'] !='') { ?>
            <h4 style="font-size: 15px;  font-weight: 600; margin: 0;padding: 0px 0px 10px;box-sizing: border-box;font-family: Lato, sans-serif;">
            <b>GSTIN: <?php echo $VENDORDETAIL['vendor_gst'] ?></b> 
            </h4>
            <?php } ?>  
          </td>
          <td style="text-align: right;">
            <p style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;font-size: 13px;">&nbsp;&nbsp;&nbsp;
              <span class="bold price" style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;font-weight: 900;color: #BF40BF;font-size: 16px;"><b>Bill No :</b>
              </span> # <?php echo $bill_number; ?>  &nbsp;&nbsp;&nbsp;&nbsp;                 
            </p>
            <p style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;font-size: 13px;">
              <span class="bold price" style="padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;font-weight: 900;color: #BF40BF;font-size: 16px;"><b>Bill
              Date :</b></span> <?php echo date('d/m/Y', strtotime($customerInfo['check_out_datetime'])); ?>                    
            </p>
          </td>
        </tr>
        <tr style="background:#fff;">
          <td style="text-align: left;vertical-align: top;border-top: 3px solid #bf40bf;padding-top: 0px;line-height: 22px;padding: 10px 15px 6px 5px;" colspan="2">
            <div style="margin: 0;box-sizing: border-box;font-family: Lato, sans-serif;font-size: 13px;">
           
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">Guest Name:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo ucfirst(stripslashes($guest_temp_name ? $guest_temp_name : $ALLGROUPBILLCUSTDATA[0]['customer_name'])); ?></i>
              <br/>
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">Guest Phone:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo ucfirst(stripslashes($ALLGROUPBILLCUSTDATA[0]['customer_mobile_number'])); ?></i>
              <br/>
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">Check In:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo date('d/m/Y H:i', strtotime($ALLGROUPBILLCUSTDATA[0]['check_in_datetime'])); ?></i>
              <br/>
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">Check Out:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo date('d/m/Y H:i', strtotime($ALLGROUPBILLCUSTDATA[0]['check_out_datetime'])); ?></i>
              <br/>
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">Number Of Persons:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo stripslashes($number_of_person); ?></i>
              <br/>
              <?php  if($customerInfo['ots_id'] > 0){ ?>
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">OTA Platform:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo stripslashes($otsList[$customerInfo['ots_id']]); ?></i>
              <?php  } ?>
            </div>
          </td>
          <td style="text-align: left;vertical-align: top;border-top: 3px solid #bf40bf;padding-top: 0px;line-height: 22px;padding: 10px 10px 10px 0px;" colspan="2">
            <div style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;font-size: 13px;"> 
              
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">GRC No.:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo stripslashes($ALLGROUPBILLCUSTDATA[0]['entry_number']); ?></i>
              <br/>
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">Room Number:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo stripslashes($assigneRooms); ?></i>
              <br/>
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">Company Name:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo stripslashes($ALLGROUPBILLCUSTDATA[0]['company_name']); ?></i>
              <br/>
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">Company Address:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo stripslashes($ALLGROUPBILLCUSTDATA[0]['company_address']); ?></i>
              <br/>
              <?php if ($billType == 'room_rent_with_gst' || $billType == 'room_rent_with_food_gst') { ?>
              <b style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;">Company GST:</b> 
              <i style="margin: 0;padding: 0;box-sizing: border-box;font-family: Lato, sans-serif;"><?php echo stripslashes($ALLGROUPBILLCUSTDATA[0]['gst_number']); ?></i>
              <?php } ?>
            </div>
          </td>
        </tr>
        <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 20%;text-align: center;font-size: 18px; color: #fff">
            DATE
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 45%;text-align: center;font-size: 18px; color: #fff">
            ITEMS
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 35%;text-align: right;font-size: 18px; color: #fff">
            PRICE (₹)
          </th>
        </tr>
        <?php if(!empty($foodListdata) && !empty($allSummarydata) && !empty($GetServiceGST)){
            $numDis = "(1 + 2 + 3)";
        } elseif((!empty($foodListdata) && !empty($allSummarydata)) || (!empty($GetServiceGST) && !empty($foodListdata)) || (!empty($GetServiceGST) && !empty($allSummarydata))){
                $numDis = "(1 + 2)";
        }
        else{
            $numDis = "(1)";
        }

        ?>
        <?php if ($billType == 'room_rent_with_gst' || $billType == 'room_rent_with_food_gst') {
            if ($gstType == 'gst_include') {
                $totalPaybalAmountRoom = $total_amount;
                $PaybalAmountRoom = round($total_amount / 1.12);
                $totalAmnt = round($PaybalAmountRoom * 12) / 100;
                $TTGst = $PaybalAmountRoom - $totalAmnt;
                $cgst = $totalAmnt / 2;
                $sgst = $totalAmnt / 2;
                $totalAmount = $PaybalAmountRoom;
            } elseif ($gstType == 'gst_exclude') {
                $totalAmount = round($total_amount * 12) / 100;
                $cgst = $totalAmount / 2;
                $sgst = $totalAmount / 2;
                $totalPaybalAmountRoom = $total_amount + $totalAmount;
            } elseif (empty($gstType)) {
                $totalAmount = round($total_amount * 12) / 100;
                $cgst = $totalAmount / 2;
                $sgst = $totalAmount / 2;
                $totalPaybalAmountRoom = $total_amount + $totalAmount;
            }
        } elseif ($billType == 'room_rent_without_food_gst' || $billType == 'room_rent_without_gst') {
            $totalAmount = $total_amount;
            $cgst = 0;
            $sgst = 0;
            $totalPaybalAmountRoom = $totalAmount;
        } ?>
        <tr>
          <td style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 20%;text-align: center;font-size: 16px;border-bottom: 1px solid #000;"><?php echo date('d/m/Y', strtotime($ALLGROUPBILLCUSTDATA[0]['check_out_datetime'])); ?></td>
          <td style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 45%;text-align: center;font-size: 16px;border-bottom: 1px solid #000;">Accumulated Room Rent<?php //echo stripslashes(ucfirst(substr($bill_item, 0, 9))); ?><br/> <span style="font-size: 10px;"><?php if (($billType == 'room_rent_with_gst' || $billType == 'room_rent_with_food_gst')) { ?>SAC - 996311<?php } ?></span></td>
          <td style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 35%;text-align: right;font-size: 16px;border-bottom: 1px solid #000;">
            <?php echo displayPrice($bill_amount); ?>
          </td>
        </tr>
        <?php 
            //endforeach;
        //endif;
        if ($gstType == 'gst_include') { ?>
        <tr>
          <td colspan="3" style="margin: 0;padding: 15px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 16px;">
            <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:15px;text-align: right;"> <b>SUB TOTAL (₹) : </b><?php echo displayPrice($totalAmount); ?>  </p>
            <p style="text-align: right font-size: 16px;margin:0;font-weight: 100; padding-bottom:15px;">CGST (₹)  :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo displayPrice($cgst); ?> </p>
            <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;">SGST (₹)  :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo displayPrice($sgst); ?> </p>
            <p style=" text-align: right;font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;"> <b>GRAND TOTAL (1) (₹) : </b><?php echo displayPrice($total_amount); ?> 
            </p>
          </td>
        </tr>
        <?php 

        } else { ?> 
            <tr>
              <td colspan="3" style="margin: 0;padding: 15px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 16px;">
                <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:15px;text-align: right;"> <b>SUB TOTAL (₹) : </b><?php echo displayPrice($total_amount); ?>  </p>
                <p style="text-align: right font-size: 16px;margin:0;font-weight: 100; padding-bottom:15px;">CGST (₹)  :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo displayPrice($cgst); ?> </p>
                <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;">SGST (₹)  :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo displayPrice($sgst); ?> </p>
                <p style=" text-align: right;font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;"> <b>GRAND TOTAL (1) (₹) : </b><?php echo displayPrice($totalPaybalAmountRoom); ?> 
                </p>
              </td>
            </tr>
        <?php } 
            $total=$totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt;
            $disc_value=$discountdata['discount_value'];
            $disc_type=$discountdata['discount_type'];
            $final_amt=getamountafterdiscount($disc_type, $disc_value, $total);
            $totaldiscount=calculatediscount($disc_type, $disc_value, $total);
        ?>
        <?php   if ($foodListdata != "") : ?>
        <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 20%;text-align: center;font-size: 18px; color: #fff">
            DATE
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 45%;text-align: center;font-size: 18px; color: #fff">
            ITEMS
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 35%;text-align:right;font-size: 18px; color: #fff">
            PRICE (₹) 
          </th>
        </tr>
<?php   foreach ($foodListdata as $allFooddatainfo) :

            if ($allFooddatainfo['order_date'] != "") {
                $orderDate = date('d/m/Y H:i', strtotime($allFooddatainfo['order_date']));
            } else {
                $orderDate = date('d/m/Y H:i');
            }

            if ($clickType == 'room_rent_with_gst' || $clickType == 'room_rent_with_food_gst') {

            if ($customerInfo['room_rent_type'] == 'gst_include') {

              $totalAmount  = round($foodBill['total_amount'] * 5) / 100;

              $cgst  = $totalAmount / 2;

              $sgst  = $totalAmount / 2;

              $totalPaybalAmount  = $foodBill['total_amount'] + $totalAmount;

            } elseif ($customerInfo['room_rent_type'] == 'gst_exclude') {

              $totalAmount  = round($foodBill['total_amount'] * 5) / 100;

              $cgst  = $totalAmount / 2;

              $sgst  = $totalAmount / 2;

              $totalPaybalAmount  = $foodBill['total_amount'] + $totalAmount;

            } elseif (empty($customerInfo['room_rent_type'])) {

              $totalAmount  = round($foodBill['total_amount'] * 5) / 100;

              $cgst  = $totalAmount / 2;

              $sgst  = $totalAmount / 2;

              $totalPaybalAmount  = $foodBill['total_amount'] + $totalAmount;

            }

          } elseif ($clickType == 'room_rent_without_food_gst' || $clickType == 'room_rent_without_gst') {

            $totalAmount  = $foodBill['total_amount'];
            $cgst  = 0;
            $sgst  = 0;
            $totalPaybalAmount  = $totalAmount;

          }
          $menuName  = explode('_', $allFooddatainfo['bill_item']);
          $billName  = $menuName[0];
          $quantity  = $menuName[1]; ?>
        <tr>
          <td style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 20%;text-align: center;font-size: 16px;border-bottom: 1px solid #000;"><?php echo date('d/m/Y', strtotime($customerInfo['check_out_datetime'])); ?></td>
          <td style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 45%;text-align: center;font-size: 16px;border-bottom: 1px solid #000;"><?php echo stripslashes(ucfirst($billName)); ?> <br/> <span style="font-size: 10px;"><?php if (($clickType == 'room_rent_with_gst' || $clickType == 'room_rent_with_food_gst')) { ?>SAC - 996331<?php } ?></span></td>
          <td style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 35%;text-align:right;font-size: 16px;border-bottom: 1px solid #000;"><?php echo displayPrice($allFooddatainfo['bill_amount']); ?>
          </td>
        </tr>
         <?php 

        endforeach; ?>
        <tr>
          <td colspan="3" style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 16px;">
            <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;text-align: right;"> <b>SUB TOTAL (₹) : </b><?php echo displayPrice($foodBill['total_amount']); ?> </p>
            <p style="text-align: right; font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;">CGST (₹)  : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo displayPrice($cgst); ?></p>
            <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;">SGST (₹)  :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo displayPrice($sgst); ?>  </p>
            <p style=" text-align: right;font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;"> <b>GRAND TOTAL (2) (₹) : </b><?php echo displayPrice($totalPaybalAmount); ?>
            </p>
          </td>
        </tr>
         <?php endif; ?>
        <?php $TotalServicesAmt = 0; 
        if($GetServiceGST){
            $num = !empty($foodListdata) ? 3 : 2;
            foreach ($GetServiceGST as $sGst) { ?>
            ?>
            <tr style="background:#bf40bf;">
              <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 20%;text-align: center;font-size: 18px; color: #fff">
                DATE
              </th>
              <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 45%;text-align: center;font-size: 18px; color: #fff">
                ITEMS
              </th>
              <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 35%;text-align: right;font-size: 18px; color: #fff">
                PRICE (₹) 
              </th>
            </tr>
            <?php 
            $GetBookID = implode(',', $GetBookIDArr);
            $ServiceQuery = "SELECT * FROM " . getTablePrefix() . "custom_bill_book  WHERE customer_id IN (".$GetBookID.") and page_source='add_a_services' and service_gst='".$sGst."' and service_check=1 ORDER BY id DESC";        
            $newServices = $this->common_model->getDataByQuery('multiple', $ServiceQuery);  

            $Services = $this->vendor_model->generateGroupbillbookServiceInvoice($GetBookIDArr, 'add_a_services',$sGst);
            foreach ($newServices as $row) {
              if ($row['order_date'] != "") {
                  $orderDate = date('d/m/Y H:i', strtotime($row['order_date']));
                } else {
                  $orderDate = date('d/m/Y H:i');
                }
                if ($billType == 'room_rent_with_gst' || $billType == 'room_rent_with_food_gst') {
                  if ($ALLGROUPBILLCUSTDATA[0]['room_rent_type'] == 'gst_include') {
                    $totalAmount  = round($Services['total_amount'] * $row['service_gst']) / 100;
                    $cgst  = $totalAmount / 2;
                    $sgst  = $totalAmount / 2;
                    $totalPaybalServiceAmount  = $Services['total_amount'] + $totalAmount;
                  } elseif ($ALLGROUPBILLCUSTDATA[0]['room_rent_type'] == 'gst_exclude') {
                    $totalAmount  = round($Services['total_amount'] * $row['service_gst']) / 100;
                    $cgst  = $totalAmount / 2;
                    $sgst  = $totalAmount / 2;
                    $totalPaybalServiceAmount  = $Services['total_amount'] + $totalAmount;
                  } elseif (empty($ALLGROUPBILLCUSTDATA[0]['room_rent_type'])) {
                    $totalAmount  = round($Services['total_amount'] * $row['service_gst']) / 100;
                    $cgst  = $totalAmount / 2;
                    $sgst  = $totalAmount / 2;
                    $totalPaybalServiceAmount  = $Services['total_amount'] + $totalAmount;
                  }
                } elseif ($billType == 'room_rent_without_food_gst' || $billType == 'room_rent_without_gst') {
                  $totalAmount  = $Services['total_amount'];
                  $cgst  = 0;
                  $sgst  = 0;
                  $totalPaybalServiceAmount  = $totalAmount;
                }
                $TotalServicesAmt+=$totalPaybalServiceAmount;
                $billName  = $row['bill_item']; ?>
            <tr>
              <td style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 20%;text-align: center;font-size: 16px;border-bottom: 1px solid #000;"><?php echo date('d/m/Y', strtotime($row['creation_date'])); ?></td>
              <td style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 45%;text-align: center;font-size: 16px;border-bottom: 1px solid #000;"><?php echo stripslashes(ucfirst($billName)); ?> <br/> <span style="font-size: 10px;"><?php echo $row['sac_code']; ?></span></td>
              <td style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;width: 35%;text-align: right;font-size: 16px;border-bottom: 1px solid #000;"><?php echo displayPrice($row['bill_amount']); ?>
              </td>
            </tr>
            <?php } ?>
            <tr>
              <td colspan="3" style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 16px;">
                <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;text-align: right;"> <b>SUB TOTAL (₹) : </b><?php echo displayPrice($Services['total_amount']); ?> </p>
                <p style="text-align: right; font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;">CGST (₹)  :&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <?php echo displayPrice($cgst); ?></p>
                <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;">SGST (₹)  : &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo displayPrice($sgst); ?>  </p>
                <p style=" text-align: right;font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;"> <b>GRAND TOTAL (₹) : </b><?php echo displayPrice($totalPaybalServiceAmount); ?>
                </p>
              </td>
            </tr>
        <?php } ?>
      <?php } ?>
      
        <!---------------- Grand Total With Word ---------------------->
    <?php if (empty($foodListdata)) { ?>
        <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: left;font-size: 18px; color: #fff;border-bottom: 0px solid #fff;" colspan="2">
            <?php if (!empty($totaldiscount)) { ?> TOTAL PAYABLE (₹) <?php echo $numDis;?> : <?php } else{ ?>GRAND TOTAL PAYABLE (₹) <?php //echo $numDis;?> : <?php } ?>
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 18px; color: #fff ; border-bottom: 0px solid #fff;font-weight: 400;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <?php echo displayPrice($totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt); ?>            
          </th>
        </tr>
        
        <?php 
        if (!empty($totaldiscount)) { ?>
        <tr>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <td colspan="3" style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 16px;">
            <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;text-align: right;"> <b>- Discount</b> (<?php echo displayPrice($totaldiscount); ?>)  </p>
          </td>
        </tr>
        <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: left;font-size: 18px; color: #fff;border-bottom: 0px solid #fff;" colspan="2">
            GRAND TOTAL PAYABLE (₹) :
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 18px; color: #fff ; border-bottom: 0px solid #fff;font-weight: 400;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <?php echo displayPrice($totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt - $totaldiscount); ?>            
          </th>
        </tr>
        <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: left;font-size: 18px; color: #fff">
            IN WORDS :
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 18px; color: #fff; font-weight: 400;" colspan="2"> <?php echo $class_obj->convert_number($totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt - $totaldiscount); ?> Rupees Only &nbsp;
          </th>
        </tr>
        <?php } else{ ?>
            <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: left;font-size: 18px; color: #fff">
            IN WORDS :
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 18px; color: #fff; font-weight: 400;" colspan="2"> <?php echo $class_obj->convert_number($totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt); ?> Rupees Only &nbsp;
          </th>
        </tr>
    <?php } } else{ ?>
        <?php 
        if (!empty($totaldiscount)) { ?>
            <tr style="background:#bf40bf;">
              <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: left;font-size: 18px; color: #fff;border-bottom: 0px solid #fff;" colspan="2">
                <?php if (!empty($totaldiscount)) { ?> TOTAL PAYABLE (₹) <?php echo $numDis;?>: <?php } else{ ?>GRAND TOTAL PAYABLE (₹) : <?php } ?>
              </th>
              <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 18px; color: #fff ; border-bottom: 0px solid #fff;font-weight: 400;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <?php echo displayPrice($totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt); ?>            
              </th>
        </tr>
        <tr>
            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
          <td colspan="3" style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 16px;">
            <p style=" font-size: 16px;margin:0;font-weight: 100; padding-bottom:10px;text-align: right;"> <b>- Discount</b> (<?php echo displayPrice($totaldiscount); ?>)  </p>
          </td>
        </tr>
        <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: left;font-size: 18px; color: #fff;border-bottom: 0px solid #fff;" colspan="2">
            GRAND TOTAL PAYABLE (₹) :
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 18px; color: #fff ; border-bottom: 0px solid #fff;font-weight: 400;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <?php echo displayPrice($totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt - $totaldiscount); ?>            
          </th>
        </tr>
        <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: left;font-size: 18px; color: #fff">
            IN WORDS :
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 18px; color: #fff; font-weight: 400;" colspan="2"> <?php echo $class_obj->convert_number($totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt - $totaldiscount);?> Rupees Only &nbsp;
          </th>
        </tr>
        <?php } else{ ?>
        <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: left;font-size: 18px; color: #fff;border-bottom: 0px solid #fff;" colspan="2">
            GRAND TOTAL PAYABLE (₹) :
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 18px; color: #fff ; border-bottom: 0px solid #fff;font-weight: 400;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <?php echo displayPrice($totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt); ?>          
          </th>
        </tr>
        <tr style="background:#bf40bf;">
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: left;font-size: 18px; color: #fff">
            IN WORDS :
          </th>
          <th style="margin: 0;padding: 10px;box-sizing: border-box;font-family: Lato, sans-serif;text-align: right;font-size: 18px; color: #fff; font-weight: 400;" colspan="2"> <?php echo $class_obj->convert_number($totalPaybalAmountRoom + $totalPaybalAmount + $TotalServicesAmt);?> Rupees Only &nbsp;
          </th>
        </tr>
    <?php } ?>
        
    <?php } ?>
    <?php if(!empty($allSelectedData)){  ?>
        <tr>
          <td colspan="3" style="text-align: center;margin: 20px 0px;padding: 30px 0px;">
            <p style="margin: 0;padding: 5px;box-sizing: border-box;font-weight: bold; font-family: Lato, sans-serif;padding-bottom: 5px;font-size: 13px;"> Details of Payment Received</p>
        <?php foreach ($allSelectedData as $key => $cust) { ?>
            <p style="margin: 0;padding: 5px;box-sizing: border-box;font-family: Lato, sans-serif;padding-bottom: 3px;font-size: 13px;">
              ₹ <?php echo displayPrice($cust['payment_paid']) . ' Received via '.stripslashes(ucfirst($cust['amount_mode'] =="offline" ? "Cash" : $cust['amount_mode'])).' on ' . date('d M Y', strtotime($cust['order_date'])); ?>
            </p>
        <?php
            } ?>
          </td>
        </tr>
         <?php } ?>    
        <?php if (!empty($VENDORDETAIL['other_details'])){ ?>
        <tr style="text-align: center">
          <td colspan="3" style="margin: 20px 0px;padding: 30px 0px;text-align: center;">
            <h3 style="text-align: center;box-sizing: border-box;font-family: Lato, sans-serif;text-align: center;padding-bottom: 5px;font-size: 13px;font-weight: 300;"><?php echo $VENDORDETAIL['other_details']; ?>
            </h3>
          </td>
        </tr>
         <?php } ?>
        <tr>
          <th style="text-align: left;padding-top: 10px;">
            <h3 style="margin: 0;padding: 0; margin-top: 40px; box-sizing: border-box;font-family: Lato, sans-serif;font-size: 16px; text-align: left;">
              <br/><br/>
              <b>CUSTOMER</b>
            </h3>
          </th>
          <th colspan="2" style="text-align: right;padding-top: 10px;">
            <h3 style="margin: 0;padding: 0; margin-top: 40px; box-sizing: border-box;font-family: Lato, sans-serif;font-size: 16px;text-align:right;">
              <br/><br/>
              <b>MANAGER</b>
            </h3>
          </th>
        </tr>
      </tbody>
    </table>
  </body>
</html>