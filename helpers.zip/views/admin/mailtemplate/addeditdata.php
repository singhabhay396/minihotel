<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{FULL_SITE_URL}dashboard" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?php echo correctLink('mailtemplateAdminData','{FULL_SITE_URL}{CURRENT_CLASS}/index'); ?>" class=""><i class="fa fa-file-text-o"></i>Mail Template</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?=$EDITDATA?'Edit':'Add'?> Mail Template</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid"> 
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?=$EDITDATA?'Edit':'Add'?> Mail Template</h3>
          <a href="<?php echo correctLink('mailtemplateAdminData','{FULL_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?=$EDITDATA['id']?>"/>
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="form-group <?php if(form_error('mailtype')): ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Mail Type<span class="required">*</span></label>
                    <input type="text" name="mailtype" id="mailtype" value="<?php if(set_value('mailtype')): echo set_value('mailtype'); else: echo stripslashes($EDITDATA['mailtype']);endif; ?>" class="form-control" placeholder="Mail Type" readonly="readonly">
                    <?php if(form_error('mailtype')): ?>
                      <span for="mailtype" generated="true" class="help-inline"><?php echo form_error('mailtype'); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="form-group <?php if(form_error('subject')): ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Subject<span class="required">*</span></label>
                    <input type="text" name="subject" id="subject" value="<?php if(set_value('subject')): echo set_value('subject'); else: echo stripslashes($EDITDATA['subject']);endif; ?>" class="form-control required" placeholder="Subject">
                    <?php if(form_error('subject')): ?>
                      <span for="subject" generated="true" class="help-inline"><?php echo form_error('subject'); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="form-group <?php if(form_error('mail_header')): ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Mail Header<span class="required">*</span></label>
                    <textarea name="mail_header" id="mail_header" class="form-control required" placeholder="Mail Header"><?php if(set_value('mail_header')): echo set_value('mail_header'); else: echo stripslashes($EDITDATA['mail_header']);endif; ?></textarea>
                    <?php if(form_error('mail_header')): ?>
                      <span for="mail_header" generated="true" class="help-inline"><?php echo form_error('mail_header'); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="form-group <?php if(form_error('mail_body')): ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Mail Body<span class="required">*</span></label>
                    <textarea name="mail_body" id="mail_body" class="form-control required" placeholder="Mail Body"><?php if(set_value('mail_body')): echo set_value('mail_body'); else: echo stripslashes($EDITDATA['mail_body']);endif; ?></textarea>
                    <?php if(form_error('mail_body')): ?>
                      <span for="mail_body" generated="true" class="help-inline"><?php echo form_error('mail_body'); ?></span>
                    <?php endif; ?>
                    <span style="color:red;">Please don't make any changes in {VALUES}. The VALUES will be changed dynamically.</span>
                  </div>
                </div>
              </div>
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-12 col-sm-12 col-xs-12">
                  <div class="form-group <?php if(form_error('mail_footer')): ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Mail Footer<span class="required">*</span></label>
                    <textarea name="mail_footer" id="mail_footer" class="form-control required" placeholder="Mail Footer"><?php if(set_value('mail_footer')): echo set_value('mail_footer'); else: echo stripslashes($EDITDATA['mail_footer']);endif; ?></textarea>
                    <?php if(form_error('mail_footer')): ?>
                      <span for="mail_footer" generated="true" class="help-inline"><?php echo form_error('mail_footer'); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="<?php echo correctLink('mailtemplateAdminData','{FULL_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-primary btn-lg form-btn">Cancel</a> 
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                  :- <strong><span style="color:#FF0000;">*</span> Indicates
                  Required Fields</strong> </span> 
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
  $(function(){
    create_editor_for_textarea('mail_header');
    create_editor_for_textarea('mail_body');
    create_editor_for_textarea('mail_footer');
  });
</script>