<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{FULL_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Testimonial</a></li>
    </ol>
  </div>
  <div class="main-content" id="addEditSection" style="display:none;">
    <div class="container-fluid"> 
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?=$EDITDATA?'Edit':'Add'?> Testimonial</h3>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?=$EDITDATA['testimonial_id']?>"/>
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>">
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="form-group <?php if(form_error('name')): ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Name<span class="required">*</span></label>
                    <input type="text" name="name" id="name"value="<?php if(set_value('name')): echo set_value('name'); else: echo stripslashes($EDITDATA['name']);endif; ?>" class="form-control required" placeholder="Name">
                    <?php if(form_error('name')): ?>
                      <p for="name" generated="true" class="error"><?php echo form_error('name'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
                <!-- <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="form-group <?php if(form_error('designation')): ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Designation<span class="required">*</span></label>
                    <input type="text" name="designation" id="designation"value="<?php if(set_value('designation')): echo set_value('designation'); else: echo stripslashes($EDITDATA['designation']);endif; ?>" class="form-control required" placeholder="Designation">
                    <?php if(form_error('designation')): ?>
                      <p for="designation" generated="true" class="error"><?php echo form_error('designation'); ?></p>
                    <?php endif; ?>
                  </div>
                </div> -->
              </div>
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-8 col-sm-8 col-xs-8">
                  <div class="form-group <?php if(form_error('content')): ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Content<span class="required">*</span></label>
                    <textarea name="content" id="content" class="form-control required" placeholder="Content"><?php if(set_value('content')): echo set_value('content'); else: echo stripslashes($EDITDATA['content']);endif; ?></textarea>
                    <?php if(form_error('content')): ?>
                      <p for="content" generated="true" class="error"><?php echo form_error('content'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="form-group <?php if(form_error('image')): ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Image<span class="required">*</span></label>
                    <?php if(set_value('image')): $testimage = set_value('image'); elseif($EDITDATA['image']): $testimage = stripslashes($EDITDATA['image']); else: $testimage = ''; endif; ?>
                    <img border="0" alt="" src="{ASSET_ADMIN_URL}images/browse-white.png" id="prodAttImageUpload" class="img-responsive" style="cursor:pointer;">
                    <input type="etxt" name="image" id="prodAttImageInput" value="<?php echo $testimage; ?>" class="form-control required" style="border:none;width:0px;height:0px;margin-top: -14px;" />
                    <?php if(form_error('image')): ?>
                      <span for="image" generated="true" class="help-inline"><?php echo form_error('image'); ?></span>
                    <?php endif; ?>
                    <span id="prodAttImageDiv" style="margin-top:5px;">
                      <?php if($testimage): ?>
                       <img border="0" alt="" src="<?php echo $testimage; ?>" class="img-responsive" width="100">&nbsp;
                       <a class="spancross" onclick="prodAttImageDelete('<?php echo $testimage; ?>');" href="javascript:void(0);"> <img border="0" alt="" src="{ASSET_ADMIN_URL}images/cross.png"></a>
                      <?php endif; ?>
                    </span>
                  </div>
                </div>
              </div>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="javascript:void(0);" class="btn btn-primary btn-lg form-btn" id="cancelAddEditSection">Cancel</a> 
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                  :- <strong><span style="color:#FF0000;">*</span> Indicates
                  Required Fields</strong> </span> 
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
<div id="testmonialImageUploadModel" class="modal" role="dialog">
  <div class="modal-dialog modal-sm"> 
    <div class="modal-content">
      <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
            <h4>
              <center>Position And Size Your Photo</center>
            </h4>
       </div>
      <div class="modal-body">
        <div class="profileimg-plug col-md-12 col-sm-12 col-xs-12">
                <div class="image-editor">
                  <div class="file-input-wrapper">
                    <label for="prodAtt-upload-profile-file" class="file-input-button">Choose Image</label>
                    <input type="file" name="image" id="prodAtt-upload-profile-file" class="cropit-image-input"><br />
                    <span style="color:#FF0000; font-size:12px;" id="prodAttBlinker">Image Must Be Min Width: 239px
                          And Min Height: 239px.</span>
                  </div>
                  <div class="cropit-preview"></div>
                  <div class="image-size-label"> Resize Image </div>
                  <div class="rotat-btn">
                    <input type="range" class="cropit-image-zoom-input"><br />
                    <button class="rotate-ccw"><i class="fa fa-refresh" aria-hidden="true"></i></button>
                    <button class="rotate-cw"><i class="fa fa-repeat"></i></button>
                  </div>
                </div>
            </div>
      </div>
      <div class="modal-footer">
            <button type="button" class="btn btn-default prodAttImageClosedButton" data-dismiss="modal">Close</button>
            <button type="button" class="btn btn-default prodAttImageSaveButton">Save</button>
            <input type="hidden" name="prodAttImageLoading" id="prodAttImageLoading" value="NO" />
        </div>
    </div>
  </div>
</div>
<script>
  $(function(){
    $('#testmonialImageUploadModel .image-editor').cropit();
    
    $('#testmonialImageUploadModel .rotate-cw').click(function() {
      $('#testmonialImageUploadModel .image-editor').cropit('rotateCW');
    });
    
    $('#testmonialImageUploadModel .rotate-ccw').click(function() {
      $('#testmonialImageUploadModel .image-editor').cropit('rotateCCW');
    });
  });
  $(document).on('click','#prodAttImageUpload',function(){
    $('#testmonialImageUploadModel').modal({backdrop:'static', show: true, keyword: false});
    $('#testmonialImageUploadModel .cropit-preview img').attr('src','');
    $('#testmonialImageUploadModel .modal-footer.plucgin-clodebtn .prodAttImageClosedButton').html('Close');
    $('#testmonialImageUploadModel .modal-footer.plucgin-clodebtn .prodAttImageSaveButton').html('Save');
    $('#testmonialImageUploadModel #prodAttImageLoading').val('NO');
    
    $(".modal-footer .prodAttImageClosedButton").removeAttr('disabled');
    $(".modal-footer .prodAttImageSaveButton").removeAttr('disabled');
  });
  $(document).on('click','.prodAttImageSaveButton',function() {  
    var imageData = $('#testmonialImageUploadModel .image-editor').cropit('export'); 
    if($('#testmonialImageUploadModel #prodAttImageLoading').val() == 'NO')
    {
      $('#testmonialImageUploadModel .prodAttImageSaveButton').html('Saving..');
      $('#testmonialImageUploadModel #prodAttImageLoading').val('YES');
      
      $(".modal-footer .prodAttImageClosedButton").attr("disabled", "disabled");
      $(".modal-footer .prodAttImageSaveButton").attr("disabled", "disabled");
      
      $.ajax({
          type: 'post',
           url: FULLSITEURL+CURRENTCLASS+'/prodAttImageUpload',
          data: {imageData:imageData},
        success: function(rdata){ 
          if(rdata != 'UPLODEERROR') {
            $('#prodAttImageInput').val(rdata);
            $('#prodAttImageDiv').html('<img src="'+rdata+'" border="0" alt="" width="100" /> <a href="javascript:void(0);" onClick="prodAttImageDelete(\''+rdata+'\');"> <img src="{ASSET_ADMIN_URL}images/cross.png" border="0" alt="" /> </a>');
            $('#testmonialImageUploadModel').modal('hide');
            $('#testmonialImageUploadModel #prodAttImageLoading').val('NO');
            return false;
          }
        }
      });
    }
  });

  //////////////////////////////////   Image delete Through Ajax
  function prodAttImageDelete(imageName)
  {
      if(confirm("Sure to delete?"))
      {
          $.ajax({
           type: 'post',
                url: FULLSITEURL+CURRENTCLASS+'/prodAttImageDelete',
         data: {csrf_api_key:csrf_api_value,imageName:imageName},
                success: function(response) { 
            document.getElementById('prodAttImageInput').value = '';
          document.getElementById('prodAttImageDiv').innerHTML ='';
                }
              });
      }
  }
</script>
<script>
  var prodAtt_blink_speed = 500; var prodAtt = setInterval(function () { var prodAttsele = document.getElementById('prodAttBlinker'); prodAttsele.style.visibility = (prodAttsele.style.visibility == 'hidden' ? '' : 'hidden'); }, prodAtt_blink_speed);
</script>  
  <div class="main-content">
    <div class="container-fluid"> 
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Testimonial</h3>
          <a href="javascript:void(0);" class="btn btn-default add_btn" id="openAddEditSection">Add Testimonial</a>
        </div>
        <hr class="differ">
        <form id="Data_Form" name="Data_Form" method="get" action="<?php echo $forAction; ?>">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6 search">
              <label>Show
                <select name="showLength" id="showLength" class="form-control input-sm">
                  <option value="2" <?php if($perpage == '2')echo 'selected="selected"'; ?>>2</option>
                  <option value="10" <?php if($perpage == '10')echo 'selected="selected"'; ?>>10</option>
                  <option value="25" <?php if($perpage == '25')echo 'selected="selected"'; ?>>25</option>
                  <option value="50" <?php if($perpage == '50')echo 'selected="selected"'; ?>>50</option>
                  <option value="100" <?php if($perpage == '100')echo 'selected="selected"'; ?>>100</option>
                  <option value="All" <?php if($perpage == 'All')echo 'selected="selected"'; ?>>All</option>
                </select>
                entries
              </label>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-6 search-ryt">
              <input type="text" name="searchValue" id="searchValue" value="<?php echo $searchValue; ?>" class="form-control input-smt" placeholder="Enter Search Text">
            </div>
          </div>
          <div class="dash">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="10%">Sr.No.</th>
                  <th>Name</th>
                  <!-- <th>Designation</th> -->
                  <th>Image</th>
                  <th>Content</th>
                  <th>Status</th>
                  <?php if($edit_data == 'Y'): ?>
                  <th width="10%" class="center">--</th>
                  <?php endif; ?>
                </tr>
              </thead>
              <tbody>
                <?php if($ALLDATA <> ""): $i=1; foreach($ALLDATA as $ALLDATAINFO): ?>
                  <tr class="<?php if($i%2 == 0): echo 'odd'; else: echo 'even'; endif; ?> gradeX">
                    <td><?=$i++?></td>
                    <td><?=stripslashes($ALLDATAINFO['name'])?></td>
                    <!-- <td><?=stripslashes($ALLDATAINFO['designation'])?></td> -->
                    <td>
                      <?php if($ALLDATAINFO['image']): ?>
                        <img src="<?=stripslashes($ALLDATAINFO['image'])?>" alt="Client image" width="100">
                      <?php endif; ?>
                    </td>
                    <td><?=stripslashes($ALLDATAINFO['content'])?></td>
                    <td><?=showStatus($ALLDATAINFO['status'])?></td>
                    <?php if($edit_data == 'Y'): ?>
                      <td class="center">
                        <div class="btn-group">
                          <button class="btn dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                          <ul class="dropdown-menu">
                            <?php if($edit_data == 'Y'): ?>
                              <li><a href="<?=$editlink.$ALLDATAINFO['testimonial_id']?>"><i class="fa fa-edit"></i> Edit Details</a></li>
                              <li class="divider"></li>
                              <?php if($ALLDATAINFO['status'] == 'Y'): ?>
                              <li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/changeStatus/<?=$ALLDATAINFO['testimonial_id']?>/N"><i class="fa fa-hand-o-up"></i> Inactive</a></li>
                              <?php elseif($ALLDATAINFO['status'] == 'N'): ?>
                              <li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/changeStatus/<?=$ALLDATAINFO['testimonial_id']?>/Y"><i class="fa fa-hand-o-up"></i> Active</a></li>
                            <?php endif; if($ALLDATAINFO['status'] == 'N'): ?>
                              <li class="divider"></li>
                              <li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/deleteData/<?=$ALLDATAINFO['testimonial_id']?>" onclick="return confirm('Are You Sure You Want To Delete This?');"><i class="fa fa-trash"></i> Delete</a></li>
                            <?php endif; endif; ?>
                          </ul>
                        </div>
                      </td>
                    <?php endif; ?>
                  </tr>
                <?php endforeach; else: ?>
                  <tr>
                    <td colspan="7" style="text-align:center;">No Data Available In Table</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
            <div class="pagi row">
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-txt"><?php echo $noOfContent; ?></div>
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-bar">
                <?=$PAGINATION?>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
var prevSerchValue  = '<?php echo $searchValue; ?>';
</script>
<script type="text/javascript">
  $(function(){
    <?php if($formError == 'Yes'): ?>
      $('#addEditSection').slideDown();
    <?php elseif($editid): ?>
      $('#addEditSection').slideDown();
    <?php endif; ?>
  });
  $(document).on('click','#openAddEditSection',function(){
    $('#addEditSection').slideDown();
  });
  <?php if($editid): ?>
    $(document).on('click','#cancelAddEditSection',function(){ 
      window.location.href = '<?php echo $cancellink; ?>';
    });
  <?php else: ?>
    $(document).on('click','#cancelAddEditSection',function(){
      $('#addEditSection').slideUp();
    });
  <?php endif; ?>
</script>