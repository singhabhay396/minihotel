<script src="{ASSET_ADMIN_URL}js/multiselect-dropdown.js"></script>
<style>
  .multiselect-dropdown-list-wrapper {
    width: 342px !important;
  }

  .multiselect-dropdown {
    width: 245px !important;
  }
</style>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{ADMIN_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-hotel"></i>Individual Messages</a></li>
    </ol>
  </div>
  <div class="main-content" id="addEditSection" style="display:none;">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Individual Messages</h3>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['message_id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="form-group <?php if (form_error('vendor_id')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Select Hotel<span class="required">*</span></label>
                    <?php if (set_value('vendor_id')) : $assignVendorId = set_value('vendor_id');
                    elseif ($EDITDATA['vendor_id']) : $assignVendorId = stripslashes($EDITDATA['vendor_id']);
                    else : $assignVendorId = '';
                    endif; ?>
                    <select name="vendor_id[]" id="vendor_id" class="form-control" multiple multiselect-search="true" multiselect-select-all="true">
                      <?php echo $this->admin_model->getAllVendors($assignVendorId); ?>
                    </select>
                    <?php if (form_error('vendor_id')) : ?>
                      <span for="vendor_id" generated="true" class="help-inline"><?php echo form_error('vendor_id'); ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-8 col-sm-8 col-xs-8">
                  <div class="form-group <?php if (form_error('message')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Individual Messages<span class="required">*</span></label>
                    <input type="text" name="message" id="message" class="form-control">
                    <?php if (form_error('message')) : ?>
                      <p for="message" generated="true" class="error"><?php echo form_error('message'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="javascript:void(0);" class="btn btn-primary btn-lg form-btn" id="cancelAddEditSection">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                  :- <strong><span style="color:#FF0000;">*</span> Indicates
                    Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Individual Messages</h3>
          <a href="javascript:void(0);" class="btn btn-default add_btn" id="openAddEditSection">Individual Messages</a>
        </div>
        <hr class="differ">
        <form id="Data_Form" name="Data_Form" method="get" action="<?php echo $forAction; ?>" autocomplete="off">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6 search">
              <label>Show
                <select name="showLength" id="showLength" class="form-control input-sm">
                  <option value="2" <?php if ($perpage == '2') echo 'selected="selected"'; ?>>2</option>
                  <option value="10" <?php if ($perpage == '10') echo 'selected="selected"'; ?>>10</option>
                  <option value="25" <?php if ($perpage == '25') echo 'selected="selected"'; ?>>25</option>
                  <option value="50" <?php if ($perpage == '50') echo 'selected="selected"'; ?>>50</option>
                  <option value="100" <?php if ($perpage == '100') echo 'selected="selected"'; ?>>100</option>
                  <option value="All" <?php if ($perpage == 'All') echo 'selected="selected"'; ?>>All</option>
                </select>
                entries
              </label>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-6 search-ryt">
              <input type="text" name="searchValue" id="searchValue" value="<?php echo $searchValue; ?>" class="form-control input-smt" placeholder="Enter Search Text">
            </div>
          </div>
          <div class="dash">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="10%">Sr.No.</th>
                  <th>From</th>
                  <th>To</th>
                  <th>Message</th>
                  <th>Delivery Date</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($ALLDATA <> "") : $i = 1;
                  foreach ($ALLDATA as $ALLDATAINFO) : ?>
                    <tr class="<?php if ($i % 2 == 0) : echo 'odd';  else : echo 'even';  endif; ?> gradeX">
                      <td><?= $i++ ?></td>
                      <?php if($ALLDATAINFO['created_by']  == $this->session->userdata('MHM_ADMIN_ID') ) : ?>
                        <td><?= stripslashes($ALLDATAINFO['admin_display_name']) ?></td>
                        <td><?= stripslashes($ALLDATAINFO['vendor_business_name']) ?></td>
                        <?php else: ?>
                          <td><?= stripslashes($ALLDATAINFO['vendor_business_name']) ?></td>
                          <td><?= stripslashes($ALLDATAINFO['admin_display_name']) ?></td>
                          <?php endif;?>
                      <td><?= stripslashes($ALLDATAINFO['message']) ?></td>
                      <td><?= date('d-m-Y h:i A', strtotime($ALLDATAINFO['creation_date'])) ?></td>
                    </tr>
                  <?php endforeach;
                else : ?>
                  <tr>
                    <td colspan="5" style="text-align:center;">No Data Available In Table</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
            <div class="pagi row">
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-txt"><?php echo $noOfContent; ?></div>
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-bar">
                <?= $PAGINATION ?>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
  var prevSerchValue = '<?php echo $searchValue; ?>';
</script>

<script>
  $(function() {
    create_editor_for_textarea('content')
  });
</script>
<script type="text/javascript">
  $(function() {
    <?php if ($formError == 'Yes') : ?>
      $('#addEditSection').slideDown();
    <?php elseif ($editid) : ?>
      $('#addEditSection').slideDown();
    <?php endif; ?>
  });
  $(document).on('click', '#openAddEditSection', function() {
    $('#addEditSection').slideDown();
  });
  <?php if ($editid) : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      window.location.href = '<?php echo $cancellink; ?>';
    });
  <?php else : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      $('#addEditSection').slideUp();
    });
  <?php endif; ?>
</script>