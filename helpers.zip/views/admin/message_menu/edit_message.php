<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{FULL_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
    </ol>
  </div>
  <div class="main-content" id="addEditSection" style="display:none;">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-quotes tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Quotes</h3>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['quotes_id'] ?>" />
              <input type="hidden" name="<?= $this->security->get_csrf_token_name(); ?>" value="<?= $this->security->get_csrf_hash(); ?>">
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-10 col-sm-10 col-xs-10">
                  <div class="form-group <?php if (form_error('quotes')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Quotes<span class="required">*</span></label>
                    <input type="text" name="quotes" id="quotes" value="<?php if (set_value('quotes')) : echo set_value('quotes'); else : echo stripslashes($EDITDATA['quotes']); endif; ?>" class="form-control required" placeholder="quotes">
                    <?php if (form_error('quotes')) : ?>
                      <p for="quotes" generated="true" class="error"><?php echo form_error('quotes'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="javascript:void(0);" class="btn btn-primary btn-lg form-btn" id="cancelAddEditSection">Cancel</a>
              <span class="tools pull-right">
                <span class="btn btn-primary btn-lg btn-block">Note: <strong><span style="color:#FF0000;">*</span> Indicates Required Fields</strong></span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="main-content">
    <div class="panel panel-headline">
      <title>Edit Message</title>
      <div class="container">
        <h2>Edit Message</h2>
        <form method="post" action="<?php echo base_url().'admin/adminownermessage/updatemessage' ?>">
          <input type="hidden" name="messageid" value="<?php echo  $msgdata['id']; ?>">
          <div class="form-group">
            <label for="dropdown">Business Name:</label>
            <select name="bussines_name" class="form-control" id="dropdown" onchange="fetchData()">
              <option>--Select Owner--</option>
              <?php foreach($ownerdata as $odata) {
                $owner_selected = ($b_name==$odata['vendor_id']) ? 'selected' : '';
              ?>
              <option value="<?php echo $odata['vendor_id']; ?>" <?php echo $owner_selected; ?>><?php echo $odata['vendor_business_name']; ?></option>
              <?php } ?>
            </select>
          </div>
          <div class="form-group" id="responseDiv">
            <?php
              $vender_ids = explode(",", $msgdata['child_hotels']);
              if (!empty($vender_ids) && isset($vender_ids[0]) && $vender_ids[0] !== "") {
                $vendor = $this->message_model->getvendorname($vender_ids['0']);
              } else {
                $vendor = $this->message_model->getcheckboxdata($b_name);
              }
              $count = count($vendor);
              for ($i = 0; $i < $count; $i++) {
                $isChecked = (in_array($vendor[$i]['vendor_id'], $vender_ids)) ? 'checked' : '';
                echo "<input type='checkbox' name='business_id[]' value='".$vendor[$i]['vendor_id']."' ".$isChecked.">&nbsp;&nbsp;".$vendor[$i]['vendor_business_name']."<br>";
              }
            ?>
          </div>
          <div class="form-group">
            <label for="textarea">Message:</label>
            <textarea name="message" class="form-control" id="textarea" rows="3"><?php echo $msgdata['message']; ?></textarea>
          </div>
          <div class="form-check">
            <?php
              $manger_checked = ($manger==1) ? 'checked' : '';
            ?>
            <input <?php echo $manger_checked; ?> name="is_manager" value="1" type="checkbox" class="form-check-input" id="is_manager">
            <label class="form-check-label" for="is_manager">Manager</label>
          </div>
          <div class="form-check">
            <input type="radio" class="form-check-input" id="active" name="status" value="A" <?php if($status=="A"){echo "checked";}?>>
            <label class="form-check-label" for="active">Active</label>
          </div>
          <div class="form-check">
            <input type="radio" class="form-check-input" id="inactive" name="status" value="I" <?php if($status=="I"){echo "checked";}?>>
            <label class="form-check-label" for="inactive">Inactive</label>
          </div>
          <div class="form-check">
            <input type="hidden" class="form-check-input" id="date" name="date" value="inactive">
          </div>
      </div></br>
        <div>
            <input type="submit" name="save" class="btn btn-primary btn-lg form-btn">
            <a class="btn btn-primary btn-lg form-btn" href="<?php echo base_url().'admin/adminownermessage/index' ?>">Cancel</a>
          </div>        
        </form><br>
    </div>
  </div>
</div>

<script>
  var prevSerchValue = '<?php echo $searchValue; ?>';
</script>
<script type="text/javascript">
  $(function() {
    <?php if ($formError == 'Yes') : ?>
      $('#addEditSection').slideDown();
    <?php elseif ($editid) : ?>
      $('#addEditSection').slideDown();
    <?php endif; ?>
  });

  $(document).on('click', '#openAddEditSection', function() {
    $('#addEditSection').slideDown();
  });

  <?php if ($editid) : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      window.location.href = '<?php echo $cancellink; ?>';
    });
  <?php else : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      $('#addEditSection').slideUp();
    });
  <?php endif; ?>
</script>

<script>
  function fetchData() {
    var selectedValue = document.getElementById("dropdown").value;
    var data = {
      selectedValue: selectedValue
    };
    $.ajax({
      type: "POST",
      url: "checkbox/"+selectedValue,
      data: data,
      success: function(response) {
        console.log(response);
        $("#responseDiv").html(response);
      },
      error: function(error) {
        console.error(error);
      }
    });
  }
</script>
