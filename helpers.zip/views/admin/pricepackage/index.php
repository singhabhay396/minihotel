<div class="main">
    <div class="bready">
        <ol class="breadcrumb">
            <li><a href="{FULL_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
            <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Manage Plans</a></li>
        </ol>
    </div>
    <div class="main-content" id="addEditSection" style="display:none;">
        <div class="container-fluid">
            <div class="panel panel-headline inr-form">
                <div class="panel-heading row">
                    <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Manage Plans</h3>
                </div>
                <hr class="differ">
                <div class="panel">
                    <div class="panel-body row">
                        <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
                            <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['plan_id'] ?>" />
                            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
                            <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                                <?php /*?><div class="col-md-6 col-sm-6 col-xs-6">
                                    <div class="form-group <?php if (form_error('title')) : ?>error<?php endif; ?>">
                                        <label class="fancy-checkbox form-headings">Title<span class="required">*</span></label>
                                        <input type="text" name="title" id="title" value="<?php if (set_value('title')) : echo set_value('title');
                                                                                            else : echo stripslashes($EDITDATA['title']);
                                                                                            endif; ?>" class="form-control required" placeholder="Title">
                                        <?php if (form_error('title')) : ?>
                                            <p for="title" generated="true" class="error"><?php echo form_error('title'); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-6">
                                    <div class="form-group <?php if (form_error('price')) : ?>error<?php endif; ?>">
                                        <label class="fancy-checkbox form-headings">Price<span class="required">*</span></label>
                                        <input type="text" name="price" id="price" value="<?php if (set_value('price')) : echo set_value('price');
                                                                                            else : echo stripslashes($EDITDATA['price']);
                                                                                            endif; ?>" class="form-control numberonly required" placeholder="Price Plan" minlength="1" maxlength="5">
                                        <?php if (form_error('price')) : ?>
                                            <p for="price" generated="true" class="error"><?php echo form_error('price'); ?></p>
                                        <?php endif; ?>
                                    </div>
                                </div><?php */ ?>
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <div class="form-group <?php if (form_error('content')) : ?>error<?php endif; ?>">
                                        <label class="fancy-checkbox form-headings">Description<span class="required">*</span></label>
                                        <textarea name="content" id="content" class="form-control required" placeholder="Description"><?php if (set_value('content')) : echo set_value('content');
                                                                                                                                        else : echo stripslashes($EDITDATA['description']);
                                                                                                                                        endif; ?></textarea>
                                        <?php if (form_error('content')) : ?>
                                            <span for="content" generated="true" class="help-inline"><?php echo form_error('content'); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php /*?> <fieldset>
                                <legend>Services Data</legend>
                                <?php $allfilterids   = array();
                                if ($TotalFilterDefault) : $TotalFilterDefaultCount = $TotalFilterDefault;
                                elseif ($QUESTIONDATA <> "") : $TotalFilterDefaultCount = count($QUESTIONDATA);
                                else : $TotalFilterDefaultCount = 1;
                                endif; ?>
                                <input type="hidden" name="TotalFilterDefault" id="TotalFilterDefault" value="<?php echo $TotalFilterDefaultCount; ?>" />
                                <div id="FilterDefault">
                                    <?php if ($TotalFilterDefault) : $i = 1;
                                        for ($j = 1; $j <= $TotalFilterDefault; $j++) :
                                            if ($i == 1) : $requiredField = 'required';
                                                $removeaddbutton = '';
                                                $numcount = '<span class="required"> * </span>';
                                                $horizontal = '';
                                            else : $requiredField = '';
                                                $removeaddbutton = '<a href="javascript:void(0);" class="removeMoreFilterDetails pull-right">-Remove this Item</a>';
                                                $numcount = $i;
                                                $horizontal = '<hr />';
                                            endif;
                                            $filter_details_id_       =   'filter_details_id_' . $i;
                                            $billItem_           =   'billItem_' . $i;
                                            $error_details_       = form_error('billItem_' . $i);
                                            array_push($allfilterids, $$filter_details_id_);
                                    ?>
                                            <span> <?php echo $horizontal; ?>
                                                <input type="hidden" name="filter_details_id_<?php echo $i; ?>" id="filter_details_id_<?php echo $i; ?>" class="form-control" value="<?php echo $$filter_details_id_; ?>" />
                                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                                                    <div class="col-md-8 col-sm-8 col-xs-8">
                                                        <div class="form-group <?php if (form_error('services')) : ?>error<?php endif; ?>">
                                                            <label class="fancy-checkbox form-headings">Services<span class="required">*</span></label>
                                                            <input type="text" name="services_<?php echo $i; ?>" id="services_<?php echo $i; ?>" class="form-control required" placeholder="Hotel Service Name">
                                                            <?php if (form_error('services')) : ?>
                                                                <p for="services" generated="true" class="error"><?php echo form_error('services'); ?></p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group"> <?php echo $removeaddbutton; ?> </div>
                                            </span>
                                        <?php $i++;
                                        endfor;
                                    elseif ($QUESTIONDATA <> "") : $i = 1;
                                        foreach ($QUESTIONDATA as  $QUESTIONDATAINFO) :  //echo "<pre>"; print_r($QUESTIONDATAINFO['test_ques']); die;

                                            if ($i == 1) : $requiredField = 'required';
                                                $removeaddbutton = '';
                                                $numcount = '<span class="required"> * </span>';
                                                $horizontal = '';
                                            else : $requiredField = '';
                                                $removeaddbutton = '<a href="javascript:void(0);" class="removeMoreFilterDetails pull-right">-Remove this Item</a>';
                                                $numcount = $i;
                                                $horizontal = '<hr />';
                                            endif;
                                            $filter_details_id_    =   $QUESTIONDATAINFO['id'];
                                            $billItem_             =   $QUESTIONDATAINFO['services'];
                                            $error_details_       = '';
                                            array_push($allfilterids, $filter_details_id_);
                                        ?>
                                            <span> <?php echo $horizontal; ?>
                                                <input type="hidden" name="filter_details_id_<?php echo $i; ?>" id="filter_details_id_<?php echo $i; ?>" class="form-control" value="<?php echo $filter_details_id_; ?>" />
                                                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                                                    <div class="col-md-8 col-sm-8 col-xs-8">
                                                        <div class="form-group <?php if (form_error('services')) : ?>error<?php endif; ?>">
                                                            <label class="fancy-checkbox form-headings">Services<span class="required">*</span></label>
                                                            <input type="text" name="services_<?php echo $i; ?>" id="services_<?php echo $i; ?>" value="<?php if (set_value('services')) : echo set_value('services');
                                                                                                                                                        else : echo stripslashes($EDITDATA['services']);
                                                                                                                                                        endif; ?>" class="form-control required" placeholder="Hotel Service Name">
                                                            <?php if (form_error('services')) : ?>
                                                                <p for="services" generated="true" class="error"><?php echo form_error('services'); ?></p>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <br />
                                                <div class="form-group"> <?php echo $removeaddbutton; ?> </div>
                                            </span>
                                        <?php $i++;
                                        endforeach;
                                    else :  ?>
                                        <span>
                                            <input type="hidden" name="filter_details_id_1" id="filter_details_id_1" class="form-control" value="" />
                                            <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                                                <div class="col-md-8 col-sm-8 col-xs-8">
                                                    <div class="form-group <?php if (form_error('services')) : ?>error<?php endif; ?>">
                                                        <label class="fancy-checkbox form-headings">Services<span class="required">*</span></label>
                                                        <input type="text" name="services_1" id="services_1" class="form-control required" placeholder="Services">
                                                        <?php if (form_error('services')) : ?>
                                                            <p for="services" generated="true" class="error"><?php echo form_error('services'); ?></p>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                <br />
                                <div class="form-group"> <a href="javascript:void(0);" class="addMoreFilterDetails pull-right">+ Add another Item</a>
                                    <input type="hidden" name="AllFilterIds" id="AllFilterIds" value="<?php echo implode('_____', $allfilterids); ?>" />
                                </div>
                            </fieldset> <?php */ ?>
                            <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
                            <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
                            <a href="javascript:void(0);" class="btn btn-primary btn-lg form-btn" id="cancelAddEditSection">Cancel</a>
                            <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                                    :- <strong><span style="color:#FF0000;">*</span> Indicates
                                        Required Fields</strong> </span>
                            </span>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="main-content">
        <div class="container-fluid">
            <div class="panel panel-headline">
                <div class="panel-heading row">
                    <h3 class="tab panel-title">Manage Plans</h3>
                    <!-- <a href="javascript:void(0);" class="btn btn-default add_btn" id="openAddEditSection">Add Manage Plans</a> -->
                </div>
                <hr class="differ">
                <form id="Data_Form" name="Data_Form" method="get" action="<?php echo $forAction; ?>">
                    <div class="dash">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th width="10%">Sr.No.</th>
                                    <th width="70%">Description</th>
                                    <?php if ($edit_data == 'Y') : ?>
                                        <th width="10%" class="center">--</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($ALLDATA <> "") : $i = 1;
                                    foreach ($ALLDATA as $ALLDATAINFO) : ?>
                                        <tr class="<?php if ($i % 2 == 0) : echo 'odd';
                                                    else : echo 'even';
                                                    endif; ?> gradeX">
                                            <td><?= $i++ ?></td>
                                            <td> <textarea cols="110" rows="9"><?= strip_tags($ALLDATAINFO['description']) ?></textarea></td>
                                            <?php if ($edit_data == 'Y') : ?>
                                                <td class="center">
                                                    <div class="btn-group">
                                                        <button class="btn dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                                                        <ul class="dropdown-menu">
                                                            <?php if ($edit_data == 'Y') : ?>
                                                                <li><a href="<?= $editlink . $ALLDATAINFO['plan_id'] ?>"><i class="fa fa-edit"></i> Edit Details</a></li>
                                                                <li class="divider"></li>
                                                                <?php if ($ALLDATAINFO['status'] == 'Y') : ?>
                                                                    <li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/changeStatus/<?= $ALLDATAINFO['plan_id'] ?>/N"><i class="fa fa-hand-o-up"></i> Inactive</a></li>
                                                                <?php elseif ($ALLDATAINFO['status'] == 'N') : ?>
                                                                    <li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/changeStatus/<?= $ALLDATAINFO['plan_id'] ?>/Y"><i class="fa fa-hand-o-up"></i> Active</a></li>
                                                            <?php endif;
                                                            endif; ?>
                                                        </ul>
                                                    </div>
                                                </td>
                                            <?php endif; ?>
                                        </tr>
                                    <?php endforeach;
                                else : ?>
                                    <tr>
                                        <td colspan="7" style="text-align:center;">No Data Available In Table</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        <div class="pagi row">
                            <div class="col-md-6 col-sm-6 col-xs-6 pagi-txt"><?php echo $noOfContent; ?></div>
                            <div class="col-md-6 col-sm-6 col-xs-6 pagi-bar">
                                <?= $PAGINATION ?>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script>
    var prevSerchValue = '<?php echo $searchValue; ?>';
</script>
<script type="text/javascript">
    $(function() {
        <?php if ($formError == 'Yes') : ?>
            $('#addEditSection').slideDown();
        <?php elseif ($editid) : ?>
            $('#addEditSection').slideDown();
        <?php endif; ?>
    });
    $(document).on('click', '#openAddEditSection', function() {
        $('#addEditSection').slideDown();
    });
    <?php if ($editid) : ?>
        $(document).on('click', '#cancelAddEditSection', function() {
            window.location.href = '<?php echo $cancellink; ?>';
        });
    <?php else : ?>
        $(document).on('click', '#cancelAddEditSection', function() {
            $('#addEditSection').slideUp();
        });
    <?php endif; ?>
</script>
<script type="text/javascript">
    $(function() {
        create_editor_for_textarea('content')
    });
</script>