<style type="text/css">
  .ordered .whish_detail > .row .col-md-12.col-sm-12.col-xs-12 {
  padding: 0;
  }
  .oredr_head {
    background: #f5f5f8;
    padding: 15px;
    margin-bottom: 15px;
  }
  .ordered {
    padding-top: 1em;
  }
  .ordered .whish_detail {
    box-shadow: 1px 1px 5px 1px rgba(207, 219, 220, 0.62);
  }
  .ordered .whish_detail > .row {
    padding: 0;
    border: 0;
  }
  .oredr_head .order_help a i {
    color: #f6412e;
  }
  .oredr_head .order_help {
    float: right;
  }
  .oredr_head .order_help a {
    border: 1px solid #cbcbe3;
    display: inline-block;
    background: #fff;
    border-radius: 1px;
    margin-left: 5px;
    color: #2d2c2c;
    text-transform: uppercase;
    font-weight: 500;
    font-size: 13px;
    letter-spacing: 1px;
    padding: 5px 15px;
  }
  .oredr_head .order_id p {
    margin: 0;
    font-size: 13px;
    color: #fff;
    background: #f6412e;
    text-transform: uppercase;
    padding: 6px 15px;
    border-radius: 1px;
    letter-spacing: 1px;
  }
  .oredr_head .order_id, .oredr_head .order_help {
    display: inline-block;
  }
  .ordered .wish_pname, .ordered .wish_price {
    line-height: 21px;
    height: auto;
    min-height: 100px;
    padding: 12px 5px 0;
  }
  .ordered .wish_pname p strong {
    font-weight: 500;
  }
  .ordered .wish_pname p {
    color: #6f6c6c;
    font-weight: 500;
    font-size: 12px;
    letter-spacing: 1px;
  }
  .delever p {
    font-size: 13px;
    letter-spacing: 0.3px;
    margin: 0;
  }
  .delever span {
    color: #4d4c4c;
    font-size: 12px;
    font-weight: 400;
    letter-spacing: 0.3px;
  }
  .order_traker {
    padding: 1em 0;
    margin: 10px 0;
    margin-top: 0px;
  }
  .order_traker ul li span {
    width: 15px;
    height: 15px;
    display: block;
    background-color: #d2d3d4;
    margin: 0 auto;
    border-radius: 50px;
    margin-bottom: 10px;
    z-index: 2;
    position: relative;
  }
  .order_traker ul li {
    list-style: none;
    display: inline-block;
    color: #3771a6;
    text-transform: uppercase;
    letter-spacing: 1px;
    font-weight: 600;
    position: relative;
    width: 24%;
    cursor: pointer;
  }
  .order_traker ul {
    padding: 0;
    margin: 0;
    width: 100%;
    display: table;
    text-align: center;
    position: relative;
  }
  .order_traker ul::before {
    /* content: "";*/
    width: 71%;
    height: 1px;
    left: 0;
    right: 0;
    background: #f4412e;
    position: absolute;
    top: 7px;
    margin: 0 auto;
  }
  .order_traker ul li::after {
    content: "";
    width: 100%;
    background: #d2d3d4;
    position: absolute;
    right: 0;
    z-index: 1;
    height: 1px;
    left: -50%;
    top: 7px;
  }
  .order_traker ul li:nth-child(1)::after {
    content: none;
  }
  .order_traker ul li.green::after {
    background: #00ce96;
  }
  .order_traker ul li.green span {
    background: #00ce96;
  }
  .order_tool::before {
    width: 100%;
    height: 0;
    content: "\f0dd";
    bottom: 11px;
    left: 0;
    right: 0;
    position: absolute;
    margin: 0 auto;
    font-family: Fontawesome;
    font-size: 22px;
    color: #f5f5f5;
    text-shadow: 0 2px 0px #c1c1da;
  }
  .order_tool {
    width: 100px;
    border: 1px solid #c1c1da;
    font-size: 11px;
    line-height: 15px;
    font-weight: 500;
    padding: 5px 4px;
    top: -55px;
    position: absolute;
    left: 0;
    right: 0;
    margin: 0 auto;
    color: #262829;
    background: #f5f5f5;
    text-align: center;
    height: 45px;
    opacity: 0;
    transition: 1s all;
    letter-spacing: -0.1px;
  }
  .order_traker ul li:hover .order_tool {
    animation: bounce 1s;
    opacity: 1;
  }
  .tracor_tot {
    border-top: 1px solid #d0d8e0;
    border-bottom: 1px solid #d0d8e0;
    margin-bottom: 15px;
    padding: 10px 20px;
  }
  .tracor_tot {
    font-size: 13px;
    color: #121212;
    font-weight: 500;
    letter-spacing: 0.5px;
  }
  .tracor_tot strong {
    font-size: 13px;
    letter-spacing: 0.5px;
    color: #5d5b80;
    font-weight: 600;
    text-transform: capitalize;
    padding-right: 10px;
  }
  .tracor_tot .o_to, .tracor_tot .o_on {
    display: inline-block;
  }
  .tracor_tot .o_to {
    float: right;
  }
</style>
<?php if($orderList <> ""): $i=0; $orderarray      = array();
          foreach($orderList as $orderListData): 
            foreach($orderListData['sessionData'] as $sessionData):
              foreach($sessionData['orderData'] as $orderData):
                if(!in_array($sessionData['orderId'],$orderarray)):
                  array_push($orderarray,$sessionData['orderId']);
                  $j=1;
                  $totalPrice = 0;
  ?><?php if($i>0):?></div><?php endif; ?>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="oredr_head">
        <div class="order_id"><p><?php echo $sessionData['orderId']; ?></p></div>
      </div>
    </div>
<?php endif; $totalPrice = ($totalPrice+$orderData['productTotalAmount']); ?>
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="col-md-2 col-sm-2 col-xs-12 p_wish">
        <div class="wishp_img">
          <a href="javascript:void(0);"><img src="<?php echo $orderData['productImage']; ?>" class="img-responsive" /></a>
        </div>
      </div>
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <div class="wish_pname">
          <a href="javascript:void(0);"><?php echo $orderData['productName'] ?></a> 
          <p><strong>Amount:</strong> <i class="fa fa-rupee"></i> <?php echo $orderData['productSingleAmount']; ?><br>  
          <strong>Quantity:</strong> <?php echo $orderData['productQuantity']; ?><br>
          <strong>GST:</strong> 18%<br>
          <strong>Total Amount:</strong> <i class="fa fa-rupee"></i> <?php echo $orderData['productTotalAmount']; ?></p>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-4 p_wish">
        <div class="wish_price delever">
          <p><?php echo $orderData['productEstDeliveryDate']?'Estimated installation/delivery Date on '.date('D M, d Y',strtotime($orderData['productEstDeliveryDate'])):''; ?></p>
        </div>
      </div>
    </div>
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="order_traker">
        <ul>
          <li class="green">
            <div class="order_tool">
              <?php echo date('D M, d Y',strtotime($orderData['productOrderDate'])); ?>
            </div>
            <span class="track_ball"></span>CONFIRMED
          </li>
          <?php if($orderData['productPackedDate']):?>
            <li class="green">
              <div class="order_tool">
                <?php echo date('D M, d Y',strtotime($orderData['productPackedDate'])); ?>
              </div>
              <span class="track_ball"></span>PACKED
            </li>
          <?php else: ?>
            <li>
              <span class="track_ball"></span>PACKED
            </li>
          <?php endif; ?>
          <?php if($orderData['productShippedDate']):?>
            <li class="green">
              <div class="order_tool">
                <?php echo date('D M, d Y',strtotime($orderData['productShippedDate'])); ?>
              </div>
              <span class="track_ball"></span>SHIPPED
            </li>
          <?php else: ?>
            <li>
              <span class="track_ball"></span>SHIPPED
            </li>
          <?php endif; ?>
          <?php if($orderData['productDeliveredDate']):?>
            <li class="green">
              <div class="order_tool">
                <?php echo date('D M, d Y',strtotime($orderData['productDeliveredDate'])); ?>
              </div>
              <span class="track_ball"></span>DELIVERED
            </li>
          <?php else: ?>
            <li>
              <span class="track_ball"></span>DELIVERED
            </li>
          <?php endif; ?>
        </ul>
      </div>
    </div>
    <?php if($j==count($sessionData['orderData'])):?>
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="tracor_tot">
          <div class="o_on">
            <strong>Ordered On</strong> <?php echo date('D M, d Y',strtotime($orderData['productOrderDate'])); ?>
          </div>
          <div class="o_to">
            <strong>Order Total </strong> <i class="fa fa-rupee"></i><?php echo displayPrice($totalPrice); ?>
          </div>
        </div>
      </div>
    <?php endif; ?>
  <?php $i++; $j++; endforeach; endforeach; endforeach; ?></div>
  <?php endif; ?>
  <?php $orderShipData   = $orderList[0]['sessionData'][0]['orderData'][0]; ?>
  <div class="row">
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <p><strong>Shipping Address</strong></p>
      </div>
    </div>
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <p><strong>Name:</strong> <?php echo $orderShipData['shippingName']; ?></p>
      </div>
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <p><strong>Phone:</strong> <?php echo $orderShipData['shippingPhone']; ?></p>
      </div>
    </div>
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <p><strong>Address :</strong> <?php echo $orderShipData['shippingAddress1']; ?></p>
      </div>
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <p><strong>Address2 :</strong> <?php echo $orderShipData['shippingAddress2']; ?></p>
      </div>
    </div>
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <p><strong>City:</strong> <?php echo $orderShipData['shippingCity']; ?></p>
      </div>
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <p><strong>State:</strong> <?php echo $orderShipData['shippingState']; ?></p>
      </div>
    </div>
    <div class="col-md-12 col-sm-12 col-xs-12">
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <p><strong>Pincode:</strong> <?php echo $orderShipData['shippingPincode']; ?></p>
      </div>
      <div class="col-md-6 col-sm-6 col-xs-12 p_wish">
        <p><strong>Address Type:</strong> <?php echo $orderShipData['shippingAddType']; ?></p>
      </div>
    </div>
  </div>