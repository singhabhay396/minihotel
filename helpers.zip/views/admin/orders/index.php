<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{FULL_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-shopping-cart"></i>Orders</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid"> 
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Orders Details</h3>
        </div>
        <hr class="differ">
        <form id="Data_Form" name="Data_Form" method="get" action="<?php echo $forAction; ?>">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6 search">
              <label>Show
                <select name="showLength" id="showLength" class="form-control input-sm">
                  <option value="2" <?php if($perpage == '2')echo 'selected="selected"'; ?>>2</option>
                  <option value="10" <?php if($perpage == '10')echo 'selected="selected"'; ?>>10</option>
                  <option value="25" <?php if($perpage == '25')echo 'selected="selected"'; ?>>25</option>
                  <option value="50" <?php if($perpage == '50')echo 'selected="selected"'; ?>>50</option>
                  <option value="100" <?php if($perpage == '100')echo 'selected="selected"'; ?>>100</option>
                  <option value="All" <?php if($perpage == 'All')echo 'selected="selected"'; ?>>All</option>
                </select>
                entries
              </label>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-6 search-ryt">
              <input type="text" name="searchValue" id="searchValue" value="<?php echo $searchValue; ?>" class="form-control input-smt" placeholder="Enter Search Text">
            </div>
          </div>
          <div class="dash">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="8%">Sr.No.</th>
                  <th width="20%">Customer Name</th>
                  <th width="12%">Order ID</th>
                  <th width="12%">Amount</th>
                  <th width="12%">Order Date</th>
                  <th width="12%">Status</th>
                  <th width="15%">Installation/delivery Date</th>
                </tr>
              </thead>
              <tbody>
                <?php if($ALLDATA <> ""): $i=1; foreach($ALLDATA as $ALLDATAINFO): ?>
                  <tr class="<?php if($i%2 == 0): echo 'odd'; else: echo 'even'; endif; ?> gradeX">
                    <td><?=$i++?></td>
                    <td>
                      <a href="javascript:void(0);" class="view-details-data" title="Customer Details" data-id="<?=$ALLDATAINFO['id'].'_____user'?>" data-width="800">
                        <?=stripslashes($ALLDATAINFO['user_name'])?>
                      </a>
                    </td>
                    <td>
                      <a href="javascript:void(0);" class="view-details-data" title="Order Details" data-id="<?=$ALLDATAINFO['order_id'].'_____order'?>" data-width="800">
                        <?=stripslashes($ALLDATAINFO['order_id'])?>
                      </a>
                    </td>
                    <td>
                        <i class="fa fa-rupee"></i> <?=stripslashes($ALLDATAINFO['total_amount'])?>
                    </td>
                    <td><?php echo date('D M, d Y',strtotime($ALLDATAINFO['order_date'])); ?></td>
                    <td><?=stripslashes($ALLDATAINFO['order_status'])?></td>
                    <td><?php echo $ALLDATAINFO['est_ins_deliv_date']!='1970-01-01 00:00:00'?date('D M, d Y',strtotime($ALLDATAINFO['est_ins_deliv_date'])):''; ?></td>
                  </tr>
                <?php endforeach; else: ?>
                  <tr>
                    <td colspan="8" style="text-align:center;">No Data Available In Table</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
            <div class="pagi row">
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-txt"><?php echo $noOfContent; ?></div>
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-bar">
                <?=$PAGINATION?>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
var prevSerchValue  = '<?php echo $searchValue; ?>';
</script>