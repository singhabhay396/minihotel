<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>

<style>
    .direct-chat-text {
        border-radius: 5px;
        position: relative;
        padding: 5px 10px;
        background: #D2D6DE;
        border: 1px solid #D2D6DE;
        margin: 5px 0 0 50px;
        color: #444;
    }

    .direct-chat-msg,
    .direct-chat-text {
        display: block;
        word-wrap: break-word;
    }

    .direct-chat-img {
        border-radius: 50%;
        float: left;
        width: 40px;
        height: 40px;
    }

    .direct-chat-info {
        display: block;
        margin-bottom: 2px;
        font-size: 12px;
    }

    .direct-chat-msg {
        margin-bottom: 10px;
    }

    .direct-chat-messages,
    .direct-chat-contacts {
        -webkit-transition: -webkit-transform .5s ease-in-out;
        -moz-transition: -moz-transform .5s ease-in-out;
        -o-transition: -o-transform .5s ease-in-out;
        transition: transform .5s ease-in-out;
    }

    .direct-chat-messages {
        -webkit-transform: translate(0, 0);
        -ms-transform: translate(0, 0);
        -o-transform: translate(0, 0);
        transform: translate(0, 0);
        padding: 10px;
        height: 400px;
        overflow: auto;
        word-wrap: break-word;
    }

    .direct-chat-text:before {
        border-width: 6px;
        margin-top: -6px;
    }

    .direct-chat-text:after {
        border-width: 5px;
        margin-top: -5px;
    }

    .direct-chat-text:after,
    .direct-chat-text:before {
        position: absolute;
        right: 100%;
        top: 15px;
        border: solid rgba(0, 0, 0, 0);
        border-right-color: #D2D6DE;
        content: ' ';
        height: 0;
        width: 0;
        pointer-events: none;
    }

    .direct-chat-warning .right>.direct-chat-text {
        background: #F39C12;
        border-color: #F39C12;
        color: #FFF;
    }

    .right .direct-chat-text {
        margin-right: 50px;
        margin-left: 0;
    }

    .direct-chat-warning .right>.direct-chat-text:after,
    .direct-chat-warning .right>.direct-chat-text:before {
        border-left-color: #F39C12;
    }

    .right .direct-chat-text:after,
    .right .direct-chat-text:before {
        right: auto;
        left: 100%;
        border-right-color: rgba(0, 0, 0, 0);
        border-left-color: #D2D6DE;
    }

    .right .direct-chat-img {
        float: right;
    }

    .box-footer {
        border-top-left-radius: 0;
        border-top-right-radius: 0;
        border-bottom-right-radius: 3px;
        border-bottom-left-radius: 3px;
        border-top: 1px solid #F4F4F4;
        padding: 10px 0;
        background-color: #FFF;
        margin-right: 44px;
    }

    .direct-chat-name {
        font-weight: 600;
    }

    .box-footer form {
        margin-bottom: 10px;
    }

    input,
    button,
    .alert,
    .modal-content {
        border-radius: 0 !important;
    }

    .ml10 {
        margin-left: 10px;
        font-size: medium;
    }
    .input-group-btn:last-child>.btn, .input-group-btn:last-child>.btn-group {
    height: 31px !important;
    width: 79px !important;
    font-size: 19px !important;
    margin-left: 7px;
}
.btn-group-xs>.btn, .btn-xs {
    padding: 5px 14px;
    font-size: medium !important;
}
</style>
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.3.14/angular.min.js"></script>

<script type="text/javascript">
    (function() {
        var ChatApp = angular.module('ChatApp', []);
        ChatApp.directive('ngEnter', function() {
            return function(scope, element, attrs) {
                element.bind("keydown keypress", function(event) {
                    if (event.which === 13) {
                        scope.$apply(function() {
                            scope.$eval(attrs.ngEnter);
                        });
                        event.preventDefault();
                    }
                });
            };
        });
        ChatApp.controller('ChatAppCtrl', ['$scope', '$http', function($scope, $http) {

            $scope.urlListMessages = '<?php echo $this->session->userdata('MHM_ADMIN_CURRENT_PATH'); ?>chatroom/init?action=list';
            $scope.urlSaveMessage = '<?php echo $this->session->userdata('MHM_ADMIN_CURRENT_PATH'); ?>chatroom/init?action=save';
            $scope.urlListOnlines = '<?php echo $this->session->userdata('MHM_ADMIN_CURRENT_PATH'); ?>chatroom/init?action=ping';
            $scope.pidMessages = null;
            $scope.pidPingServer = null;
            $scope.beep = new Audio('{ASSET_ADMIN_URL}images/beep.ogg');
            $scope.messages = [];
            $scope.online = [];
            $scope.lastMessageId = null;
            $scope.historyFromId = null;
            $scope.me = {
                username: "<?php echo ucfirst($_COOKIE['MHM_USERNAME']); ?>",
				userimage: "<?php echo $this->session->userdata('MHM_ADMIN_CURRENT_LOGO'); ?>",
                message: null
            };
            $scope.pageTitleNotificator = {
                vars: {
                    originalTitle: window.document.title,
                    interval: null,
                    status: 0
                },
                on: function(title, intervalSpeed) {
                    var self = this;
                    if (!self.vars.status) {
                        self.vars.interval = window.setInterval(function() {
                            window.document.title = (self.vars.originalTitle == window.document.title) ?
                                title : self.vars.originalTitle;
                        }, intervalSpeed || 500);
                        self.vars.status = 1;
                    }
                },
                off: function() {
                    window.clearInterval(this.vars.interval);
                    window.document.title = this.vars.originalTitle;
                    this.vars.status = 0;
                }
            };

            $scope.saveMessage = function(form, callback) {
                var data = $.param($scope.me);
                // if (!($scope.me.username && $scope.me.username.trim())) {
                //     return $scope.openModal();
                // }
                if (!($scope.me.message && $scope.me.message.trim() &&
                        $scope.me.username && $scope.me.userimage && $scope.me.username.trim())) {
                    return;
                }
                $scope.me.message = '';
                return $http({
                    method: 'POST',
                    url: $scope.urlSaveMessage,
                    data: data,
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                }).success(function(data) {
                    $scope.listMessages(true);
                });
            };

            $scope.replaceShortcodes = function(message) {
                var msg = '';
                msg = message.toString().replace(/(\[img])(.*)(\[\/img])/, "<img src='$2' />");
                msg = msg.toString().replace(/(\[url])(.*)(\[\/url])/, "<a href='$2'>$2</a>");
                return msg;
            };

            $scope.notifyLastMessage = function() {
                if (typeof window.Notification === 'undefined') {
                    return;
                }
                console.log($scope);
                window.Notification.requestPermission(function(permission) {
                    var lastMessage = $scope.getLastMessage();
                    if (permission == 'granted' && lastMessage && lastMessage.username) {
                        var notify = new window.Notification(lastMessage.username + ' says:', {
                            body: lastMessage.message
                        });
                        notify.onclick = function() {
                            window.focus();
                        };
                        notify.onclose = function() {
                            $scope.pageTitleNotificator.off();
                        };
                        var timmer = setInterval(function() {
                            notify && notify.close();
                            typeof timmer !== 'undefined' && window.clearInterval(timmer);
                        }, 10000);
                    }
                });
            };
            $scope.getLastMessage = function() {
                return $scope.messages[$scope.messages.length - 1];
            };

            $scope.listMessages = function(wasListingForMySubmission) {
                return $http.post($scope.urlListMessages, {}).success(function(data) {
                    $scope.messages = [];
                    angular.forEach(data, function(message) {
                        message.message = $scope.replaceShortcodes(message.message);
                        $scope.messages.push(message);
                    });
                    var lastMessage = $scope.getLastMessage();
                    var lastMessageId = lastMessage && lastMessage.id;
                    if ($scope.lastMessageId !== lastMessageId) {
                        $scope.onNewMessage(wasListingForMySubmission);
                    }
                    $scope.lastMessageId = lastMessageId;
                });
            };

            $scope.onNewMessage = function(wasListingForMySubmission) {
                if ($scope.lastMessageId && !wasListingForMySubmission) {
                    $scope.playAudio();
                    $scope.pageTitleNotificator.on('New message');
                    $scope.notifyLastMessage();
                }

                $scope.scrollDown();
                window.addEventListener('focus', function() {
                    $scope.pageTitleNotificator.off();
                });
            };

            $scope.pingServer = function(msgItem) {
                return $http.post($scope.urlListOnlines, {}).success(function(data) {
                    $scope.online = data;
                });
            };

            $scope.init = function() {
                $scope.listMessages();
                $scope.pidMessages = window.setInterval($scope.listMessages, 3000);
                $scope.pidPingServer = window.setInterval($scope.pingServer, 8000);
            };

            $scope.scrollDown = function() {
                var pidScroll;
                pidScroll = window.setInterval(function() {
                    $('.direct-chat-messages').scrollTop(window.Number.MAX_SAFE_INTEGER * 0.001);
                    window.clearInterval(pidScroll);
                }, 100);
            };
            $scope.clearHistory = function() {
                var lastMessage = $scope.getLastMessage();
                var lastMessageId = lastMessage && lastMessage.id;
                lastMessageId && ($scope.historyFromId = lastMessageId);
            };

            $scope.openModal = function() {
                $('#choose-name').modal('show');
            };
            $scope.playAudio = function() {
                $scope.beep && $scope.beep.play();
            };
            $scope.init();
        }]);
    })();
</script>
<div class="main">
    <div class="bready">
        <ol class="breadcrumb">
        <li><a href="{VENDOR_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
        <li><a href="javascript:void(0);" class="active"><i class="fa fa-hotel"></i>Compose Messages</a></li>
        </ol>
    </div>
    <div class="main-content" ng-controller="ChatAppCtrl">
        <div class="container-fluid">
            <div class="panel panel-headline">
                <hr class="differ">
                <div class="box-body">
                <div class="direct-chat-messages">
                    <div class="direct-chat-msg" ng-repeat="message in messages" ng-if="historyFromId < message.id" ng-class="{'right':!message.me}">
                        <div class="direct-chat-info clearfix">
                            <span class="direct-chat-name" ng-class="{'pull-left':message.me, 'pull-right':!message.me}">{{ message.username }}</span>
                            <span class="direct-chat-timestamp " ng-class="{'pull-left':!message.me, 'pull-right':message.me}">{{ message.date }}</span>
                        </div>
                        <img class="direct-chat-img" src="{{message.image}}">
                        <div class="direct-chat-text">
                            <span>{{ message.message }}</span>
                        </div>
                    </div>
                </div>
                <div class="box-footer">
                    <form ng-submit="saveMessage()">
                        <div class="input-group">
                            <input type="text" placeholder="Type message..." autofocus="autofocus" class="form-control" ng-model="me.message" ng-enter="saveMessage()">
							<!--<textarea name="" id="content" cols="30" rows="1" autofocus="autofocus"class="form-control" ng-model="me.message" ng-enter="saveMessage()"></textarea>  -->
                            <span class="input-group-btn">
                            <button type="submit" class="btn btn-warning btn-flat">Send</button>
                            </span>
                        </div>
                    </form>
                    <div class="clearfix">
                        <span class="badge pull-left">Online users: {{ total.total || 1 }}</span>
                        <!-- <a class="btn btn-xs btn-warning pull-right ml10" href="" data-toggle="modal" data-target="#choose-name">Change username</a> -->
                        <!-- <a class="btn btn-xs btn-warning pull-right" href="" data-toggle="modal" data-target="#clear-history">Clear history</a> -->
                        </span>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>

<!--- Model POPUP    ----->
    <div class="modal" id="clear-history">
        <div class="modal-dialog">
            <div class="modal-content">
                <form>
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">
                            <span aria-hidden="true">&times;</span>
                            <span class="sr-only">Close</span>
                        </button>
                        <h4 class="modal-title">Chat history</h4>
                    </div>
                    <div class="modal-body">
                        <label class="radio">Are you sure to clear chat history?</label>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-sm btn-default" data-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal" ng-click="clearHistory()">Accept</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <script type="text/javascript">
  $(function(){
    create_editor_for_textarea('content')
  });
</script>