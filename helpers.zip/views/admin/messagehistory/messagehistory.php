<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/ui/1.12.0/jquery-ui.js"></script>
<script>
    $(function() {
        $("#fromDate").datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            maxDate: 0,
            yearRange: "1960:<?php echo date('Y'); ?>"
        });
    });
    $(function() {
        $("#toDate").datepicker({
            dateFormat: 'dd-mm-yy',
            changeMonth: true,
            changeYear: true,
            maxDate: 0,
            yearRange: "1960:<?php echo date('Y'); ?>"
        });
    });
</script>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{FULL_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-calendar"></i>Reservation History</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Reservation History</h3>
            <a href="{FULL_SITE_URL}{CURRENT_CLASS}/index" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <form id="Data_Form" name="Data_Form" method="get" action="<?php echo $forAction; ?>" autocomplete="off">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6 search">
              <label>Show
                <select name="showLength" id="showLength" class="form-control input-sm">
                  <option value="2" <?php if ($perpage == '2') echo 'selected="selected"'; ?>>2</option>
                  <option value="10" <?php if ($perpage == '10') echo 'selected="selected"'; ?>>10</option>
                  <option value="25" <?php if ($perpage == '25') echo 'selected="selected"'; ?>>25</option>
                  <option value="50" <?php if ($perpage == '50') echo 'selected="selected"'; ?>>50</option>
                  <option value="100" <?php if ($perpage == '100') echo 'selected="selected"'; ?>>100</option>
                  <option value="All" <?php if ($perpage == 'All') echo 'selected="selected"'; ?>>All</option>
                </select>
                entries
              </label>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-6 search-ryt">
              <input type="text" name="searchValue" id="searchValue" value="<?php echo $searchValue; ?>" class="form-control input-smt" placeholder="Enter Search Text">
            </div>
          </div>
        </form>
        <?php /*?><div class="row">
                    <form action="{VENDOR_SITE_URL}{CURRENT_CLASS}/messagehistory" method="get" name="searchData" id="searchData">
                        <div class="col-md-3 col-sm-3 col-xs-3">
                            <input type="text" name="fromDate" id="fromDate" value="<?php if ($searchDate <> "") : echo date('d-m-Y', strtotime($searchDate));
                                                                                    endif; ?>" class="form-control input-smt" placeholder="From Date">
                        </div>
                        <div class="col-md-3 col-sm-3 col-xs-3">
                            <input type="text" name="toDate" id="toDate" value="<?php if ($searchDate <> "") : echo date('d-m-Y', strtotime($searchDate));
                                                                                endif; ?>" class="form-control input-smt" placeholder="To Date">
                        </div>
                       
                        <div class="col-md-3 col-sm-3 col-xs-3">
                            <button type="submit" class="btn btn-primary btn-lg form-btn">Search</button>
                        </div>
                    </form>
                </div><?php */?>
          <div class="dash">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="10%">Sr. No.</th>
                  <th width="10%">Guest Name</th>
                  <th width="10%">Guest Mobile Number</th>
                  <th width="10%">Booking Id</th>
                  <th width="10%">Room Type</th>
                  <th width="10%">Check-In Date & Time</th>
                  <th width="10%">Check-out Date & Time</th>
                  <th width="10%">Stay Duration</th>
                  <th width="10%">NUmber Of Person</th>
                  <th width="10%">Meal Plan</th>
                  <th width="10%">Approval Status</th>
                  <th width="10%">Approval Date</th>
                  <th width="20%">Message Summary</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($ALLDATAHISTORY <> "") : $i = 1; foreach ($ALLDATAHISTORY as $ALLDATAINFO) :   ?>
                    <tr class="<?php if ($i % 2 == 0) : echo 'odd'; else : echo 'even'; endif; ?> gradeX">
                      <td><?= $i++ ?></td>
                      <td><?= stripslashes($ALLDATAINFO['guest_name']) ?></td>
                      <td><?= stripslashes($ALLDATAINFO['guest_mobile_number']) ?></td>
                      <td><?= stripslashes($ALLDATAINFO['booking_id']) ?></td>
                      <td><?= ucfirst($ALLDATAINFO['room_type']) ?></td>
                      <td><?= date('d-m-Y h:i A', strtotime($ALLDATAINFO['reminder_datetime'])) ?></td>
                      <td><?= date('d-m-Y h:i A', strtotime($ALLDATAINFO['reminder_end_datetime'])) ?></td>
                      <td><?= stripslashes($ALLDATAINFO['stay_duration']) ?></td>
                      <td><?= stripslashes($ALLDATAINFO['no_of_person']) ?></td>
                      <td><?= stripslashes($ALLDATAINFO['meal_plan']) ?></td>
                      <?php if($ALLDATAINFO['admin_approval']  == 'Y'): ?>
                      <td class="alert alert-success">Approved</td>
                      <?php else: ?>
                      <td class="alert alert-danger">Decline</td>
                      <?php endif; ?>
                      <td><?= date('d-m-Y h:i A', strtotime($ALLDATAINFO['creation_date'])) ?></td>
                      <td><textarea rows="3" cols="30"><?= stripslashes($ALLDATAINFO['payment_summery']) ?></textarea></td>
                    </tr>
                  <?php endforeach;
                else : ?>
                  <tr>
                    <td colspan="5" style="text-align:center;">No Data Available In Table</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
            <div class="pagi row">
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-txt"><?php echo $noOfContent; ?></div>
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-bar">
                <?= $PAGINATION ?>
              </div>
            </div>
          </div>
      </div>
    </div>
  </div>
</div>
