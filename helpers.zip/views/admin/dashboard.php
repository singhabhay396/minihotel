<style>
  marquee {
    background: linear-gradient(-45deg, #ee7752, #e73c7e, #23a6d5, #23d5ab);
    background-size: 400% 400%;
    animation: gradient 15s ease infinite;
    height: 5vh;
  }

  @keyframes gradient {
    0% {
      background-position: 0% 50%;
    }

    50% {
      background-position: 100% 50%;
    }

    100% {
      background-position: 0% 50%;
    }
  }
</style>
<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{FULL_SITE_URL}dashboard" class="active"><i class="lnr lnr-home"></i>Dashboard</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
      <marquee width="100%" direction="right" height="60%" bgcolor="lightgreen">
          <?php if ($adminMssageData <> "") : ?>
            <strong style="color:black">You Have New Message(s) From Vendor.</strong>
          <?php endif; ?>
        </marquee>
        <div class="panel-heading">
          <h3 class="panel-title">Welcome To MHM Project</h3>
        </div>
        <div class="panel-body">
          <div class="row box_guard">
          <div class="col-md-3 col-sm-3 col-xs-6">
              <div class="card card-odd" style="height: 142px;">
                <div class="card-content bg-1"> <a href="<?php echo $this->session->userdata('MHM_ADMIN_CURRENT_PATH'); ?>chatroom/index" title="Chat Room">
                    <div class="media align-items-stretch">
                      <div class="p-2 text-center  absobox"> <i class="fa fa-comments font-large-2 white"></i> </div>
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;">Group Chat</h5>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-1"> <a href="#" title="Hotels">
                    <div class="media align-items-stretch">
                      <div class="p-2 text-center  absobox"> <i class="fa fa-user font-large-2 white"></i> </div>
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5>Hotels</h5>
                        <h5 class="text-bold-400 mb-0"><i class="ft-plus"></i><?= $totalHotel ?></h5>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            </div>
            <!-- <div class="col-md-3 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-3"> <a href="#" title="Customer">
                    <div class="media align-items-stretch">
                      <div class="p-2 text-center absobox"> <i class="fa fa-users font-large-2 white"></i> </div>
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5>Customers</h5>
                        <h5 class="text-bold-400 mb-0"><i class="ft-plus"></i> 200</h5>
                      </div>
                    </div>
                  </a> </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <div class="card card-odd">
                <div class="card-content bg-4"> <a href="#" title="Orders">
                    <div class="media align-items-stretch">
                      <div class="p-2 text-center  absobox"> <i class="fa fa-shopping-cart font-large-2 white"></i> </div>
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5>Total Sales</h5>
                        <h5 class="text-bold-400 mb-0"><i class="fa fa-rupee"></i> 25000</h5>
                      </div>
                    </div>
                  </a> </div>
              </div>
            </div>
            <div class="col-md-3 col-sm-3 col-xs-6">
              <div class="card card-even">
                <div class="card-content bg-4"> <a href="#" title="Orders">
                    <div class="media align-items-stretch">
                      <div class="p-2 text-center absobox"> <i class="fa fa-shopping-cart font-large-2 white"></i> </div>
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5>Total Bill Book</h5>
                        <h5 class="text-bold-400 mb-0"><i class="fa fa-rupee"></i> 2000</h5>
                      </div>
                    </div>
                  </a> </div>
              </div>
            </div> -->
          </div>
        </div>
      </div>
    </div>
  </div>
</div>