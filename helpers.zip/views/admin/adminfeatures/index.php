<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{FULL_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Features</a></li>
    </ol>
  </div>
  <div class="main-content" id="addEditSection" style="display:none;">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Features</h3>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['heading_id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="form-group <?php if (form_error('title')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Title<span class="required">*</span></label>
                    <input type="text" name="title" id="title" value="<?php if (set_value('title')) : echo set_value('title');
                                                                      else : echo stripslashes($EDITDATA['title']);
                                                                      endif; ?>" class="form-control required" placeholder="Title">
                    <?php if (form_error('title')) : ?>
                      <p for="title" generated="true" class="error"><?php echo form_error('title'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-4 col-sm-4 col-xs-4">
                  <div class="form-group <?php if (form_error('image')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Image<span class="required">*</span></label>
                    <?php if (set_value('image')) : $testimage = set_value('image');
                    elseif ($EDITDATA['image']) : $testimage = stripslashes($EDITDATA['image']);
                    else : $testimage = '';
                    endif; ?>
                    <img border="0" alt="" src="{ASSET_ADMIN_URL}images/browse-white.png" id="featuAttImageUpload" class="img-responsive" style="cursor:pointer;">
                    <input type="etxt" name="image" id="featuAttImageInput" value="<?php echo $testimage; ?>" class="form-control required" style="border:none;width:0px;height:0px;margin-top: -14px;" />
                    <?php if (form_error('image')) : ?>
                      <span for="image" generated="true" class="help-inline"><?php echo form_error('image'); ?></span>
                    <?php endif; ?>
                    <span id="featuAttImageDiv" style="margin-top:5px;">
                      <?php if ($testimage) : ?>
                        <img border="0" alt="" src="<?php echo $testimage; ?>" class="img-responsive" width="100">&nbsp;
                        <a class="spancross" onclick="featuAttImageDelete('<?php echo $testimage; ?>');" href="javascript:void(0);"> <img border="0" alt="" src="{ASSET_ADMIN_URL}images/cross.png"></a>
                      <?php endif; ?>
                    </span>
                  </div>
                </div>
              </div>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="javascript:void(0);" class="btn btn-primary btn-lg form-btn" id="cancelAddEditSection">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                  :- <strong><span style="color:#FF0000;">*</span> Indicates
                    Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div id="featureImageUploadModel" class="modal" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4>
            <center>Position And Size Your Photo</center>
          </h4>
        </div>
        <div class="modal-body">
          <div class="profileimg-plug col-md-12 col-sm-12 col-xs-12">
            <div class="image-editor">
              <div class="file-input-wrapper">
                <label for="featuAtt-upload-profile-file" class="file-input-button">Choose Image</label>
                <input type="file" name="image" id="featuAtt-upload-profile-file" class="cropit-image-input"><br />
                <span style="color:#FF0000; font-size:12px;" id="featuAttBlinker">Image Must Be Min Width: 140px
                  And Min Height: 140px.</span>
              </div>
              <div class="cropit-preview"></div>
              <div class="image-size-label"> Resize Image </div>
              <div class="rotat-btn">
                <input type="range" class="cropit-image-zoom-input"><br />
                <button class="rotate-ccw"><i class="fa fa-refresh" aria-hidden="true"></i></button>
                <button class="rotate-cw"><i class="fa fa-repeat"></i></button>
              </div>
            </div>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default featuAttImageClosedButton" data-dismiss="modal">Close</button>
          <button type="button" class="btn btn-default featuAttImageSaveButton">Save</button>
          <input type="hidden" name="featuAttImageLoading" id="featuAttImageLoading" value="NO" />
        </div>
      </div>
    </div>
  </div>
  <script>
    $(function() {
      $('#featureImageUploadModel .image-editor').cropit();

      $('#featureImageUploadModel .rotate-cw').click(function() {
        $('#featureImageUploadModel .image-editor').cropit('rotateCW');
      });

      $('#featureImageUploadModel .rotate-ccw').click(function() {
        $('#featureImageUploadModel .image-editor').cropit('rotateCCW');
      });
    });
    $(document).on('click', '#featuAttImageUpload', function() {
      $('#featureImageUploadModel').modal({
        backdrop: 'static',
        show: true,
        keyword: false
      });
      $('#featureImageUploadModel .cropit-preview img').attr('src', '');
      $('#featureImageUploadModel .modal-footer.plucgin-clodebtn .featuAttImageClosedButton').html('Close');
      $('#featureImageUploadModel .modal-footer.plucgin-clodebtn .featuAttImageSaveButton').html('Save');
      $('#featureImageUploadModel #featuAttImageLoading').val('NO');

      $(".modal-footer .featuAttImageClosedButton").removeAttr('disabled');
      $(".modal-footer .featuAttImageSaveButton").removeAttr('disabled');
    });
    $(document).on('click', '.featuAttImageSaveButton', function() {
      var imageData = $('#featureImageUploadModel .image-editor').cropit('export');
      if ($('#featureImageUploadModel #featuAttImageLoading').val() == 'NO') {
        $('#featureImageUploadModel .featuAttImageSaveButton').html('Saving..');
        $('#featureImageUploadModel #featuAttImageLoading').val('YES');

        $(".modal-footer .featuAttImageClosedButton").attr("disabled", "disabled");
        $(".modal-footer .featuAttImageSaveButton").attr("disabled", "disabled");

        $.ajax({
          type: 'post',
          url: FULLSITEURL + CURRENTCLASS + '/featuAttImageUpload',
          data: {
            imageData: imageData
          },
          success: function(rdata) {
            if (rdata != 'UPLODEERROR') {
              $('#featuAttImageInput').val(rdata);
              $('#featuAttImageDiv').html('<img src="' + rdata + '" border="0" alt="" width="100" /> <a href="javascript:void(0);" onClick="featuAttImageDelete(\'' + rdata + '\');"> <img src="{ASSET_ADMIN_URL}images/cross.png" border="0" alt="" /> </a>');
              $('#featureImageUploadModel').modal('hide');
              $('#featureImageUploadModel #featuAttImageLoading').val('NO');
              return false;
            }
          }
        });
      }
    });

    //////////////////////////////////   Image delete Through Ajax
    function featuAttImageDelete(imageName) {
      if (confirm("Sure to delete?")) {
        $.ajax({
          type: 'post',
          url: FULLSITEURL + CURRENTCLASS + '/featuAttImageDelete',
          data: {
            csrf_api_key: csrf_api_value,
            imageName: imageName
          },
          success: function(response) {
            document.getElementById('featuAttImageInput').value = '';
            document.getElementById('featuAttImageDiv').innerHTML = '';
          }
        });
      }
    }
  </script>
  <script>
    var featuAtt_blink_speed = 500;
    var featuAtt = setInterval(function() {
      var featuAttsele = document.getElementById('featuAttBlinker');
      featuAttsele.style.visibility = (featuAttsele.style.visibility == 'hidden' ? '' : 'hidden');
    }, featuAtt_blink_speed);
  </script>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Features</h3>
          <a href="javascript:void(0);" class="btn btn-default add_btn" id="openAddEditSection">Add Features</a>
        </div>
        <hr class="differ">
        <form id="Data_Form" name="Data_Form" method="get" action="<?php echo $forAction; ?>">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6 search">
              <label>Show
                <select name="showLength" id="showLength" class="form-control input-sm">
                  <option value="2" <?php if ($perpage == '2') echo 'selected="selected"'; ?>>2</option>
                  <option value="10" <?php if ($perpage == '10') echo 'selected="selected"'; ?>>10</option>
                  <option value="25" <?php if ($perpage == '25') echo 'selected="selected"'; ?>>25</option>
                  <option value="50" <?php if ($perpage == '50') echo 'selected="selected"'; ?>>50</option>
                  <option value="100" <?php if ($perpage == '100') echo 'selected="selected"'; ?>>100</option>
                  <option value="All" <?php if ($perpage == 'All') echo 'selected="selected"'; ?>>All</option>
                </select>
                entries
              </label>
            </div>
            <div class="col-md-6 col-sm-6 col-xs-6 search-ryt">
              <input type="text" name="searchValue" id="searchValue" value="<?php echo $searchValue; ?>" class="form-control input-smt" placeholder="Enter Search Text">
            </div>
          </div>
          <div class="dash">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="10%">Sr.No.</th>
                  <th>Title</th>
                  <th>Image</th>
                  <th>Status</th>
                  <?php if ($edit_data == 'Y') : ?>
                    <th width="10%" class="center">--</th>
                  <?php endif; ?>
                </tr>
              </thead>
              <tbody>
                <?php if ($ALLDATA <> "") : $i = 1;
                  foreach ($ALLDATA as $ALLDATAINFO) : ?>
                    <tr class="<?php if ($i % 2 == 0) : echo 'odd';
                                else : echo 'even';
                                endif; ?> gradeX">
                      <td><?= $i++ ?></td>
                      <td><?= stripslashes($ALLDATAINFO['title']) ?></td>
                      <td>
                        <?php if ($ALLDATAINFO['image']) : ?>
                          <img src="<?= stripslashes($ALLDATAINFO['image']) ?>" alt="Client image" width="100">
                        <?php endif; ?>
                      </td>
                      <td><?= showStatus($ALLDATAINFO['status']) ?></td>
                      <?php if ($edit_data == 'Y') : ?>
                        <td class="center">
                          <div class="btn-group">
                            <button class="btn dropdown-toggle" data-toggle="dropdown">Action <span class="caret"></span></button>
                            <ul class="dropdown-menu">
                              <?php if ($edit_data == 'Y') : ?>
                                <li><a href="<?= $editlink . $ALLDATAINFO['heading_id'] ?>"><i class="fa fa-edit"></i> Edit Details</a></li>
                                <li class="divider"></li>
                                <?php if ($ALLDATAINFO['status'] == 'Y') : ?>
                                  <li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/changeStatus/<?= $ALLDATAINFO['heading_id'] ?>/N"><i class="fa fa-hand-o-up"></i> Inactive</a></li>
                                <?php elseif ($ALLDATAINFO['status'] == 'N') : ?>
                                  <li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/changeStatus/<?= $ALLDATAINFO['heading_id'] ?>/Y"><i class="fa fa-hand-o-up"></i> Active</a></li>
                                <?php endif;
                                if ($ALLDATAINFO['status'] == 'N') : ?>
                                  <li class="divider"></li>
                                  <!--<li><a href="{FULL_SITE_URL}{CURRENT_CLASS}/deleteData/<?= $ALLDATAINFO['heading_id'] ?>" onclick="return confirm('Are You Sure You Want To Delete This?');"><i class="fa fa-trash"></i> Delete</a></li>
                              --><?php endif;
                              endif; ?>
                            </ul>
                          </div>
                        </td>
                      <?php endif; ?>
                    </tr>
                  <?php endforeach;
                else : ?>
                  <tr>
                    <td colspan="7" style="text-align:center;">No Data Available In Table</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
            <div class="pagi row">
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-txt"><?php echo $noOfContent; ?></div>
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-bar">
                <?= $PAGINATION ?>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
  var prevSerchValue = '<?php echo $searchValue; ?>';
</script>
<script type="text/javascript">
  $(function() {
    <?php if ($formError == 'Yes') : ?>
      $('#addEditSection').slideDown();
    <?php elseif ($editid) : ?>
      $('#addEditSection').slideDown();
    <?php endif; ?>
  });
  $(document).on('click', '#openAddEditSection', function() {
    $('#addEditSection').slideDown();
  });
  <?php if ($editid) : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      window.location.href = '<?php echo $cancellink; ?>';
    });
  <?php else : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      $('#addEditSection').slideUp();
    });
  <?php endif; ?>
</script>