<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{FULL_SITE_URL}dashboard" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="<?php echo correctLink('smallcmsAdminData', '{FULL_SITE_URL}{CURRENT_CLASS}/index'); ?>" class=""><i class="fa fa-file-text-o"></i>General Data</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i><?= $EDITDATA ? 'Edit' : 'Add' ?> General Data</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> General Data</h3>
          <a href="<?php echo correctLink('smallcmsAdminData', '{FULL_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['small_cms_id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>&nbsp;</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('contact_email')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Contact Email<span class="required">*</span></label>
                      <input type="text" name="contact_email" id="contact_email" value="<?php if (set_value('contact_email')) : echo set_value('contact_email');
                                                                                        else : echo stripslashes($EDITDATA['contact_email']);
                                                                                        endif; ?>" class="form-control required" placeholder="Contact Email">
                      <?php if (form_error('contact_email')) : ?>
                        <span for="contact_email" generated="true" class="help-inline"><?php echo form_error('contact_email'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('contact_phone')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Contact Phone<span class="required">*</span></label>
                      <input type="text" name="contact_phone" id="contact_phone" value="<?php if (set_value('contact_phone')) : echo set_value('contact_phone');
                                                                                        else : echo stripslashes($EDITDATA['contact_phone']);
                                                                                        endif; ?>" class="form-control required" placeholder="Phone Number">
                      <?php if (form_error('contact_phone')) : ?>
                        <span for="contact_phone" generated="true" class="help-inline"><?php echo form_error('contact_phone'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('contact_address')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Contact Address<span class="required">*</span></label>
                      <input type="text" name="contact_address" id="contact_address" value="<?php if (set_value('contact_address')) : echo set_value('contact_address');
                                                                                            else : echo stripslashes($EDITDATA['contact_address']);
                                                                                            endif; ?>" class="form-control required" placeholder="Contact Address">
                      <?php if (form_error('contact_address')) : ?>
                        <span for="contact_address" generated="true" class="help-inline"><?php echo form_error('contact_address'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </fieldset>
              <fieldset>
                <legend>Social Media Link</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('link1')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Facebook Link<span class="required">*</span></label>
                      <input type="text" name="link1" id="link1" value="<?php if (set_value('link1')) : echo set_value('link1');
                                                                        else : echo stripslashes($EDITDATA['link1']);
                                                                        endif; ?>" class="form-control" placeholder="Facebook Link">
                      <?php if (form_error('link1')) : ?>
                        <span for="link1" generated="true" class="help-inline"><?php echo form_error('link1'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('link2')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Youtube Link</label>
                      <input type="text" name="link2" id="link2" value="<?php if (set_value('link2')) : echo set_value('link2');
                                                                        else : echo stripslashes($EDITDATA['link2']);
                                                                        endif; ?>" class="form-control" placeholder="Youtube Link">
                      <?php if (form_error('link2')) : ?>
                        <span for="link2" generated="true" class="help-inline"><?php echo form_error('link2'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('link3')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Instagram Link<span class="required">*</span></label>
                      <input type="text" name="link3" id="link3" value="<?php if (set_value('link3')) : echo set_value('link3');
                                                                        else : echo stripslashes($EDITDATA['link3']);
                                                                        endif; ?>" class="form-control " placeholder="Instagram Link">
                      <?php if (form_error('link3')) : ?>
                        <span for="link3" generated="true" class="help-inline"><?php echo form_error('link3'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group <?php if (form_error('link4')) : ?>error<?php endif; ?>">
                      <label class="fancy-checkbox form-headings">Twitter Link<span class="required">*</span></label>
                      <input type="text" name="link4" id="link4" value="<?php if (set_value('link4')) : echo set_value('link4');
                                                                        else : echo stripslashes($EDITDATA['link4']);
                                                                        endif; ?>" class="form-control" placeholder="Twitter Link">
                      <?php if (form_error('link4')) : ?>
                        <span for="link4" generated="true" class="help-inline"><?php echo form_error('link4'); ?></span>
                      <?php endif; ?>
                    </div>
                  </div>
                </div>
              </fieldset>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="<?php echo correctLink('smallcmsAdminData', '{FULL_SITE_URL}{CURRENT_CLASS}/index'); ?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                  :- <strong><span style="color:#FF0000;">*</span> Indicates
                    Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
  $(function() {
    create_editor_for_textarea('content')
  });
</script>