<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="{VENDOR_SITE_URL}dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-whatsapp"></i>WhatsApp Messages</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">WhatsApp Messages</h3>
        </div>
        <hr class="differ">
        <form id="Data_Form" name="Data_Form" method="get" action="{FULL_SITE_URL}chatroom/DownloadWhatsappData" autocomplete="off">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6 search">
              <label>
                <select id="years" name="years" class="form-control input-sm" onchange="Search()">
                  <?php
                  $Y = date('Y');
                  for ($i=2022; $i <= $Y; $i++) {
                    $selected = '';
                    if($Y==$i){
                      $selected = 'selected';
                    } 
                    echo '<option value="'.$i.'" '.$selected.'>'.$i.'</option>';
                  }
                  $CMonths =date('m');
                  ?>
                </select>
                <select id="months" name="months" class="form-control input-sm" onchange="Search()">
                  <option value="01" <?php if($CMonths=='01'){ echo 'selected';} ?>>January</option>
                  <option value="02" <?php if($CMonths=='02'){ echo 'selected';} ?>>February</option>
                  <option value="03" <?php if($CMonths=='03'){ echo 'selected';} ?>>March</option>
                  <option value="04" <?php if($CMonths=='04'){ echo 'selected';} ?>>April</option>
                  <option value="05" <?php if($CMonths=='05'){ echo 'selected';} ?>>May</option>
                  <option value="06" <?php if($CMonths=='06'){ echo 'selected';} ?>>June</option>
                  <option value="07" <?php if($CMonths=='07'){ echo 'selected';} ?>>July</option>
                  <option value="08" <?php if($CMonths=='08'){ echo 'selected';} ?>>August</option>
                  <option value="09" <?php if($CMonths=='09'){ echo 'selected';} ?>>September</option>
                  <option value="10" <?php if($CMonths=='10'){ echo 'selected';} ?>>October</option>
                  <option value="11" <?php if($CMonths=='11'){ echo 'selected';} ?>>November</option>
                  <option value="12" <?php if($CMonths=='12'){ echo 'selected';} ?>>December</option>                
                </select>
                <select id="vendor_id" name="vendor_id" class="form-control input-sm" onchange="Search()">
                  <option value="All">All</option>
                  <?php
                  foreach($AllVendor as $row) {
                    echo '<option value="'.$row['id'].'">'.$row['vendor_business_name'].'</option>';
                  }
                  ?>                
                </select>
                <select id="msg_type" name="msg_type" class="form-control input-sm" onchange="Search()">
                  <option value="All">All</option>
                  <option value="CheckIn">CheckIn</option>             
                  <option value="CheckOut">CheckOut</option>             
                  <option value="BulkMsg">BulkMsg</option>             
                </select>
                <select id="status" name="status" class="form-control input-sm" onchange="Search()">
                  <option value="All">Both</option>
                  <option value="1">Send</option>             
                  <option value="0">Faild</option>                         
                </select>
                <button type="submit" class="btn btn-primary btn-lg form-btn">Download</button>
              </label>  
            </div>
          </div>
        </form>
        <div class="dash">
          <table class="table table-bordered">
            <thead>
              <tr>
                <th width="10%">Sr.No.</th>
                <th>Business Name</th>
                <th>Msg Type</th>
                <th>Mobile</th>
                <th>Customer Name</th>
                <th>Message</th>
                <th>Status</th>
                <th width="10%">Date</th>
              </tr>
            </thead>
            <tbody id="Result"></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
$("dosument").ready(function(){
  loadData(1);
});
function Search(){
  loadData(1);
}
function Pagination(page){
  loadData(page);
}
function loadData(page){
  $("#Result").html('<tr><td colspan="10"><center>Loading..</center></td></tr>');
  var years       = $("#years").val();
  var months      = $("#months").val();
  var vendor_id      = $("#vendor_id").val();
  var msg_type      = $("#msg_type").val();
  var status      = $("#status").val();
  $.ajax({
    url : '{FULL_SITE_URL}chatroom/whatsapplisting',
    type: "GET",
    data : {years:years,months:months,page:page,vendor_id:vendor_id,msg_type:msg_type,status:status},
    success:function(a)
    {
      $("#Result").html(a);
    }
  });
}
</script>