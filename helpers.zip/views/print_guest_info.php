<html>
  <head>
    <style>
      @media print {
      body {
      font-family: Arial, Helvetica, sans-serif; }
      th,td{ font-size:10pt;}
      * {
      padding: 0;
      margin: 0;
      }
      }
    </style>
  </head>
  <body>
    <div style="height:1px; width:100%; background:#dddddd;"></div>
    <div class="clearfix"></div>
    <?php if($VENDORDATA['vendor_image'] != ''){ ?>
    <div style="text-align:center;">
      <img src="<?php echo $VENDORDATA['vendor_image']; ?>" style="width: 120px;margin: auto;margin-bottom: 10px;">
    </div>
    <?php } ?>
    <h3 style="text-align:center"><?php echo stripslashes(ucfirst($VENDORDATA['vendor_business_name'])); ?></h3>
    <div class="table-wrapper2 table-Div" id="table-Div" style="display: block;">
      <?php if (!empty($viewData)) { //echo "<pre>"; print_r($viewData['hotel_manager_name']); exit; ?>
      <table class="table border-none"  style="width: 100%; border-collapse: collapse;font-size: 11pt;overflow: wrap">
        <tbody>
          <tr>
            <td>
              <table class="table border-none">
                <thead>
                  <tr>
                    <th align="left" colspan="2"><strong>Personal details</strong></th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td align="left" width="30%"><strong>Hotel Manager Name</strong></td>
                    <td align="left" width="70%"><?php echo ($viewData['hotel_manager_name']) ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Customer Name</strong></td>
                    <td align="left" width="70%"><?php echo ($viewData['customer_name']) ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Email</strong></td>
                    <td align="left" width="70%"><?php echo ($viewData['customer_email']) ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Customer Mobile Number</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['customer_mobile_number']) ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Address</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['person_address']) ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Age</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['age']) ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>ID Card</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['id_card']) ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Check-in Date Time</strong></td>
                    <td align="left" width="70%"><?php echo date('d-m-Y H:i:s A', strtotime($viewData['check_in_datetime'])) ?></td>
                  </tr>
                  <?php if($viewData['entry_type'] == 'Guest' && $viewData['estimated_checkout'] != ""){ 
                    $estimated = !empty($viewData['estimated_checkout']) ? date('d-m-Y',strtotime($viewData['estimated_checkout'])).' 12:00 PM' :'';
                    ?>
                  <tr>
                    <td align="left" width="30%"><strong>Estimated Checkout</strong></td>
                    <td align="left" width="70%"><?php echo $estimated; ?></td>
                  </tr>
                <?php } ?>
                  <tr>
                    <td align="left" width="30%"><strong>Check-out Date Time</strong></td>
                    <?php if ($viewData['check_out_datetime'] != "") : ?>
                    <td align="left" width="70%"><?php echo date('d-m-Y H:i:s A', strtotime($viewData['check_out_datetime'])) ?></td>
                    ;
                    <?php else : ?>
                    <td align="left" width="70%">N/A</td>
                    <?php  endif; 
                      if($viewData['reffer_mode'] == 'offline'){
                        $bMode = 'Direct';
                      }else{
                        $bMode = $viewData['reffer_mode'];
                      } ?>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>GRC No.</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['entry_number']); ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Room Number</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($roomNumber['room_no']); ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Number Of Person</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['number_of_person']); ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Room Rent</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['amount']); ?></td>
                  </tr>
                  <!--tr>
                    <td align="left" width="30%"><strong>Address</strong></td>
                    <td align="left" width="70%">' . stripslashes($viewData['address']) . '</td>
                    </tr-->                   
                  <tr>
                    <td align="left" width="30%"><strong>GSTIN</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['gst_number']); ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Company Name</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['company_name']); ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Company Address</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['company_address']); ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Plan</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($viewData['choose_plan']); ?></td>
                  </tr>
                  <tr>
                    <td align="left" width="30%"><strong>Booking Mode</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes(ucfirst($bMode)); ?></td>
                  </tr>
                  <!--tr>
                    <td align="left" width="30%"><strong>Hotal Name</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes(ucfirst($VENDORDATA['vendor_business_name'])); ?></td>
                    </tr-->
                  <tr>
                    <td align="left" width="30%"><strong>OTA Name</strong></td>
                    <td align="left" width="70%"><?php echo stripslashes($otaName['ots_name']) ?></td>
                  </tr>
                  <?php 
                    $DIRECT_MODE = $viewData['direct_mode'] ?? 'N/A';
                    $ONLINE_MODE = $viewData['online_mode'] ?? 'N/A';
                    if($viewData['direct_mode'] == "non_commission"){
                        $modes = 'Without Commission';
                    }
                    else{ 
                        $modes = ucfirst($DIRECT_MODE);
                    }
                    if($viewData['reffer_mode'] == ''){
                    
                    }
                    $COMMISSION_AMOUNT = $viewData['commission_amount'] ?? '0.00';
                    $PREPAID_AMOUNT = $viewData['prepaid_amount'] ?? '0.00';
                    if ($viewData['reffer_mode'] == "online") : ?>
                  <!--tr>
                    <td align="left" width="30%"><strong>Payment Mode </strong></td>
                    <td align="left" width="70%"><?php echo ucfirst($ONLINE_MODE) ?></td>
                    </tr-->;
                  <?php if ($ONLINE_MODE == "prepaid") : ?>
                  <!--tr>
                    <td align="left" width="30%"><strong>How Much Prepaid?</strong></td>
                    <td align="left" width="70%"><?php echo $PREPAID_AMOUNT ?></td>
                    </tr--->
                  <?php endif; 
                    elseif ($viewData['reffer_mode'] == "offline") :
                    ?>
                  <tr>
                    <td align="left" width="30%"><strong>Direct Mode</strong></td>
                    <td align="left" width="70%"><?php echo ucfirst($modes) ?></td>
                  </tr>
                  <?php if ($DIRECT_MODE == "commission") : ?>
                  <tr>
                    <td align="left" width="30%"><strong>How Much Commision?</strong></td>
                    <td align="left" width="70%"><?php echo $COMMISSION_AMOUNT ?></td>
                  </tr>
                  <?php endif;
                    endif; ?>
                  <tr>
                    <td align="left" width="30%"><strong>Remarks</strong></td>
                    <td align="left" width="70%"><textarea cols="80" rows="3"><?php echo stripslashes($viewData['remarks']); ?></textarea></td>
                  </tr>
                  <!--tr>
                    <td align="left" width="30%"><strong>Status</strong></td>
                    <td align="left" width="70%"><?php echo showStatus($viewData['status']); ?></td>
                    </tr--> 
                </tbody>
              </table>
            </td>
          </tr>
          <tr>
            <td>
              <table class="table border-none">
                <thead>
                  <tr>
                    <th align="left" colspan="2"><strong>Identity Proof details</strong></th>
                  </tr>
                </thead>
                <tbody>
                  <?php 
                    if ($kycData != ""){ //print_r($kycData); exit;
                      foreach ($kycData as $kData) : ?>
                  <tr>
                    <?php 
                      $loc = base_url().''.$kData['doc_url']; 
                      $loc2 = $this->config->item("root_path") . 'assets/customerDocuments/location.png';
                      ?>
                    <td align="center" width="100%">
                      <a target="_new" download href="<?php echo $loc; ?>">View</a>
                    </td>
                  </tr>
                  <?php     
                    endforeach;
                    } else{ ?>
                  <tr>
                    <td>N/A</td>
                  </tr>
                  <?php } ?>
                </tbody>
              </table>
            </td>
          </tr>
          </td></tr>
        </tbody>
      </table>
      <?php
        $CountAdvance = 0;
        foreach ($ALLDATA as $key=>$ALLDATAINFO){
        if($ALLDATAINFO['page_source']=='add_an_advance'){
        $CountAdvance++;
        }
        }
        if($CountAdvance>0){
        ?>
      <h3>Advance Details</h3>
     <?php  $transaction_id=0;
      $ResQuery = "SELECT transaction_id FROM ".getTablePrefix()."vendor WHERE vendor_id = '".sessionData('MHM_VENDOR_ID')."' order by id desc";
      $query = $this->db->query($ResQuery);
      if ($query->num_rows() > 0){
        $ResData = $query->result_array();
        foreach ($ResData as $row) {
          $transaction_id = $row['transaction_id'];
        }
      } ?>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 15%">Sr. No.</th>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 15%">Bill Items</th>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 10%">Amount Paid</th>
            <?php if($transaction_id > 0){?>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 12%">Transaction Id</th>
            <?php } ?>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 18%">Payment Mode</th>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 10%">Date & Time</th>
          </tr>
        </thead>
        <tbody id="sub_guest">
          <?php $i=0;
            foreach ($ALLDATA as $key=>$ALLDATAINFO){
                //echo "<pre>"; print_r($ALLDATAINFO); exit;
                $delQuery = "SELECT check_in_datetime,check_out_datetime FROM " . getTablePrefix() . "customer_summary_book WHERE summary_book_id = '" . $ALLDATAINFO['customer_id'] . "' AND hotel_manager_id= '".$ALLDATAINFO['hotel_manager_id']."' ";
                $chkOut = $this->common_model->getDataByQuery('single', $delQuery);
              if($ALLDATAINFO['page_source']=='add_an_advance'){
                $i++;
            ?>
          <tr id="sub_row_0" class="addSub">
            <td style="width:10%;text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;"><?php echo $i; ?> 
            </td>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;"><?= stripslashes($ALLDATAINFO['bill_item'])?>
            </td>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;"><?=stripslashes($ALLDATAINFO['payment_paid'])?>
            </td>
            <?php if($transaction_id > 0){?>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;"><?=stripslashes($ALLDATAINFO['transaction_id'])?>
            </td>
            <?php } ?>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
              <?php 
                if ($ALLDATAINFO['amount_mode'] == "prepaid"){
                  echo 'Prepaid';
                }elseif ($ALLDATAINFO['amount_mode']=='offline') {
                  echo 'Offline';
                }elseif ($ALLDATAINFO['amount_mode']=='online') {
                  echo 'Online';
                }elseif ($ALLDATAINFO['amount_mode']=='BTC') {
                  echo 'BTC';
                }
                ?>
            </td>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
              <?=date('d-m-Y h:i A', strtotime($ALLDATAINFO['order_date']))?>
            </td>
          </tr>
          <?php } } ?>
        </tbody>
      </table>
      <?php } ?>
      <?php if(!empty($subGuestData)){ ?>
      <h3>Other Guest Details</h3>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 15%">Guest Name</th>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 20%">Email</th>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 10%">Phone</th>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 25%">Address</th>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 10%">Age</th>
            <th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 10pt;
              font-weight: 400; width: 10%">Id Card</th>
          </tr>
        </thead>
        <tbody id="sub_guest">
          <?php foreach ($subGuestData as $key => $value) { ?>
          <tr id="sub_row_0" class="addSub">
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;"><?php echo stripslashes($value['sub_customer_name']); ?> 
            </td>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;"><?php echo stripslashes($value['sub_customer_email']) ?>
            </td>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;"><?php echo stripslashes($value['sub_customer_mobile_number']) ?>
            </td>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
              <?php echo stripslashes($value['sub_person_address']) ?>
            </td>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;"><?php echo stripslashes($value['sub_age']) ?>
            </td>
            <td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;"><?php echo stripslashes($value['sub_id_card']) ?>
            </td>
          </tr>
          <?php }  ?>
        </tbody>
      </table>
      <?php } ?>

      <table class="table table-bordered" width="100%">
        <tbody id="sub_guest">
        <tr id="sub_row_0" class="addSub">
            <th style="text-align: left;padding-top: 10px;">
              <br> <br>  <br>   
              <h3 style="margin: 0;padding: 0; margin-top: 30px; box-sizing: border-box;font-family: Lato, sans-serif;font-size: 16px; text-align: left;">
                <b>Manager Signature</b>
              </h3>
            </th>
            <th style="text-align: right;padding-top: 10px;">
              <br> <br>  <br>   
              <h3 style="margin: 0;padding: 0; margin-top: 30px; box-sizing: border-box;font-family: Lato, sans-serif;font-size: 16px; text-align: right;">
                <b>Customer Signature</b>
              </h3>
            </th>
          </tr>
          
          <tr>
          <?php 
          if ($kycData != ""){ //print_r($kycData); exit;
            foreach ($kycData as $kData) : ?>
                <?php 
                $loc = base_url().''.$kData['doc_url']; 
                $loc2 = $this->config->item("root_path") . 'assets/customerDocuments/location.png';
                ?>
                <th style="text-align:center;padding-top: 10px;">
                  <img src="<?php echo $loc; ?>" style="width:300px;">
                </td>
            <?php     
            endforeach;
          }
          ?>
          </tr>
        </tbody>
      </table>
      <?php } ?>
    </div>
  </body>
</html>