<html>
	
	<head>
		<title></title>
		<style>
			@media print {
            body {
			font-family: Arial, Helvetica, sans-serif; }
			th,td{ font-size:8pt;}
			* {
			padding: 0;
			margin: 0;
            }
			
			}
		</style>
	</head>
<body>
	<h4>Occupied Rooms (<?php echo date("d-m-Y H:i:s"); ?>)</h4>
    <div style="height:1px; width:100%; background:#dddddd;"></div>
		<div class="clearfix"></div>			
	<div class="table-wrapper2 table-Div" id="table-Div" style="display: block;">
		<?php if (!empty($TotalCheckIn)) { ?>

			<table  class="table table-bordered" style="width: 100%; border-collapse: collapse;font-size: 11pt;overflow: wrap" >
				<thead>
					<tr>
						<th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 8pt;
						font-weight: 400; width: 5%">Sr No.</th>
						<th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 8pt;
						font-weight: 400; width: 15%">Customer name</th>
						<th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 2px;   font-size: 8pt;
						font-weight: 400; width: 10%">Room number</th>
						<th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 8pt;
						font-weight: 400; width: 10%">GRC No.</th>
						<th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 0px;   font-size: 8pt;
						font-weight: 400; width: 15%">Check in date time</th>
						<th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 8pt;
						font-weight: 400; width: 10%">Plan</th>
						<th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 8pt;
						font-weight: 400; width: 10%">Room rent</th>
						<th style="text-align: left;background: #eeeef2ab !important;color: #202084 !important;word-wrap: break-word;vertical-align: middle;  border: 1px solid #dddddd;  padding: 5px;   font-size: 8pt;
						font-weight: 400; width: 10%">OTA</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($TotalCheckIn as $key=>$row) { //echo "<pre>";print_r($TotalCheckIn);exit;

						// $roomNumber = $this->common_model->getDataByParticularField('room_number', 'room_id', $row['assign_room_number']);
						$ots = $this->common_model->getOtsName( $row['ots_id']);
						if($row['reffer_mode'] == 'online'){
							$otsName = !empty($ots[0]['ots_name']) ? $ots[0]['ots_name'] : 'N/A';		
						}
						else{
							$otsName = "Direct";
						}
						
						if($row['check_out_datetime'] == ''){
					?>
					<tr>
						<td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
							<?php echo $key+1; ?>
						</td>
						<td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
							<?php echo !empty($row['customer_name']) ? $row['customer_name'] : 'N/A'; ?>
						</td>
						<td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 3px;border: 1px solid #dddddd;font-size: 8pt;">
							<?php echo !empty($row['room_no']) ? $row['room_no'] : 'N/A'; ?>
						</td>
						<td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
							<?php echo !empty($row['entry_number']) ? $row['entry_number'] : 'N/A'; ?>
						</td>
						<td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
							<?php echo !empty($row['check_in_datetime']) ? date('d/m/Y H:i:s', strtotime($row['check_in_datetime'])) : 'N/A'; ?>
						</td>
						<td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
							<?php echo !empty($row['choose_plan']) ? $row['choose_plan'] : 'N/A'; ?>
						</td>
						<td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
							<?php echo !empty($row['amount']) ? $row['amount'] : 'N/A'; ?>
						</td>
						<td style="text-align: left;color: #000000 !important;word-wrap: break-word;vertical-align: middle;padding: 2px;border: 1px solid #dddddd;font-size: 8pt;">
							<?php echo $otsName; ?>
						</td>
						<!-- Add other table cells similarly -->
					</tr>
					<?php } ?>
					<?php } ?>
				</tbody>
			</table>
		<?php } ?>
	</div>
</body>
</html>
