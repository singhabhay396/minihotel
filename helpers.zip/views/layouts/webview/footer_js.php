<script src="https://unpkg.com/flickity@2/dist/flickity.pkgd.min.js"></script> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js" type="text/javascript"></script> 