<script src="{ASSET_ADMIN_URL}js/klorofil-common.js"></script>

<script src="{ASSET_ADMIN_URL}js/jquery.validate.js"></script>
<script src="{ASSET_ADMIN_URL}js/ashish.js"></script>

<script src="{ASSET_ADMIN_URL}js/bootstrap-datepicker.js"></script>
<script src="{ASSET_ADMIN_URL}js/jquery.cropit.js"></script>
<script src="{ASSET_ADMIN_URL}js/ajaxupload.js"></script>

<script src="{ASSET_ADMIN_URL}js/ckeditor/ckeditor.js" type="text/javascript"></script>
<script type="text/javascript">
	function create_editor_for_textarea(textareaid) {
		if (document.getElementById(textareaid)) {
			// Replace the <textarea id="Description"> with a CKEditor
			// instance, using default configuration.
			CKEDITOR.replace(textareaid, {
				filebrowserBrowseUrl: '{ASSET_ADMIN_URL}js/ckeditor/filemanager/browser/default/browser.html?Connector={ASSET_ADMIN_URL}js/ckeditor/filemanager/connectors/php/connector.php',
				filebrowserImageBrowseUrl: '{ASSET_ADMIN_URL}js/ckeditor/filemanager/browser/default/browser.html?Type=Image&Connector={ASSET_ADMIN_URL}js/ckeditor/filemanager/connectors/php/connector.php',
				filebrowserFlashBrowseUrl: '{ASSET_ADMIN_URL}js/ckeditor/filemanager/browser/default/browser.html?Type=Flash&Connector={ASSET_ADMIN_URL}js/ckeditor/filemanager/connectors/php/connector.php',
				filebrowserUploadUrl: '{ASSET_ADMIN_URL}js/ckeditor/filemanager/connectors/php/upload.php?Type=File',
				filebrowserImageUploadUrl: '{ASSET_ADMIN_URL}js/ckeditor/filemanager/connectors/php/upload.php?Type=Image',
				filebrowserFlashUploadUrl: '{ASSET_ADMIN_URL}js/ckeditor/filemanager/connectors/php/upload.php?Type=Flash',
				allowedContent: true,
				height: '300px',
				toolbar: [{
						name: 'document',
						items: ['JustifyLeft', 'JustifyCenter', 'JustifyRight','Format','Source', '-', 'InsertTable','NumberedList','BulletedList']
					}, // Defines toolbar group with name (used to create voice label) and items in 3 subgroups.
					['Cut', 'Copy', 'Paste', '-', 'Undo', 'Redo', 'Table'], // Defines toolbar group without name.
					{
						name: 'basicstyles',
						items: ['Bold', 'Italic'],
						contentToolbar: ['tableColumn', 'tableRow', 'mergeTableCells']
					}
				]
			});
		}
	};
</script>