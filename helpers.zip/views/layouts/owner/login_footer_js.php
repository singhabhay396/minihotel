<script src="{ASSET_VENDOR_URL}js/jquery.min.js"></script>
<script src="{ASSET_VENDOR_URL}js/jquery.validate.js"></script>
<script src="{ASSET_VENDOR_URL}js/ashish.login.js"></script>