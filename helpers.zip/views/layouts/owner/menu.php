<?php $restQuery = "SELECT id FROM ".getTablePrefix()."restaurant_setting WHERE owner_id=".sessionData('MHM_OWNER_ID')." AND is_restaurant = 1 ";
    $restInfo = $this->common_model->getDataByQuery('multiple', $restQuery);
    ?>
<div id="sidebar-nav" class="sidebar">
  <div class="sidebar-scroll">
    <nav>
      <ul class="nav">
        <li><a href="<?=base_url('owner/dashboard')?>" <?php if (strtolower($activeMenu) == 'dashboard'){ ?> class="active" <?php }?>>Dashboard</a></li>
        <?php if(!empty($this->session->userdata('MHM_IS_OWNER'))){ ?>
        <li><a href="<?=base_url('owner/hotel')?>" <?php if (strtolower($activeMenu) == 'Hotel'){ ?>class="active" <?php }?>> Hotel</a></li>
      <?php } ?>
        <li><a href="<?=base_url('owner/calendar/index')?>" <?php if (strtolower($activeMenu) == 'Calendar'){ ?>class="active" <?php }?>> Calendar</a></li>
        
        <li><a href="<?=base_url('owner/guestcheckoutlist/index')?>" <?php if (strtolower($activeMenu)=='CheckedOut'): ?>class="active" <?php endif;?>> Checked-Out Customers</a></li>
        <li><a href="<?=base_url('owner/billbookdata/index')?>" <?php if (strtolower($activeMenu) == 'BillBook'){ ?>class="active" <?php }?>> Bill Book</a></li>
        <li><a href="<?=base_url('owner/businessreport/index')?>" <?php if (strtolower($activeMenu) == 'BusinessReports'){ ?>class="active" <?php }?>> Business Reports</a></li>
        <!--li><a href="<?=base_url('owner/reports/index')?>" <?php if (strtolower($activeMenu) == 'TodayReports'){ ?>class="active" <?php }?>> Today Reports</a></li-->
        <li><a href="<?=base_url('owner/collectionreport/index')?>" <?php if (strtolower($activeMenu)=='CollectionReports'): ?>class="active" <?php endif;?>> Download Collection Report</a></li>
        <?php if(!empty($this->session->userdata('MHM_IS_OWNER'))){ ?>
        <li><a href="<?=base_url('owner/manager/index')?>" <?php if (strtolower($activeMenu) == 'Manager'){ ?>class="active" <?php }?>> Managers</a></li>
        <?php if(!empty($restInfo)){?>
        <li><a href="<?=base_url('owner/restaurant/index')?>" <?php if (strtolower($activeMenu) == 'Restaurant'){ ?>class="active" <?php }?>> Restaurant</a></li>
        <?php } ?>
        <li><a href="<?=base_url('owner/kot/index')?>" <?php if (strtolower($activeMenu) == 'KOT'){ ?>class="active" <?php }?>> KOT</a></li>
      <?php } ?>
        <li><a href="<?=base_url('owner/log/index')?>" <?php if (strtolower($activeMenu) == 'Log'){ ?>class="active" <?php }?>> Log</a></li>
        <li><a href="<?=base_url('owner/guestcheckoutlist/addopenerbalance')?>" <?php if (strtolower($activeMenu)=='CheckedOut'): ?>class="active" <?php endif;?>> Update Opening Balance</a></li>
        <?php if(!empty($this->session->userdata('MHM_IS_OWNER'))){ ?>
        <li><a href="<?=base_url('owner/subowner/index')?>" <?php if (strtolower($activeMenu)=='CheckedOut'): ?>class="active" <?php endif;?>> Sub Owner</a></li>
      <?php } ?>
      </ul>
    </nav>
  </div>
</div>