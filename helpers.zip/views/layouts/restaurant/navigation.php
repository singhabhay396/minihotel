<style>
  .img-responsive {
    width: 80px;
    height: 60px;
  }
</style>
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="brand"> <a href="<?=base_url('restaurant/dashboard')?>"><img src="{ASSET_VENDOR_URL}images/logo.png" alt="Klorofil Logo" class="img-responsive logo"></a> </div>
  <div class="container-fluid">
    <div class="navbar-btn">
      <button type="button" class="btn-toggle-fullwidth"><i class="lnr lnr-arrow-left-circle"></i></button>
    </div>
    <div class="nav-title-rw">
      <strong>
        <h3 style="color:#000000"> Welcome Restaurant</h3>
      </strong>
      <p></p>
    </div>
    <div id="navbar-menu">
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown"> <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown"><span><?php echo sessionData('MHM_REST_NAME'); ?> (<?php echo sessionData('MHM_REST_BUSINESS_NAME'); ?>)</span> <i class="icon-submenu lnr lnr-chevron-down"></i></a>
          <ul class="dropdown-menu">
            <li><a href="<?=base_url('restaurant/login/logout')?>"><i class="lnr lnr-exit"></i> <span>Logout</span></a></li>
          </ul>
        </li>
      </ul>
    </div>
    <div class="show-hide">
       <div class="dropdown custum">
          <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown"><?php echo sessionData('MHM_REST_NAME'); ?>
          <span class="caret"></span></button>
          <ul class="dropdown-menu">
            <li><a href="<?=base_url('restaurant/login/logout')?>"><i class="lnr lnr-exit"></i> <span>Logout</span></a></li>
          </ul>
        </div>
    </div>
  </div>
</nav>