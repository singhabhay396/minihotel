<div id="sidebar-nav" class="sidebar">
  <div class="sidebar-scroll">
    <?php 
    $restQuery = "SELECT * FROM ".getTablePrefix()."restaurant_setting WHERE vendor_id=".sessionData('MHM_REST_HOTEL_ID')." AND is_table = 1 ";
    //echo $restQuery; exit;
    $restInfo = $this->common_model->getDataByQuery('single', $restQuery);

    ?>
    <nav>
      <ul class="nav"> 
        <li><a href="<?=base_url('restaurant/dashboard')?>" <?php if (strtolower($activeMenu) == 'Dashboard'){ ?> class="active" <?php }?>>Dashboard</a></li>
        <?php if(!empty($restInfo)){ ?>
        <li><a href="<?=base_url('restaurant/table/index')?>" <?php if(strtolower($activeMenu)=='Table'):?>class="active"<?php endif;?>> Table</a></li>
      <?php } ?>
        <li><a href="<?=base_url('restaurant/menu')?>" <?php if(strtolower($activeMenu)=='Menu'):?>class="active"<?php endif;?>> Food Menu</a></li>
        <li><a href="<?=base_url('restaurant/report')?>" <?php if(strtolower($activeMenu)=='Sale'):?>class="active"<?php endif;?>> Total Sale</a></li>
        <li><a href="<?=base_url('restaurant/dashboard/settings')?>" <?php if(strtolower($activeMenu)=='Settings'):?>class="active"<?php endif;?>> General Settings</a></li>
      </ul>
    </nav>
  </div>
</div>