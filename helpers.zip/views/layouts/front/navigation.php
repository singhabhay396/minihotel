<?php
$GeneralData           = $this->front_model->getGeneralData();
?>
<header class="header">
    <div class="header-top">
        <div class="container">
            <div class="col-md-5">
                <div class="Content-left">
                    Welcome to MHM
                </div>
            </div>
            <div class="col-md-7">
                <div class="Content-right">
                    <span class="Top-contact">
                        <img src="{ASSET_FRONT_URL}images/icons/incomming-call.png"> <?= $GeneralData['contact_phone'] ?>
                    </span>
                    <span class="Top-email">
                        <img src="{ASSET_FRONT_URL}images/icons/mail.png"> <?= $GeneralData['contact_email'] ?>
                    </span>
                </div>
            </div>
        </div>
    </div>
    <!-- End of Header Top -->
    <div class="header-middle show-hide ">
        <div class="container">
            <div class="show-hide">

                <nav class="navbar navbar-light light-blue lighten-4">
                
                  <!-- Navbar brand -->
                  <a class="navbar-brand" href="#"></a>
                
                  <!-- Collapse button -->
                  <button class="navbar-toggler toggler-example" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1"
                    aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation"><span class="dark-blue-text"><i
                        class="fas fa-bars fa-1x"></i></span></button>
                
                  <!-- Collapsible content -->
                  <div class="collapse navbar-collapse" id="navbarSupportedContent1">
                
                    <!-- Links -->
                    <ul class="navbar-nav mr-auto">
                      <li class="nav-item active">
                        <a href="<?php echo base_url(); ?>">Home</a>
                      </li>
                      <li class="nav-item">
                         <a href="#about-us">About Us </a>
                      </li>
                      <li class="nav-item">
                         <a href="#features">Features </a>
                      </li>
                      <li class="nav-item">
                         <a href="#contact">Contact Us </a>
                      </li>
                    </ul>
                    <!-- Links -->
                
                  </div>
                  <!-- Collapsible content -->
                
                </nav>
                <!--/.Navbar-->
                
                  </div>
            <div class="header-left mr-md-4">
                <a href="#" class="" aria-label="menu-toggle">
                </a>
                <a  href="<?php echo base_url(); ?>" class="logo ml-lg-0">
                   <img class="" src="{ASSET_FRONT_URL}images/logo.png" alt="logo">
                </a>
                <div class="middle-menu">
                    <nav class="main-nav">
                        <ul class="menu active-underline">
                            <li class="active">
                                <a href="<?php echo base_url(); ?>">Home</a>
                            </li>
                            <li>
                                <a href="#about-us">About Us </a>
                            </li>
                            <li>
                                <a href="#features">Features </a>
                            </li>
                            <li>
                                <a href="#contact">Contact Us </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
              
            <div class="header-right ml-4">
                <div class="login-button">
                    <a href="<?php echo base_url(); ?>owner/login">
                        <button type="button" class="btn btn-warning">Owner Login</button>
                    </a>
                </div>
                <div class="login-button">
                    <a href="<?php echo base_url(); ?>vendor/login">
                        <button type="button" class="btn btn-warning">Manager Login</button>
                    </a>
                </div>
                <div class="get-started-button">
                    <a href="<?php echo base_url(); ?>user/sign-up">
                        <button type="button" class="btn btn-warning">Get Started</button>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <div class="header-middle show-hide2 ">
        <div class="container">
            <div class="header-left mr-md-4">
                <a href="#" class="" aria-label="menu-toggle">
                </a>
                <a  href="<?php echo base_url(); ?>" class="logo ml-lg-0">
                   <img class="" src="{ASSET_FRONT_URL}images/logo.png" alt="logo">
                </a>
                <div class="middle-menu">
                    <nav class="main-nav">
                        <ul class="menu active-underline">
                            <li class="active">
                                <a href="<?php echo base_url(); ?>">Home</a>
                            </li>
                            <li>
                                <a href="#about-us">About Us </a>
                            </li>
                            <li>
                                <a href="#features">Features </a>
                            </li>
                            <li>
                                <a href="#contact">Contact Us </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </div>
              <div class="show-hide">

                <nav class="navbar navbar-light light-blue lighten-4">
                
                  <!-- Navbar brand -->
                  <a class="navbar-brand" href="#"></a>
                
                  <!-- Collapse button -->
                  <button class="navbar-toggler toggler-example" type="button" data-toggle="collapse" data-target="#navbarSupportedContent1"
                    aria-controls="navbarSupportedContent1" aria-expanded="false" aria-label="Toggle navigation"><span class="dark-blue-text"><i
                        class="fas fa-bars fa-1x"></i></span></button>
                
                  <!-- Collapsible content -->
                  <div class="collapse navbar-collapse" id="navbarSupportedContent1">
                
                    <!-- Links -->
                    <ul class="navbar-nav mr-auto">
                      <li class="nav-item active">
                        <a href="<?php echo base_url(); ?>">Home</a>
                      </li>
                      <li class="nav-item">
                         <a href="#about-us">About Us </a>
                      </li>
                      <li class="nav-item">
                         <a href="#features">Features </a>
                      </li>
                      <li class="nav-item">
                         <a href="#contact">Contact Us </a>
                      </li>
                    </ul>
                    <!-- Links -->
                
                  </div>
                  <!-- Collapsible content -->
                
                </nav>
                <!--/.Navbar-->
                
                  </div>
            <div class="header-right ml-4">
                <div class="login-button">
                    <a href="<?php echo base_url(); ?>owner/login">
                        <button type="button" class="btn btn-warning">Owner Login</button>
                    </a>
                </div>
                <div class="login-button">
                    <a href="<?php echo base_url(); ?>restaurant/login">
                        <button type="button" class="btn btn-warning">Restaurant Login</button>
                    </a>
                </div>
                <div class="login-button">
                    <a href="<?php echo base_url(); ?>vendor/login">
                        <button type="button" class="btn btn-warning">Manager Login</button>
                    </a>
                </div>
                <div class="get-started-button">
                    <a href="<?php echo base_url(); ?>user/sign-up">
                        <button type="button" class="btn btn-warning">Get Started</button>
                    </a>
                </div>
            </div>
        </div>
    </div>
</header>