<!-- Favicon -->

<link rel="icon" type="image/png" sizes="96x96" href="{ASSET_FRONT_URL}images/favicon.png">

<!-- Vendor CSS -->

<link rel="stylesheet" type="text/css" href="{ASSET_FRONT_URL}vendor/fontawesome-free/css/all.min.css">

<!-- Plugins CSS -->

<link rel="stylesheet" type="text/css" href="{ASSET_FRONT_URL}vendor/animate/animate.min.css">

<!-- Link Swiper's CSS -->

<link rel="stylesheet" href="{ASSET_FRONT_URL}vendor/swiper/swiper-bundle.min.css">

<!-- <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css"> -->

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">



<!-- Default CSS -->

<link rel="stylesheet" type="text/css" href="{ASSET_FRONT_URL}css/demo1.min.css">

<link rel="stylesheet" href="{ASSET_FRONT_URL}css/ashish.css">



<script type="text/ecmascript">

    var BASEURL = '{BASE_URL}';

    var FRONTURL = '{FRONT_URL}';

    var ADMINURL = '{ADMIN_URL}';

    var VENDORURL = '{VENDOR_URL}';

    var FRONTSITEURL = '{FRONT_SITE_URL}';

    var FULLSITEURL = '{FULL_SITE_URL}';

    var VENDORSITEURL = '{VENDOR_SITE_URL}';

    var ASSETURL = '{ASSET_URL}';

    var ASSETFRONTURL = '{ASSET_FRONT_URL}';

    var ASSETADMINURL = '{ASSET_ADMIN_URL}';

    var ASSETVENDORURL = '{ASSET_VENDOR_URL}';

    var CURRENTCLASS = '{CURRENT_CLASS}';

    var CURRENTMETHOD = '{CURRENT_METHOD}';

    var csrf_api_key = '<?php echo $this->security->get_csrf_token_name(); ?>';

    var csrf_api_value = '<?php echo $this->security->get_csrf_hash(); ?>';

    var USERID = '<?php echo sessionData('MHM_USER_ID'); ?>';

</script>

<script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

<script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>

<script src="{ASSET_FRONT_URL}js/main.min.js"></script>



<!-- google analytics -->

<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-F305Y5KT9L"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-F305Y5KT9L');
</script>

<!-- googleanalitics -->
