<footer class="main-footer">
    <div class="container">
        <div class="row text-center footer-padd">
            <h3 class="">Useful Links</h3>
            <div>
                <ul class="widget-body">
                    <li><a href="#features">Features</a></li>
                    <li><a href="#contact">Contact Us</a></li>
                    <li><a href="#about-us">About Us</a></li>
                    <li><a href="<?php echo base_url() ?>subscription">Subscription</a></li>
                    <li><a href="<?php echo base_url() ?>terms-and-condition">Terms & Conditions</a></li>
                    <li><a href="<?php echo base_url() ?>privacy-policy">Privacy Policy</a></li>
                </ul>
            </div>
        </div>
        <?php
        $GeneralData           = $this->front_model->getGeneralData();
        ?>
        <div class="row text-center footer-padd2">
            <h3 class="">Contact Us</h3>
            <div class="span-content-set">
                <span class="contact-details"><img src="{ASSET_FRONT_URL}images/icons/location-f.png"> <?= $GeneralData['contact_address'] ?>
                </span>
                <span class="contact-details"><img src="{ASSET_FRONT_URL}images/icons/telephone-2.png"> <?= $GeneralData['contact_phone'] ?>
                </span>
                <span class="contact-details"><img src="{ASSET_FRONT_URL}images/icons/email-1.png"> <?= $GeneralData['contact_email'] ?>
                </span>
            </div>
        </div>
        <div class="social-icons">
           <?php if($GeneralData['link1']) {?> <span><a href="<?= $GeneralData['link1'] ?>"><img src="{ASSET_FRONT_URL}images/icons/facebook-app-symbol.png"></a></span><?php }?>
            <?php if($GeneralData['link2']) {?>  <span><a href="<?= $GeneralData['link2'] ?>"><img src="{ASSET_FRONT_URL}images/icons/youtube-logotype.png"></a></span><?php }?>
           <!-- <span><a href="<?= $GeneralData['link3'] ?>"><img src="{ASSET_FRONT_URL}images/icons/instagram.png"></a></span>-->
             <?php if($GeneralData['link4']) {?> <span><a href="<?= $GeneralData['link4'] ?>"><img src="{ASSET_FRONT_URL}images/icons/twitter.png"></a></span><?php }?>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <p class="copyright">Copyright © <?php echo date('Y'); ?> Mini Hotel Man Business Solutions (OPC) Pvt.Ltd | All Rights Reserved</a>
            </div>
        </div>
    </div>
</footer>
<!-- <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#alertMessageModal">Open Modal</button> -->
<div id="alertMessageModal" class="modal" role="dialog" style="display: none; margin-top: 174.333px;">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-body">
                <div class=" msg_pop alert alert-dismissible pop-up alert-success" role="alert">Loading...</div>
            </div>
        </div>
    </div>
</div>
<script>
    <?php if ($this->session->flashdata('alert_warning')) : ?>
        alertMessageModelPopup('<?php echo $this->session->flashdata('alert_warning'); ?>', 'Warning');
    <?php elseif ($this->session->flashdata('alert_error')) : ?>
        alertMessageModelPopup('<?php echo $this->session->flashdata('alert_error'); ?>', 'Error');
    <?php elseif ($this->session->flashdata('alert_success')) : ?>
        alertMessageModelPopup('<?php echo $this->session->flashdata('alert_success'); ?>', 'Success');
    <?php endif; ?>
    ///////////         ALERT MESSAGE MODEL         ///////////////////
    function alertMessageModelPopup(message, type, timeout) {
        var wheight = (($(window).height() / 3) - 50);
        $("#alertMessageModal").modal('show');
        $("#alertMessageModal").css('margin-top', wheight);
        $("#alertMessageModal .modal-body div").removeClass('alert-success').removeClass('alert-warning').removeClass('alert-danger');
        if (type == 'Success') {
            $("#alertMessageModal .modal-body div").addClass('alert-success').html('<i class="fa fa-check-circle"></i> ' + message);
        } else if (type == 'Warning') {
            $("#alertMessageModal .modal-body div").addClass('alert-warning').html('<i class="fa fa-info-circle"></i> ' + message);
        } else if (type == 'Error') {
            $("#alertMessageModal .modal-body div").addClass('alert-danger').html('<i class="fa fa-times-circle"></i> ' + message);
        }
        if (timeout != 'NO') {
            setTimeout(AlertMessageModelPopupTimedOut, 5000);
        }
    }
    function AlertMessageModelPopupTimedOut() {
        $("#alertMessageModal").modal('hide');
    }
</script>