<script src="{ASSET_FRONT_URL}js/jquery.validate.js"></script>
<script src="{ASSET_FRONT_URL}js/ashish.js"></script>
<!-- Plugin JS File -->
<script src="{ASSET_FRONT_URL}vendor/jquery.plugin/jquery.plugin.min.js"></script>
<script src="{ASSET_FRONT_URL}vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
<script src="{ASSET_FRONT_URL}vendor/zoom/jquery.zoom.js"></script>
<script src="{ASSET_FRONT_URL}vendor/jquery.countdown/jquery.countdown.min.js"></script>
<script src="{ASSET_FRONT_URL}vendor/magnific-popup/jquery.magnific-popup.min.js"></script>
<script src="{ASSET_FRONT_URL}vendor/photoswipe/photoswipe.js"></script>
<script src="{ASSET_FRONT_URL}vendor/photoswipe/photoswipe-ui-default.js"></script>
<script src="{ASSET_FRONT_URL}vendor/skrollr/skrollr.min.js"></script>
<!-- Swiper JS -->
<script src="{ASSET_FRONT_URL}vendor/swiper/swiper-bundle.min.js"></script>
<script>
    var swiper = new Swiper(".mySwiper", {
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        pagination: {
            el: ".swiper-pagination",
            clickable: true,
        },
        navigation: {
            nextEl: ".swiper-button-next",
            prevEl: ".swiper-button-prev",
        },
    });
</script>
<!-- End of Footer -->
<!-- Start of Mobile Menu -->
<div class="mobile-menu-wrapper">
    <div class="mobile-menu-overlay"></div>
    <!-- End of .mobile-menu-overlay -->
    <a href="#" class="mobile-menu-close"><i class="close-icon"></i></a>
    <!-- End of .mobile-menu-close -->
    <div class="mobile-menu-container scrollable">
        <form action="#" method="get" class="input-wrapper">
            <input type="text" class="form-control" name="search" autocomplete="off" placeholder="Search" required />
            <button class="btn btn-search" type="submit">
                <i class="w-icon-search"></i>
            </button>
        </form>
        <!-- End of Search Form -->
        <div>
            <ul class="mobile-menu">
                <li><a href="<?php echo base_url(); ?>">Home</a></li>
                <li>
                    <a href="#!">Main Category</a>
                    <ul>
                        <li><a href="#!">Sub Catgory</a></li>
                        <li><a href="#!">Sub Catgory</a></li>
                        <li><a href="#!">Sub Catgory</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#!">Main Category</a>
                    <ul>
                        <li><a href="#!">Sub Catgory</a></li>
                        <li><a href="#!">Sub Catgory</a></li>
                        <li><a href="#!">Sub Catgory</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#!">Main Category</a>
                    <ul>
                        <li><a href="#!">Sub Catgory</a></li>
                        <li><a href="#!">Sub Catgory</a></li>
                        <li><a href="#!">Sub Catgory</a></li>
                    </ul>
                </li>
                <li>
                    <a href="#!">Main Category</a>
                    <ul>
                        <li><a href="#!">Sub Catgory</a></li>
                        <li><a href="#!">Sub Catgory</a></li>
                        <li><a href="#!">Sub Catgory</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</div>
<!-- End of Mobile Menu -->
<!-- Start of Scroll Top -->
<a id="scroll-top" class="scroll-top" href="#top" title="Top" role="button">
    <i class="w-icon-angle-up"></i>
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 70 70">
        <circle id="progress-indicator" fill="transparent" stroke="#000000" stroke-miterlimit="10" cx="35" cy="35" r="34" style="stroke-dasharray: 16.4198, 400;"></circle>
    </svg> </a>
</div>
<!-- End of Page-wrapper-->
