<!DOCTYPE html>
<html lang="ar">
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <title>Mini Hotel Man Customer Invoice</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <style>
    @media print {
      @page {
        margin: 0px;
        size: 80mm 200mm;
      }      
    }
  </style>
</head>
<body onload="window.print();" >
  <div class="container-fluid">
    <div id='printContainer'>
      <?php
      if(!empty(sessionData('MHM_REST_IMAGE'))){
        echo '<p class="text-center"><img src="'.sessionData('MHM_REST_IMAGE').'" style="width: 100px;"></p>';
      }
      ?>
      <h2 id="slogan" class="text-center"><?=ucfirst($Restaurant['rest_name'])?></h2>
      <p class="text-center">
        <?php
        if($Restaurant['unit_of']){
          echo 'A Unit of '.$Restaurant['unit_of'].'<br/>';
        }
        ?>
        <?=ucfirst($VENDORDETAIL['vendor_address'])?><br>
        Phone - <?=$VENDORDATA['first_manager_contact_number']?><br/>
        <?php 
        if($Restaurant['gstin'] && $gst_type == 'with_gst'){
          echo 'GSTIN - '.$Restaurant['gstin'].'<br/>';
        }
        ?>
        <hr>
        Name - <b><?=$CUSTDATA['customer_name']?></b>
      </p>
      <hr>
      <table width="100%">
        <tr>
          <td>Date - </td>
          <td><?=date('d/m/Y H:i',strtotime($FoodData[0]['creation_date']))?></td>
        </tr>
        <tr>
          <td>KOT No.- </td>
          <td><?=$FoodData[0]['kot_number']?></td>
          <td>Bill No.- </td>
          <td><?=$CUSTDATA['bill_number']?></td>
        </tr>
      </table>
      <hr>
      <table width="100%">
        <tr>
          <td>Item</td>
          <td>QTY</td>
          <td>Price</td>
          <td>Amount</td>
        </tr>
        <tr><td colspan="4"><hr></td></tr>
        <?php
        $Total = 0;
        //echo "<pre>"; print_r($FoodData); exit;
        foreach ($FoodData as $menu) {
          if($gst_type == 'with_gst'){
            $Total += $menu['advance_paid'];
          }
          else{
            $Total += $menu['menu_price'];
          }
          
          ?>
          <tr>
            <td><?=ucfirst($menu['bill_item'])?></td>
            <td style="text-align: center;"><?=$menu['quantity']?></td>
            <td style="text-align: center;"><?=($menu['menu_price']/$menu['quantity'])?></td>
            <td style="text-align: center;"><?=$menu['menu_price']*$menu['quantity']?></td>
          </tr>
        <?php
        }
        if($gst_type=='with_gst'){
          if($CheckGSTType=='gst_exclusive'){
            $totalAmnt  = round($Total * 5) / 100;
            //$TotalAmt  = $Total - $totalAmnt;
            $TotalAmt  = $Total;
            $cgst  = $totalAmnt / 2;
            $sgst  = $totalAmnt / 2;
            $GrandTotal  = $Total + $totalAmnt;
          }else{
            $TotalAmt  = $Total/1.05;
            $totalAmnt  = ($TotalAmt * 5) / 100;
            $cgst  = $totalAmnt / 2;
            $sgst  = $totalAmnt / 2;
            $GrandTotal  = $Total;
          }
        }else{
          $TotalAmt  = $Total;
          $GrandTotal  = $Total;
        }
        ?>  
        <tr><td colspan="4"><hr></td></tr>
        <tr>
          <td colspan="4" style="text-align: right;">
            <?php
            if($gst_type=='with_gst'){
              echo 'TOTAL: '.number_format($TotalAmt,2).'<br/>';
              echo 'CGST (2.5%): '.number_format($cgst,2).'<br/>';
              echo 'SGST (2.5%): '.number_format($sgst,2).'<br/>';
            }
            echo '<b>GRAND TOTAL: '.number_format($GrandTotal,2).'</b>';
            ?>
          </td>
        </tr>
      </table>
      <hr>
      <p class="text-center">
        <?php
        if($Restaurant['fssai_number']){
          echo 'FSSAI NO. - '.$Restaurant['fssai_number'].'<br/>';
        }
        ?>
        THANK YOU FOR YOUR VISIT
      </p>
      <hr>
    </div>

    <br/><br/><br/><br/>
    <div id='printContainer'>
      <div id='printContainer'>
        <p class="text-center">
          <?=date('d/m/Y H:i',strtotime($FoodData[0]['creation_date']))?><br/>
          KOT No.- <?=$FoodData[0]['kot_number']?> <br/>
          Room No.- <?=$RoomNo['room_no']?>
        </p>
        <hr>
        <table width="100%">
          <tr>
            <td>Item</td>
            <td>Qty</td>
          </tr>
          <tr><td colspan="2"><hr></td></tr>
          <?php
          foreach ($FoodData as $menu) {
            ?>
            <tr>
              <td><b><?=ucfirst($menu['bill_item'])?></b></td>
              <td style="text-align: center;"><?=$menu['quantity']?></td>
            </tr>
          <?php
          }
          ?>  
        </table>
      </div>
    </div>
  </div>
</body>
</html>