<?php
if($print_type=='A4'){
	require_once(APPPATH."views/restaurant/food/A4Print.php");
}else{
	require_once(APPPATH."views/restaurant/food/POSPrint.php");
}
?>
