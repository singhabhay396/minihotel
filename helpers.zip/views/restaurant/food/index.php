<style>
  .panel-body .btn-group .btn.dropdown-toggle{background: none;border: 0px;  }
  .panel-body .btn-group {color: #fff;position: absolute;right: 61px;font-size: 19px;top: 5px;background: none;}
  .panel-body .btn-group i.fa.fa-bars {font-size: 15px;}
  @keyframes gradient {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
  }
  .card.card-even {/ border: 1px solid #efefef; /padding: 15px;text-align: center;background-color: #3f51b5;height: 50px;overflow: hidden;margin-bottom: 20px;display: flex;flex-direction: row;justify-content: center;}
  .bread-time {color: #323232;font-size: 20px;font-weight: 700;letter-spacing: 0.4px;position: absolute;right: 12%;top: 16%;}
  .card.card-even h5{font-size: 14px !important;}
</style>

<div class="main">
  <div class="bready">
    <div class="row">
      <div class="col-md-2">
        <ol class="breadcrumb">
          <li><a href="dashboard" class="active"><i class="lnr lnr-home"></i>Dashboard</a></li>
        </ol>
      </div>
    </div>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel">
          <div class="panel-body row">
            <fieldset>
              <legend>Food Category</legend>
              <div class="row">
                <div class="col-md-4">
                  <input type="text" name="menu_name" onkeyup="SearchMenu()" id="menu_name" placeholder="Search Menu Name" class="form-control">
                </div>
                <div class="col-md-1">
                  <a href="javascript:void(0)" onclick="SearchMenu()" class="btn btn-default add_btn">Search</a>
                </div>
              </div>
              <br/>
              <?php
              if($CategoryArr){
              foreach ($CategoryArr as $Result) {
              ?>
                <div class="col-md-2 col-sm-3 col-xs-6">
                  <div class="card card-even" style="background-color: #0047AB;">
                    <div class="card-content bg-3"> 
                      <a href="javascript:void(0)" onclick="GetFoodMenuLists('<?=$Result['id']?>')" title="<?=$Result['category_name']?>">
                        <div class="media align-items-stretch">
                          <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><?=$Result['category_name']?></strong></h5>
                          </div>
                        </div>
                      </a> 
                    </div>
                  </div>
                </div> 
              <?php  
              }
              }
              ?>
            </fieldset>
          </div>
          <div class="panel-body row" id="FoodMenuList"></div>
          <div class="panel-body row" id="FoodMenuCart"></div>
        </div>
      </div>
    </div>
  </div>
</div>


<form action="<?=base_url('restaurant/food/SaveKOT')?>" method="get" class="modal fade" id="currentPageForm" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align: center;">Settle Table</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
        <input type="hidden" name="customer_id" id="customer_id" value="">
        <input type="hidden" name="TotalAmount" id="TotalAmount" value="">
        <input type="hidden" name="GrandAmount" id="GrandAmount" value="">
        <input type="hidden" name="GSTAmt" id="GSTAmt" value="">
        <input type="hidden" name="cgst" id="cgst" value="">
        <input type="hidden" name="sgst" id="sgst" value="">
        
        <div class="row" id="PostItToRoom">
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Settle Type</label>
              <select name="settle_type" required id="settle_type" onchange="SettleType()" class="form-control">
                <option value="Post_it_to_room" selected>Post it to room</option>
                <option value="Settle_on_the_spot">Settle on the spot</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">GST Type</label>
              <select name="gst_type" required id="gst_type" onchange="GSTType()" class="form-control">
                <option value="gst_exclusive" selected>GST Exclusive</option>
                <option value="gst_inclusive">GST Inclusive</option>
              </select>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <center style="color: red; font-size: 20px;"><strong>Total Amount :- <i class="fa fa-inr"></i> <span id="TotalAmt"></span></strong></center>
          </div>
        </div>
        <div class="row" id="SettleInSpot" style="display: none;">
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Amount Mode</label>
              <select name="amount_mode1" id="amount_mode1" class="form-control">
                <option value="offline">Offline (Cash)</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Payment Paid </label>
              <input type="text" name="payment_paid1" id="payment_paid1" onkeyup="PaymentPaid()" class="form-control numberonly" placeholder="Payment Paid">
              <a href="javascript:void(0)" onclick="FullPaid(1)">Paid in full</a> 
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Amount Mode </label>
              <select name="amount_mode2" id="amount_mode2" class="form-control">
                <option value="online">Online (Bank transfer, UPI, Paytm, Gpay, PhonePe)</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Payment Paid </label>
              <input type="text" name="payment_paid2" id="payment_paid2" onkeyup="PaymentPaid()" class="form-control numberonly" placeholder="Payment Paid">
              <a href="javascript:void(0)" onclick="FullPaid(2)">Paid in full</a> 
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Discount</label>
              <input type="text" name="discount" id="discount" readonly required class="form-control numberonly" placeholder="Discount">
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <span class="btn btn-primary btn-lg btn-block">Note:-
              <strong>
                <span style="color:#FF0000;">*</span> Indicates Required Fields
              </strong>
            </span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" style="padding: 6px 12px;">Close</button>
        <button type="submit" class="btn btn-primary" style="padding: 6px 12px;">Submit</button>
      </div>
    </div>
  </div>
</form>

<script type="text/javascript">
function SettleType() {
  var type = $('#settle_type').val();
  if(type!=''){
    if(type=='Post_it_to_room'){
      $('#SettleInSpot').hide();
    }else{
      $('#SettleInSpot').show();
    }
  }else{ 
    $('#SettleInSpot').hide();
  }
} 
function GSTType(){
  var gst_type = $('#gst_type').val();
  var GSTAmt = parseInt($('#GSTAmt').val());
  var TotalAmount = parseInt($('#TotalAmount').val());
  if(gst_type=='gst_exclusive'){
    var GrandAmount = TotalAmount+GSTAmt;
    $('#TotalAmt').html(GrandAmount);
  }else{
    var GrandAmount = TotalAmount;
    $('#TotalAmt').html(TotalAmount);
  }
  $('#GrandAmount').val(GrandAmount);
  $('#payment_paid1').val('');
  $('#payment_paid2').val('');
  $('#discount').val('');
}
function AddATableModal(customer_id,TotalAmount,GSTAmt,cgst,sgst) {
  $('#customer_id').val(customer_id);
  $('#discount').val(TotalAmount);
  $('#TotalAmount').val(TotalAmount);
  $('#GSTAmt').val(GSTAmt);
  $('#cgst').val(cgst);
  $('#sgst').val(sgst);
  GSTType();
  $('#currentPageForm').modal("show");
}
function PaymentPaid(){
  var GrandAmount = $('#GrandAmount').val();
  var amt2 = $('#payment_paid2').val();
  var amt1 = $('#payment_paid1').val();
  if(amt1==''){ var amt1 = 0 }
  if(amt2==''){ var amt2 = 0 }
  var total = parseInt(amt2) + parseInt(amt1);
  var discount = parseInt(GrandAmount) - parseInt(total);
  $('#discount').val(discount);
}
function FullPaid(id){
  var GrandAmount = $('#GrandAmount').val();
  $('#discount').val('0');
  if(id==2){
    $('#payment_paid2').val(GrandAmount);
    $('#payment_paid1').val('');
  }else{
    $('#payment_paid1').val(GrandAmount);
    $('#payment_paid2').val('');
  }
}
  
$(function() { 
  GetFoodMenuCart();
});
function SearchMenu(){
  var menu_name = $('#menu_name').val();
  $("#FoodMenuList").html('<fieldset><legend>Food Menu</legend><div class="col-md-12"><center>Loading..</center></div></fieldset>');
  $.ajax({
    url : "<?=base_url('restaurant/food/FoodMenuList')?>",
    type: "GET",
    data : {menu_id:0,menu_name:menu_name},
    success:function(a){
      $("#FoodMenuList").html(a);
    }
  });
}
function GetFoodMenuLists(menu_id){
  $("#FoodMenuList").html('<fieldset><legend>Food Menu</legend><div class="col-md-12"><center>Loading..</center></div></fieldset>');
  $.ajax({
    url : "<?=base_url('restaurant/food/FoodMenuList')?>",
    type: "GET",
    data : {menu_id:menu_id},
    success:function(a){
      $("#FoodMenuList").html(a);
    }
  });
}
function AddToCardMenu(menu_id){
  $.ajax({
    url : "<?=base_url('restaurant/food/AddToCardMenu')?>",
    type: "GET",
    data : {menu_id:menu_id,customer_id:'<?=$CustomerData['id']?>'},
    success:function(a){
      GetFoodMenuCart();
    }
  });
}
function DeleteItem(id){
  if (confirm('Are You Sure You Want To Delete This?')) {
    $.ajax({
      url : "<?=base_url('restaurant/food/DeleteItem')?>",
      type: "GET",
      data : {id:id},
      success:function(a){
        GetFoodMenuCart();
      }
    });  
  }
}

function GetFoodMenuCart(){
  $("#FoodMenuCart").html('<fieldset><legend>Menu Cart</legend><div class="col-md-12"><center>Loading..</center></div></fieldset>');
  $.ajax({
    url : "<?=base_url('restaurant/food/FoodMenuCart')?>",
    type: "GET",
    data : {customer_id:'<?=$CustomerData['id']?>'},
    success:function(a){
      $("#FoodMenuCart").html(a);
    }
  });
}
function increaseqty(id){
  var qty = $("#qty_"+id).val();
  var qty = Number(qty) + Number(1); // 5  
  $("#qty_"+id).val(qty);
  $.post("<?=base_url('restaurant/food/FoodUpdateAddToCart')?>", {qty:qty,id:id}, function(data){
    GetFoodMenuCart();
  });
}
function descreaseqty(id){
  var cqty = $("#qty_"+id).val();
  var qty = Number(cqty) - Number(1); // 5
  if(qty > 0){
    $("#qty_"+id).val(qty);
    $.post("<?=base_url('restaurant/food/FoodUpdateAddToCart')?>", {qty:qty,id:id}, function(data){
      GetFoodMenuCart();
    });
  }else{
    $("#qty_"+id).val(cqty);
  }
}
</script>