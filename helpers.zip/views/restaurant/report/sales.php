<link rel="stylesheet" href="//code.jquery.com/ui/1.12.0/themes/base/jquery-ui.css">
<script src="{ASSET_VENDOR_URL}js/bootstrap-datepicker.js"></script>
<script>
  $(function() {
    $("#searchDate").datepicker({
      dateFormat: 'dd-mm-yy',
      changeMonth: true,
      changeYear: true,
      maxDate: 0,
      yearRange: "1960:<?php echo date('Y'); ?>"
    });
  });
</script>

<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-file-text-o"></i>Total Sale</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <hr class="differ">
        <form id="Data_Form" name="Data_Form" method="get" action="" autocomplete="off">
          <div class="row">
            <div class="col-md-6 col-sm-6 col-xs-6 search">
              <label>Show
              <select name="showLength" id="showLength" class="form-control input-sm">
                <option value="All" <?php if ($perpage == 'All') echo 'selected="selected"'; ?>>All</option>
              </select>entries
              </label>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2 search-ryt">
              <select class="form-control" name="sale_type">
                <option value="All" <?php if($sale_type=='All'){echo 'selected';} ?>>All</option>
                <option value="Table" <?php if($sale_type=='Table'){echo 'selected';} ?>>Table</option>
                <option value="Room" <?php if($sale_type=='Room'){echo 'selected';} ?>>Room</option>
              </select>
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2 search-ryt">
              <input type="text" name="searchDate" id="searchDate" value="<?php if ($searchDate <> "") : echo date('m/d/Y', strtotime($searchDate)); endif; ?>" class="form-control input-smt" placeholder="Search By Date">
            </div>
            <div class="col-md-2 col-sm-2 col-xs-2 search-ryt">
              <input type="submit" class="btn btn-default add_btn" style="float: left;" value="Search">
            </div>
          </div>
          <div class="dash">
            <table class="table table-bordered">
              <thead>
                <tr>
                  <th width="5%">Sr. No.</th>
                  <th>Room/Table Number</th>
                  <th>KOT Number</th>
                  <th width="25%">Bill Items</th>
                  <th width="25%">Total Bill</th>
                  <th width="25%">Mode of Payment</th>
                  <th width="10%">Order Date and Time</th>
                </tr>
              </thead>
              <tbody>
                <?php 
                $i = 1;
                foreach ($RoomResultArr as $row) {
                  $ItemData = $this->common_model->GetSaleCustomerItemData($row['kot_number'],$hotel_manager_id);
                ?>
                  <tr class="gradeX">
                    <td><?= $i++ ?></td>
                    <td><?= stripslashes($row['room_no']) ?></td>
                    <td><?= stripslashes($row['kot_number']) ?></td>
                    <td>
                      <?php
                      foreach ($ItemData as $Item) {
                        echo $Item['bill_item'].' ('.$Item['quantity'].')<br/>';
                      }
                      ?> 
                    </td>
                    <td><i class="fa fa-inr"></i><?= stripslashes($row['total_amt']) ?></td>
                    <td>
                      <?php
                      if($row['amount_mode']=='offline'){
                        echo 'Offline (Cash)';
                      }else{
                        echo 'Online';
                      }
                      ?>
                    </td>
                    <td><?= date('d-m-Y h:i A', strtotime($row['creation_date'])) ?></td>
                  </tr>
                <?php
                }
                //echo '<pre>';print_r($TableResultArr);die();
                foreach ($TableResultArr as $row) :
                  $ItemData = $this->common_model->GetSaleTableItemData($row['kot_no'],$hotel_manager_id);
                  ?>
                  <tr class="gradeX">
                    <td><?= $i++ ?></td>
                    <td><?= $row['table_name'] ?></td>
                    <td><?= $row['kot_no'] ?></td>
                    <td>
                      <?php
                      foreach ($ItemData as $Item) {
                        echo $Item['menu_name'].' ('.$Item['qty'].')<br/>';
                      }
                      ?> 
                    </td>
                    <td><i class="fa fa-inr"></i><?= stripslashes($row['total_amt']) ?></td>
                    <td></td>
                    <td><?= date('d-m-Y h:i A', strtotime($row['add_date'])) ?></td>
                  </tr>
                <?php endforeach;?>
              </tbody>
            </table>
            <div class="pagi row">
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-txt"><?php echo $noOfContent; ?></div>
              <div class="col-md-6 col-sm-6 col-xs-6 pagi-bar">
                <?= $PAGINATION ?>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>