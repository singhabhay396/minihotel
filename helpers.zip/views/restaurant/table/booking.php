<style>
  .panel-body .btn-group .btn.dropdown-toggle{background: none;border: 0px;  }
  .panel-body .btn-group {color: #fff;position: absolute;right: 61px;font-size: 19px;top: 5px;background: none;}
  .panel-body .btn-group i.fa.fa-bars {font-size: 15px;}
  @keyframes gradient {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
  }
  .card.card-even {/ border: 1px solid #efefef; /padding: 15px;text-align: center;background-color: #3f51b5;height: 50px;overflow: hidden;margin-bottom: 20px;display: flex;flex-direction: row;justify-content: center;}
  .bread-time {color: #323232;font-size: 20px;font-weight: 700;letter-spacing: 0.4px;position: absolute;right: 12%;top: 16%;}
  .card.card-even h5{font-size: 14px !important;}
</style>

<div class="main">
  <div class="bready">
    <div class="row">
      <div class="col-md-2">
        <ol class="breadcrumb">
          <li><a href="dashboard" class="active"><i class="lnr lnr-home"></i>Dashboard</a></li>
        </ol>
      </div>
    </div>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel">
          <div class="panel-body row">
            <fieldset>
              <legend>Food Category</legend>
              <div class="row">
                <div class="col-md-4">
                  <input type="text" name="menu_name" onkeyup="SearchMenu()" id="menu_name" placeholder="Search Menu Name" class="form-control">
                </div>
                <div class="col-md-1">
                  <a href="javascript:void(0)" onclick="SearchMenu()" class="btn btn-default add_btn">Search</a>
                </div>
              </div>
              <br/>
              <?php
              if($CategoryArr){
              foreach ($CategoryArr as $Result) {
              ?>
                <div class="col-md-2 col-sm-3 col-xs-6">
                  <div class="card card-even" style="background-color: #0047AB;">
                    <div class="card-content bg-3"> 
                      <a href="javascript:void(0)" onclick="GetFoodMenuLists('<?=$Result['id']?>')" title="<?=$Result['category_name']?>">
                        <div class="media align-items-stretch">
                          <div class="p-2 bg-gradient-x-primary white media-body">
                            <h5 style="text-transform: capitalize;"><strong><?=$Result['category_name']?></strong></h5>
                          </div>
                        </div>
                      </a> 
                    </div>
                  </div>
                </div> 
              <?php  
              }
              }
              ?>
            </fieldset>
          </div>
          <div class="panel-body row" id="FoodMenuList"></div>
          <div class="panel-body row" id="FoodMenuCart"></div>
        </div>
      </div>
    </div>
  </div>
</div>

<script type="text/javascript">
$(function() { 
  GetFoodMenuCart();
});
function SearchMenu(){
  var menu_name = $('#menu_name').val();
  $("#FoodMenuList").html('<fieldset><legend>Food Menu</legend><div class="col-md-12"><center>Loading..</center></div></fieldset>');
  $.ajax({
    url : "<?=base_url('restaurant/food/FoodMenuList')?>",
    type: "GET",
    data : {menu_id:0,menu_name:menu_name},
    success:function(a){
      $("#FoodMenuList").html(a);
    }
  });
}
function GetFoodMenuLists(menu_id){
  $("#FoodMenuList").html('<fieldset><legend>Food Menu</legend><div class="col-md-12"><center>Loading..</center></div></fieldset>');
  $.ajax({
    url : "<?=base_url('restaurant/food/FoodMenuList')?>",
    type: "GET",
    data : {menu_id:menu_id},
    success:function(a){
      $("#FoodMenuList").html(a);
    }
  });
}
function AddToCardMenu(menu_id){
  $.ajax({
    url : "<?=base_url('restaurant/table/AddToCardMenu')?>",
    type: "GET",
    data : {menu_id:menu_id,table_id:'<?=$table_id?>'},
    success:function(a){
      GetFoodMenuCart();
    }
  });
}
function DeleteItem(id){
  if (confirm('Are You Sure You Want To Delete This?')) {
    $.ajax({
      url : "<?=base_url('restaurant/table/DeleteItem')?>",
      type: "GET",
      data : {id:id},
      success:function(a){
        GetFoodMenuCart();
      }
    });  
  }
}

function GetFoodMenuCart(){
  $("#FoodMenuCart").html('<fieldset><legend>Menu Cart</legend><div class="col-md-12"><center>Loading..</center></div></fieldset>');
  $.ajax({
    url : "<?=base_url('restaurant/table/FoodMenuCart')?>",
    type: "GET",
    data : {table_id:'<?=$table_id?>'},
    success:function(a){
      $("#FoodMenuCart").html(a);
    }
  });
}
function increaseqty(id){
  var qty = $("#qty_"+id).val();
  var qty = Number(qty) + Number(1); // 5  
  $("#qty_"+id).val(qty);
  $.post("<?=base_url('restaurant/table/FoodUpdateAddToCart')?>", {qty:qty,id:id}, function(data){
    GetFoodMenuCart();
  });
}
function descreaseqty(id){
  var cqty = $("#qty_"+id).val();
  var qty = Number(cqty) - Number(1); // 5
  if(qty > 0){
    $("#qty_"+id).val(qty);
    $.post("<?=base_url('restaurant/table/FoodUpdateAddToCart')?>", {qty:qty,id:id}, function(data){
      GetFoodMenuCart();
    });
  }else{
    $("#qty_"+id).val(cqty);
  }
}
</script>