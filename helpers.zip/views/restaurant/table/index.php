<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="dashboard"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-hotel"></i>Table List</a></li>
    </ol>
  </div>
  <div class="main-content" id="addEditSection" style="display:none;">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Table</h3>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="form-group <?php if (form_error('table_name')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Table Name<span class="required">*</span></label>
                    <input type="text" name="table_name" id="table_name" value="<?php if (set_value('table_name')) : echo set_value('table_name'); else : echo stripslashes($EDITDATA['table_name']); endif; ?>" class="form-control required" placeholder="Table Name">
                    <?php if (form_error('table_name')) : ?>
                      <p for="table_name" generated="true" class="error"><?php echo form_error('table_name'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="form-group">
                    <label class="fancy-checkbox form-headings">Sort<span class="required">*</span></label>
                    <input type="number" min="0" name="sort" id="sort" value="<?php if (set_value('sort')) : echo set_value('sort'); else : echo stripslashes($EDITDATA['sort']); endif; ?>" class="form-control required" placeholder="Sort">
                  </div>
                </div>
              </div>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="javascript:void(0);" class="btn btn-primary btn-lg form-btn" id="cancelAddEditSection">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note :- <strong><span style="color:#FF0000;">*</span> Indicates Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Table List</h3>
          <a href="javascript:void(0);" class="btn btn-default add_btn" id="openAddEditSection">Add Table</a>
        </div>
        <hr class="differ">
        <form id="Data_Form" name="Data_Form" method="get" action="<?php echo $forAction; ?>" autocomplete="off">
          <div class="dash">
            <table class="table table-bordered">
              <thead>
                <tr>
                <th width="10%">Sr. No.</th>
                  <th>Table Name</th>
                  <th>Sort</th>
                  <th width="10%" class="center">Edit</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($ALLDATA <> "") : $i = 1;
                  foreach ($ALLDATA as $ALLDATAINFO) : ?>
                    <tr>
                      <td><?= $i++ ?></td>
                      <td><?= stripslashes($ALLDATAINFO['table_name']) ?></td>
                      <td><?= stripslashes($ALLDATAINFO['sort']) ?></td>
                      <td class="center">
                        <a href="<?=base_url('restaurant/table/index?editid='.$ALLDATAINFO['id'])?>"> Edit Details</a>
                      </td>
                    </tr>
                  <?php endforeach;
                else : ?>
                  <tr>
                    <td colspan="5" style="text-align:center;">No Data Available In Table</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
  var prevSerchValue = '<?php echo $searchValue; ?>';
</script>
<script type="text/javascript">
  $(function() {
    <?php if ($formError == 'Yes') : ?>
      $('#addEditSection').slideDown();
    <?php elseif ($editid) : ?>
      $('#addEditSection').slideDown();
    <?php endif; ?>
  });
  $(document).on('click', '#openAddEditSection', function() {
    $('#addEditSection').slideDown();
  });
  <?php if ($editid) : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      window.location.href = '<?=base_url('restaurant/table')?>';
    });
  <?php else : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      $('#addEditSection').slideUp();
    });
  <?php endif; ?>
</script>