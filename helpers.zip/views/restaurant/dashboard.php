<style>
  .panel-body .btn-group .btn.dropdown-toggle{background: none;border: 0px;  }
  .panel-body .btn-group {color: #fff;position: absolute;right: 61px;font-size: 19px;top: 5px;background: none;}
  .panel-body .btn-group i.fa.fa-bars {font-size: 15px;}
  .panel.panel-headline .btn-group {position: absolute;right: 50px;top: 20px;}
  .panel.panel-headline button.btn.dropdown-toggle {background: #fff;border: none;color: #000;}
  @keyframes gradient {
    0% {background-position: 0% 50%;}
    50% {background-position: 100% 50%;}
    100% {background-position: 0% 50%;}
  }
  .card.card-even {/ border: 1px solid #efefef; /padding: 15px;text-align: center;background-color: #3f51b5;border-radius: 100px;height: 150px;overflow: hidden;margin-bottom: 20px;display: flex;flex-direction: row;justify-content: center;align-items: baseline;}
  .bread-time {color: #323232;font-size: 20px;font-weight: 700;letter-spacing: 0.4px;position: absolute;right: 12%;top: 16%;}
  .panel-heading {padding: 8px 115px;border-bottom: 1px solid transparent;border-top-left-radius: 3px;margin: 0px 0px;text-align: center;border-top-right-radius: 3px;display: flex;justify-content: center;}
  .panel-heading .add_btn {margin: auto;text-align: center;padding: 6px 10px !important;}
  .mydiv {width:100%;height:100%;color:black;font-weight:bold;animation: myanimation 10s infinite;}
</style>

<div class="main">
  <div class="bready">
    <div class="row">
      <div class="col-md-2">
        <ol class="breadcrumb">
          <li><a href="dashboard" class="active"><i class="lnr lnr-home"></i>Dashboard</a></li>
        </ol>
      </div>
    </div>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="panel-title tab"> CheckIn Customer</h3>
        </div>
        <hr class="differ">
        <div class="row">  
          <?php
          if($CheckInData){
          foreach ($CheckInData as $Result) {
          ?>
            <div class="col-md-2 col-sm-3 col-xs-6">
              <div class="card card-even" style="background-color: #0047AB;">
                <div class="card-content bg-3"> 
                  <a href="food/service/<?= $Result['encrypt_id'] ?>" title="<?=$Result['customer_name']?>">
                    <div class="media align-items-stretch"> 
                      <div class="p-2 bg-gradient-x-primary white media-body">
                        <h5 style="text-transform: capitalize;"><strong><?=$Result['room_no']?></strong></h5>
                        <h4 style="text-transform: capitalize; color: #fff; font-size: 18px;">  <?=$Result['customer_name']?> </h4>
                      </div>
                    </div>
                  </a> 
                </div>
              </div>
            </div> 
          <?php  
          }
          }
          ?>
        </div>
      </div>
    </div>
  </div>
  <?php if(!empty($restInfo)){ ?>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="panel-title tab"> Table</h3>
        </div>
        <hr class="differ">
        <div class="row">  
          <?php
          if($TableArr){
            foreach ($TableArr as $Table) {
              $KOTQuery = "SELECT id FROM ".getTablePrefix()."hotel_menu_cart WHERE table_id='".$Table['id']."' ";
              $CountKOT = $this->common_model->getDataByQuery('count', $KOTQuery);
              $colorCode = '#0047AB';
              $Amount = '';
              if($CountKOT>0){
                $colorCode = '#f4e23d';
                $TotalAmount = $this->common_model->GetTableTotalAmt($Table['id'],$hotel_manager_id);
                $Amount = '<h4 style="text-transform: capitalize; color: #fff; font-size: 18px;"><i class="fa fa-inr"></i> '.$TotalAmount.'</h4>';
              }
            ?>
              <div class="col-md-2 col-sm-3 col-xs-6">
                <?php
                if($CountKOT>0){
                  $GSTAmt   = round($TotalAmount * 5) / 100;
                  $cgst     = $GSTAmt / 2;
                  $sgst     = $GSTAmt / 2;
                ?>
                <div class="btn-group">
                  <button class="btn dropdown-toggle" data-toggle="dropdown" aria-expanded="false"><i class="fa fa-bars" aria-hidden="true"></i></button>
                  <ul class="dropdown-menu">
                    <li><a href="javascript:void(0)" onClick="AddATableModal('<?=base64_encode($Table['id'])?>','<?=$TotalAmount?>','<?=$GSTAmt?>','<?=$cgst?>','<?=$sgst?>')"> Settle KOT</a></li> 
                  </ul>
                </div>
                <?php
                }
                ?>
                <div class="card card-even" style="background-color: <?=$colorCode?>;">
                  <div class="card-content bg-3"> 
                    <a href="<?=base_url('restaurant/table/booking/'.base64_encode($Table['id']))?>" title="<?=$Table['table_name']?>">
                      <div class="media align-items-stretch"> 
                        <div class="p-2 bg-gradient-x-primary white media-body">
                          <h5 style="text-transform: capitalize; font-size:70px"><strong><?=$Table['table_name']?></strong></h5>
                          <?=$Amount?>   
                        </div>
                      </div>
                    </a> 
                  </div>
                </div>
              </div> 
            <?php  
            }
          } 
          ?>
        </div>
      </div>
    </div>
  </div>
<?php } ?>
</div>


<form action="<?=base_url('restaurant/table/SaveKOT')?>" method="get" class="modal fade" id="currentPageForm" tabindex="-1" role="dialog" aria-labelledby="basicModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" style="text-align: center;">Settle Table</h4>
      </div>
      <div class="modal-body">
        <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
        <input type="hidden" name="table_id" id="table_id" value="">
        <input type="hidden" name="TotalAmount" id="TotalAmount" value="">
        <input type="hidden" name="GrandAmount" id="GrandAmount" value="">
        <input type="hidden" name="GSTAmt" id="GSTAmt" value="">
        <input type="hidden" name="cgst" id="cgst" value="">
        <input type="hidden" name="sgst" id="sgst" value="">
        
        <div class="row">
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">GST Type</label>
              <select name="gst_type" required id="gst_type" onchange="GSTType()" class="form-control">
                <option value="gst_exclusive" selected>GST Exclusive</option>
                <option value="gst_inclusive">GST Inclusive</option>
              </select>
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <center style="color: red; font-size: 20px;"><strong>Total Amount :- <i class="fa fa-inr"></i> <span id="TotalAmt"></span></strong></center>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Amount Mode</label>
              <select name="amount_mode1" id="amount_mode1" class="form-control">
                <option value="offline">Offline (Cash)</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Payment Paid </label>
              <input type="text" name="payment_paid1" id="payment_paid1" onkeyup="PaymentPaid()" class="form-control numberonly" placeholder="Payment Paid">
              <a href="javascript:void(0)" onclick="FullPaid(1)">Paid in full</a> 
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Amount Mode </label>
              <select name="amount_mode2" id="amount_mode2" class="form-control">
                <option value="online">Online (Bank transfer, UPI, Paytm, Gpay, PhonePe)</option>
              </select>
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Payment Paid </label>
              <input type="text" name="payment_paid2" id="payment_paid2" onkeyup="PaymentPaid()" class="form-control numberonly" placeholder="Payment Paid">
              <a href="javascript:void(0)" onclick="FullPaid(2)">Paid in full</a> 
            </div>
          </div>
          <div class="col-md-6 col-sm-12 col-xs-12">
            <div class="form-group ">
              <label class="fancy-checkbox form-headings">Discount</label>
              <input type="text" name="discount" id="discount" readonly required class="form-control numberonly" placeholder="Discount">
            </div>
          </div>
          <div class="col-md-12 col-sm-12 col-xs-12">
            <span class="btn btn-primary btn-lg btn-block">Note:-
              <strong>
                <span style="color:#FF0000;">*</span> Indicates Required Fields
              </strong>
            </span>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal" style="padding: 6px 12px;">Close</button>
        <button type="submit" class="btn btn-primary" style="padding: 6px 12px;">Submit</button>
      </div>
    </div>
  </div>
</form>


<script type="text/javascript">
function GSTType(){
  var gst_type = $('#gst_type').val();
  var GSTAmt = parseInt($('#GSTAmt').val());
  var TotalAmount = parseInt($('#TotalAmount').val());
  if(gst_type=='gst_exclusive'){
    var GrandAmount = TotalAmount+GSTAmt;
    $('#TotalAmt').html(GrandAmount);
  }else{
    var GrandAmount = TotalAmount;
    $('#TotalAmt').html(TotalAmount);
  }
  $('#GrandAmount').val(GrandAmount);
  $('#payment_paid1').val('');
  $('#payment_paid2').val('');
  $('#discount').val('');
}
function AddATableModal(table_id,TotalAmount,GSTAmt,cgst,sgst) {
  $('#table_id').val(table_id);
  $('#discount').val(TotalAmount);
  $('#TotalAmount').val(TotalAmount);
  $('#GSTAmt').val(GSTAmt);
  $('#cgst').val(cgst);
  $('#sgst').val(sgst);
  GSTType();
  $('#currentPageForm').modal("show");
}

function PaymentPaid(){
  var GrandAmount = $('#GrandAmount').val();
  var amt2 = $('#payment_paid2').val();
  var amt1 = $('#payment_paid1').val();
  if(amt1==''){ var amt1 = 0 }
  if(amt2==''){ var amt2 = 0 }
  var total = parseInt(amt2) + parseInt(amt1);
  var discount = parseInt(GrandAmount) - parseInt(total);
  $('#discount').val(discount);
}
function FullPaid(id){
  var GrandAmount = $('#GrandAmount').val();
  $('#discount').val('0');
  if(id==2){
    $('#payment_paid2').val(GrandAmount);
    $('#payment_paid1').val('');
  }else{
    $('#payment_paid1').val(GrandAmount);
    $('#payment_paid2').val('');
  }
}
</script>