<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('restaurant/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-hotel"></i>Menu Category</a></li>
    </ol>
  </div>
  <div class="main-content" id="addEditSection" style="display:none;">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Menu Category</h3>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-6 col-sm-6 col-xs-6">
                  <div class="form-group <?php if (form_error('category_name')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Category Name<span class="required">*</span></label>
                    <input type="text" name="category_name" id="category_name" value="<?php if (set_value('category_name')) : echo set_value('category_name'); else : echo stripslashes($EDITDATA['category_name']); endif; ?>" class="form-control required" placeholder="Category Name">
                    <?php if (form_error('category_name')) : ?>
                      <p for="category_name" generated="true" class="error"><?php echo form_error('category_name'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="javascript:void(0);" class="btn btn-primary btn-lg form-btn" id="cancelAddEditSection">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note :- <strong><span style="color:#FF0000;">*</span> Indicates Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Menu Category</h3>
          <a href="javascript:void(0);" class="btn btn-default add_btn" id="openAddEditSection">Add Menu Category</a>
        </div>
        <hr class="differ">
        <form id="Data_Form" name="Data_Form" method="get" action="<?php echo $forAction; ?>" autocomplete="off">
          <div class="dash">
            <table class="table table-bordered">
              <thead>
                <tr>
                <th width="10%">Sr. No.</th>
                  <th>Hotel Room Category</th>
                  <th width="20%" class="center">More Options</th>
                </tr>
              </thead>
              <tbody>
                <?php if ($ALLDATA <> "") : $i = 1;
                  foreach ($ALLDATA as $ALLDATAINFO) : ?>
                    <tr class="<?php if ($i % 2 == 0) : echo 'odd';
                                else : echo 'even';
                                endif; ?> gradeX">
                      <td><?= $i++ ?></td>
                      <td><?= stripslashes($ALLDATAINFO['category_name']) ?></td>
                      <td class="center">
                        <a href="<?=base_url('restaurant/menu/menucategory?editid='.$ALLDATAINFO['id'])?>"><i class="fa fa-edit"></i> Edit Details</a>
                      </td>
                    </tr>
                  <?php endforeach;
                else : ?>
                  <tr>
                    <td colspan="5" style="text-align:center;">No Data Available In Table</td>
                  </tr>
                <?php endif; ?>
              </tbody>
            </table>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>
<script>
  var prevSerchValue = '<?php echo $searchValue; ?>';
</script>
<script type="text/javascript">
  $(function() {
    <?php if ($formError == 'Yes') : ?>
      $('#addEditSection').slideDown();
    <?php elseif ($editid) : ?>
      $('#addEditSection').slideDown();
    <?php endif; ?>
  });
  $(document).on('click', '#openAddEditSection', function() {
    $('#addEditSection').slideDown();
  });
  <?php if ($editid) : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      window.location.href = '<?=base_url('restaurant/menu/menucategory')?>';
    });
  <?php else : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      $('#addEditSection').slideUp();
    });
  <?php endif; ?>
</script>