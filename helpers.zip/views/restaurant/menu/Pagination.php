<?php 
if ($ALLDATA != "") : $i = 1;
  foreach ($ALLDATA as $key=>$ALLDATAINFO) :
    $CategoryName = $ALLDATAINFO['category_name'] ?? 'N/A'; 
  ?>
    <tr class="gradeX">
      <td><?=$key+1?></td>
      <td><?=$CategoryName?></td>
      <td><?=ucfirst($ALLDATAINFO['menu_name'])?></td>
      <td><?=$ALLDATAINFO['price']?></td>
      <td><?=showStatus($ALLDATAINFO['status'])?></td>
      <td class="center">
        <div class="btn-group">
          <button class="btn dropdown-toggle" data-toggle="dropdown">More Options <span class="caret"></span></button>
          <ul class="dropdown-menu">
            <li><a href="<?=base_url('restaurant/menu/index?editid='.$ALLDATAINFO['menu_id'])?>"><i class="fa fa-edit"></i> Edit Details</a></li>
            <li class="divider"></li>
            <?php if ($ALLDATAINFO['status'] == 'Y') : ?>
              <li><a href="<?=base_url('restaurant/menu/changeStatus/'.$ALLDATAINFO['menu_id'].'/N')?>"><i class="fa fa-hand-o-up"></i> Inactive</a></li>
            <?php elseif ($ALLDATAINFO['status'] == 'N') : ?>
              <li><a href="<?=base_url('restaurant/menu/changeStatus/'.$ALLDATAINFO['menu_id'].'/Y')?>"><i class="fa fa-hand-o-up"></i> Active</a></li>
            <?php endif; ?>
              <li class="divider"></li>
              <li><a href="<?=base_url('restaurant/menu/deleteData/'.$ALLDATAINFO['menu_id'])?>" onclick="return confirm('Are You Sure You Want To Delete This?');"><i class="fa fa-trash"></i> Delete</a></li>
            
          </ul>
        </div>
      </td>
    </tr>
    <?php  
  endforeach;
  echo '<tr><td colspan="10" style="text-align:center;">'.$PAGINATION.'</td></tr>';
else : ?>
  <tr>
    <td colspan="10" style="text-align:center;">No Data Available In Table</td>
  </tr>
<?php endif; ?>