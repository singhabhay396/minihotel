<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="<?=base_url('restaurant/dashboard')?>"><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-hotel"></i>Menus</a></li>
    </ol>
  </div>
  <div class="main-content" id="addEditSection" style="display:none;">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab"><?= $EDITDATA ? 'Edit' : 'Add' ?> Menu</h3>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?= $EDITDATA['menu_id'] ?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                <div class="col-md-4 col-sm-6 col-xs-6">
                  <div class="form-group">
                    <label class="fancy-checkbox form-headings">Menu Category</label>
                    <select id="category_id" name="category_id" class="form-control">
                      <option value="0">Select</option>
                      <?php
                      foreach ($CategoryArr as $cat) {
                        $selected = '';
                        if($EDITDATA['category_id']==$cat['id']){
                          $selected = 'selected';
                        }
                        echo '<option '.$selected.' value="'.$cat['id'].'">'.$cat['category_name'].'</option>';
                      }
                      ?>
                    </select>
                  </div>
                </div>

                <div class="col-md-4 col-sm-6 col-xs-6">
                  <div class="form-group <?php if (form_error('menu_name')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Menu Name<span class="required">*</span></label>
                    <input type="text" name="menu_name" id="menu_name" value="<?php if (set_value('menu_name')) : echo set_value('menu_name');
                                                                                              else : echo stripslashes($EDITDATA['menu_name']);
                                                                                              endif; ?>" class="form-control required" placeholder="Menu Name">
                    <?php if (form_error('menu_name')) : ?>
                      <p for="menu_name" generated="true" class="error"><?php echo form_error('menu_name'); ?></p>
                    <?php endif; if($menuError):  ?>
                      <span for="menu_name" generated="true" class="help-inline"><?php echo $menuError; ?></span>
                    <?php endif; ?>
                  </div>
                </div>
                <div class="col-md-4 col-sm-6 col-xs-6">
                  <div class="form-group <?php if (form_error('menu_price')) : ?>error<?php endif; ?>">
                    <label class="fancy-checkbox form-headings">Price<span class="required">*</span></label>
                    <input type="text" name="menu_price" id="menu_price" value="<?php if (set_value('menu_price')) : echo set_value('menu_price');
                                                                                              else : echo stripslashes($EDITDATA['price']);
                                                                                              endif; ?>" class="form-control required" placeholder="Price">
                    <?php if (form_error('menu_price')) : ?>
                      <p for="menu_price" generated="true" class="error"><?php echo form_error('menu_price'); ?></p>
                    <?php endif; ?>
                  </div>
                </div>
              </div>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="javascript:void(0);" class="btn btn-primary btn-lg form-btn" id="cancelAddEditSection">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note
                  :- <strong><span style="color:#FF0000;">*</span> Indicates
                    Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline">
        <div class="panel-heading row">
          <h3 class="tab panel-title">Menus</h3>
          <a href="javascript:void(0);" class="btn btn-default add_btn" id="openAddEditSection">Add Menu</a>
          <?php /* if($ALLDATA <> ""): ?>
            <a href="{VENDOR_SITE_URL}{CURRENT_CLASS}/manageorder" class="btn btn-default add_btn" style="margin-right:10px;">Manage Hotel Room order</a>
          <?php endif; */ ?>
          <a href="<?=base_url('restaurant/menu/menucategory')?>" class="btn btn-default add_btn" style="margin-right:10px;">Menu Category </a>
        </div>
        <hr class="differ">
        <div class="row">
          <div class="col-md-6 col-sm-6 col-xs-6 search">
            <label>Show
              <select onchange="Search()" name="numofrecords" id="numofrecords" class="form-control input-sm">
                <option value="10" selected>10</option>
                <option value="25">25</option>
                <option value="50">50</option>
                <option value="100">100</option>
                <option value="All">All</option>
              </select>
              entries
            </label>
          </div>
        </div>
        <div class="dash">
          <table class="table table-bordered">
            <thead>
              <tr>
              <th width="10%">Sr. No.</th>
                <th>Category Name</th>
                <th width="20%">Menu</th>
                <th width="20%">Price</th>
                <th width="20%">Status</th>
                <th width="10%" class="center">More Options</th>
              </tr>
            </thead>
            <thead>
              <tr>
                <th>#</th>
                <th>
                  <select id="search_category_id" onchange="Search()" class="form-control">
                    <option value="All">All</option>
                    <?php
                    foreach ($CategoryArr as $key => $cat) {
                      echo '<option value="'.$cat['id'].'">'.$cat['category_name'].'</option>';
                    }                    ?>
                  </select>
                </th>
                <th><input type="text" id="search_menu_name" class="form-control"></th>
                <th><input type="text" id="search_price" class="form-control"></th>
                <th>
                  <select id="search_status" onchange="Search()" class="form-control">
                    <option value="All">All</option>
                    <option value="Y">Active</option>
                    <option value="N">De-Active</option>
                  </select>
                </th>
                <th>
                  <button type="button" onclick="Search()" class="btn btn-primary btn-lg">
                    <i class="fa fa-search"></i>
                  </button>
                </th>
              </tr>
            </thead>
            <tbody id="Result"></tbody>
          </table>
        </div>
      </div>
    </div>
  </div>
</div>
<script>
  var prevSerchValue = '<?php echo $searchValue; ?>';
</script>
<script type="text/javascript">
  $(function() { 
    loadData(1);
  });
  function Search(){
    loadData(1);
  }
  function Pagination(page){
    loadData(page);
  }
  function loadData(page){
    $("#Result").html('<tr><td colspan="10"><center>Loading..</center></td></tr>');
    var category_id  = $("#search_category_id").val();
    var menu_name  = $("#search_menu_name").val();
    var price  = $("#search_price").val();
    var status  = $("#search_status").val();
    var numofrecords  = $("#numofrecords").val();
    $.ajax({
      url : "<?=base_url('restaurant/menu/Pagination')?>",
      type: "GET",
      data : {category_id:category_id,menu_name:menu_name,price:price,status:status,numofrecords:numofrecords,page:page},
      success:function(a){
        $("#Result").html(a);
      }
    });   
  }  

  $(function() {
    <?php if ($formError == 'Yes') : ?>
      $('#addEditSection').slideDown();
    <?php elseif ($editid) : ?>
      $('#addEditSection').slideDown();
    <?php endif; ?>
  });
  $(document).on('click', '#openAddEditSection', function() {
    $('#addEditSection').slideDown();
  });
  <?php if ($editid) : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      window.location.href = '<?php echo $cancellink; ?>';
    });
  <?php else : ?>
    $(document).on('click', '#cancelAddEditSection', function() {
      $('#addEditSection').slideUp();
    });
  <?php endif; ?>
</script>