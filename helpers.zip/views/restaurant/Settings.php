<div class="main">
  <div class="bready">
    <ol class="breadcrumb">
      <li><a href="dashboard" class=""><i class="lnr lnr-home"></i>Dashboard</a></li>
      <li><a href="javascript:void(0);" class="active"><i class="fa fa-edit"></i>Edit Profile Details</a></li>
    </ol>
  </div>
  <div class="main-content">
    <div class="container-fluid">
      <div class="panel panel-headline inr-form">
        <div class="panel-heading row">
          <h3 class="panel-title tab">Edit Profile Details</h3>
          <a href="{VENDOR_SITE_URL}profile" class="btn btn-default add_btn">Back</a>
        </div>
        <hr class="differ">
        <div class="panel">
          <div class="panel-body row">
            <form id="currentPageForm" name="currentPageForm" class="form-auth-small" method="post" action="">
              <input type="hidden" name="CurrentIdForUnique" id="CurrentIdForUnique" value="<?=$EDITDATA['id']?>" />
              <input type="hidden" name="CurrentDataID" id="CurrentDataID" value="<?=$EDITDATA['vendor_id']?>" />
              <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">
              <fieldset>
                <legend>Personal Details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox">Name of Restaurant<span class="required">*</span></label>
                      <input type="text" name="rest_name" id="rest_name" value="<?php echo stripslashes($EDITDATA['rest_name']);?>" class="form-control required" placeholder="Name of Restaurant">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox">Phone<span class="required">*</span></label>
                      <input type="tel" min="0" name="rest_phone" id="rest_phone" value="<?php echo stripslashes($EDITDATA['rest_phone']);?>" class="form-control required" placeholder="Phone">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox">Email<span class="required">*</span></label>
                      <input type="email" readonly value="<?php echo stripslashes($EDITDATA['rest_email']);?>" class="form-control" placeholder="Email">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox">FSSAI Number</label>
                      <input type="text" name="fssai_number" id="fssai_number" value="<?php echo stripslashes($EDITDATA['fssai_number']);?>" class="form-control" placeholder="FSSAI Number">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group"> 
                      <label class="fancy-checkbox">A Unit of </label>
                      <input type="text" name="unit_of" id="unit_of" value="<?php echo stripslashes($EDITDATA['unit_of']);?>" class="form-control" placeholder="A Unit of">
                    </div>
                  </div>

                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Image</label>
                      <?php $logo = stripslashes($EDITDATA['logo']);?>
                      <img border="0" alt="" src="{ASSET_ADMIN_URL}images/browse-white.png" id="firstImageUpload" class="img-responsive" style="cursor:pointer;">
                      <input type="etxt" name="logo" id="firstAvtar" value="<?php echo $logo; ?>" class="form-control" style="border:none;width:0px;height:0px;margin-top: -14px;" />
                      <span id="firstAvtarImageDiv" style="margin-top:5px;">
                        <?php if ($logo): ?>
                          <img border="0" alt="" src="<?php echo $logo; ?>" class="img-responsive">&nbsp;
                          <a class="spancross" onclick="firstImageDelete('<?php echo $logo; ?>');" href="javascript:void(0);"> <img border="0" alt="" src="{ASSET_ADMIN_URL}images/cross.png"></a>
                        <?php endif;?>
                      </span>
                    </div>
                  </div>
                </div>
              </fieldset>

              <fieldset>
                <legend>Address Details</legend>
                <div class="col-md-12 col-sm-12 col-xs-12 form-space">
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Address<span class="required">*</span></label>
                      <input type="text" name="address" id="address" value="<?php echo stripslashes($EDITDATA['address']);?>" class="form-control required" placeholder="Address">
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-4 col-xs-4">
                    <div class="form-group">
                      <label class="fancy-checkbox">GSTIN<span class="required">*</span></label>
                      <input type="text" name="gstin" id="gstin" value="<?php echo stripslashes($EDITDATA['gstin']);?>" class="form-control required" placeholder="GSTIN">
                    </div>
                  </div>
                  <div class="col-md-8 col-sm-8 col-xs-8">
                    <div class="form-group">
                      <label class="fancy-checkbox form-headings">Extra Remarks</label>
                      <textarea name="remarks" id="remarks" class="form-control" cols="40" rows="5"><?=stripslashes($EDITDATA['remarks'])?></textarea>
                    </div>
                  </div>
                </div>
              </fieldset>
              <input type="hidden" name="SaveChanges" id="SaveChanges" value="Submit">
              <button type="submit" class="btn btn-primary btn-lg form-btn">Submit</button>
              <a href="<?=base_url('restaurant/dashboard/settings')?>" class="btn btn-primary btn-lg form-btn">Cancel</a>
              <span class="tools pull-right"> <span class="btn btn-primary btn-lg btn-block">Note:- <strong><span style="color:#FF0000;">*</span> Indicates Required Fields</strong> </span>
              </span>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>