<section class="accoutbase">
	<div class="container">
	  	<div class="col-md-12 col-sm-12 col-xs-12 whitebadse">
		    <section class="terms-use">
		        <div class="col-md-12 col-sm-12 col-xs-12">
		          	<div class="heading_terms">
		            	<h2><?php echo stripslashes($CMSDATA['title']); ?></h2>
		          	</div>
		          	<?php echo stripslashes($CMSDATA['content']); ?>
		        </div>
		    </section>
	  	</div>
	</div>
</section>