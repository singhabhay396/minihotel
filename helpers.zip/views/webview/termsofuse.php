<section class="accoutbase">
    <div class="container">
      	<div class="col-md-12 col-sm-12 col-xs-12 whitebadse">
        	<section class="terms-use">
            	<?php echo stripslashes($CMSDATA['content']); ?>
        	</section>
      	</div>
    </div>
</section>