<section class="accoutbase">
    <div class="container">
      	<div class="col-md-12 col-sm-12 col-xs-12 whitebadse">
	        <section class="terms-use about row">
		        <div class="col-md-12 col-sm-12 col-xs-12">
		            <h2><?php echo stripslashes($CMSDATA['title']); ?></h2>
		            <?php echo stripslashes($CMSDATA['content']); ?>
		         </div>
	        </section>
      	</div>
    </div>
</section>