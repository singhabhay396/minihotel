<!-- Start of Top Content Section -->
<?php if ($HeadingData <> "") : ?>
    <main class="main bottom-header-bg">
        <div class="container-fluid">
            <div class="row">
                <div class="bottom-header-content">
                    <h1><?= $HeadingData['title'] ?></h1>
                    <h3><?= $HeadingData['sub_title'] ?></h3>
                    <p><?= $HeadingData['content'] ?></p>
                </div>
            </div>
        </div>
    </main>
<?php endif; ?>
<!-- END of Top Content Section -->
<!-- Start of Slider Section -->
<section class="main-section">
    <div class="swiper mySwiper">
        <div class="swiper-wrapper">
            <?php if (!empty($SliderData)) : foreach ($SliderData as $slider) : ?>
                    <div class="swiper-slide"><img src="<?= $slider['slider_image'] ?>">
                        <div class="slider-content">
                            <h3><?= $slider['sub_title'] ?></h3>
                            <h1><?= $slider['title'] ?></h1>
                            <p><?= $slider['content'] ?></p>
                        </div>
                    </div>
            <?php endforeach;
            endif; ?>
        </div>
        <div class="swiper-button-next"></div>
        <div class="swiper-button-prev"></div>
        <div class="swiper-pagination"></div>
    </div>
</section>
<!-- End of Slider Section -->
<!-- Testimonial Section START --><?php if (!empty($TestimonialData)): ?>
<section class="testimonial-main">
    <div class="container">
        <div class="row">
            <div id="testim" class="testim">
                <div class="testim-cover" style="background-image:url({ASSET_FRONT_URL}images/testimonial.jpg);">
                    <div class="wrap ">
                        <span id="right-arrow" class="arrow right fa fa-chevron-right"></span>
                        <span id="left-arrow" class="arrow left fa fa-chevron-left "></span>
                        <ul id="testim-dots" class="dots">
                            <?php if (!empty($TestimonialData)) : foreach ($TestimonialData as $TData) : ?>
                                    <li class="dot"></li>
                            <?php endforeach;
                            endif; ?>
                        </ul>
                        <div id="testim-content" class="cont">
                            <?php if (!empty($TestimonialData)) : foreach ($TestimonialData as $TData) : ?>
                                    <div>
                                        <div class="img"><img src="<?php echo $TData['image']; ?>" alt=""></div>
                                        <h2><?php echo $TData['name']; ?></h2>
                                        <p><?php echo stripslashes($TData['content']); ?></p>
                                    </div>
                            <?php endforeach;
                            endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section><?php endif; ?>

<!-- Testimonial Section END -->


<!-- Video Section START -->
<?php if ($HeadingData <> "") : ?>
    <section class="video-section" style="background-image: url({ASSET_FRONT_URL}images/video-bg.jpg);">
        <div class="container">
            <div class="row">
                <div class="video-pad">
                    <iframe width="100%" height="400" src="<?= $HeadingData['video_url'] ?>" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
            </div>
        </div>
    </section>
<?php endif; ?>
<!-- Video Section END -->
<!-- Icon with text Section START -->

<section>
    <div class="container" id="features">
        <div class="row">
            <div class="features-section">
                <h2>Features</h2>
            </div>
            <div class="row">
                <?php if (!empty($FeaturesData)) : foreach ($FeaturesData as $Fdata) : ?>
                        <div class="col-md-2 perticular-featured-box">
                            <div class="feature-icon-set">
                                <img src="<?php echo $Fdata['image']; ?>">
                                <p><?php echo $Fdata['title']; ?></p>
                            </div>
                        </div>
                <?php endforeach;
                endif; ?>
            </div>
        </div>
    </div>
</section>
<!-- Icon with text Section END -->
<!-- Contact Form Section START -->
<section style="background-image: url({ASSET_FRONT_URL}images/Mask-group.jpg);">
    <div class="container padd-form" id="contact">
        <div class="row contact-bg">
            <div class="text-center">
                <h3>Contact Us</h3>
            </div>
            <?php
            if ($this->session->flashdata('alert_success')) {
                echo "<div class='alert alert-primary'>" . $this->session->flashdata('alert_success') . "</div>";
                $this->session->unset_userdata('alert_success');
            }
            ?>
            <div class="contact-form">
                <form name="currentPageForm" id="currentPageForm" method="post" action="" autocomplete="off">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="formGroupExampleInput"></label>
                                <input type="text" class="form-control" id="formGroupExampleInput" name="first_name" placeholder="First Name" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="formGroupExampleInput2"></label>
                                <input type="text" class="form-control" id="formGroupExampleInput2" name="last_name" placeholder="Last Name" >
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="formGroupExampleInput3"></label>
                                <input type="email" class="form-control" id="formGroupExampleInput3" name="email" placeholder="Your Email Address" required>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="formGroupExampleInput2"></label>
                                <input type="text" class="form-control" id="formGroupExampleInput2" name="subject" placeholder="Your Subject">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group">
                                <textarea class="form-control2" placeholder="Your Message" id="exampleFormControlTextarea1" name="description" rows="3"></textarea>
                            </div>
                        </div>
                        <button type="submit" name="currentPageFormSubmit" id="currentPageFormSubmit" class="btn btn-warning submit-btn">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<!-- Contact Form Section END -->

<!-- About Us Section START -->
<?= stripslashes($AboutUsData['content']) ?>



<!-- Main JS -->
<!-- WebFont.js -->
<!-- About Us Section END -->

<script>
    WebFontConfig = {
        google: {
            families: ['Poppins:400,500,600,700,800']
        }
    };
    (function(d) {
        var wf = d.createElement('script'),
            s = d.scripts[0];
        wf.src = '{ASSET_FRONT_URL}js/webfont.js';
        wf.async = true;
        s.parentNode.insertBefore(wf, s);
    })(document);
</script>
<!-- Initialize Swiper -->

<script>
    'use strict'
    var testim = document.getElementById("testim"),
        testimDots = Array.prototype.slice.call(document.getElementById("testim-dots").children),
        testimContent = Array.prototype.slice.call(document.getElementById("testim-content").children),
        testimLeftArrow = document.getElementById("left-arrow"),
        testimRightArrow = document.getElementById("right-arrow"),
        testimSpeed = 4500,
        currentSlide = 0,
        currentActive = 0,
        testimTimer,
        touchStartPos,
        touchEndPos,
        touchPosDiff,
        ignoreTouch = 30;;

    window.onload = function() {

        // Testim Script
        function playSlide(slide) {
            for (var k = 0; k < testimDots.length; k++) {
                testimContent[k].classList.remove("active");
                testimContent[k].classList.remove("inactive");
                testimDots[k].classList.remove("active");
            }

            if (slide < 0) {
                slide = currentSlide = testimContent.length - 1;
            }

            if (slide > testimContent.length - 1) {
                slide = currentSlide = 0;
            }

            if (currentActive != currentSlide) {
                testimContent[currentActive].classList.add("inactive");
            }
            testimContent[slide].classList.add("active");
            testimDots[slide].classList.add("active");

            currentActive = currentSlide;

            clearTimeout(testimTimer);
            testimTimer = setTimeout(function() {
                playSlide(currentSlide += 1);
            }, testimSpeed)
        }

        testimLeftArrow.addEventListener("click", function() {
            playSlide(currentSlide -= 1);
        })

        testimRightArrow.addEventListener("click", function() {
            playSlide(currentSlide += 1);
        })

        for (var l = 0; l < testimDots.length; l++) {
            testimDots[l].addEventListener("click", function() {
                playSlide(currentSlide = testimDots.indexOf(this));
            })
        }

        playSlide(currentSlide);
        // keyboard shortcuts
        document.addEventListener("keyup", function(e) {
            switch (e.keyCode) {
                case 37:
                    testimLeftArrow.click();
                    break;

                case 39:
                    testimRightArrow.click();
                    break;

                case 39:
                    testimRightArrow.click();
                    break;

                default:
                    break;
            }
        })
        testim.addEventListener("touchstart", function(e) {
            touchStartPos = e.changedTouches[0].clientX;
        })
        testim.addEventListener("touchend", function(e) {
            touchEndPos = e.changedTouches[0].clientX;
            touchPosDiff = touchStartPos - touchEndPos;
            if (touchPosDiff > 0 + ignoreTouch) {
                testimLeftArrow.click();
            } else if (touchPosDiff < 0 - ignoreTouch) {
                testimRightArrow.click();
            } else {
                return;
            }

        })
    }
</script>

<script>
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();

            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
</script>