<style>
    .background-black {
        padding: 55px;
        background-color: #00000085;
    }
    .form-border {
        border: 2px solid #a3a2a2;
        padding: 40px;
    }

    form.form-label label {
        color: #fff;
    }

    .form-row-padd {
        padding-bottom: 37px;
    }
    .input-style input {
        background-color: #fff;
        border-radius: 5px;
    }
    .form-submit {
        text-align: center;
        padding-top: 50px;
    }
</style>
<section class="section-padding signup-form-bg" style="background-image: url({ASSET_FRONT_URL}images/video-bg.jpg);">
    <div class="container background-black">
        <div class="row">
            <div class="form-border">
            <form name="currentPageForm" id="currentPageForm" action="" method="post" autocomplete="off" style="color:#e3e3e3">
                    <div class="row form-row-padd">
                        <div class="col-md-6 input-style">
                            <label>Phone</label>
                            <input type="text" class="form-control required" name="vendor_phone" value='<?php echo sessionData('USER_REGISTER_PHONE'); ?>' placeholder="Phone" readonly>
                            <?php if(form_error('vendor_phone')): ?>
                                    <p><?php echo form_error('vendor_phone'); ?></p>
                                <?php endif; if($vendorphone):  ?>
                                    <p><?php echo $vendorphone; ?></p>
                                <?php endif; ?>
                                </div>
                        <div class="col-md-6 input-style">
                            <label>OTP</label>
                            <input type="text" class="form-control required" name="vendor_otp" value='' placeholder="OTP" maxlength="4">
                            <?php if(form_error('vendor_otp')): ?>
                                    <p style="color: red !impotant;"><?php echo form_error('vendor_otp'); ?></p>
                                <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-submit">
                        <input type="Submit" name="currentPageFormSubmit" id="currentPageFormSubmit" class="btn btn-warning" value="Proceed" />

                        <!--<a href="<?php echo $this->session->userdata('MHM_FRONT_CURRENT_PATH').'vendor/login' ?>" class="btn btn-warning">Back to Login</a>-->
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
    $(document).ready(function(){
        <?php if($formError): ?>
            alertMessageModelPopup('<?php echo $formError; ?>','Error');
        <?php endif; ?>
    });
</script>