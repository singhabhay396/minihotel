<style>
    .background-black {
        padding: 55px;
        background-color: #00000085;
    }

    .form-border {
        border: 2px solid #a3a2a2;
        padding: 40px;
    }

    form.form-label label {
        color: #fff;
    }

    .form-row-padd {
        padding-bottom: 37px;
    }

    .input-style input {
        background-color: #fff;
        border-radius: 5px;
    }

    .form-submit {
        text-align: center;
        padding-top: 50px;
    }
</style>
<script src='https://www.google.com/recaptcha/api.js'></script>
<section class="section-padding signup-form-bg" style="background-image: url({ASSET_FRONT_URL}images/video-bg.jpg);">
    <div class="container background-black">
        <div class="row">
            <div class="form-border">
                 <?php
                if($this->session->flashdata('message'))
                {
                ?>
                    <div class="alert alert-danger">
                        <?php
                        echo $this->session->flashdata('message');
                        ?>
                    </div>
                <?php
                }

                if($this->session->flashdata('success_message'))
                {
                ?>
                    <div class="alert alert-success">
                        <?php
                        echo $this->session->flashdata('success_message');
                        ?>
                    </div>
                <?php
                }
                ?>
                <form name="currentPageForm" id="currentPageForm" action="" method="post" autocomplete="off" style="color:#e3e3e3">
                    <div class="row form-row-padd">
                        <div class="col-md-6 input-style">
                            <label>Name of Hotel/Guest house</label>
                            <input type="text" class="form-control" name="vendor_business_name" value='' placeholder="Name of Hotel/Guest house" required>
                        </div>
                        <div class="col-md-6 input-style">
                            <label>Referral code (if any)</label>
                            <input type="text" class="form-control" name="referral_code" value='' placeholder="Referral code">
                        </div>
                    </div>
                    <div class="row form-row-padd">
                        <div class="col-md-6 input-style">
                            <label>Full Address</label>
                            <input type="text" class="form-control" name="vendor_address" value='' placeholder="Full Address" required>
                        </div>
                        <div class="col-md-6 input-style">
                            <label>Primary Contact number (Owner)</label>
                            <input type="tel" class="form-control numberOnly" name="vendor_phone" value='' placeholder="Primary Contact number" required minlength="10" maxlength="12">
                        <?php if (form_error('vendor_phone')) : ?>
                                    <p><?php echo form_error('vendor_phone'); ?></p>
                                <?php endif;?>
                      </div>
                    </div>
                    <div class="row form-row-padd">
                        <div class="col-md-6 input-style">
                            <label>Secondary Contact number (Owner)</label>
                            <input type="tel" class="form-control numberOnly" name="owner_secoundry_contact_number" value='' placeholder="Secondary Contact number" minlength="10" maxlength="12">
                        </div>
                        <!-- <div class="col-md-6 input-style">
                            <label>Number of Rooms (Please fill in the name of all rooms (01,02,201,204 etc))</label>
                            <input type="text" class="form-control" name="" value=''  placeholder="Number of Rooms">
                        </div> -->
                    </div>
                    <div class="row form-row-padd">
                        <div class="col-md-6 input-style">
                            <label>Email</label>
                            <input type="email" class="form-control" name="vendor_email" value='' placeholder="Email" required>
                          <?php if (form_error('vendor_email')) : ?>
                                    <p><?php echo form_error('vendor_email'); ?></p>
                                <?php endif; ?>
                        </div>
                        <div class="col-md-6 input-style">
                            <label>You Are</label><br>
                            <input class="form-check-input" type="radio" name="you_are" id="inlineRadioOwner" value="Owner">
                            <label class="form-check-label" for="inlineRadioOwner">Owner</label><br>
                            <input class="form-check-input" type="radio" name="you_are" id="inlineRadioLessee" value="Lessee">
                            <label class="form-check-label" for="inlineRadioLessee">Lessee</label>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 input-style">
                            <label>Contact number (Manager 1)</label>
                            <input type="tel" class="form-control numberOnly" name="first_manager_contact_number" value='' placeholder="Contact number (Manager 1)" required minlength="10" maxlength="12">
                        </div>
                        <div class="col-md-6 input-style">
                            <label>Contact number (Manager 2) (optional)</label>
                            <input type="tel" class="form-control numberOnly" name="secound_manager_contact_number" value='' placeholder="Contact number (Manager 2)" minlength="10" maxlength="12">
                        </div>
                    </div>
                    
                    <!-- <div class="row">
                        <div class="col-md-6 input-style">
                            <label>Upload Guest House Photo</label>
                            <input type="file" class="form-control" name="guest_house_img" value='' placeholder="Guest House Image" required >
                        </div>
                        <div class="col-md-6 input-style">
                            <label>Delhi Police Licence</label>
                            <input type="tel" class="form-control numberOnly" name="delhi_police_licence" value='' placeholder="Contact number (Manager 2)" minlength="10" maxlength="12">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 input-style">
                            <label>MCD Health Trade License</label>
                            <input type="file" class="form-control" name="mcd_health_trade_license" value='' placeholder="MCD Health Trade License" required >
                        </div>
                        <div class="col-md-6 input-style">
                            <label>GST Certificate</label>
                            <input type="file" class="form-control" name="gst_certificate" value='' placeholder="GST Certificate">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 input-style">
                            <label>Delhi Fire Service NOC/Licence</label>
                            <input type="file" class="form-control" name="delhi_fire_service" value='' placeholder="Delhi Fire Service NOC/Licence" required >
                        </div>
                        <div class="col-md-6 input-style">
                            <label>DPCC Consent</label>
                            <input type="file" class="form-control" name="dpcc_consent" value='' placeholder="DPCC Consent">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 input-style">
                            <label>Upload Aadhar Card of owner</label>
                            <input type="file" class="form-control" name="upload_aadhar_card" value='' placeholder="Upload Aadhar Card of owner" required >
                        </div>
                        <div class="col-md-6 input-style">
                            <label>Upload Pan Card of owner</label>
                            <input type="file" class="form-control" name="upload_pan_card_of_owner" value='' placeholder="Upload Pan Card of owner">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 input-style">
                            <label>GST number</label>
                            <input type="text" class="form-control numberonly" name="gst_number" value='' placeholder="GST number">
                        </div>
                    </div> -->
                    <div class="form-submit">
                        <input type="checkbox" name="accept_policy" id="accept_policy" value='Yes' required>
                        <label>By signing up, you agree to our <a href="<?php echo base_url(); ?>terms-and-condition" target="_blank">terms & conditions</a> and <a href="<?php echo base_url(); ?>privacy-policy" target="_blank">privacy policy</a></label>
                    </div>
                    <div class="form-group">
                        <div class="g-recaptcha" data-sitekey="6LfZO9EpAAAAAIiOmS5_eskGanZ4dL1JsFQeEiqm"></div>
                    </div>
                    <div class="form-submit">
                        <!-- <button type="button" class="btn btn-warning">SUBMIT</button> -->
                        <input type="Submit" name="currentPageFormSubmit" id="currentPageFormSubmit" class="btn btn-warning" value="Sign up" />
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<script type="text/javascript">
grecaptcha.ready(function() {
grecaptcha.execute('<?php echo $site_key; ?>', {action: 'profile'})
.then(function(token) {
console.log(token);
document.getElementById('g-recaptcha-response').value=token;
document.getElementById('action').value='profile';
});
});
</script>
