
<!-- Start of Top Content Section -->
<main class="main bottom-header-bg">
    <div class="container-fluid">
        <div class="row">
            <div class="bottom-header-content">
            <h1><?= strtoupper($TDATA['title']) ?></h1>
            </div>
        </div>
    </div>
</main>

<!-- END of Top Content Section -->

<!-- Start of PRIVACY POLICY Section -->

<section class="section-padding">
    <div class="container">
        <div class="row">
            <div>
                <?= stripslashes($TDATA['content']) ?>
            </div>
        </div>
    </div>
</section>

<!-- End of PRIVACY POLICY Section -->