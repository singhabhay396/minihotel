<!-- Start of Top Content Section -->
<style>
section.pricing-section {
    margin: 40px;
}
    .pricing {
	 display: flex;
	 flex-wrap: wrap;
	 justify-content: center;
}
 .pricing .plan {
	 background-color: #fff;
	 padding: 2.5rem;
	 margin: 12px;
	 border-radius: 5px;
	 text-align: center;
	 transition: 0.3s;
	 cursor: pointer;
	 box-shadow: rgba(100, 100, 111, 0.2) 0px 7px 29px 0px;
}
 .pricing .plan h2 {
	 font-size: 22px;
	 margin-bottom: 12px;
}
 .pricing .plan .price {
	 margin-bottom: 1rem;
	 font-size: 30px;
}
 .pricing .plan ul.features {
	 list-style-type: none;
	 text-align: left;
}
 .pricing .plan ul.features li {
	 margin: 8px;
}
 .pricing .plan ul.features li .fas {
	 margin-right: 4px;
}
 .pricing .plan ul.features li .fa-check-circle {
	 color: #000000;
}
 .pricing .plan ul.features li .fa-times-circle {
	 color: #eb4d4b;
}
 .pricing .plan button {
	 border: none;
	 width: 100%;
	 padding: 12px 35px;
	 margin-top: 1rem;
	 background-color: #370063;
	 color: #fff;
	 border-radius: 5px;
	 cursor: pointer;
	 font-size: 16px;
}
 .pricing .plan.popular {
	 border: 2px solid #6ab04c;
	 position: relative;
	 transform: scale(1.08);
}
 .pricing .plan.popular span {
	 position: absolute;
	 top: -20px;
	 left: 50%;
	 transform: translateX(-50%);
	 background-color: #6ab04c;
	 color: #fff;
	 padding: 4px 20px;
	 font-size: 18px;
	 border-radius: 5px;
}
 .pricing .plan:hover {
	 box-shadow: 5px 7px 67px -28px rgba(0, 0, 0, 0.37);
	 transform: scale(1.02);
    transition-delay: 0s;
}
 .pricing-head{
     text-align:center;
     margin-bottom:60px;
 }
    </style>
<main class="main bottom-header-bg">
<div class="container-fluid">
    <div class="row">
        <div class="bottom-header-content">
            <h1>Pricing</h1>
           </div>
    </div>
</div>
</main>
<!-- END of Top Content Section -->
<!-- Start of PRIVACY POLICY Section -->
<?= stripslashes($TDATA['description']) ?>
<!-- End of PRIVACY POLICY Section -->

<!-- Button trigger modal -->
<!--<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalCenter">-->
<!--  Launch demo modal-->
<!--</button>-->

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle"></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
          <img src="{ASSET_FRONT_URL}images/WITHOUT-TEXT.png">
       <p>Please call our relationship manager at 
+91 8851411589 and he will be happy to serve you.
</p>
      </div>
     
    </div>
  </div>
</div>